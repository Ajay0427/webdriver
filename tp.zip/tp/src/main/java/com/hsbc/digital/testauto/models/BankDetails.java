package com.hsbc.digital.testauto.models;

/**
 * This class holds the values for Bank details details while adding New payee
 * 
 * @author Shweta Jain
 * 
 */
public class BankDetails {


    private String accountNumber;

    private String bankCntry;

    private String bankCity;

    private String accountCCY;

    private String bankName;

    private String bankCode;

    private String bankAddress1;
    private String bankAddress2;
    private String bankAddress3;
    private String bankState;
    private String bankZipCode;
    private String bankZipCodeExtension;

    public String getAccountNumber() {
        return this.accountNumber;
    }

    public void setAccountNumber(final String accountNumber) {
        this.accountNumber = accountNumber;
    }


    public String getBankCntry() {
        return bankCntry;
    }

    public void setBankCntry(String bankCntry) {
        this.bankCntry = bankCntry;
    }


    public String getAccountCCY() {
        return accountCCY;
    }

    public void setAccountCCY(String accountCCY) {
        this.accountCCY = accountCCY;
    }


    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankCity() {
        return bankCity;
    }

    public void setBankCity(String bankCity) {
        this.bankCity = bankCity;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public void setBankState(final String bankState) {
        this.bankState = bankState;
    }

    public String getBankState() {
        return this.bankState;
    }

    public void setBankZipCode(final String bankZipCode) {
        this.bankZipCode = bankZipCode;
    }

    public String getBankZipCode() {
        return bankZipCode;
    }

    public void setBankZipCodeExtension(final String bankZipCodeExtension) {
        this.bankZipCodeExtension = bankZipCodeExtension;
    }

    public String getBankZipCodeExtension() {
        return bankZipCodeExtension;
    }

    public void setBankAddressFields(String address) {
        this.setBankAddress1(address.split("::")[0]);
        this.setBankAddress2(address.split("::")[1]);
        this.setBankAddress3(address.split("::")[2]);
    }

    public String getBankAddress1() {
        return bankAddress1;
    }

    public void setBankAddress1(String bankAddress1) {
        this.bankAddress1 = bankAddress1;
    }

    public String getBankAddress2() {
        return bankAddress2;
    }

    public void setBankAddress2(String bankAddress2) {
        this.bankAddress2 = bankAddress2;
    }

    public String getBankAddress3() {
        return bankAddress3;
    }

    public void setBankAddress3(String bankAddress3) {
        this.bankAddress3 = bankAddress3;
    }


}
