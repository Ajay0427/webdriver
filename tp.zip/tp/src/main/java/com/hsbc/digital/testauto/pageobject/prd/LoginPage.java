/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.prd;


import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.hsbc.digital.testauto.pageobject.LoginModel;


/**
 * <p>
 * <b> Login flow locators and specific implementation for PRD(China) </b>
 * </p>
 */
public class LoginPage extends LoginModel {

    @FindBy(xpath = "//div[@class='dijitReset dijitInputField dijitInputContainer']//input[@id='password']")
    private WebElement passwordField;

    @FindBy(xpath = "//input[@id='secureCode']")
    private WebElement secureCode;

    WebDriver driver;

    public LoginPage(final WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @Override
    public void loginToUserNamePage(final String userName, final String password) {
        waitAndCloseLoginPopUp();
        super.loginToUserNamePage(userName, password);
        passwordField.sendKeys(password);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#viewNo2 input.submit_input")));
        driver.findElement(By.cssSelector("#viewNo2 input.submit_input")).click();
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.LoginModel#waitAndClickSubmit()
     */
    public void waitAndClickSubmit() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("formSubmitButton3")));
        driver.findElement(By.id("formSubmitButton3")).click();
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.LoginModel#loginWithOtp(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
     */
    public void loginWithOtp(final String userName, final String memorableAnswer, final String otpKey, final String serialNumber,
        final String password) {

        waitAndCloseLoginPopUp();
        super.loginToUserNamePage(userName, password);
        String otp = StringUtils.EMPTY;
        try {
            otp = super.tokenGenerator.generateOTP(userName, serialNumber, otpKey);
            super.wait.until(ExpectedConditions.visibilityOf(this.secureCode));
            secureCode.clear();
            secureCode.sendKeys(otp);

        } catch (IOException e) {
            LoginModel.logger.error("Exception thrown LoginModel:loginWithOtp :", e);
        }
    }
}
