package com.hsbc.digital.testauto.pageobject.ca;



import java.text.ParseException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyConfirmPageModel;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

public class MoveMoneyConfirmPage extends MoveMoneyConfirmPageModel {

    // Label Values for M2M fields


    // Query Raised to Confirm Label Values for other MM Functions

    protected static final String LABEL_FROM = "From";
    protected static final String LABEL_TO = "To";
    protected static final String LABEL_PAYEENAME = "Payee name";
    protected static final String LABEL_NOTIFY = "Notify me by";
    protected static final String LABEL_LANG = "Language";
    protected static final String LABEL_SQUES = "Security question";
    protected static final String LABEL_SANS = "Security answer";
    protected static final String LABEL_EMAILADDRESS = "Email address";
    protected static final String LABEL_FEE = "Fee";
    protected static final String LABEL_DATE = "Date";
    protected static final String LABEL_MSGPAYEE = "Message to payee";
    protected static final String LABEL_AMOUNT = "Amount";
		   protected static final String LABEL_START_DATE = "Date of first payment";
		   


    public static final By pageFieldNameconfi = By
        .xpath(".//div[contains(@class,'confirmationPage')]//div[contains(@class,'confirmationDetails ')]");

    public static final By pageFieldValueconfi = By
        .xpath("//following-sibling::div[contains(@class, 'itemLabel') or contains(@class,'confirmTransferValue')]");


    public MoveMoneyConfirmPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }
    @Override
    protected void isStartDateDisplayed(Transaction transaction) {
        try {
            String startDate = DateUtil.getDateToString(DATE_FORMAT, transaction.getFirstDateOfTransaction());
            Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_START_DATE, startDate, UICommonUtil.confirmPage,
                UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Start Date not found.");
            Reporter.log("Start Date displayed is :" + startDate);
        } catch (ParseException e) {
            MoveMoneyCapturePageModel.logger.error(e);
            Assert.fail("Parsing to Payment Date Fail " + e.getMessage(), e);
        }

    }
    @Override
    protected void isFromAccountNameDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_FROM, accountDetail.getAccountName(), UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given From Account Name not found.");
        Reporter.log("From Account Name displayed is :" + accountDetail.getAccountName());
    }

    @Override
    protected void isFromAccountNumberDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_FROM, accountDetail.getAccountNumber(),
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given From Account Number not found.");
        Reporter.log("From Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    @Override
    protected void isToAccountNameDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_TO, accountDetail.getAccountName(), UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Name not found.");
        Reporter.log("To Account Name displayed is :" + accountDetail.getAccountName());
    }

    @Override
    protected void isToAccountNumberDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_TO, accountDetail.getAccountNumber(), UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Number not found.");
        Reporter.log("To Account Number displayed is :" + accountDetail.getAccountNumber());
    }
 

    @Override
    
    protected void isAmountDisplayed(String amount) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_AMOUNT, amount, UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Transfer Amount not found.");
        Reporter.log("Amount displayed is :" + amount);
    }


    @Override
    protected void isPayeeName(final String payeename) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PAYEENAME, payeename, UICommonUtil.confirmPage,
            pageFieldNameconfi, pageFieldValueconfi), "Given Payee Name not found.");
        Reporter.log("payee name is  :" + payeename);


    }


    @Override
    protected void isNotifyMeBy(final String email) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_NOTIFY, email, UICommonUtil.confirmPage, pageFieldNameconfi,
            pageFieldValueconfi), "Given NotifyMeBy not found.");
        Reporter.log("Is Notify Me By name correct" + email);


    }

    @Override
    protected void isLanguage(final String lang) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_LANG, lang, UICommonUtil.confirmPage, pageFieldNameconfi,
            pageFieldValueconfi), "Given Language not found.");
        Reporter.log("lang  name is  :" + lang);


    }

    @Override
    protected void isSecurityQue(final String securityquestion) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_SQUES, securityquestion, UICommonUtil.confirmPage,
            pageFieldNameconfi, pageFieldValueconfi), "Given Security Que not found.");
        Reporter.log("Securityquestion  name is  :" + securityquestion);


    }

    @Override
    protected void isSecurityAns(final String securityanswer) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_SANS, securityanswer, UICommonUtil.confirmPage,
            pageFieldNameconfi, pageFieldValueconfi), "Given Security Ans not found.");
        Reporter.log("Securityanswer  name is  :" + securityanswer);


    }

    @Override
    protected void isEmailAddressSender(final String emailaddresssender) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_EMAILADDRESS, emailaddresssender, UICommonUtil.confirmPage,
            pageFieldNameconfi, pageFieldValueconfi), "Given Email Address Sender not found.");
        Reporter.log("email  name is  :" + emailaddresssender);


    }

    @Override
    protected void isFee(final String fee) {
        Assert.assertTrue(
            uiCommonUtil.textByParentAndSibling(LABEL_FEE, fee, UICommonUtil.confirmPage, pageFieldNameconfi, pageFieldValueconfi),
            "Given Fee not found.");
        Reporter.log("Fee  name is  :" + fee);


    }

    @Override
    protected void isDate(final String date) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_DATE, date, UICommonUtil.confirmPage, pageFieldNameconfi,
            pageFieldValueconfi), "Given Date not found.");
        Reporter.log("Date  name is  :" + date);

    }

    @Override
    protected void isPayeeReferenceTextDisplayed(final String payeeReference) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_EMAILADDRESS, payeeReference, UICommonUtil.confirmPage,
            pageFieldNameconfi, pageFieldValueconfi), "Given Your Reference Text not found.");
        Reporter.log("Your Reference Text displayed is :" + payeeReference);
    }


    @Override
    protected void validateNowFlowIETransfer(final Transaction transactionDetail) {
        isPayeeName(transactionDetail.getToAccount().getPayeeName());
        isNotifyMeBy(transactionDetail.getToAccount().getEmailName());
        isEmailAddressSender(transactionDetail.getToAccount().getEmailAddress());
        isLanguage(transactionDetail.getToAccount().getLang());
        isSecurityQue(transactionDetail.getToAccount().getSecurityQue());
        isSecurityAns(transactionDetail.getToAccount().getSecurityAns());
        isNotifyMeBy(transactionDetail.getToAccount().getNotifyMeBy());
        isEmailAddressSender(transactionDetail.getToAccount().getEmailAddress());
        isFee(transactionDetail.getToAccount().getFee());
        isDate(transactionDetail.getToAccount().getDate());

    }

    
    
    @Override
    public void verifyLCY2LCYNowIETransactionDetailsOnConfirmPage(final Transaction transactionDetail) {
        validateNowFlowIETransfer(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        isPayeeReferenceTextDisplayed(transactionDetail.getPayeeReference());
        Reporter.log("LCY2LCYNow Transaction Details verified on Confirm Page.");
    }

    /**************** Recurring Flow Verification ****************/
    /* RD -  Transaction End date is removed from below methods & amount is replaced with debit amount */
    @Override
    public void verifyM2MLCY2LCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }

    @Override
    public void verifyM2MLCY2FCYRecurringTransactionDetailsOnConfirmPage(final Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2FCYRecurring Transaction Details Verified on Confirm Page");
    }
    
    @Override
    public void verifyM2MFCY2LCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("FCY2LCYRecurring Transaction Details Verified on Confirm Page");
    }
    
    @Override
    public void verifyM2MFCY2FCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("FCY2LFYRecurring Transaction Details Verified on Confirm Page");
    }


}
