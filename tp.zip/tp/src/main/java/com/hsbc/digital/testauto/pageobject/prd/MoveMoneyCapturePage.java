package com.hsbc.digital.testauto.pageobject.prd;

import java.util.Map;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.models.TransactionFrequency;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;

public class MoveMoneyCapturePage extends MoveMoneyCapturePageModel {

    private final WebDriverWait wait;

    protected static final String ENTITY_BANK_COUNTRY = "China";

    @FindBy(xpath = "//div[@data-dojo-attach-point='_popOptionLabel'or contains(@id,'_PurposeOfPayment_')]//input[contains(@id,'arrowid')]")
    private WebElement reasonForTransaction;

    @FindBy(linkText = "Transfer and Currency Conversion")
    public WebElement payOrTransfer;

    @FindBy(xpath = "//div[contains(@id, 'SelectPayee')]//span[contains(@class, 'Label')]")
    private WebElement myPayeesLabel;

    public MoveMoneyCapturePage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30000);

    }

    /**
     * Method to get the ENTITY COUNTRY NAME as displayed in Account Selection
     * DropDown
     * 
     */
    @Override
    protected String getEntityBankCountry() {
        return ENTITY_BANK_COUNTRY;
    }


    @Override
    public String selectReasonForTransaction(Transaction transaction) {
        wait.until(ExpectedConditions.visibilityOf(reasonForTransaction));
        return selectRandamValue(reasonForTransaction, listDropdown);
    }

    @Override
    public void clickTermsAndConditionsCheckBox() {
        uiCommonUtil.activeElement(locatorTermAndConditionCheckBox).click();
    }

    @Override
    protected void selectTransactionEndDate(Transaction transactionDetails) {
        transactionDetails.setTransactionFrequency(TransactionFrequency.NOOFTRANSACTION);
        selectValue(transactionEndDateDropIcon, listDropdown, transactionDetails.getTransactionFrequency().getValue());
        Reporter.log("Transaction End Date value selected is :" + transactionDetails.getTransactionFrequency().getValue());
    }

    @Override
    protected void clickMyPayeeTab() {
        myPayeesTab.click();
        wait.until(ExpectedConditions.visibilityOf(myPayeesLabel));
        Reporter.log("My Payees tab is clicked.");
    }

    @Override
    protected AccountDetails enterNewPayeeDetails(String payeeName, String payeeAccountNumber) {
        AccountDetails accountDetails = new AccountDetails();
        if (!nextToPersonalDetailsButtons.isEmpty() && nextToPersonalDetailsButtons.get(DEFAULT_LIST_STARTING_INDEX).isDisplayed()) {
            nextToPersonalDetailsButtons.get(DEFAULT_LIST_STARTING_INDEX).click();
            payeeName = RandomUtil.generateAlphabatic(DEFAULT_REFERENCE_TEXT_LENGTH);
            newPayeeNameText.clear();
            newPayeeNameText.sendKeys(payeeName);
            newPayeeNameText.sendKeys(Keys.RETURN);
        }
        accountNumberText.clear();
        accountNumberText.sendKeys(payeeAccountNumber);
        accountDetails.setAccountName(payeeName);
        accountDetails.setAccountNumber(payeeAccountNumber);
        return accountDetails;
    }

    @Override
    public String enterAddress() {
        String address = "";
        Reporter.log("This method is not applicable in prd.");
        return address;
    }

    @Override
    public AccountDetails enterNewHSBCDomesticLCYPayeeDetails(final String profile, final Map<String, String> envProperties) {
        String payeeName = "";
        String payeeAccountNumber = RandomUtil.generateIntNumber(DEFAULT_ACCOUNT_NUMBER_LENGTH);
        clickTabsToOpenNewPersonPayeeDetails();
        return enterNewPayeeDetails(payeeName, payeeAccountNumber);
    }
}
