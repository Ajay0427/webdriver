/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.mx;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

import com.hsbc.digital.testauto.pageobject.ReportLostOrStolenCardModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Report
 * Lost Or Stolen Card for Mexico entity. </b>
 * </p>
 */
public class ReportLostOrStolenCard extends ReportLostOrStolenCardModel {

    // Locator for report Lost Stolen Card Link on Footer
    @FindBy(xpath = "//div[contains(@class,'footer')]//a[contains(text(),'lost or stolen card')]")
    private WebElement reportLostStolenCardLinkOnFooter;

    /**
     * @param driver
     */
    public ReportLostOrStolenCard(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);

    }

    /**
     * Method to click Report Lost Or Stolen Card Footer Link.
     * 
     */
    public void clickReportLostOrStolenCardFooterLink() {
        scrollToWebElement(reportLostStolenCardLinkOnFooter);
        reportLostStolenCardLinkOnFooter.click();
        Reporter.log("Report lost Or stolen card link on Footer clicked. ");
    }

    /**
     * Method to verify report Lost Card Footer Menu Flow.
     * 
     */
    @Override
    public void reportLostCardFooterMenuFlow() {
        clickReportLostOrStolenCardFooterLink();
        clickCloseButton();
    }

}
