/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.au;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.AccountTypes;
import com.hsbc.digital.testauto.models.OpenAccountDetails;
import com.hsbc.digital.testauto.pageobject.LandingPageModel;
import com.hsbc.digital.testauto.pageobject.ca.StopChequeCapturePage;

/**
 * <p>
 * <b>Landing Page pom for CBH. </b>
 * </p>
 */
public class LandingPage extends LandingPageModel {

    private static final String[] currentAccountExpectedLabels = {"Status of account", "Available balance", "Credit Limit",
        "Total hold", "Credit interest rate", "Account name"};

    private static final String[] expectedTDTransactionHeaders = {"Balance", "Start date", "Maturity date", "Interest rate",
        "Interest paid"};


    @FindBy(xpath = "//*[@id='Manage']//button[@data-dojo-attach-point='_manageBtnNode']")
    private WebElement manangeButton;

    @FindBy(xpath = "//div[@class='manageContainer']//a[text()='Stop a cheque']")
    private List<WebElement> stopChequeLinkManageMenuList;

    // Manage Future Links
    @FindBy(partialLinkText = "Pay or transfer")
    private WebElement payOrTransferLink;

    @FindBy(xpath = "//div[contains(@id,'TitlePane')]//span[contains(@unique-account-number,'|')]")
    private List<WebElement> accountdetails;

    @FindBy(partialLinkText = "Future payments or transfers")
    private WebElement futurePaymentsLink;

    @FindBy(xpath = "//div[@class='manageContainer']//a[@data-uid='newtransaction']")
    private WebElement moveMoneyLink;

    @FindBy(xpath = "//div[@class='manageContainer']//a[@data-uid='billpaymenthistory']")
    private WebElement billPaymentHistoryLink;

    @FindBy(xpath = "//div[@class='manageContainer']//a[@data-uid='futuredatemanagement']")
    private WebElement futureDatePaymentLink;

    @FindBy(xpath = "//div[contains(@class,'manageContainer') or contains(@class,'ManageContainer')]//a[@data-uid='statements']")
    private WebElement statementsLink;

    @FindBy(xpath = "//div[@class='manageContainer']//a[@data-uid='statementoptions']")
    private WebElement statementOptionsLink;

    @FindBy(xpath = "//div[contains(@class,'manageContainer') or contains(@class,'ManageContainer')]//a[@data-uid='editmaturityinstructions']")
    private WebElement maturityInstructionLink;

    @FindBy(xpath = "//div[contains(@class,'manageContainer') or contains(@class,'ManageContainer')]//a[@data-uid='printaccountview']")
    private WebElement printAccountViewLink;

    @FindBy(xpath = "//div[contains(@class,'manageContainer') or contains(@class,'ManageContainer')]//a[@data-uid='downloadaccountview']")
    private WebElement downloadAccountViewLink;

    @FindBy(xpath = "//div[@id='_dapAccountSnapshot']//p[@data-dojo-attach-point='_dapAccountNumber']")
    private WebElement overviewAccountNumber;

    @FindBy(xpath = "//div[contains(@class,'manageContainer')]//a[contains(text(),'Order a cheque')]")
    private WebElement orderChequesLink;

    @FindBy(xpath = "//div[contains(@class,'manageContainer')]//a[contains(text(),'Stop a cheque')]")
    private WebElement stopChequeLink;

    private final By locatorAmount = By.cssSelector(".gridxCell.amount");
    // x-path for Clear Results button
    @FindBy(xpath = "//button[contains(@data-dojo-attach-point,'dapClearResults')]")
    private WebElement clearResultsButton;


    @FindBy(xpath = "//a[text()='Rename account']")
    private WebElement renameAccountLink;

    // Error for Invalid Account name
    @FindBy(xpath = "  //span[contains(text(),'No transactions')]")
    private WebElement errorInvalidAccountName;

    @FindBy(xpath = "//input[contains(@id,'EditNickname')]")
    private WebElement renameAccountTextBox;

    @FindBy(xpath = ".//*[@id='balanceField']//span[@class='icon']")
    private WebElement balanceHelpIcon;

    @FindBy(xpath = "//div[contains(@id,'EditNickname')]//p")
    private WebElement accountNickname;

    // X path for to get selected account number on Dashboard
    @FindBy(xpath = "//div[contains(@id,'dapAccountSnapshot')]//p[2]")
    private WebElement selectedAccountNumber;

    // X path of Account NAme WebElement under Details Section
    @FindBy(xpath = "//dt[contains(text(),'Account name')]")
    private WebElement accountNameDetailsSection;

    // X path of Account selected account number of different enity
    @FindBy(xpath = "//p[@id='accountNumber']//span[1]")
    private WebElement selectedAccountNumberDiffrentEntity;


    private static final String SCROLL_TO_VIEW = "arguments[0].scrollIntoView(true);";

    private final By locatorBalance = By.cssSelector(".gridxCell.balance");


    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(StopChequeCapturePage.class);

    public LandingPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    public void verifyMortgageAccountOverviewInfo(AccountDetails accountDetails) {

    }


    @Override
    public WebElement getClearResultsButton() {
        return clearResultsButton;
    }

    @Override
    public void verifyRetirementAccountOverviewInfo(final AccountDetails accountDetails) {

    }

    @Override
    public void verifyLoanAccountOverviewInfo(final AccountDetails accountDetails) {

    }

    @Override
    public void verifyAccountOverviewInfo(final AccountDetails accountDetails) {
        verifyAccountInfo(accountDetails);
        isElementDisplayed(moveMoneyButtons.get(0));
        Reporter.log("Move Money Button on overview section displayed. ");
        isElementDisplayed(manageButton);
        Reporter.log("Manage Button on overview section displayed. ");
        isElementDisplayed(searchButton);
        Reporter.log("Search Button on overview section displayed. ");
        isElementDisplayed(detailsButton);
        Reporter.log("Details Button on overview section displayed. ");
    }

    @Override
    public void verifyCurrentManageLinks() {
        manageButton.click();
        Reporter.log("Manage Button Clicked. ");
        verifyManageCommonLinks();
        isElementDisplayed(orderChequesLink);
        Reporter.log("Order Cheques Link on manage section displayed. ");
        isElementDisplayed(stopChequeLink);
        Reporter.log("Stop Cheque Link on manage section displayed. ");
        manangeButton.click();
    }

    public void verifyManageCommonLinks() {

        isElementDisplayed(moveMoneyLink);
        Reporter.log("Move Money Link on manage section displayed");
        isElementDisplayed(futureDatePaymentLink);
        Reporter.log("Future Date Payment Link on manage section displayed");
        isElementDisplayed(billPaymentHistoryLink);
        Reporter.log("Bill Payment History Link on manage section displayed");
        isElementDisplayed(statementsLink);
        Reporter.log("Statements Link on manage section displayed");
        isElementDisplayed(statementOptionsLink);
        Reporter.log("Statement Option Link on manage section displayed");
        isElementDisplayed(printAccountViewLink);
        Reporter.log("Print Account View Link on manage section displayed");
        isElementDisplayed(downloadAccountViewLink);
        Reporter.log("Download Account View Link on manage section displayed");


    }

    /**
     * Method to verify account number on account overview section.
     * 
     * @param object
     *            of AccountDetails class
     */
    @Override
    public void verifyAccountNumber(final AccountDetails accountDetails) {
        /* Assert.assertTrue(
             overviewAccountNumber.isDisplayed()
                 && accountDetails.getAccountNumber().equalsIgnoreCase(overviewAccountNumber.getText()),
             "Account Number not displayed and incorrect");*/
        Assert.assertTrue(
            overviewAccountNumber.isDisplayed() && (overviewAccountNumber.getText().contains(accountDetails.getAccountNumber())),
            "Account Number not displayed and incorrect");
        Reporter.log("Account Number: " + overviewAccountNumber.getText() + " displayed and verified. ");
    }

    @Override
    public void verifyTDAccountOverviewInfo(final AccountDetails accountDetails) {
        verifyTDAccountInfo(accountDetails);
        isElementDisplayed(manageButton);
        Reporter.log("Manage Button on overview section displayed. ");
        isElementDisplayed(detailsButton);
        Reporter.log("Details Button on overview section displayed. ");

    }


    public void verifyTDTransactionHistoryWidget() {
        if (!transactionTableHeaders.isEmpty()) {
            verifyFields(Arrays.asList(expectedTDTransactionHeaders), transactionTableHeaders);
        }

        if (dateColumnAll.size() > 5) {
            verifyViewMoreFunctionality(dateColumnAll.size());
        } else if (dateColumnAll.size() < 5) {
            Assert.assertTrue(viewMoreButtonList.isEmpty(), "View More Button Displayed");
            Reporter.log("Transactions in history are less then 5. Hence, View More button not displayed. ");
        }
    }


    public void verifyTDAccountInfo(final AccountDetails accountDetails) {
        verifyAccountDescription(accountDetails);
        verifyAccountNumber(accountDetails);
        verifyAccountCurrency(accountDetails);
        isBalanceDisplayed(accountDetails);
        Reporter.log("Balance on overview Page displayed. ");
        if (!transactionGrid.isEmpty()) {
            verifyTDTransactionHistoryWidget();
        } else {
            Reporter.log("There are no transactions performed for this account. ");
        }
    }


    @Override
    public void verifyCurrentAccountDetails() {
        verifyFields(Arrays.asList(LandingPage.currentAccountExpectedLabels), detailsLabels);
    }

    @Override
    public void verifySavingsAccountDetails() {

    }

    @Override
    public void verifyLoanAccountDetails() {

    }

    @Override
    public void verifyTDAccountDetails() {

    }

    @Override
    public void verifyRetirementAccountDetails() {

    }

    @Override
    public void verifyMortgageAccountDetails() {

    }

    @Override
    public void verifyMoveMoneyNavigation(final AccountDetails accDetail) {
        if (!moveMoneyButtons.isEmpty()) {
            clickElement(moveMoneyButtons.get(0));
            Reporter.log("Move Money Button is clicked. ");

            clickElement(primaryTransactionCancelButton);
            Reporter.log("New Transaction Cancel Button is clicked. ");

            clickElement(secondaryTransactionCancelButton);
            Reporter.log("Transaction Cancel Button is clicked to return to 'My Accounts' page. ");
        } else {
            Reporter.log("Move Money button not displayed for this account type. ");
        }

    }

    @Override
    public void verifyMultipleEntityAccounts() {
        if (linkedEntities.size() > 1 || arrowButton.size() > 0) {
            Reporter.log("Profile linked with multiple entities");
            int randomIndex = RandomUtil.generateIntNumber(1, linkedEntities.size());
            WebElement element = arrowButton.get(randomIndex);
            element.click();

            verifyOtherEntityOverviewSection(otherEntityAccountLists);

        } else {
            Reporter.log("Linked entities not found.");
        }
    }

    @Override
    public void verifyOtherEntityOverviewSection(final List<WebElement> listOfAccounts) {
        WebElement account = listOfAccounts.get(0);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", account);
        String accountText = account.getText();
        account.click();
        Assert.assertTrue(accountText.contains(selectedAccountNumberDiffrentEntity.getText()),
            "Selected account number not displayed on Account Overview Section");
    }


    @Override
    public void verifyAccountSummarySection() {
        isElementDisplayed(accountSummaryTitle);
        Reporter.log("Summary Section Title is displayed. ");
    }


    @Override
    public void verifyRetirementAccountPrint(final AccountDetails accountDetails) {}


    @Override
    public void verifyRealTimeUpdate(final AccountDetails accountDetails) {
        AccountTypes accountTypes = checkAccountType(accountDetails);
        if (accountTypes.equals(AccountTypes.SAVINGS) || accountTypes.equals(AccountTypes.CURRENT)) {
            detailsButton.click();
            Reporter.log("Details Button clicked. ");
            renameAccountLink.click();
            Reporter.log("Rename Account Link clicked. ");
            enterNickname();
            verifyAccountNickname();
            detailsButton.click();
            Reporter.log("Details Button clicked. ");
        }

    }

    public void enterNickname() {
        int maxlength = Integer.parseInt(renameAccountTextBox.getAttribute("maxlength"));
        String randomText = RandomUtil.generateAlphaNumericText(maxlength);
        renameAccountTextBox.clear();
        renameAccountTextBox.sendKeys(randomText);
        accountNameDetailsSection.click();
        accountNameDetailsSection.click();
        // Actions actions = new Actions(driver);
        // actions.moveToElement(balanceHelpIcon).click().build();
    }


    public void verifyAccountNickname() {
        Assert.assertTrue(accountDescription.getText().equals(accountNickname.getText()), "nickname not updated");
        Reporter.log("Nickname updated properly. ");
        renameAccountLink.click();
        renameAccountTextBox.clear();
        accountNameDetailsSection.click();
        accountNameDetailsSection.click();
        // Actions actions = new Actions(driver);
        // actions.moveToElement(balanceHelpIcon).click().build();
    }


    @Override
    public void verifyOrderOfAccounts() {
        List<AccountDetails> actualList = new ArrayList<>();
        for (WebElement account : accountdetails) {
            ((JavascriptExecutor) driver).executeScript(LandingPage.SCROLL_TO_VIEW, account);
            AccountDetails accountDetails = new AccountDetails();
            storeProductCode(accountDetails, account);
            LandingPage.logger.info("Accounts:" + accountDetails);
            AccountTypes accountTypes = checkAccountType(accountDetails);
            setAccountSequence(accountDetails, accountTypes);
            actualList.add(accountDetails);
        }
        LandingPage.logger.info("Before sort:" + actualList);
        AccountListComparator comparator = new AccountListComparator();
        Collections.sort(actualList, comparator);
        LandingPage.logger.info("after Sort:" + actualList);
        for (int i = 0; i < accountdetails.size(); i++) {
            WebElement account = accountdetails.get(i);
            ((JavascriptExecutor) driver).executeScript(LandingPage.SCROLL_TO_VIEW, account);
            /*String sample = account.getAttribute("unique-account-number");
            String[] sampleArray = sample.split("\\|\\|");*/
            String accountNumber = account.findElement(By.xpath(".//span[contains(@class,'itemName')]")).getText();
            if (!accountNumber.equals(actualList.get(i).getAccountNumber())) {
                Assert.fail("Accounts are not in sorted order.");
            }
        }
        Reporter.log("Accounts are in sorted order.");
    }

    private void setAccountSequence(final AccountDetails accountDetails, final AccountTypes accountTypes) {
        switch (accountTypes) {
        case CURRENT:
            accountDetails.setAccountSequence(1);
            break;
        case SAVINGS:
            accountDetails.setAccountSequence(2);
            break;
        case TERMDEPOSIT:
            accountDetails.setAccountSequence(3);
            break;
        case TFSASAVINGS:
            accountDetails.setAccountSequence(4);
            break;
        case TFSATERMDEPOSIT:
            accountDetails.setAccountSequence(5);
            break;
        case RRSP:
            accountDetails.setAccountSequence(6);
            break;
        case INVESTMENT:
            accountDetails.setAccountSequence(7);
            break;
        case CREDIT:
            accountDetails.setAccountSequence(8);
            break;
        case LOAN:
            accountDetails.setAccountSequence(9);
            break;
        case MORTGAGE:
            accountDetails.setAccountSequence(10);
            break;
        default:
            Assert.fail("No matching account found");
            break;
        }
    }

    private class AccountListComparator implements Comparator<AccountDetails> {

        @Override
        public int compare(final AccountDetails ac1, final AccountDetails ac2) {
            int result = 0;
            if (ac1.getAccountSequence() < ac2.getAccountSequence()) {
                result = -1;
            } else if (ac1.getAccountSequence() > ac2.getAccountSequence()) {
                result = 1;
            }
            if (result == 0) {
                result = ac1.getProductCode().compareTo(ac2.getProductCode());
            }
            if (result == 0) {
                result = ac1.getAccountNumber().compareTo(ac2.getAccountNumber());
            }
            return result;
        }

    }

    @Override
    public void storeProductCode(final AccountDetails accountDetails, final WebElement account) {
        String accountNumber = account.getText().split("\\r?\\n")[1];
        String uniqueAccountNumber = account.getAttribute("unique-account-number");
        String productCode = uniqueAccountNumber.split("\\|\\|")[2];
        Assert.assertTrue(!productCode.isEmpty(), "Product Code attribute is not found.");
        accountDetails.setProductCode(productCode);
        accountDetails.setAccountNumber(accountNumber);
    }

    @Override
    public AccountTypes checkAccountType(final AccountDetails accountDetails) {
        String productCode = productCodes.get(accountDetails.getProductCode());
        Assert.assertTrue(!productCode.isEmpty(), "Product Code: " + accountDetails.getProductCode()
            + " :not found in product mapping sheet");
        if (productCode.equalsIgnoreCase("Chequing")) {
            return AccountTypes.CURRENT;
        } else if (productCode.equalsIgnoreCase("Savings")) {
            return AccountTypes.SAVINGS;
        } else if (productCode.equalsIgnoreCase("Registered TFSA Savings")) {
            return AccountTypes.TFSASAVINGS;
        } else if (productCode.equalsIgnoreCase("Credit Cards")) {
            return AccountTypes.CREDIT;
        } else if (productCode.equalsIgnoreCase("Term Deposit")) {
            return AccountTypes.TERMDEPOSIT;
        } else if (productCode.equalsIgnoreCase("Registered TFSA Term Deposit")) {
            return AccountTypes.TFSATERMDEPOSIT;
        } else if (productCode.equalsIgnoreCase("Loan")) {
            return AccountTypes.LOAN;
        } else if (productCode.equalsIgnoreCase("Mortgages")) {
            return AccountTypes.MORTGAGE;
        } else if (productCode.equalsIgnoreCase("Registered RRSP Investment Bundle")) {
            return AccountTypes.RRSP;
        } else if (productCode.equalsIgnoreCase("Mutual Funds")) {
            return AccountTypes.INVESTMENT;
        } else if (productCode.equalsIgnoreCase("HIDC \\(Non GSP Bijit\\)")) {
            return AccountTypes.HIDC;
        } else {
            Assert.fail("No matching account found with product code.");
            Reporter.log("Account Selected does not match any criteria.");
        }
        return null;
    }

    @Override
    public String getFromDate() throws ParseException {
        return DateUtil.getDateToString("dd/MM/yyyy",
            DateUtil.getStringToDate("dd MMM yyyy", dateColumnAll.get(dateColumnAll.size() - 1).getText()));
    }

    @Override
    public String getToDate() throws ParseException {
        return DateUtil.getDateToString("dd/MM/yyyy", DateUtil.getStringToDate("dd MMM yyyy", dateColumnAll.get(0).getText()));
    }

    @Override
    public void verifyFields(final List<String> expectedLabels, final List<WebElement> actualLabelList) {
        List<String> actualLabels = new ArrayList<>();
        for (WebElement actualLabel : actualLabelList) {
            if (!actualLabel.getText().trim().isEmpty()) {
                actualLabels.add(actualLabel.getText());
            }
        }
        if (expectedLabels.size() == actualLabels.size() && expectedLabels.containsAll(actualLabels)) {
            Reporter.log("Field labels are displayed as expected: " + expectedLabels);
        } else {
            Reporter.log("The number of fields in the Expected List: " + expectedLabels.size()
                + " does not match with the number of fields in the Actual List: " + actualLabels.size());
            Reporter.log("The Expected labels: " + expectedLabels);
            Reporter.log("The Actual labels: " + actualLabels);
            Assert.fail("Mismatch in Labels in Details Section");
        }
    }

    @Override
    protected String getLatestTransactionHistoryBalance() {
        return transactionDetailDisplayElements.get(0).findElement(locatorBalance).getText();
    }

    @Override
    protected String getLatestTransactionHistoryAmount() {
        return transactionDetailDisplayElements.get(0).findElement(locatorAmount).getText();
    }

    @Override
    public boolean isStopChequeLinkPresent() {
        return !stopChequeLinkManageMenuList.isEmpty();
    }

    @Override
    public void verifyErrorForInvalidAccountName() {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", errorInvalidAccountName);
        Assert.assertTrue(errorInvalidAccountName.isDisplayed(), "Transactions displayed for invalid account. ");
        String errMessage = errorInvalidAccountName.getText();
        Reporter.log("Error is displayed as :" + errMessage);
    }

    @Override
    public void clickStopChequeLink() {
        stopChequeLinkManageMenuList.get(0).click();
    }

    @Override
    public void verifyCreatedAccontOnDashboard(final OpenAccountDetails objOpenAccountDetails) {
        wait.until(ExpectedConditions.visibilityOf(leftHandMenuMyAccount));
        String xpathAccountNumber = "//span[contains(@unique-account-number,'" + objOpenAccountDetails.getCreatedAccount() + "')]";
        WebElement actAccountNumber = driver.findElement(By.xpath(xpathAccountNumber));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", actAccountNumber);
        actAccountNumber.click();
        Assert.assertTrue(actAccountNumber.getText().contains(selectedAccountNumber.getText()),
            "Created account does not displayed on Dasbhboard page");
    }

    /**
     * Method to verify Account Summary Print Preview section.
     * 
     */
    @Override
    public void verifyAccountSummaryPrintPreviewPage() {
        isElementDisplayed(accountSummaryPreviewPrintButton);
        Reporter.log("Print Button on Summary Preview Page displayed. ");
        isElementDisplayed(accountSummaryPrintPreviewCancelButton);
        Reporter.log("Calcel button on Summary Preview Page displayed. ");
        accountSummaryPrintPreviewCancelButton.click();
        Reporter.log("Cancel Button is clicked. ");
    }


}
