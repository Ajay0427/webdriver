/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.hk;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.pageobject.QuickMoveMoneyCaptureModel;

/**
 * 
 * This model class will hold locators and functionality for Quick move
 * money widget for HK entity .This widget is present on Dashboard page. 
 * @author Nikita Garg
 * @version 1.0.0
 */

public class QuickMoveMoney extends QuickMoveMoneyCaptureModel {
    
            
    @FindBy(xpath = "//table[contains(@id, 'SelectDropDown')]//span[contains(@class,'balance')]")
    private WebElement fromAccountBalance;
    
    @FindBy(xpath = "//div[starts-with(@id,'group_gpib_mvmny_bijit_SelectAccount_') and not(contains(@id,'_accountLabel'))][2]//table[contains(@id, 'SelectDropDown')]//span[contains(@class,'balance')]")
    private WebElement toAccountBalance;
       
    private final By accountsList = By.xpath(".//*[contains(@id,'_text') and contains(@class,'childSection') or contains(@class,'singleAccountSection')]");
    
    private final By hiddenAccountNumberList = By.xpath(".//span[@class='noDisplay' and @aria-hidden='true']");
           
    public QuickMoveMoney(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    public WebElement getfromAccountBalanceElement() {
        return this.fromAccountBalance;
    }

    public WebElement getToAccountBalanceElement() {
        return toAccountBalance;
    }

    protected By getListItems(){
        return accountsList;
    }
    
    public void selectAccount(final WebElement dropDownIcon, final WebElement dropDownItems, final AccountDetails accountDetails) {
        dropDownIcon.click();
        wait.until(ExpectedConditions.visibilityOf(dropDownItems));
        List<WebElement> accountDropdownList = dropDownItems.findElements(getListItems());
        while (true) {
            int randomIndex = RandomUtil.generateIntNumber(1, accountDropdownList.size());
            for (int index = 1; index < accountDropdownList.size(); index++) {
                WebElement accountRow = accountDropdownList.get(index);
                wait.until(ExpectedConditions.visibilityOf(accountRow));
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", accountRow);
                   String accountNumber = (String) jsx.executeScript(QuickMoveMoneyCaptureModel.GET_HIDDEN_TEXT, accountRow.findElement(hiddenAccountNumberList));
                   if ( checkAccountInfo(accountDetails,accountNumber,accountRow) || (accountDetails == null && index == randomIndex)) {
                    accountRow.click();
                    Reporter.log("Account Selected:" + accountRow.getText());
                    break;
                }
            }
            if ( checkBalance(getfromAccountBalanceElement().getText())|| !errorContainer.isEmpty()) {
                dropDownIcon.click();
            } else {
                break;
            }
        }
    }

    private boolean checkAccountInfo(AccountDetails accountDetails, String accountNumber, WebElement accountRow){
        
        return accountDetails != null && accountNumber.contains(accountDetails.getAccountNumber()) && accountRow.getText().contains(accountDetails.getAccountName());
    }
    private boolean checkBalance(String balance){
        boolean flag = false;
        Double formattedBalance = Double.parseDouble(balance.replace(",", ""));
        if(formattedBalance<=0){
            flag= true;
        }
        return flag;
    }
    
  }
