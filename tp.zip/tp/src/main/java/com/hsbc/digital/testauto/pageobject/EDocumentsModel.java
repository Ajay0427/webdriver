/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.EDocumentEnum;

/**
 * <p>
 * <b>This class will have locators and behavior for E Documents.</b>
 * </p>
 */
public abstract class EDocumentsModel {

    @FindBy(xpath = ".//*[@title='My documents']")
    private WebElement myDocumentsHeading;

    @FindBy(xpath = ".//*[@class='edocDateRange' and @data-dojo-attach-point='_selectCheckBox']/ul[@data-dojo-attach-point='_dateRangeContainer']//input[@type='radio']")
    private List<WebElement> dateRangeFiveOption;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='_attachDateRangeAllLink']")
    private WebElement dateRangeAllOptions;

    @FindBy(xpath = ".//*[@class='edocAccountDetails']//input[@type='checkbox']")
    private List<WebElement> accountType;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='_clearAccountAtpt']")
    private WebElement clearAccountType;

    @FindBy(xpath = ".//*[@class='edocDocumentType']//input[@type='checkbox']")
    private List<WebElement> documentType;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='_clearDocAtpt']")
    private WebElement clearDocType;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='_viewResultsButton']")
    private WebElement viewButton;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='_resetResultsButton']")
    private WebElement resetButton;

    @FindBy(xpath = ".//input[contains(@id,'arrowid_hdx_dijits_form_Select')][contains(@class,'dijitArrowButtonInner')")
    private WebElement sortArrowButton;

    @FindBy(xpath = ".//*[contains(@class,'hdxSelectDropDownPopup')]//table")
    private WebElement sortByTable;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='listDataNode']//following-sibling::div[contains(@class,'actualDate')]")
    private WebElement documentDate;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='listDataNode']//following-sibling::div[contains(@aria-labelledby,'colDocumentType')]")
    private WebElement documentTypeAndName;

    @FindBy(xpath = ".//*[contains(@class,'dijitArrowNode')]//parent::div//span[contains(text(),'View')]")
    private WebElement viewDetails;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='printbutton']")
    private WebElement printButton;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='downloadbutton']")
    private WebElement downloadButton;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='openbutton']")
    private WebElement openButton;

    @FindBy(xpath = ".//*[contains(@class,'dijitArrowNode')]//parent::div//span[contains(text(),'Close')]")
    private WebElement closeDetails;

    // @author=Prateek Kumar

    @FindBy(xpath = "//div[contains(@id,'group/gpib/edocumentManagement/bijit/ListItem_')]")
    private List<WebElement> taxSlipList;

    @FindBy(xpath = "//td[contains(@class,'dijitButtonNode')]/input[contains(@class,'dijitArrowButtonInner')]")
    private WebElement sortByDropBox;

    @FindBy(xpath = "//tr[contains(@id,'dijit_MenuItem_')]/td[contains(@id,'dijit_MenuItem_') and contains(@id,'_text') and contains(@class,'dijitMenuItemLabel')]")
    private List<WebElement> dropBoxOptions;

    @FindBy(xpath = "//span[text()='Next']")
    private WebElement next;

    @FindBy(xpath = "//div[@class='paginationRelativeDiv']/div[@class='nextButton']/span[contains(@class,'dijitButton')]/span[contains(@data-dojo-attach-event,'ondijitclick:__')]/span[@role='button']")
    private WebElement checkNextEnablility;

    @FindBy(xpath = ".//table[contains(@id,'hdx_dijits_form_Select_')]/tbody/tr/td[contains(@class,'dijitStretch')]/div[contains(@class,'dijitInputField')]/span[@role='option']")
    private WebElement dropdownTextField;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='listDataNode']//following-sibling::div[contains(@aria-labelledby,'colDocumentType')]//div")
    private List<WebElement> accNum;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='listDataNode']//following-sibling::div[contains(@class,'actualDate')]")
    private List<WebElement> dates;
    /*
     * 
     * Date Range Dialogue Box
     */

    @FindBy(xpath = ".//div[contains(@id,'OpenAllOptionDialog') and @role]")
    private WebElement dateRangeDialogueBox;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='_heading'][contains(text(),'Date')]")
    private WebElement dateRangeDialogueHeading;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='_seeAllDateRangeContainer']//input[@type='radio']")
    private List<WebElement> dateRangeDialogueTable;

    @FindBy(xpath = ".//div[contains(@id,'OpenAllOptionDialog') and @role]//div[contains(@class,'applyCancelDiv')]//button[@data-dojo-attach-point='_applyButton']")
    private WebElement dateRangeDialogueApplyBtn;

    @FindBy(xpath = ".//div[contains(@id,'OpenAllOptionDialog') and @role]//div[contains(@class,'applyCancelDiv')]//button[@data-dojo-attach-point='_cancelButton']")
    private WebElement dateRangeDialogueCancelBtn;

    @FindBy(xpath = ".//div[contains(@id,'OpenAllOptionDialog') and @role]//button[@data-dojo-attach-point='closeButtonNode']")
    private WebElement dateRangeDialogueCloseBtn;


    private final WebDriverWait wait;

    private final WebDriver driver;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(QuickMoveMoneyCaptureModel.class);

    public EDocumentsModel(final WebDriver driver) {
        PageFactory.initElements(driver, this);
        this.driver = driver;
        wait = new WebDriverWait(driver, 30);
    }


    public void viewDownloadPreview() {
        List<WebElement> docName = documentTypeAndName.findElements(By.xpath("//span[2]"));
        if (!taxSlipList.isEmpty()) {
            wait.until(ExpectedConditions.visibilityOfAllElements(taxSlipList));
            EDocumentsModel.logger.info("eDoc List is Displayed...");
            int tobeSelectedIndex = RandomUtil.generateIntNumber(0, docName.size());
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", docName.get(tobeSelectedIndex));
            if (docName.get(tobeSelectedIndex).getAttribute("aria-readonly") != "true") {
                EDocumentsModel.logger.info("Tax Slip is not editable...");
            }
        } else {
            EDocumentsModel.logger.info("The Filtered Criteria does not contain any transaction.");
        }
    }

    public void checkForMaxTenTaXSlipsAreDisplayed() {
        Assert.assertSame(dates.size() <= 10 ? true : false, true, "Customer can view max of 10 eDocs on this Page.");
        Reporter.log("My documents page contains atmost 10 TaxSlips.", true);
    }

    /*
     * Method to verify whether the displayed taxslips are sorted according to
     * the dropDownMenu selected Option
     */
    public void sortBY() throws ParseException {
        sortByDropBox.click();
        int tobeSelectedIndex = RandomUtil.generateIntNumber(0, dropBoxOptions.size());
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", dropBoxOptions.get(tobeSelectedIndex));
        dropBoxOptions.get(tobeSelectedIndex).click();
        if (dates.size() == 0) {
            EDocumentsModel.logger.info("No TaxSlip Found...");
            Reporter.log("No TaxSlip Found.");
        } else if (dates.size() == 1) {
            EDocumentsModel.logger.info("Only one TaxSlip is found` which is already sorted in itself.");
            Reporter.log("Only one TaxSlip is found` which is already sorted in itself.", true);
        } else {
            switch (EDocumentEnum.dropDownSortingOptions.values()[tobeSelectedIndex]) {
            case DATE_NEWEST:
                sortByDateNewest();
                break;
            case DATE_OLDEST:
                sortByDateOldest();
                break;
            case ACCOUNT_NAME_AZ:
                sortByAZ();
                break;
            case ACCOUNT_NAME_ZA:
                sortByZA();
                break;
            case ACCOUNT_NUMBER_09:
                sortByAccNumAsc();
                break;
            case ACCOUNT_NUMBER_90:
                sortByAccNumDesc();
                break;
            default:
                EDocumentsModel.logger.info("Something Unusual must have happened.");
            }
        }
    }

    /*
     * Check Whether the TaxSlips are sorted By NewestDate
     */
    public void sortByDateNewest() throws ParseException {
        Date dateAccntOne = null, dateAccntTwo = null;
        boolean nextButtonIsClickedOn = false;
        dateAccntOne = DateUtil.getStringToDate(DateUtil.DATE_FORMAT_MMDDYYYY, dates.get(0).getText().toString().trim());
        for (;;) {
            for (int i = (nextButtonIsClickedOn == false) ? 1 : 0; i < dates.size(); i++) {
                dateAccntTwo = DateUtil.getStringToDate(DateUtil.DATE_FORMAT_MMDDYYYY, dates.get(i).getText().toString().trim());
                if (dateAccntOne.compareTo(dateAccntTwo) >= 0) {
                    dateAccntOne = dateAccntTwo;
                } else {
                    Reporter.log("TaxSlips are not in Sorted Order.", false);
                    Assert.fail("Test Case Failed  : " + getClass());
                }
            }
            checkForMaxTenTaXSlipsAreDisplayed();
            if (checkNextEnablility.getAttribute("aria-disabled").toString().trim().equalsIgnoreCase("false")) {
                EDocumentsModel.logger.info("'Next' is clicked on...");
                nextButtonIsClickedOn = true;
                next.click();
            } else {
                break;
            }
        }
    }

    /*
     * Check Whether the TaxSlips are sorted By OldestDate
     */
    public void sortByDateOldest() throws ParseException {
        Date dateAccntOne = null, dateAccntTwo = null;
        boolean nextButtonIsClickedOn = false;
        dateAccntOne = DateUtil.getStringToDate(DateUtil.DATE_FORMAT_MMDDYYYY, dates.get(0).getText().toString().trim());
        for (;;) {
            for (int i = (nextButtonIsClickedOn == false) ? 1 : 0; i < dates.size(); i++) {
                dateAccntTwo = DateUtil.getStringToDate(DateUtil.DATE_FORMAT_MMDDYYYY, dates.get(i).toString().trim());
                if (dateAccntOne.compareTo(dateAccntTwo) <= 0) {
                    dateAccntOne = dateAccntTwo;
                } else {
                    Reporter.log("TaxSlips are not in Sorted Order.", false);
                    Assert.fail("Test Case Failed  : " + getClass());
                }
            }
            checkForMaxTenTaXSlipsAreDisplayed();
            if (checkNextEnablility.getAttribute("aria-disabled").toString().trim().equalsIgnoreCase("false")) {
                EDocumentsModel.logger.info("'Next' is clicked on...");
                nextButtonIsClickedOn = true;
                next.click();
            } else {
                break;
            }
        }
    }

    /*
     * Check Whether the TaxSlips are sorted By AccountName(A-Z)
     */
    public void sortByAZ() {
        List<WebElement> accName = documentTypeAndName.findElements(By.xpath("//span[@class='subTitle']"));
        String accntNameFirst, accntNameSec;
        boolean nextButtonIsClickedOn = false;
        accntNameFirst = accName.get(0).toString();
        for (;;) {
            for (int i = (nextButtonIsClickedOn == false) ? 1 : 0; i < accName.size(); i++) {
                accntNameSec = accName.get(i).toString();
                if (accntNameFirst.compareTo(accntNameSec) >= 0) {
                    accntNameFirst = accntNameSec;
                    if (i != accName.size()) {
                        accntNameSec = accName.get(i).toString();
                    }
                } else {
                    Reporter.log("TaxSlips are not in Sorted Order.", false);
                    Assert.fail("Test Case Failed  : " + getClass());
                }
            }
            checkForMaxTenTaXSlipsAreDisplayed();
            if (checkNextEnablility.getAttribute("aria-disabled").toString().trim().equalsIgnoreCase("false")) {
                EDocumentsModel.logger.info("'Next' is clicked on...");
                nextButtonIsClickedOn = true;
                next.click();
            } else {
                break;
            }
        }
    }

    /*
     * Check Whether the TaxSlips are sorted By AccountName(Z-A)
     */
    public void sortByZA() {
        List<WebElement> accName = documentTypeAndName.findElements(By.xpath("//span[@class='subTitle']"));
        String accntNameFirst, accntNameSec;
        boolean nextButtonIsClickedOn = false;
        accntNameFirst = accName.get(0).toString();
        for (;;) {
            for (int i = (nextButtonIsClickedOn == false) ? 1 : 0; i < accName.size(); i++) {
                accntNameSec = accName.get(i).toString();
                if (accntNameFirst.compareTo(accntNameSec) <= 0) {
                    accntNameFirst = accntNameSec;
                    if (i != accName.size()) {
                        accntNameSec = accName.get(i).toString();
                    }
                } else {
                    Reporter.log("TaxSlips are not in Sorted Order.", false);
                    Assert.fail("Test Case Failed  : " + getClass());
                }
            }
            checkForMaxTenTaXSlipsAreDisplayed();
            if (checkNextEnablility.getAttribute("aria-disabled").toString().trim().equalsIgnoreCase("false")) {
                EDocumentsModel.logger.info("'Next' is clicked on...");
                nextButtonIsClickedOn = true;
                next.click();
            } else {
                break;
            }
        }
    }

    /*
     * Check Whether the TaxSlips are sorted By AccNum09
     */
    public void sortByAccNumAsc() {
        int accNumFirst, accNumSec;
        String temp;
        boolean nextButtonIsClickedOn = false;
        temp = accNum.get(0).getText().toString();
        accNumFirst = Integer.parseInt(temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")));
        for (;;) {
            for (int i = (nextButtonIsClickedOn == false) ? 1 : 0; i < accNum.size(); i++) {
                temp = accNum.get(i).getText().toString();
                accNumSec = Integer.parseInt(temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")));
                if (accNumFirst <= accNumSec) {
                    accNumFirst = accNumSec;
                } else {
                    Reporter.log("TaxSlips are not in Sorted Order.", false);
                    Assert.fail("Test Case Failed  : " + getClass());
                }
            }
            checkForMaxTenTaXSlipsAreDisplayed();
            if (checkNextEnablility.getAttribute("aria-disabled").toString().trim().equalsIgnoreCase("false")) {
                EDocumentsModel.logger.info("'Next' is clicked on...");
                nextButtonIsClickedOn = true;
                next.click();
            } else {
                break;
            }
        }
    }

    /*
     * Check Whether the TaxSlips are sorted By AccNum90
     */
    public void sortByAccNumDesc() {
        int accNumFirst, accNumSec;
        String temp;
        boolean nextButtonIsClickedOn = false;
        temp = accNum.get(0).getText().toString();
        accNumFirst = Integer.parseInt(temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")));
        for (;;) {
            for (int i = (nextButtonIsClickedOn == false) ? 1 : 0; i < accNum.size(); i++) {
                temp = accNum.get(i).getText().toString();
                accNumSec = Integer.parseInt(temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")));
                if (accNumFirst >= accNumSec) {
                    accNumFirst = accNumSec;
                } else {
                    Reporter.log("TaxSlips are not in Sorted Order.", false);
                    Assert.fail("Test Case Failed  : " + getClass());
                }
            }
            checkForMaxTenTaXSlipsAreDisplayed();
            if (checkNextEnablility.getAttribute("aria-disabled").toString().trim().equalsIgnoreCase("false")) {
                EDocumentsModel.logger.info("'Next' is clicked on...");
                nextButtonIsClickedOn = true;
                next.click();
            } else {
                break;
            }
        }
    }


    public void selectRadioButton(final List<WebElement> elem) {
        if (!elem.isEmpty()) {
            int tobeSelectedIndex = RandomUtil.generateIntNumber(0, elem.size());
            ((JavascriptExecutor) this.driver).executeScript("arguments[0].scrollIntoView(true);", elem.get(tobeSelectedIndex));
            elem.get(tobeSelectedIndex).click();
            Reporter.log("Element Selected at index:" + tobeSelectedIndex);
        } else {
            Reporter.log(elem + "are not valid or not found");
        }

    }

    public void selectDaterangeFiveOptions() {

        selectRadioButton(dateRangeFiveOption);

    }

    public void selectDaterangeAllOptions() {

        wait.until(ExpectedConditions.visibilityOf(dateRangeAllOptions));
        dateRangeAllOptions.click();
        wait.until(ExpectedConditions.visibilityOf(dateRangeDialogueBox));
        selectRadioButton(dateRangeDialogueTable);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", this.dateRangeDialogueApplyBtn);
        dateRangeDialogueApplyBtn.click();

    }


    public void selectAccountType() {

        wait.until(ExpectedConditions.visibilityOfAllElements(this.accountType));
        selectRadioButton(this.accountType);

    }

    public void selectDocumentType() {

        wait.until(ExpectedConditions.visibilityOfAllElements(this.documentType));
        selectRadioButton(this.documentType);

    }

    public void clickPrintBtn() {
        wait.until(ExpectedConditions.visibilityOf(this.printButton));
        printButton.click();
        Reporter.log(this.printButton.getText() + ": clicked");

    }

    public void clickViewtn() {
        wait.until(ExpectedConditions.visibilityOf(this.viewButton));
        viewButton.click();
        Reporter.log(this.viewButton.getText() + ": clicked");

    }
}
