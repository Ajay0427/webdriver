package com.hsbc.digital.testauto.pageobject.cbh;

import java.text.ParseException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.hsbc.digital.testauto.models.StopChequeDetails;
import com.hsbc.digital.testauto.pageobject.StopChequeConfirmPageModel;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

/**
 * <p>
 * <b> Stop Cheque Confirm page object model to hold generic function and
 * locators for cbh entity of story stop cheque</b>
 * </p>
 * 
 * @version 1.0.0
 * @author Neeraj Kumar
 */
public class StopChequeConfirmPage extends StopChequeConfirmPageModel {

    @FindBy(xpath = "//div[contains(@class, 'submitButtonsPanel')]//*[contains(@data-dojo-attach-point, 'dapAgainBtn')]")
    private WebElement stopAnotherChequeButton;

    @Override
    protected WebElement getStopAnotherChequeButton() {
        return stopAnotherChequeButton;
    }

    public StopChequeConfirmPage(final WebDriver driver) {
        super(driver);
        uiCommonUtil = new UICommonUtil(driver);
    }

    @Override
    public void validateConfirmPageWithChequeNumber(final StopChequeDetails stopChequeDetails) throws ParseException {
        wait.until(ExpectedConditions.visibilityOf(confirmPageTitle));
        isPageTitleDisplayed(confirmPageTitle);
        isIssueChequeAccountNameDisplayed(stopChequeDetails);
        isIssueChequeAccountNumberDisplayed(stopChequeDetails);
        isChequeNumberDisplayed(stopChequeDetails);
        isAmountDisplayed(stopChequeDetails);
        isReasonToStopChequeDisplayed(stopChequeDetails);
    }

    @Override
    public void validateConfirmPageWithChequeRange(final StopChequeDetails stopChequeDetails) throws ParseException {
        wait.until(ExpectedConditions.visibilityOf(confirmPageTitle));
        isPageTitleDisplayed(confirmPageTitle);
        isIssueChequeAccountNameDisplayed(stopChequeDetails);
        isIssueChequeAccountNumberDisplayed(stopChequeDetails);
        isChequeRangeDisplayed(stopChequeDetails);
        isReasonToStopChequeDisplayed(stopChequeDetails);
    }

}
