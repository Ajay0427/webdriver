/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.ca;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Flyover
 * Menu for Canada entity. </b>
 * </p>
 */
public class FlyerMenuNavigation extends FlyerMenuNavigationModel {


    /*
     * -------- HEADER LINKS --------
     */
    @FindBy(xpath = "//a[contains(@class,'navigation-link')]//span[contains(text(),'Products & services')]")
    private WebElement productAndServicesLinkHeader;

    @FindBy(xpath = "//a[contains(@class,'navigation-link')]//span[contains(text(),'Investments & financial planning')]")
    private WebElement myInvestmentsAndFinancialLinkHeader;

    /*
     * FOR MASS
     */
    /*
     * My Banking Header Links
     */
    @FindBy(xpath = "//span[text()='My Accounts']")
    public WebElement myAccountLinkMyBankingHeader;

    /*
     * My Banking - My investment accounts Links
     */
    @FindBy(linkText = "Launch HSBC InvestDirect")
    private WebElement launchHSBCInvestLinkMyInvestmentMyBankingHeader;

    @FindBy(linkText = "Logon to HSBC Private Investment Management")
    private WebElement logonToHSBCPrivateLinkMyInvestmentMyBankingHeader;

    /*
     * My Banking - Report a lost or stolen card Links
     */
    @FindBy(linkText = "Report a lost or stolen card")
    private WebElement reportALostCardLinkReportLostCardMyBankingHeader;

    /*
     * My Banking - My profile Links
     */
    @FindBy(linkText = "Update Personal details")
    private WebElement updatePersonalDetailsLinkMyProfileMyBankingHeader;

    @FindBy(linkText = "Statement/notification options")
    private WebElement statementOrNotificationLinkMyProfileMyBankingHeader;

    @FindBy(linkText = "Alert settings")
    private WebElement alertSettingsLinkMyProfileMyBankingHeader;


    /*
     * My Banking - Move Money Header Links
     */
    @FindBy(linkText = "Pay or transfer")
    private WebElement payOrTransferLinkMoveMoneyMyBankingHeader;

    @FindBy(linkText = "Future payments or transfers")
    private WebElement futurePaymentsOrTransfersLinkMoveMoneyMyBankingHeader;

    @FindBy(linkText = "Pending INTERAC e-Transfer")
    private WebElement pendingINTERACLinkMoveMoneyMyBankingHeader;

    @FindBy(linkText = "Bill payment history")
    private WebElement billPaymentHistoryLinkMoveMoneyMyBankingHeader;

    /*
     * My Banking - Global view Links
     */
    @FindBy(linkText = "Add or remove a country")
    private WebElement addOrRemoveACountryLinkGlobalViewMyBankingHeader;

    /*
     * My Banking - Security Links
     */
    @FindBy(linkText = "Switch my Security Device")
    private WebElement switchMySecurityLinkSecurityMyBankingHeader;

    @FindBy(linkText = "Change personal security details")
    private WebElement changePersonalSecurityLinkSecurityMyBankingHeader;

    @FindBy(linkText = "Change my password")
    private WebElement changeMyPasswordLinkSecurityMyBankingHeader;

    @FindBy(linkText = "Help with my Security Device")
    private WebElement helpWithMySecurityLinkSecurityMyBankingHeader;

    @FindBy(linkText = "Security centre")
    private WebElement securityCenterLinkSecurityMyBankingHeader;

    /*
     * My Banking - Cheques Links
     */

    @FindBy(linkText = "Order cheques")
    private WebElement orderChequesLinkChequesMyBankingHeader;

    @FindBy(linkText = "Stop a cheque")
    private WebElement stopAChequeLinkChequesMyBankingHeader;

    @Override
    public WebElement getStopAChequeLinkChequesMyBankingHeader() {
        return stopAChequeLinkChequesMyBankingHeader;
    }

    /*
     * My Banking - Travel Links
     */
    @FindBy(linkText = "Notify us of travel")
    private WebElement notifyUsOfTravelLinkTravelMyBankingHeader;

    /*
     * My Banking - Account services Links
     */
    @FindBy(linkText = "Rename accounts")
    private WebElement renameAccountsLinkAccountServicesMyBankingHeader;

    @FindBy(linkText = "View foreign exchange rates")
    private WebElement viewForeignExchangeLinkAccountServicesMyBankingHeader;

    /*
     * My Banking - Documents Links
     */
    @FindBy(linkText = "View and print statements")
    private WebElement viewAndPrintStatementsLinkDocumentsMyBankingHeader;

    @FindBy(linkText = "View terms and conditions")
    private WebElement viewTermsAndConditionsLinkDocumentsMyBankingHeader;

    /*
     * Products & Services - Account Opening Links
     */
    @FindBy(xpath = "//a[text()='Everyday Banking']")
    private WebElement everydayBankingLinkAccountOpeningProductAndServicesHeader;

    @FindBy(xpath = "//a[text()='GICs and Term Deposits']")
    private WebElement gicAndTermDepositsLinkAccountOpeningProductAndServicesHeader;

    @FindBy(xpath = "//a[text()='Tax-Free Savings Accounts (TFSA)']")
    private WebElement taxFreeSavingsLinkAccountOpeningProductAndServicesHeader;

    /*
     * Products & Services - Advice And Tools Links
     */
    @FindBy(linkText = "Saving for your goals")
    private WebElement savingForGoalsLinkAdviceAndToolsProductAndServicesHeader;

    @FindBy(linkText = "Get a travel insurance quote")
    private WebElement getATravelLinkAdviceAndToolsProductAndServicesHeader;

    @FindBy(linkText = "Travel insurance FAQs")
    private WebElement travelInsuranceLinkAdviceAndToolsProductAndServicesHeader;

    @FindBy(linkText = "Chequing account interest rates")
    private WebElement chequingAccountLinkAdviceAndToolsProductAndServicesHeader;

    @FindBy(linkText = "Savings account interest rates")
    private WebElement savingAccountInterestLinkAdviceAndToolsProductAndServicesHeader;

    @FindBy(linkText = "Foreign currency interest rates")
    private WebElement foreignCurrencyInterestLinkAdviceAndToolsProductAndServicesHeader;

    @FindBy(linkText = "Foreign currency converter and exchange rates")
    private WebElement foreignCurrencyConverterLinkAdviceAndToolsProductAndServicesHeader;

    @FindBy(linkText = "Life stage calculators")
    private WebElement lifeStageCalculatorsLinkAdviceAndToolsProductAndServicesHeader;

    @FindBy(linkText = "Personal service charges statement of disclosure")
    private WebElement personalServiceChargesLinkAdviceAndToolsProductAndServicesHeader;

    @FindBy(xpath = "//a[contains(text(),'Powers of attorney and joint deposit accounts info')]")
    private WebElement powersOfAttorneyLinkAdviceAndToolsProductAndServicesHeader;

    /*
     * Products & Services - Banking Links
     */
    @FindBy(linkText = "Products overview")
    private WebElement productsOverviewLinkBankingProductAndServicesHeader;

    /*
     * Products & Services - Knowledge Center Links
     */
    @FindBy(linkText = "Mortgage calculators")
    private WebElement mortgageCalculatorsLinkKnowledgeCentreProductAndServicesHeader;

    @FindBy(linkText = "Mortgage FAQs")
    private WebElement mortgageFQAsLinkKnowledgeCentreProductAndServicesHeader;

    @FindBy(linkText = "RRSP calculators")
    private WebElement rrspCalculatorLinkKnowledgeCentreProductAndServicesHeader;

    @FindBy(linkText = "Mortgage rates")
    private WebElement mortgageRatesLinkKnowledgeCentreProductAndServicesHeader;

    /*
     * Products & Services - Borrowing Links
     */
    @FindBy(linkText = "Borrowing overview")
    private WebElement borrowingOverviewLinkBorrowingProductAndServicesHeader;

    @FindBy(linkText = "Mortgages")
    private WebElement mortgagesLinkBorrowingProductAndServicesHeader;

    @FindBy(linkText = "Loans")
    private WebElement loansLinkBorrowingProductAndServicesHeader;

    @FindBy(linkText = "Credit Cards")
    private WebElement creditCardsLinkBorrowingProductAndServicesHeader;

    /*
     * Products & Services - Ways to bank Links
     */
    @FindBy(linkText = "Online Banking")
    private WebElement onlineBankingLinkWaysToBankProductAndServicesHeader;

    @FindBy(linkText = "ATM")
    private WebElement atmLinkWaysToBankProductAndServicesHeader;

    @FindBy(linkText = "Mobile banking")
    private WebElement mobileBankingLinkWaysToBankProductAndServicesHeader;

    @FindBy(linkText = "Telephone Banking")
    private WebElement telephoneBankingLinkWaysToBankProductAndServicesHeader;

    @FindBy(linkText = "Branch")
    private WebElement branchLinkWaysToBankProductAndServicesHeader;

    @FindBy(linkText = "INTERAC e-Transfer")
    private WebElement interacETransferLinkWaysToBankProductAndServicesHeader;

    /*
     * Products & Services - Insurance Links
     */
    @FindBy(linkText = "HSBC Travel Insurance")
    private WebElement hsbcTravelInsuranceLinkInsuranceProductAndServicesHeader;

    /*
     * Products & Services - HSBC Premier Links
     */
    @FindBy(linkText = "HSBC Premier overview")
    private WebElement hsbcPremierOverviewLinkHSBCPremierProductAndServicesHeader;

    /*
     * Products & Services - HSBC Advance Links
     */
    @FindBy(linkText = "HSBC Advance overview")
    private WebElement hsbcAdvanceOverviewLinkHSBCAdvanceProductAndServicesHeader;

    /*
     * Investments and Financial planning - Advice and insights Links
     */
    @FindBy(linkText = "Investment insights centre")
    private WebElement investmentInsightLinkAdviceInsightInvestmentsHeader;

    @FindBy(linkText = "Stock Market GIC Market Tracker")
    private WebElement stockMarketGICLinkAdviceInsightInvestmentsHeader;

    @FindBy(linkText = "HSBC Mutual Fund Information & resources")
    private WebElement hsbcMutualFundLinkAdviceInsightInvestmentsHeader;

    @FindBy(linkText = "Self-directed online investment tools & resources")
    private WebElement selfDirectedOnlineInvestmentLinkAdviceInsightInvestmentsHeader;

    @FindBy(linkText = "Self-directed online investing FAQs")
    private WebElement selfDirectedOnlineInvestingLinkAdviceInsightInvestmentsHeader;

    @FindBy(linkText = "Wealth Planning")
    private WebElement wealthPlanningLinkAdviceInsightInvestmentsHeader;

    /*
     * Investments and Financial planning - Investment solutions Links
     */
    @FindBy(linkText = "Term Deposits")
    private WebElement termDepositsLinkInvestmentsolutionsInvestmentsHeader;

    @FindBy(linkText = "Guranteed Investment Certificates (GIC)")
    private WebElement guranteedInvestmentCertificatesLinkInvestmentsolutionsInvestmentsHeader;

    @FindBy(linkText = "Mutual Funds")
    private WebElement mutualFundsLinkInvestmentsolutionsInvestmentsHeader;

    @FindBy(linkText = "Managed Solutions")
    private WebElement managesSolutionsLinkInvestmentsolutionsInvestmentsHeader;

    @FindBy(linkText = "Registered Products")
    private WebElement registeredProductsLinkInvestmentsolutionsInvestmentsHeader;

    @FindBy(linkText = "Tax-Free Savings Accounts (TFSA)")
    private WebElement taxFreeSavingsLinkInvestmentsolutionsInvestmentsHeader;

    @FindBy(linkText = "Self-directed online investing")
    private WebElement selfDirectedOnlineInvestingLinkInvestmentsolutionsInvestmentsHeader;

    @FindBy(linkText = "Private Investment Management")
    private WebElement privateInvestmentManagementLinkInvestmentsolutionsInvestmentsHeader;

    /*
     * Investments and Financial planning - Retiring and Education Links
     */
    @FindBy(linkText = "Plan for a comfortable retirement")
    private WebElement planForAComfortableLinkRetiringAndEducationInvestmentsHeader;

    @FindBy(linkText = "Receive an income in retirement")
    private WebElement receiveAnIncomeLinkRetiringAndEducationInvestmentsHeader;

    @FindBy(linkText = "Saving for education")
    private WebElement savingForEducationLinkRetiringAndEducationInvestmentsHeader;

    @FindBy(linkText = "Grow your wealth")
    private WebElement growYourWealthLinkRetiringAndEducationInvestmentsHeader;

    @FindBy(linkText = "Plan your children's future")
    private WebElement planYourChildrenLinkRetiringAndEducationInvestmentsHeader;

    @FindBy(linkText = "Plan your retirement")
    private WebElement planYourRetirementLinkRetiringAndEducationInvestmentsHeader;

    @FindBy(linkText = "Live your retirement")
    private WebElement liveYourRetirementLinkRetiringAndEducationInvestmentsHeader;

    /*
     * Investments and Financial planning - HSBC Premier Link
     */
    @FindBy(linkText = "HSBC Premier overview")
    private WebElement hsbcPremierOverviewLinkHSBCPremierInvestmentsHeader;

    /*
     * Investments and Financial planning - HSBC Advance Link
     */
    @FindBy(linkText = "HSBC Advance overview")
    private WebElement hsbcAdvanceOverviewLinkHSBCAdvanceInvestmentsHeader;


    /*
     * CONTACT HSBC
     */
    @FindBy(linkText = "Contact and support")
    private WebElement contactAndSupportLinkContactHSBCHeader;

    @FindBy(linkText = "Send a message")
    private WebElement sendAMessageLinkContactHSBCHeader;

    @FindBy(linkText = "Find a branch or ATM")
    private WebElement findABranchOrATMLinkContactHSBCHeader;

    @FindBy(linkText = "Have a specialist contact me")
    private WebElement haveASpecialistLinkContactHSBCHeader;

    @FindBy(linkText = "Book an appointment")
    private WebElement bookAnAppointmentLinkContactHSBCHeader;

    @FindBy(linkText = "HSBC on social media")
    private WebElement hsbcOnSocialMediaLinkContactHSBCHeader;


    /*
     * Existing Locators
     */
    @FindBy(linkText = "Add or remove a country")
    public WebElement addRemoveCountryLink;


    @FindBy(xpath = "//a[text()='Rename accounts']")
    public WebElement renameAccountsLink;

    @FindBy(xpath = "//*[@data-uid= 'lostStolenCard']")
    public WebElement reportLostStolenCard;


    @FindBy(linkText = "Future payments or transfers")
    public WebElement futurePayment;

    @FindBy(xpath = "//a[text()='GICs and Term Deposits']")
    public WebElement GICsAndTDLink;

    @FindBy(xpath = ".//a[@data-uid='payeemanagement']")
    private WebElement linkMyPayees;

    public FlyerMenuNavigation(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }


    /*
     * --------------------------- NAVIGATION FLOWS ---------------------------
     */
    @Override
    public void navigateToGlobalViewPage() {
        super.myMenu(addRemoveCountryLink);
    }

    @Override
    public void navigateToRenameAccountsPage() {
        super.myMenu(renameAccountsLink);
    }

    @Override
    public void navigateToReportLostOrStolenCardPage() {
        super.myMenu(reportLostStolenCard);
    }

    @Override
    public void navigateToFutureDatedTransaction() {
        super.myMenu(futurePayment);
    }

    @Override
    public void navigateToApplyOpenNewTD() {
        super.myMenuProductAndServices(gicAndTermDepositsLinkAccountOpeningProductAndServicesHeader);
    }

    @Override
    public void navigateToTFSA() {
        super.myMenuProductAndServices(taxFreeSavingsLinkAccountOpeningProductAndServicesHeader);
    }

    @Override
    public void navigateToEverydayBanking() {
        super.myMenuProductAndServices(everydayBankingLinkAccountOpeningProductAndServicesHeader);
    }

    @Override
    public void navigateToMypayeesPage() {
        super.myMenu(linkMyPayees);
    }


    @Override
    public void navigateToBillPaymentHistory() {
        super.myMenu(billPaymentHistoryLinkMoveMoneyMyBankingHeader);
    }

    @Override
    public void navigateToUpdateContactDetails() {

        super.myMenu(updatePersonalDetailsLinkMyProfileMyBankingHeader);
    }

    @Override
    public void navigateToStatementOrNotificationOptions() {
        super.myMenu(statementOrNotificationLinkMyProfileMyBankingHeader);
    }

    @Override
    public void navigateToAlertSettings() {
        super.myMenu(alertSettingsLinkMyProfileMyBankingHeader);
    }

    @Override
    public void navigateToMyAccount() {
        myMenu(myAccount);
    }


}
