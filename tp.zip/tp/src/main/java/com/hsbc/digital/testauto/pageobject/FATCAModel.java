/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.library.RandomUtil;

/***
 * <p>
 * <b> This model class will hold locators and functionality for FATCA page.
 * </b>
 * </p>
 * 
 * @author SatyaPrakash S Vyas
 * @version 1.0.0
 */
public abstract class FATCAModel {

    @FindBy(xpath = "//div[@id='stackContainer']//h2[text()='Citizenship information']")
    private List<WebElement> headingFATCAPage;

    @FindBy(xpath = "//input[contains(@id,'citizenshipYes') and @type='radio']")
    private WebElement radioYes;

    @FindBy(xpath = "//input[contains(@id,'citizenshipNo') and @type='radio']")
    private WebElement radioNo;

    @FindBy(xpath = "//div[@data-dojo-attach-point='_currentAddress']")
    private WebElement residentialAddress;

    @FindBy(xpath = "//input[starts-with(@id,'hdx_dijits_form_DateTextBox')]")
    private WebElement dateTextBox;

    @FindBy(xpath = "//input[@name='confirmradio']")
    private List<WebElement> radioButtons;

    @FindBy(xpath = "//span[contains(@class,'btnPrimary')]//span[text()='Continue']")
    private WebElement continueButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='cancelBtnNode']")
    private WebElement cancelButton;

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_Dialog_') and not (contains(@style,'display: none'))]//button[(@data-dojo-attach-point='_captureCancelYes')]")
    public WebElement cancelDialogYes;

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_Dialog_') and not (contains(@style,'display: none'))]//button[(@data-dojo-attach-point='_captureCancelNo')]")
    public WebElement cancelDialogNo;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(FATCAModel.class);

    public FATCAModel(final WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    public void fillCitizenshipPage(final boolean isYes) throws ParseException {
        if (!headingFATCAPage.isEmpty()) {
            if (isYes) {
                // TODO will be checked once have requirement for FATCA yes
                // scenario
            } else {
                Date finalDate = DateUtil.addYears(DateUtil.getSystemDate(), -5);
                dateTextBox.sendKeys(DateUtil.getDateToString("dd/MM/yyyy", finalDate));
                if (radioButtons.isEmpty()) {
                    int randomNumber = RandomUtil.generateIntNumber(0, radioButtons.size() - 1);
                    radioButtons.get(randomNumber).click();
                }
            }
        }
    }
}
