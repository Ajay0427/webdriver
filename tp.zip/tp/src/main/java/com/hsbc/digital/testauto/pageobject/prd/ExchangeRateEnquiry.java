/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.prd;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.hsbc.digital.testauto.pageobject.ExchangeRateEnquiryModel;

/**
 * <p>
 * <b> This class will hold locators and functionality related methods for
 * story Exchange Rate Enquiry specific to Canada Entity </b>
 * </p>
 * 
 * @author Deepti Patil
 * 
 */
public class ExchangeRateEnquiry extends ExchangeRateEnquiryModel {

    private static final String[] EXPECTED_CURRENCY_LIST = {"AUD", "CAD", "CHF", "CNY", "EUR", "GBP", "HKD", "JPY", "NZD", "SGD",
        "USD", "ZAR"};

    private static final String DEFAULT_CURRENCY = "CNY";

    public ExchangeRateEnquiry(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    /**
     * Method to add expected list of currencies.
     * 
     * @return array list of currencies
     */
    @Override
    public List<String> getExpectedCurrencyList() {
        return Arrays.asList(EXPECTED_CURRENCY_LIST);
    }

    @Override
    public String getDefaultCurrency() {
        return DEFAULT_CURRENCY;
    }

}
