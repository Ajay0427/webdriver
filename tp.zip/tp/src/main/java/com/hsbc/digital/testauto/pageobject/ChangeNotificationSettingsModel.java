/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 *
 *
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;


/***
 * <p>
 * <b> This model class will hold locators and functionality to Change
 * Notification Settings Page. </b>
 * </p>
 *
 * @author Midde Rajesh Kumar
 * @version 1.0.0
 */
public abstract class ChangeNotificationSettingsModel {

    protected final WebDriver driver;

    @FindBy(xpath = "//button[text()='Subscribe']")
	protected WebElement subscribeButton;

    @FindBy(xpath = "//td[@data-dojo-attach-point='titleNode']")
    protected WebElement accountDropDownIcon;

    @FindBy(xpath = "//div[@id='dapAccountsPopupDropDown_menu']/table/tbody/tr/td[contains(@id,'dijit_MenuItem')]")
    private List<WebElement> accountDropDownList;

    @FindBy(xpath = "//input[@value='Debits larger than']")
    private WebElement debitsLargerThanCheckBox;

    @FindBy(xpath = "//input[@value='Minimum balance']")
    private WebElement minimumBalanceCheckBox;

    @FindBy(xpath = "//input[@value='Credits larger than']")
    private WebElement creditsLargerThanCheckBox;

    @FindBy(xpath = "//button[@class='btnPrimary']")
    private WebElement continueButton;

    @FindBy(xpath = "//button[contains(@class,'btnTertiary')]")
    private WebElement cancleButton;

    @FindBy(xpath = "//button[contains(@class,'btnPrimary')]")
    private WebElement saveButton;

    @FindBy(xpath = "//a[contains(@class,'iconButton editIcon')]")
    private WebElement editPersonelDetailsLink;

    @FindBy(xpath = "//input[contains(@id,'email')]")
    private WebElement emailInput;

    /* ********** WebElements For Alert Settings Page ********** */

    @FindBy(xpath = "//div[contains(@class,'colStmt_paper')]//input")
    private WebElement statementsPaperRadioButton;

    @FindBy(xpath = "//div[contains(@class,'colStmt_electronic')]//input")
    private WebElement statementsOnlineRadioButton;

    @FindBy(xpath = "//div[contains(@class,'colUpdate_paper')]//input")
    private WebElement updatesPaperRadioButton;

    @FindBy(xpath = "//div[contains(@class,'colUpdate_secure_message')]//input")
    private WebElement updatesSecureMessageRadioButton;

    @FindBy(xpath = "//input[@id='communicationPreferencesBijit-acceptDisclChcek']")
    private WebElement acceptCheckBox;


    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(ChangeNotificationSettingsModel.class);

    public ChangeNotificationSettingsModel(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    /**
     *
     * This method is to Subscribe Notification Alerts
     *
     */
    public void subscribeAlerts() {
        subscribeButton.click();
        selectAccount();
        Assert.assertTrue(minimumBalanceCheckBox.isDisplayed(), "Minimum Balance Check Box is not Displayed");
        minimumBalanceCheckBox.click();
        Reporter.log("Minumum Balance Check Box is Clicked");
        continueButton.click();
        saveButton.click();
    }

    /**
     *
     * This method is to Select the Account from DropDown List
     *
     */
    public void selectAccount() {
        accountDropDownIcon.click();
        if (!accountDropDownList.isEmpty()) {
            int listCount = accountDropDownList.size();
            int selectedElementNumber = RandomUtil.generateIntNumber(1, listCount);
            for (int count = 0; count < listCount; count++) {
                WebElement tempAccDropDown = accountDropDownList.get(count);
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", tempAccDropDown);
                if (count == selectedElementNumber) {
                    Reporter.log("Account Selected:" + tempAccDropDown.getText());
                    tempAccDropDown.click();
                    break;
                }
            }
        } else {
            Assert.fail("No Accounts Avialable to Select");
        }
    }

    /**
     *
     * This method is to verify the cancel flow for subscribe notification
     * alerts
     *
     */
    public void verifyCancelFlowForSubscribeAlerts() {
        subscribeButton.click();
        selectAccount();
        minimumBalanceCheckBox.click();
        cancleButton.click();
        Assert.assertTrue(subscribeButton.isDisplayed(), "Subscribe Button is Not Displayed");
        Reporter.log("Subscribe Button is Displayed.");
    }

    /**
     *
     * This method is to verify the Edit Personal Details Page
     *
     */
    public void verifyEditPersonelDetailsPage() {
        editPersonelDetailsLink.click();
        Assert.assertTrue(emailInput.isDisplayed(), "Email Input Box is Not Displayed");
        Reporter.log("Email Input Box is Displayed.");

    }

    /**
     *
     * This method is to Set Statement Setting As Paper
     *
     */
    public void setStatementSettingAsPaper() {
        Assert.assertFalse(statementsPaperRadioButton.isSelected(), "Radio Button is Already Selected");
        statementsPaperRadioButton.click();
        Reporter.log("Paper Radio Button is selected");
        acceptCheckBox.click();
        Reporter.log("Accept Check Box is clicked");
        saveButton.click();
        Reporter.log("Save Button is Clicked");
        Assert.assertTrue(statementsPaperRadioButton.isSelected(), "Paper Radio Button is not Selected");
    }

    /**
     *
     * This method is to Set Statement Setting As Online
     *
     */
    public void setStatementSettingAsOnline() {
        Assert.assertFalse(statementsOnlineRadioButton.isSelected(), "Radio Button is Already Selected");
        statementsOnlineRadioButton.click();
        Reporter.log("Online Radio Button is selected");
        acceptCheckBox.click();
        Reporter.log("Accept Check Box is clicked");
        saveButton.click();
        Reporter.log("Save Button is Clicked");
        Assert.assertTrue(statementsOnlineRadioButton.isSelected(), "Online Radio Button is not Selected");
    }

    public void verifyTermsAndConditionPopUp() {}
}
