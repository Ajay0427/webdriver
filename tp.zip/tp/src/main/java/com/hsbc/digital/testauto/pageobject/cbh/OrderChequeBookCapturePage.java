/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.cbh;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.pageobject.OrderChequeBookCapturePageModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Order
 * Cheque Book for US entity. </b>
 * </p>
 */
public class OrderChequeBookCapturePage extends OrderChequeBookCapturePageModel {

    @FindBy(xpath = "//label[text()='Number of cheque books']/following-sibling::div//input[contains(@id,'arrowid') and contains(@id,'Select')]")
    private WebElement numberOfChequeBooksDropDownIcon;

    @FindBy(xpath = "//div[contains(@class,'dijitMenuActive')]")
    private WebElement activeDropDown;

    private final By noOfItems = By.xpath(".//td[contains(@id,'dijit_MenuItem') and contains(@id,'text')]");

    @FindBy(xpath = "//label[contains(text(),'Number of pages')]/following-sibling::div//input[contains(@id,'arrowid') and contains(@id,'Select')]")
    private WebElement numberOfPagesDropDownIcon;

    @FindBy(xpath = "//label[text()='Number of cheque books']/following-sibling::div//div[contains(@class,'InputField')]")
    private WebElement selectedNoOfChequeBooks;

    @FindBy(xpath = "//label[contains(text(),'Number of pages')]/following-sibling::div//div[contains(@class,'InputField')]")
    private WebElement selectedNoOfPages;

    @FindBy(xpath = "//label[text()='Account']/following-sibling::div//span[@class='accountSelectSingleOption']//span[@data-parent]")
    private List<WebElement> selectedAccountWithNoDropDown;

    @FindBy(xpath = ".//*[@id='dapManageAccContainer']//a[text()='Order a chequebook']")
    private List<WebElement> orderChequesLink;

    @FindBy(xpath = "//div[contains(@id,'SelectAccount')]//input[contains(@id,'arrowid')]")
    private WebElement accountDropDownIcon;

    private static final String ACCOUNT_TYPE_CODE = "CSV";

    private static final int EXPECTED_MAX_NUMBER_OF_BOOKS = 3;

    public OrderChequeBookCapturePage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    public boolean isOrderChequeBookLinkDisplayed() {
        if (!orderChequesLink.isEmpty()) {
            Reporter.log("Order Cheque Book link in manage tab is displayed. ");
            return true;
        } else {
            return false;
        }
    }

    @Override
    public AccountDetails selectDetailsOnCapturePage() {
        selectNumberOfChequeBooks();
        selectNumberOfPages();
        AccountDetails accDetail = setAccountDetails();
        clickContinueButton();
        return accDetail;
    }

    @Override
    public void captureDetailsForDuplicateCheque(final AccountDetails objAccountDetails) {
        selectNumberOfChequeBooks();
        selectNumberOfPages();
        String accountNumber = objAccountDetails.getAccountNumber();
        clickAccountDropDownButton();
        WebElement accNumber = driver.findElement(By
            .xpath("//td[contains(@id,'MenuItem') and contains(@id,'text')]//span[@class='accountDetails' and text()='"
                + accountNumber + "']"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", accNumber);
        accNumber.click();
    }

    @Override
    public void selectNumberOfChequeBooks() {
        clickNumberOfChequesDropDownButton();
        verifyMaximumNumberOfChequeBooks();
        selectValues(activeDropDown.findElements(noOfItems));
        Reporter.log("Number of Pages in cheque book Selected. ");
    }

    @Override
    public void selectNumberOfPages() {
        clickNumberOfPagesDropDown();
        selectValues(activeDropDown.findElements(noOfItems));
    }

    @Override
    public void selectValues(final List<WebElement> list) {
        int index = RandomUtil.generateIntNumber(0, list.size());
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", list.get(index));
        list.get(index).click();
    }

    public void clickNumberOfPagesDropDown() {
        numberOfPagesDropDownIcon.click();
    }

    @Override
    public void clickNumberOfChequesDropDownButton() {
        numberOfChequeBooksDropDownIcon.click();
    }

    @Override
    public void verifyMaximumNumberOfChequeBooks() {
        List<WebElement> noOfChequeBooks = activeDropDown.findElements(noOfItems);
        Assert.assertTrue(
            Integer.parseInt(noOfChequeBooks.get(noOfChequeBooks.size() - 1).getText()) == EXPECTED_MAX_NUMBER_OF_BOOKS,
            "Maximum number of books in list is not as expected. ");
        Reporter.log("Maximum number of books in list is as expected. ");
    }

    @Override
    public AccountDetails setAccountDetails() {
        AccountDetails accountDetails = new AccountDetails();
        selectAccount();
        String[] details = !selectedAccountWithNoDropDown.isEmpty() ? selectedAccountWithNoDropDown.get(0).getText()
            .split("\\r?\\n") : selectedAccount.getText().split("\\r?\\n");
        // String[] details = selectedAccount.getText().split("\\r?\\n");
        accountDetails.setAccountName(details[0]);
        accountDetails.setAccountNumber(details[1]);
        // accountDetails.setNumberOfChequeBooks(selectedNumberOfChequeBooks.getText());
        // return accountDetails;

        /* String[] details = selectedAccount.getText().split("\\r?\\n");
         accountDetails.setAccountName(details[0]);
         accountDetails.setAccountNumber(details[1]);*/
        accountDetails.setNumberOfChequeBooks(selectedNoOfChequeBooks.getText());
        accountDetails.setNumberOfPages(selectedNoOfPages.getText());
        return accountDetails;
    }

    public void clickOrderChequeBookLink() {
        orderChequesLink.get(0).click();
        Reporter.log("Order chequebook link clicked. ");
    }

    public void selectAccount() {
        clickAccountDropDownButton();
        selectValues(activeDropDown.findElements(noOfItems));
        Reporter.log("Account Selected. ");
    }

    public void clickAccountDropDownButton() {
        accountDropDownIcon.click();
        Reporter.log("Accounts selection drop down button clicked. ");
    }

    @Override
    public void verifyInvalidAccounts() {
        for (WebElement account : accountsLists) {
            if (account.getAttribute("unique-account-number").contains(ACCOUNT_TYPE_CODE)) {
                account.click();
                if (manageButtonList.isEmpty()) {
                    Reporter.log("Manage button not displayed for the account. ");
                } else {
                    clickManageButton();
                    Assert.assertTrue(orderChequesLink.isEmpty(),
                        "Order Cheque Book link is displayed for the account. Hence Failed. ");
                    Reporter.log("Order Cheque Book link is not displayed for the account. ");
                }
            }
        }
    }
}
