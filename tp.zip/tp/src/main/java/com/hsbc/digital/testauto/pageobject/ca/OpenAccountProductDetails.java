/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.ca;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import com.hsbc.digital.testauto.pageobject.OpenAccountProductDetailsModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Canada
 * entity. </b>
 * </p>
 */
public class OpenAccountProductDetails extends OpenAccountProductDetailsModel {

    private WebDriverWait wait;

    @FindBy(xpath = "//div[@class='btnApplNw']//span[text()='Open']")
    private WebElement applyNowButton;

    public OpenAccountProductDetails(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        this.wait = new WebDriverWait(driver, 30);
    }

    @Override
    public void clickApplyOnOpenTDPage() {
        wait.until(ExpectedConditions.elementToBeClickable(applyNowButton));
        applyNowButton.click();
        wait.until(ExpectedConditions.visibilityOf(personalDetailsForm));
        Reporter.log("Open Button clicked.");
    }
}
