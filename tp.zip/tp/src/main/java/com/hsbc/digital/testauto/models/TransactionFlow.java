package com.hsbc.digital.testauto.models;

public enum TransactionFlow {

    M2M_TRANSFER("M2MTransfer"), M2NMHSBC_TRANSFER("M2NMHSBCTransfer"), M2NMNONHSBC_TRANSFER("M2NMNonHSBCTransfer"), M2NMINTERNATIONAL_TRANSFER(
        "M2NMInternationalTransfer"), M2COMPANY_TRANSFER("M2Company"), M2MINTERNATIONAL_TRANSFER("M2MInternationalTransfer");

    private final String value;

    private TransactionFlow(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
