/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.digital.testauto.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.models.AccountDetails;

/**
 * <p>
 * <b> This Model class will hold locators and functionality related methods
 * for Story Order Cheque Book Confirmation Page that can be used around all
 * entities </b>
 * </p>
 * 
 * @version 1.0.0
 * @author Deepti Patil
 * 
 */

public abstract class OrderChequeBookConfirmPageModel {

    protected final WebDriver driver;

    /********************** Locators on Confirmation Page ******************************/
    // Locator for order cheque book page heading
    @FindBy(xpath = "//div[@id='orderChequeBookId']//h2")
    private WebElement orderChequeBookConfirmationPage;

    // Locator for confirmation message
    @FindBy(xpath = "//div[contains(@class,'confirmation')]/p")
    private WebElement confirmationMessage;

    // Locator for account number on Confirmation Page
    @FindBy(xpath = "//dd[@data-dojo-attach-point='_confirmAssociatedAccount']/span[contains(@class,'verifyAccountNumber')]")
    private WebElement accountNumberConfirmPage;

    // Locator for account name on Confirmation Page
    @FindBy(xpath = "//dd[@data-dojo-attach-point='_confirmAssociatedAccount']")
    private WebElement accountNameConfirmPage;

    // Locator for number Of Cheque books on Confirmation Page
    @FindBy(xpath = "//dd[@data-dojo-attach-point='_confirmNumberOfPagesInChequeBook']")
    protected WebElement numberOfChequeBookConfirmPage;

    // Locator for My Accounts Confirmation Page
    @FindBy(xpath = "//button[contains(text(),'My accounts')]")
    private WebElement myAccountsButton;

    // Locator for Disclaimer on Confirmation Page
    @FindBy(xpath = "//div[contains(@data-dojo-attach-point,'confirmation')]//div[contains(@class,'sectionedFooter')]/p")
    protected WebElement disclaimerMessageConfirmPage;

    private static final String EXPECTED_CONFIRM_PAGE_TITLE = "Confirmation";

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(OrderChequeBookConfirmPageModel.class);

    public OrderChequeBookConfirmPageModel(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void verifyNumberOfChequeBookConfirmPage(AccountDetails accountDetails) {}

    public void isDeliveryAddressOnConfirmPageDisplayed() {}

    public void isDisclaimerMessageOnConfirmPageDisplayed() {}

    public void confirmPageDetails(AccountDetails accountDetails) {
        verifyDetailsOnConfirmPage(accountDetails);
        clickMyAccountsButton();
    }

    /**
     * Method to verify details on confirmation page
     * 
     * @param account
     *            details
     */
    public void verifyDetailsOnConfirmPage(final AccountDetails accountDetails) {
        isOrderChequeConfirmPageDisplayed();
        isConfirmationMessageDisplayed();
        verifyAccountDetailsConfirmPage(accountDetails);
        verifyNumberOfChequeBookConfirmPage(accountDetails);
        isDeliveryAddressOnConfirmPageDisplayed();
        isDisclaimerMessageOnConfirmPageDisplayed();
    }

    /**
     * Method to verify confirmation message on confirmation page
     * 
     */
    public void isConfirmationMessageDisplayed() {
        Assert.assertTrue(confirmationMessage.isDisplayed(), "Confirmation message on confirmation page displayed. ");
        Reporter.log("Confirmation message on confirmation page displayed. ");
    }


    /**
     * Method to verify account selected on confirmation page
     * 
     * @param accountDetails
     */
    public void verifyAccountDetailsConfirmPage(final AccountDetails accountDetails) {
        Assert.assertTrue(accountNameConfirmPage.getText().contains(accountDetails.getAccountName())
            && accountDetails.getAccountNumber().equals(accountNumberConfirmPage.getText()),
            "Account Details on Confirmation page does not match. ");
        Reporter.log("Account Details on Confirmation page are same as selected. ");
    }

    /**
     * Method to click on My accounts button on confirmation page.
     * 
     */
    public void clickMyAccountsButton() {
        myAccountsButton.click();
        Reporter.log("My Accounts button clicked. ");
    }

    /**
     * Method to verify confirmation page is displayed.
     * 
     */
    public void isOrderChequeConfirmPageDisplayed() {
        Assert.assertTrue(orderChequeBookConfirmationPage.isDisplayed()
            && orderChequeBookConfirmationPage.getText().equalsIgnoreCase(EXPECTED_CONFIRM_PAGE_TITLE),
            "Order Cheque Book Verify Page is not displayed or displayed title does not match with expected title.. ");
        Reporter.log("Order Cheque Book Verify Page is displayed and displayed title matches with expected title. ");
    }
}
