package com.hsbc.digital.testauto.pageobject.uk;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

import com.hsbc.digital.testauto.pageobject.CommunicationPreferencesModel;


/**
 * Contains locators and functions of Communication Preferences story for UK -
 * Capture Page
 * 
 * @author Neha Rajesh Gupta
 * 
 * **/

public class CommunicationPreferences extends CommunicationPreferencesModel {

    private final By emailRadioButtonCapturePage = By.xpath("//input[contains(@id,'EMK')]");

    private final By messagesNDocumentsRadioButtonCapturePage = By.xpath("//input[contains(@id,'SEM')]");

    private final By telephoneRadioButtonCapturePage = By.xpath("//input[contains(@id,'TMI')]");

    private final By mobileMessagingRadioButtonCapturePage = By.xpath("//input[contains(@id,'MMA')]");

    private final By postRadioButtonCapturePage = By.xpath("//input[contains(@id,'DMI')]");

    @FindBy(xpath = "//div[contains(@id,'content')]/h1")
    private WebElement communicationPreferencesCapturePageHeading;

    @FindBy(xpath = "//div[contains(@class,'hsbcButtonCenter')]/a[contains(@title,'Confirm')]")
    private WebElement confirmButtonCapturePage;

    public CommunicationPreferences(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    public void capturePageHeadingDisplayed() {
        communicationPreferencesCapturePageHeading.isDisplayed();
        Reporter.log("Capture page heading is displayed.");
    }

    @Override
    public void clickOnConfirmButton() {
        confirmButtonCapturePage.isDisplayed();
        confirmButtonCapturePage.click();
        Reporter.log("Confirm button on capture page clicked successfully.");
    }

    @Override
    public boolean selectEmailRadioButtonCapturePage() {
        return selectRadioButton(emailRadioButtonCapturePage);
    }

    @Override
    public boolean selectMessagesNDocumentRadioButtonCapturePage() {
        return selectRadioButton(messagesNDocumentsRadioButtonCapturePage);
    }

    @Override
    public boolean selectTelephoneRadioButtonCapturePage() {
        return selectRadioButton(telephoneRadioButtonCapturePage);
    }

    @Override
    public boolean selectMobileMessagingRadioButtonCapturePage() {
        return selectRadioButton(mobileMessagingRadioButtonCapturePage);
    }

    @Override
    public boolean selectPostRadioButtonCapturePage() {
        return selectRadioButton(postRadioButtonCapturePage);
    }

    @Override
    public boolean selectRadioButton(By webElement) {
        boolean bValue = false;
        List<WebElement> oRadioButton = driver.findElements(webElement);
        bValue = oRadioButton.get(0).isSelected();
        if (bValue == true) {
            oRadioButton.get(1).click();
        } else {
            oRadioButton.get(0).click();
        }
        return bValue;
    }


}
