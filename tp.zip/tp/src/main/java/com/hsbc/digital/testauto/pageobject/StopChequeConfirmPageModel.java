package com.hsbc.digital.testauto.pageobject;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.models.StopChequeDetails;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

/**
 * <p>
 * <b> Stop Cheque Confirm page object model to hold generic function and
 * locators for story stop cheque</b>
 * </p>
 * 
 * @version 1.0.0
 * @author Neeraj Kumar
 */

public class StopChequeConfirmPageModel {

    protected final WebDriverWait wait;
    protected UICommonUtil uiCommonUtil;

    /**
     * Field Label on Confirm page
     */
    protected static final String LABEL_ACCOUNT = "Account";
    protected static final String LABEL_PAYEE_NAME = "Payee name";
    protected static final String LABEL_CHEQUE_NUMBER = "Cheque number";
    protected static final String LABEL_AMOUNT = "Amount";
    private static final String LABEL_CHEQUE_RANGE = "Cheque range";
    private static final String LABEL_ISSUE_DATE = "Issue date";
    private static final String LABEL_REASON_TO_STOP_CHEQUE = "Reason to stop cheque";
    private static final String TITLE_CONFIRM_PAGE = "Confirmation";

    protected String getLabelChequeRange() {
        return LABEL_CHEQUE_RANGE;
    }

    @FindBy(xpath = "//div[contains(@id, 'StopCheque')]//div[contains(@class, 'steptracker-heading')]//*[contains(@data-dojo-attach-point, 'dapPageTitle')]")
    protected WebElement confirmPageTitle;

    @FindBy(xpath = "//div[@class='subPanelWrap verificationPage confirmPage']//div[@class='row disclaimer']//p")
    private WebElement disclamierContainerElement;

    @FindBy(xpath = "//button[@type='button' and text()='Stop another cheque']")
    private WebElement stopAnotherChequeButton;

    protected WebElement getStopAnotherChequeButton() {
        return stopAnotherChequeButton;
    }

    @FindBy(xpath = "//button[@type='button' and text()='Stop another cheque']")
    private WebElement myAccountButton;

    @FindBy(xpath = "//div[@class='dijitStackContainerChildWrapper dijitVisible']//button[@type='button' and contains(@data-dojo-attach-point,'printContent')]")
    private WebElement printButton;

    @FindBy(xpath = "//p[@data-dojo-attach-point='dapAlertText']/span")
    private List<WebElement> confirmationPageTitleList;

    @FindBy(xpath = "//div[contains(@id, 'PrintFriendlyFormatDialog') and contains(@aria-labelledby, 'title')]")
    private WebElement printPage;

    @FindBy(xpath = "//div[contains(@id, 'PrintFriendlyFormatDialog')]//*[contains(@class, 'printFriendlyHeading')]")
    private WebElement printPageTitle;

    @FindBy(xpath = "//div[contains(@id, 'PrintFriendlyFormatDialog') and contains(@aria-labelledby, 'title')]//button[@data-dojo-attach-point= 'closeButton']")
    private WebElement cancelOnPrintDialogButton;


    public StopChequeConfirmPageModel(final WebDriver driver) {
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30000);
        uiCommonUtil = new UICommonUtil(driver);
    }

    public void verifyPageTitle() {
        wait.until(ExpectedConditions.visibilityOf(confirmPageTitle));
        Assert.assertTrue(confirmPageTitle.isDisplayed(), "Stop Cheque confirm page is not displayed.");
        Reporter.log("Stop Cheque confirm page is displayed.");
    }

    public void clickStopAnotherChequeButton() {
        wait.until(ExpectedConditions.elementToBeClickable(getStopAnotherChequeButton()));
        getStopAnotherChequeButton().click();
        Reporter.log("Stop Another Cheque button clicked on confirmationm page.");
    }

    public void clickPrintButton() {
        wait.until(ExpectedConditions.elementToBeClickable(printButton));
        printButton.click();
        Reporter.log("Print button clicked on Confirmation page.");
    }

    public void clickMyAccountButton() {
        wait.until(ExpectedConditions.elementToBeClickable(myAccountButton));
        myAccountButton.click();
        Reporter.log("My Account button clicked on Confirmation page.");
    }

    public void verifyPrintPageTitle() {
        wait.until(ExpectedConditions.visibilityOf(printPageTitle));
        Assert.assertTrue(printPageTitle.isDisplayed(), "Print Page is not displayed.");
        Reporter.log("Print Page is displayed.");
    }

    public void clickCancelOnPrintDialog() {
        wait.until(ExpectedConditions.elementToBeClickable(cancelOnPrintDialogButton));
        cancelOnPrintDialogButton.click();
        wait.until(ExpectedConditions.not(ExpectedConditions.visibilityOf(printPage)));
        Reporter.log("Print page is closed.");
    }

    protected void isPageTitleDisplayed(final WebElement pageTitle) {
        Assert.assertTrue(pageTitle.getText().equalsIgnoreCase(TITLE_CONFIRM_PAGE), "Page Title does not match.");
        Reporter.log("Page title is displayed as :" + pageTitle.getText());
    }

    protected void isIssueChequeAccountNameDisplayed(final StopChequeDetails stopChequeDetails) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_ACCOUNT, stopChequeDetails.getIssueChequeAccount()
            .getAccountName(), UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given Issue Cheque Account Name not found.");
        Reporter.log("Issue Cheque Account Name displayed is :" + stopChequeDetails.getIssueChequeAccount().getAccountName());
    }

    protected void isIssueChequeAccountNumberDisplayed(final StopChequeDetails stopChequeDetails) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_ACCOUNT, stopChequeDetails.getIssueChequeAccount()
            .getAccountNumber(), UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given Issue Cheque Account Number not found.");
        Reporter.log("Issue Cheque Account Number displayed is :" + stopChequeDetails.getIssueChequeAccount().getAccountNumber());
    }

    protected void isPayeeNameDisplayed(final StopChequeDetails stopChequeDetails) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PAYEE_NAME, stopChequeDetails.getPayeeName(),
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Payee Name not found.");
        Reporter.log("Payee Name displayed is :" + stopChequeDetails.getPayeeName());
    }

    protected void isChequeNumberDisplayed(final StopChequeDetails stopChequeDetails) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_AMOUNT, stopChequeDetails.getChequeNumber(),
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Cheque Number not found.");
        Reporter.log("Cheque Number displayed is :" + stopChequeDetails.getChequeNumber());
    }

    protected void isChequeRangeDisplayed(final StopChequeDetails stopChequeDetails) {
        String chequeRange = stopChequeDetails.getChequeNumber() + " � " + stopChequeDetails.getChequeEndNumber();
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(getLabelChequeRange(), chequeRange, UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Cheque Range not found.");
        Reporter.log(getLabelChequeRange() + "displayed is :" + chequeRange);
    }

    protected void isAmountDisplayed(final StopChequeDetails stopChequeDetails) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_AMOUNT, stopChequeDetails.getAmount(),
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Transfer Amount not found.");
        Reporter.log("Amount displayed is :" + stopChequeDetails.getAmount());
    }

    protected void isChequeIssueDateDisplayed(final StopChequeDetails stopChequeDetails) throws ParseException {
        Date parseDate = DateUtil.getStringToDate(DateUtil.DATE_FORMAT_MMDDYYYY, stopChequeDetails.getIssueDate());
        String chequeIssueDate = DateUtil.getDateToString(DateUtil.DATE_FORMAT_DDMMMYYYY, parseDate);
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_ISSUE_DATE, chequeIssueDate, UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Cheque Issue Date not found.");
        Reporter.log("Cheque Issue Dated displayed is :" + stopChequeDetails.getIssueDate());
    }

    protected void isReasonToStopChequeDisplayed(final StopChequeDetails stopChequeDetails) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_REASON_TO_STOP_CHEQUE,
            stopChequeDetails.getReasonToStopCheque(), UICommonUtil.confirmPage, UICommonUtil.pageFieldName,
            UICommonUtil.pageFieldValue), "Given Reason To StopCheque not found.");
        Reporter.log("Reason To StopCheque displayed is :" + stopChequeDetails.getAmount());
    }


    private void isDisclaimerMessageDisplayed() {
        Assert.assertTrue(disclamierContainerElement.isDisplayed(), "Disclaimer message is not displayed on confirmation page");
        Reporter.log("Disclaimer message is displayed as :" + disclamierContainerElement.getText());
    }

    public void validateConfirmPageWithChequeNumber(final StopChequeDetails stopChequeDetails) throws ParseException {
        wait.until(ExpectedConditions.visibilityOf(confirmPageTitle));
        isDisclaimerMessageDisplayed();
        isIssueChequeAccountNameDisplayed(stopChequeDetails);
        isIssueChequeAccountNumberDisplayed(stopChequeDetails);
        isPayeeNameDisplayed(stopChequeDetails);
        isChequeNumberDisplayed(stopChequeDetails);
        isAmountDisplayed(stopChequeDetails);
    }

    public void validateConfirmPageWithChequeRange(final StopChequeDetails stopChequeDetails) throws ParseException {
        wait.until(ExpectedConditions.visibilityOf(confirmPageTitle));
        isPageTitleDisplayed(confirmPageTitle);
        isDisclaimerMessageDisplayed();
        isIssueChequeAccountNameDisplayed(stopChequeDetails);
        isIssueChequeAccountNumberDisplayed(stopChequeDetails);
        isChequeRangeDisplayed(stopChequeDetails);
    }
}
