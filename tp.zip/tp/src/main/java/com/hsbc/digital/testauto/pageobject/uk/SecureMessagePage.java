/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.uk;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.ScreenShot;
import com.hsbc.digital.testauto.pageobject.SecureMessageModel;

/**
 * <p>
 * <b>This class will have locators and specific behavior for UK for Secure
 * Messaging story. </b>
 * </p>
 */
public class SecureMessagePage extends SecureMessageModel {

    @FindBy(xpath = "//p[@data-dojo-attach-point='_sendBlockHelpTextHead']")
    private WebElement LostStolenContactMessage;

    public SecureMessagePage(final WebDriver driver) {
        super(driver);
    }

    @Override
    public void isMessageExist(final String messageTitle) {

    }

    @Override
    public void typeAndSendMessage(final String message, final String subject) {
        if (subject.contains("Lost and Stolen") || subject.contains("Unrecognised Transaction")) {
            Assert.assertTrue(LostStolenContactMessage.isDisplayed(), "Contacts details not displayed");
            Reporter.log("Contacts details displayed");
        } else {
            typeMessage(message);
            ScreenShot.takeScreenShot(driver);
            sendButtons.get(0).click();
            Reporter.log("Clicked on Send Button");
        }
    }

}
