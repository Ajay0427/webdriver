package com.hsbc.digital.testauto.pageobject.us;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.AddBeneficiaryDetails;
import com.hsbc.digital.testauto.models.BankDetails;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

public class AddBeneficiary extends com.hsbc.digital.testauto.pageobject.AddBeneficiaryModel {
    protected final WebDriverWait wait;
    private final JavascriptExecutor jsx;

    private static final String ENTITY_BANK_COUNTRY = "US";
    private static final String COMPANY_PAYEE_DETAIL_ENTITY = "us";
    private static final int DEFAULT_ACCOUNT_NUMBER_LENGTH = 12;
    private static final String PAYEE_NAME_LABEL = "Payee Name";
    private static final String ACCOUNT_NUMBER_LABEL = "Your account number with payee";
    private static final String PAYEE_ADDRESS = "Address";
    private static final String SUCCESS_MSG = "added";
    private static final String ADDRSS_VALIDTN_WRNG_MSG = "The Address You entered is not valid";
    private static final String ZIP_CODE_SEPARATOR = "-";
    private String invalidAddressString = "";

    private final By locatorCompanyPayeeName = By
        .xpath("//div[starts-with(@id,'gridx_Grid_')]//td[contains(@class,'payeeName')]/span[2]");

    // ********************* Payee Search Options Fill up********************

    @FindBy(xpath = "//label[contains(@class,'forSelect') and contains(@for,'companyName')]//following-sibling::div[contains(@id,'hdx')]//input[contains(@id,'hdx')]")
    private WebElement enterCmpnyNameTxt;
    @FindBy(xpath = "//div[contains(@class,'newBillPaySection')]//label[contains(@class,'forSelect') and not(contains(@for,'company'))]//following-sibling::div[contains(@id,'hdx')]//input[contains(@id,'dijits')]")
    private WebElement enterCmpnyZipCodeTxt;
    @FindBy(xpath = "//input[@id='actNumb']")
    private WebElement enterCmpnyAccntNmbr;
    @FindBy(xpath = "//input[@id='reActNumb']")
    private WebElement reEnterCmpnyAccntNmbr;
    @FindBy(xpath = "//button[@value='Search Payee' and @class='btnSecondary']")
    private WebElement searchPayeeBtn;

    // ******************** Add Payee Options Pop UP *******************

    @FindBy(xpath = "//div[@class='searchDialog']/h1")
    private WebElement searchPayeePopUpTxt;
    @FindBy(xpath = ".//button[@data-dojo-attach-point='_addPayeeManual']")
    private WebElement addPayeeManuallyBtn;

    // ******************** After Selecting Manually Add Payee ****************

    @FindBy(xpath = "//input[contains(@id,'payeeNameLabel')]")
    private WebElement addManualPayeeName;
    @FindBy(xpath = ".//input[contains(@id,'addressLabel')]")
    private WebElement addPayeeFirstAddress;
    @FindBy(xpath = ".//input[contains(@id,'addressLabel1')]")
    private WebElement addPayeeSecondAddress;
    @FindBy(xpath = ".//input[contains(@id,'cityLabel')]")
    private WebElement addManuallyPayeeCity;
    @FindBy(xpath = "//table[contains(@aria-labelledby,'AddCompanyManually')]//td[contains(@class,'dijitArrowButton')]")
    private WebElement payeeStateDropDownArrow;
    @FindBy(xpath = "//div[contains(@id,'Select_')]//tr")
    private List<WebElement> payeeStateList;
    @FindBy(xpath = ".//input[contains(@id,'_zipCodeLabel')]")
    private WebElement addManuallyPayeeZip;
    @FindBy(xpath = ".//input[contains(@id,'zipCodeExtension')]")
    private WebElement zipCodeExtensiontxt;
    @FindBy(xpath = "//input[contains(@id,'AddCompanyManually') and contains(@name,'actNumName')]")
    private WebElement accountNumberTxt;
    @FindBy(xpath = ".//input[contains(@id,'_BillPayeeAccountNum')]")
    private WebElement toPayeeAccountNumber;
    @FindBy(xpath = ".//input[contains(@id,'confirmBillPayeeAccountNum')]")
    private WebElement confirmPayeeAccountNumber;
    @FindBy(xpath = ".//input[contains(@id,'telephoneLabel')]")
    private WebElement addManuallyPayeeTelephone;

    // *********************** Address Validation popUp Elements***************

    @FindBy(xpath = "//div[contains(@aria-labelledby,'ValidatePayee')]//div[contains(@class,'dijitDialogPaneContent')]")
    private WebElement addressValidationPopUp;
    @FindBy(xpath = "//p[contains(@data-dojo-attach-point,'warning')]")
    private WebElement warningMsgAddressValidation;
    @FindBy(xpath = "//div[contains(@class,'addPayeeVerifyDialog')]//button[contains(@data-dojo-attach-point,'continue')]")
    private WebElement continueBtnOnAddrssValidtnPopUp;
    @FindBy(xpath = "//div[contains(@class,'addPayeeVerifyDialog')]//button[contains(@data-dojo-attach-point,'Cancel')]")
    private WebElement cancelBtnOnAddrssValidtnPopUp;
    @FindBy(xpath = "//div[contains(@class,'validatePayeeAdrssContent')]/div[contains(@class,'addressList')]")
    private List<WebElement> validAddressList;
    private final By companyAddress = By.xpath("//span[contains(@class,'billAddrss')]");
    private final By companyStreet = By.xpath("//span[contains(@class,'billStreet')]");
    private final By companyCity = By.xpath("//span[contains(@class,'billCity')]");
    private final By companyState = By.xpath("//span[contains(@class,'billState')]");
    private final By companyZipCode = By.xpath("//span[contains(@class,'billZipCode')]");

    /********************** Review page Elements **************/

    @FindBy(xpath = "//div[contains(@id,'AddPayeeVerifyDialog')]//div[contains(@class,'DialogPaneContent')]")
    private WebElement reviewPagePopUp;
    @FindBy(xpath = "//div[contains(@class,'addPayeeVerifyDialog')]//h1[contains(@class,'printFriendlyHeading')]")
    private WebElement reviewPagetxt;
    @FindBy(xpath = "//div[contains(@id,'AddPayeeVerifyDialog')]//div[contains(@class,'submitButtonsPanel')]/button[contains(@data-dojo-attach-point,'continueButton')]")
    private WebElement confirmBtnOnReviewPage;
    @FindBy(xpath = "//div[contains(@id,'AddPayeeVerifyDialog')]//div[contains(@class,'submitButtonsPanel')]/button[contains(@data-dojo-attach-point,'CancelButton')]")
    private WebElement cancelBtnOnReviewPage;
    private final By payeeAddressValue = By
        .xpath("//div[contains(@class,'itemValue')]/span[contains(@data-dojo-attach-point,'BillPayeeAddressValue')]");
    private final By payeeStreetValue = By
        .xpath("//div[contains(@class,'itemValue')]/span[contains(@data-dojo-attach-point,'BillPayeeStreetValue')]");
    private final By payeeCityValue = By
        .xpath("//div[contains(@class,'itemValue')]/span[contains(@data-dojo-attach-point,'BillPayeeCityValue')]");
    private final By payeeStateValue = By
        .xpath("//div[contains(@class,'itemValue')]/span[contains(@data-dojo-attach-point,'BillPayeeStateValue')]");

    /************************** Confirm Page Elements *******************/

    @FindBy(xpath = "//p[contains(@data-dojo-attach-point,'messagePlace')]")
    private WebElement confirmPayeeMsg;
    @FindBy(xpath = "//div[contains(@id, 'Confirm')]//button[contains(@data-dojo-attach-point,'closeButton')]")
    private WebElement confirmPageCancelBtn;


    public AddBeneficiary(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30000);
        jsx = (JavascriptExecutor) driver;
    }


    /**
     * Getter setter methods for invalid Address String
     */

    private void setInvalidAddressString(final String invalidAddressString) {
        this.invalidAddressString = invalidAddressString;
    }

    private String getInvalidAddressString() {
        return invalidAddressString;
    }

    /**
     * method starts from here @author Md Tanbir Hossain
     */
    @Override
    protected List<AccountDetails> validCompanyPayeeDetails() {
        List<AccountDetails> storeAccountValue = new ArrayList<>();
        storeAccountValue.clear();
        List<WebElement> payeeList = driver.findElements(locatorAllPayeesRow);
        if (!payeeList.isEmpty()) {
            for (WebElement payee : payeeList) {
                jsx.executeScript(SCROLL_TO_VIEW, payee);
                if (payee.findElement(locatorPayeeType).getAttribute("alt").equalsIgnoreCase(COMPANY_PAYEE)) {
                    String companyPayeeName = payee.findElement(locatorPayeeName).getText();
                    String companyPayeeNickName = payee.findElement(locatorCompanyPayeeName).getText();
                    String companyPayeeNumber = payee.findElement(
                        By.xpath("//div[starts-with(@id,'gridx_Grid_')]//td[contains(@class,'payeeName')]/strong[text()='"
                            + companyPayeeName + "']/parent::*//span[1]")).getText();
                    AccountDetails accountInformations = new AccountDetails();
                    accountInformations.setAccountName(companyPayeeName);
                    accountInformations.setAccountNumber(companyPayeeNumber);
                    accountInformations.setAccountNickName(companyPayeeNickName);
                    storeAccountValue.add(accountInformations);
                }
            }
        }
        return storeAccountValue;
    }

    /**
     * @author Ranadeep Banik Condition for checking payee nickname (if
     *         available) included
     */
    @Override
    public AccountDetails payToSelectedPayee(final AccountDetails accountDetail) {
        List<WebElement> payeeRows = driver.findElements(locatorAllPayeesRow);
        for (WebElement payeeRow : payeeRows) {
            jsx.executeScript(SCROLL_TO_VIEW, payeeRow);
            String personPayeeName = payeeRow.findElement(locatorPayeeName).getText();
            WebElement payBtnElement = payeeRow.findElement(payButton);
            if (personPayeeName.equalsIgnoreCase(accountDetail.getAccountName())
                || personPayeeName.equalsIgnoreCase(accountDetail.getAccountNickName())) {
                payBtnElement.isEnabled();
                payBtnElement.click();
                break;
            }
        }
        return accountDetail;
    }

    @Override
    protected String getEntityBankCountry() {
        return ENTITY_BANK_COUNTRY;
    }

    @Override
    protected List<AccountDetails> validPersonPayeeDetails(final String entityCurrency, final boolean domesticHSBCPayee,
        final boolean domesticAccount, final boolean domesticCurrency) {
        List<AccountDetails> storeAccountValue = new ArrayList<>();
        String entity = getEntityBankCountry();
        List<WebElement> payeeList = driver.findElements(locatorAllPayeesRow);
        for (WebElement payee : payeeList) {
            jsx.executeScript(SCROLL_TO_VIEW, payee);
            if (payee.findElement(locatorPayeeType).getAttribute("alt").equalsIgnoreCase(PERSON_PAYEE)) {
                String personPayeeName = payee.findElement(locatorPayeeNickName).getText().isEmpty() ? payee.findElement(
                    locatorPayeeName).getText() : payee.findElement(locatorPayeeNickName).getText();
                WebElement btnView = payee.findElement(locatorViewPayee);
                wait.until(ExpectedConditions.elementToBeClickable(btnView));
                btnView.click();
                wait.until(ExpectedConditions.visibilityOf(payee.findElement(locatorManagePerson)));
                WebElement elemManagePerson = payee.findElement(locatorManagePerson);
                String personPayeeBankCountry = domesticHSBCPayee ? payee.findElement(locatorPayeeCountry).getText() : (String) jsx
                    .executeScript(GET_HIDDEN_TEXT, elemManagePerson.findElement(locatorPayeeBankCountry));
                String personPayeeNumber = elemManagePerson.findElement(locatorPayeeAccountNumber).getText();
                String personPayeeCurrency = elemManagePerson.findElement(locatorPayeeCurrency).getText();
                if (isValidPayee(domesticAccount, domesticCurrency, entity, entityCurrency, personPayeeBankCountry,
                    personPayeeCurrency) && !personPayeeBankCountry.trim().isEmpty()) {
                    AccountDetails accountDetails = addPayeeAccountInformation(personPayeeName, personPayeeNumber,
                        personPayeeBankCountry, personPayeeCurrency);
                    storeAccountValue.add(accountDetails);
                }
            }
        }
        return storeAccountValue;
    }

    /**
     * @author Ranadeep Banik
     * 
     */

    private void enterCompanyName(final String companyName) {
        enterCmpnyNameTxt.clear();
        enterCmpnyNameTxt.sendKeys(companyName);
    }

    private void enterCompanyZipCode(final String zipCode) {
        enterCmpnyZipCodeTxt.clear();
        enterCmpnyZipCodeTxt.sendKeys(zipCode);
    }

    private void enterAccountNumber(final String accntNmbr) {
        enterCmpnyAccntNmbr.clear();
        enterCmpnyAccntNmbr.sendKeys(accntNmbr);
        reEnterCmpnyAccntNmbr.clear();
        reEnterCmpnyAccntNmbr.sendKeys(accntNmbr);
    }

    @Override
    public int addCompanyPayee() {
        int companyPayeeCount = getAllpayeesCount();
        Map<String, String> properties = FileUtil.getConfigProperties(COMPANY_PAYEE_DETAIL_ENTITY);
        String companyNameSearch = properties.get("CompanyName");
        String companyZipSearch = properties.get("ZipCode");
        String accntNumber = RandomUtil.generateIntNumber(DEFAULT_ACCOUNT_NUMBER_LENGTH);
        wait.until(ExpectedConditions.elementToBeClickable(newPayeeTab));
        newPayeeTab.click();
        wait.until(ExpectedConditions.visibilityOf(enterCmpnyNameTxt));
        enterCompanyName(companyNameSearch);
        enterCompanyZipCode(companyZipSearch);
        enterAccountNumber(accntNumber);
        searchPayeeBtn.click();
        wait.until(ExpectedConditions.visibilityOf(searchPayeePopUpTxt));
        return companyPayeeCount;
    }

    private void clickAddPayeeManuallyButton() {
        wait.until(ExpectedConditions.elementToBeClickable(addPayeeManuallyBtn));
        addPayeeManuallyBtn.click();
    }

    private String addPayeeName(final String payeeName) {
        wait.until(ExpectedConditions.visibilityOf(addManualPayeeName));
        addManualPayeeName.sendKeys(payeeName);
        return payeeName;
    }

    private AddBeneficiaryDetails addPayeeNameManually() {
        AddBeneficiaryDetails payeeDetails = new AddBeneficiaryDetails();
        String payeeName = RandomUtil.generateAlphaNumericText(RandomUtil.generateIntNumber(5, 10));
        clickAddPayeeManuallyButton();
        payeeDetails.setPayeeName(addPayeeName(payeeName));
        return payeeDetails;
    }

    @Override
    public String selectCompanyPayee() {
        return addPayeeNameManually().getPayeeName();
    }

    private String addPayeeAddrss1(final String address1) {
        addPayeeFirstAddress.clear();
        addPayeeFirstAddress.sendKeys(address1);
        return address1;
    }

    private String addPayeeAddrss2(final String address2) {
        addPayeeSecondAddress.clear();
        addPayeeSecondAddress.sendKeys(address2);
        return address2;
    }

    private String enterPayeeCity(final String payeeCity) {
        addManuallyPayeeCity.clear();
        addManuallyPayeeCity.sendKeys(payeeCity);
        return payeeCity;
    }

    private String selectPayeeStateFromDropDown(final String payeeState) {
        payeeStateDropDownArrow.click();
        for (WebElement states : payeeStateList) {
            jsx.executeScript(SCROLL_TO_VIEW, states);
            if (states.getText().contains(payeeState)) {
                states.click();
            }
        }
        return payeeState;
    }

    private String addPayeeZipCode(final String payeeZipCode) {
        addManuallyPayeeZip.clear();
        addManuallyPayeeZip.sendKeys(payeeZipCode);
        return payeeZipCode;
    }

    private String addPayeeZipCodeExtension(final String payeeZipCodeExtension) {
        zipCodeExtensiontxt.clear();
        zipCodeExtensiontxt.sendKeys(payeeZipCodeExtension);
        return payeeZipCodeExtension;
    }

    private String fetchPayeeAccountNumber() {
        return accountNumberTxt.getAttribute("value");
    }

    private void addPayeeTelephone(final String telephone) {
        addManuallyPayeeTelephone.clear();
        addManuallyPayeeTelephone.sendKeys(telephone);
    }

    @Override
    public BankDetails enterCompanyPayeeInvalidDetails() {
        setInvalidAddressString(RandomUtil.generateAlphaNumericText(3));
        return enterCompanyPayeeDetails();
    }

    @Override
    public BankDetails enterCompanyPayeeDetails() {
        BankDetails objBankDetails = new BankDetails();
        Map<String, String> properties = FileUtil.getConfigProperties(COMPANY_PAYEE_DETAIL_ENTITY);
        String bankAdd1 = getInvalidAddressString() + properties.get("PayeeAdd1");
        String bankAdd2 = getInvalidAddressString() + properties.get("PayeeAdd2");
        String bankCity = getInvalidAddressString() + properties.get("PayeeCity");
        String bankState = properties.get("PayeeState");
        String bankZipCode = properties.get("PayeeZip");
        String bankZipCodeExtension = properties.get("PayeeZipExtn");
        String telephone = properties.get("Telephone");
        objBankDetails.setBankAddress1(addPayeeAddrss1(bankAdd1));
        objBankDetails.setBankAddress2(addPayeeAddrss2(bankAdd2));
        objBankDetails.setBankCity(enterPayeeCity(bankCity));
        objBankDetails.setBankState(selectPayeeStateFromDropDown(bankState));
        objBankDetails.setBankZipCode(addPayeeZipCode(bankZipCode));
        objBankDetails.setBankZipCodeExtension(addPayeeZipCodeExtension(bankZipCodeExtension));
        objBankDetails.setAccountNumber(fetchPayeeAccountNumber());
        addPayeeTelephone(telephone);
        return objBankDetails;
    }

    public void isPayeeNameDisplayed(final AddBeneficiaryDetails objAddBeneficiaryDetails, final By pageElement) {
        Assert.assertTrue(commonUtil.textByParentAndSibling(PAYEE_NAME_LABEL, objAddBeneficiaryDetails.getPayeeName(), pageElement,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Payee name Label is Not Displayed");
        logger.info("Payee Name verified Successfully");
    }

    public void isAddressDisplayed(final BankDetails bankDetails, final By pageElement) {
        Assert.assertTrue(commonUtil.textByParentAndSibling(PAYEE_ADDRESS, bankDetails.getBankAddress1(), pageElement,
            UICommonUtil.pageFieldName, payeeAddressValue), "Payee Address Not Matched");
        Assert.assertTrue(commonUtil.textByParentAndSibling(PAYEE_ADDRESS, bankDetails.getBankAddress2(), pageElement,
            UICommonUtil.pageFieldName, payeeStreetValue), "Payee Street Not Matched");
        Assert.assertTrue(commonUtil.textByParentAndSibling(PAYEE_ADDRESS, bankDetails.getBankCity(), pageElement,
            UICommonUtil.pageFieldName, payeeCityValue), "Payee City Not Matched");
        Assert.assertTrue(commonUtil.textByParentAndSibling(PAYEE_ADDRESS,
            bankDetails.getBankState() + " " + bankDetails.getBankZipCode(), pageElement, UICommonUtil.pageFieldName,
            payeeStateValue), "Payee State Not Matched");
        logger.info("Address Field verified Successfully");
    }

    public void isAccountNumberDisplayed(final BankDetails bankDetails, final By pageElement) {
        Assert.assertTrue(commonUtil.textByParentAndSibling(ACCOUNT_NUMBER_LABEL, bankDetails.getAccountNumber(), pageElement,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Account Number Not Found");
        logger.info("Account Number Successfully Verified");
    }

    @Override
    public void verifyPayeeReviewPage(final AddBeneficiaryDetails objAddBeneficiaryDetails) {
        wait.until(ExpectedConditions.visibilityOf(reviewPagePopUp));
        isPayeeNameDisplayed(objAddBeneficiaryDetails, UICommonUtil.verifyPage);
        isAddressDisplayed(objAddBeneficiaryDetails.getBankDetails(), UICommonUtil.verifyPage);
        isAccountNumberDisplayed(objAddBeneficiaryDetails.getBankDetails(), UICommonUtil.verifyPage);
        logger.info("Review Page elements validated Successfully");
    }

    @Override
    public void clickConfirmOnReviewPage() {
        wait.until(ExpectedConditions.elementToBeClickable(confirmBtnOnReviewPage));
        confirmBtnOnReviewPage.click();
    }

    @Override
    public void verifySucessMessage(final AddBeneficiaryDetails addBeneficiaryDetails) {
        wait.until(ExpectedConditions.visibilityOf(confirmPayeeMsg));
        Assert
            .assertTrue(confirmPayeeMsg.getText().contains(SUCCESS_MSG), "Confirmation Added Payee Succesfully Message Not Shown");
        isPayeeNameDisplayed(addBeneficiaryDetails, UICommonUtil.confirmPage);
        isAddressDisplayed(addBeneficiaryDetails.getBankDetails(), UICommonUtil.confirmPage);
        isAccountNumberDisplayed(addBeneficiaryDetails.getBankDetails(), UICommonUtil.confirmPage);
        logger.info("Confirmation Page elements validated Successfully");
    }

    @Override
    public void closeConfirmDialog() {
        confirmPageCancelBtn.click();
    }

    @Override
    public void clickContinueOnAddressValidationPopUp() {
        wait.until(ExpectedConditions.elementToBeClickable(continueBtnOnAddrssValidtnPopUp));
        continueBtnOnAddrssValidtnPopUp.click();
        logger.info("Continue Button Clicked on Address Validation Pop Up");
    }

    @Override
    public void clickCancelOnAddressValidationPopUp() {
        wait.until(ExpectedConditions.elementToBeClickable(cancelBtnOnAddrssValidtnPopUp));
        cancelBtnOnAddrssValidtnPopUp.click();
        logger.info("Cancel Button Clicked on Address Validation Pop Up");
    }

    public BankDetails validateAddressList(final List<BankDetails> objBankDetailsList) {
        if (objBankDetailsList.size() > 1) {
            int randomIndex = RandomUtil.generateIntNumber(DEFAULT_LIST_STARTING_INDEX, objBankDetailsList.size() - 1);
            return objBankDetailsList.get(randomIndex);
        }
        return objBankDetailsList.get(0);
    }

    public BankDetails validateAddress(BankDetails objBankDetails) {
        List<BankDetails> validBankDetailsList = new ArrayList<>();
        if (!validAddressList.isEmpty()) {
            for (WebElement addressLine : validAddressList) {
                jsx.executeScript(SCROLL_TO_VIEW, addressLine);
                String bankAddress = addressLine.findElement(companyAddress).getText();
                String bankStreet = addressLine.findElement(companyStreet).getText();
                String bankCity = addressLine.findElement(companyCity).getText();
                String bankZipCode = addressLine.findElement(companyZipCode).getText();
                String bankState = addressLine.findElement(companyState).getText();
                objBankDetails.setBankAddress1(bankAddress);
                objBankDetails.setBankAddress2(bankStreet);
                objBankDetails.setBankCity(bankCity);
                objBankDetails.setBankZipCode(bankZipCode);
                objBankDetails.setBankState(bankState);
                validBankDetailsList.add(objBankDetails);
            }
        }
        return validateAddressList(validBankDetailsList);
    }

    @Override
    public BankDetails validateAddressFromFinalistMapi(AddBeneficiaryDetails objAddBeneDetails) {
        Assert.assertTrue(addressValidationPopUp.isDisplayed(), "Validation Pop up Not Displayed");
        Assert.assertTrue(warningMsgAddressValidation.getText().contains(ADDRSS_VALIDTN_WRNG_MSG),
            "Address Validation Warning Message not Shown");
        return validateAddress(objAddBeneDetails.getBankDetails());
    }

    @Override
    public void reEnterCompanyPayeeDetailsWithCorrectAddress(final BankDetails objBankDetails) {
        String zipCode = objBankDetails.getBankZipCode().contains(ZIP_CODE_SEPARATOR) ? objBankDetails.getBankZipCode().substring(
            DEFAULT_LIST_STARTING_INDEX, objBankDetails.getBankZipCode().indexOf(ZIP_CODE_SEPARATOR.charAt(0))) : objBankDetails
            .getBankZipCode();
        addPayeeAddrss1(objBankDetails.getBankAddress1());
        addPayeeAddrss2(objBankDetails.getBankAddress2());
        enterPayeeCity(objBankDetails.getBankCity());
        selectPayeeStateFromDropDown(objBankDetails.getBankState());
        addPayeeZipCode(zipCode);
    }


}
