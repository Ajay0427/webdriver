package com.hsbc.digital.testauto.pageobject.us;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.pageobject.DownloadStatementHistoryModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Download
 * Statement History for PRD entity. </b>
 * </p>
 */
public class DownloadStatementHistory extends DownloadStatementHistoryModel {

    public DownloadStatementHistory(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = ".//input[contains(@id,'AccountSelect')]")
    private WebElement accountDropDownIcon;

    @FindBy(xpath = "//*[contains(@class,'iconButton viewDownload')]")
    private List<WebElement> downloadButton;

    @FindBy(xpath = "//div[contains(@class,'requestReasonValidationMessage')]//span[contains(@class,'dijitSelectLabel')]")
    private WebElement reasonForRequestLabel;

    @FindBy(xpath = ".//*[contains(@id,'otherReasonLbl')]")
    private WebElement otherReasonsLabel;

    @Override
    public void selectAccountFromDropDownList() {
        selectFromDropDown(accountDropDownIcon, tempDropdownList);
    }

    @Override
    public void selectRequestStatementAccountFromDropDownList() {
        selectFromDropDown(accountDropDownIcon, dropDwnList);
    }

    @FindBy(xpath = ".//input[contains(@id,'form_Select')]")
    private WebElement dateDropDownIcon;

    @FindBy(xpath = ".//*[contains(@class,'selectByDatePopup')]//tbody/tr")
    private List<WebElement> dateDropdownList;


    @Override
    public void selectFromStatementDropDownList() {
        selectFromDropDown(statementTypeOptnlDropDwnIcon, dropDwnList);
    }

    @Override
    public void selectFromReasonForRequestDropDownList() {
        requestReasonValidationMessageDropDwnIcon.click();

        int index = RandomUtil.generateIntNumber(1, dropDwnList.size());
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", dropDwnList.get(index));
        dropDwnList.get(index).click();
        if ("Other".equalsIgnoreCase(reasonForRequestLabel.getText())) {
            otherReasonsLabel.click();
            otherReasonsLabel.sendKeys(RandomUtil.generateAlphaNumericText(10));
        }
    }


    @Override
    public AccountDetails selectYearFromDropdown() {
        AccountDetails accountDetails = new AccountDetails();
        selectedYear = selectYearFromDropDownList(dateDropdownList);
        accountDetails.setSelectedYear(selectedYear);
        Reporter.log("Year: " + selectedYear + " selected from Search By Date List");
        return accountDetails;
    }


    @Override
    public String selectYearFromDropDownList(final List<WebElement> dateList) {
        dateDropDownIcon.click();
        String selectedDate = StringUtils.EMPTY;
        int datelistCount = dateList.size();
        int selectedElementNumber = RandomUtil.generateIntNumber(1, datelistCount - 1);
        for (int count = 0; count < datelistCount; count++) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", dateList.get(count));
            if (count == selectedElementNumber) {
                selectedDate = dateList.get(count).getText();
                Reporter.log("Dropdown Selected:" + selectedDate);
                dateList.get(count).click();
                break;
            }
        }
        return selectedDate;
    }

    @Override
    public void verifyDateDropDownList() {
        dateDropDownIcon.click();

        List<WebElement> datesDropdownList = dateDropdownList;
        for (WebElement elem : datesDropdownList) {

            Reporter.log("Date DropDown Options: " + elem.getText());
        }

    }

    public static final String EXPECTEDERRORMESSAGE = "There are no statements to show for this account.";

    @FindBy(xpath = ".//*[contains(@id,'notificationMessageId')]")
    private WebElement noTransactionHistoryMessage;

    @FindBy(xpath = ".//*[contains(@id,'notificationMessageId')]")
    private List<WebElement> noTransactionHistoryMessages;

    @Override
    public void verifyNoTransactionHistoryMessage() {
        if (noTransactionHistoryMessages.size() > 0) {

            Assert.assertTrue(noTransactionHistoryMessage.isDisplayed(), "There are Transactions avilable");
        } else {

            Reporter.log("No Statement Transaction History Message not displayed");
        }
    }

    @Override
    public void clickAndVerifyDownloadTransaction() {
        int index = Integer.parseInt(RandomUtil.generateIntNumber(downloadButton.size()));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", downloadButton.get(index));
        downloadButton.get(index).click();
        // downloadButton.get(Integer.parseInt(RandomUtil.generateIntNumber(downloadButton.size()))).click();
    }
}