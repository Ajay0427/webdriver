/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.cbh;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.hsbc.digital.testauto.pageobject.ViewPrintFeeTnCModel;

/**
 * <p>
 * <b> This model class will hold locators and functionality for View Fee Terms
 * and conditions To navigate to this page we need to click Tariif of Charges
 * link under MyBanking tab </b>
 * </p>
 * 
 * @author Neeraj Kumar
 * @version 1.0.0
 */
public class ViewPrintFeeTnC extends ViewPrintFeeTnCModel {

    // xpath to find Products & Services heading
    @FindBy(xpath = "//ul[@data-dojo-attach-point='menuNode']/li[2]")
    public WebElement productservicingLink;

    // xpath of link to navigate Edit Tariff Of Charges page
    @FindBy(xpath = "//a[@data-uid='tariffOfCharges']")
    public WebElement tariffOfChargesLink;

    // xpath of button to to close tab
    @FindBy(xpath = "//button[@title='Close']")
    public WebElement closeButton;

    // xpath of button to to download file
    @FindBy(xpath = "//button[@title='Download as PDF']")
    public WebElement downloadAsPDFButton;


    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(ViewPrintFeeTnC.class);


    public ViewPrintFeeTnC(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);

    }


}
