/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.prd;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Flyover
 * Menu for PRD(China) entity. </b>
 * </p>
 */
public class FlyerMenuNavigation extends FlyerMenuNavigationModel {

    /*
     * -------- HEADER LINKS --------
     */
    @FindBy(xpath = "//a[contains(@class,'navigation-link')]//span[contains(text(),'Products & Services')]")
    private WebElement productAndServicesLinkHeader;

    @FindBy(xpath = "//a[contains(@class,'navigation-link')]//span[contains(text(),'My investments')]")
    private WebElement myInvestmentsLinkHeader;

    /*
     * FOR MASS
     */
    /*
     * My Banking Header Links
     */
    @FindBy(linkText = "My accounts")
    public WebElement myAccountLinkMyBankingHeader;

    /*
     * My Banking - My profile Links
     */
    @FindBy(linkText = "Update Personal details")
    private WebElement updatePersonalDetailsLinkMyProfileMyBankingHeader;

    @FindBy(linkText = "Statement/notification options")
    private WebElement statementOrNotificationLinkMyProfileMyBankingHeader;

    @FindBy(linkText = "Alert settings")
    private WebElement alertSettingsLinkMyProfileMyBankingHeader;

    /*
     * My Banking - Limits Header Links
     */
    @FindBy(linkText = "Manage Internet Banking Limits")
    private WebElement manageInternetLimitsLinkLimitsMyBankingHeader;

    /*
     * My Banking - Time Deposits Header Links
     */
    @FindBy(linkText = "Open new time deposit")
    private WebElement openTimeDepositLinkTimeDepositMyBankingHeader;

    /*
     * My Banking - More Serivces Header Links
     */
    @FindBy(linkText = "Mobile Alerts Service")
    private WebElement mobileAlertsServiceLinkMoreServiceMyBankingHeader;

    @FindBy(xpath = "//a[contains(text(),'Request Replacement PIN for Debit Card')]")
    private WebElement requestPINLinkMoreServiceMyBankingHeader;

    /*
     * My Banking - Move Money Header Links
     */
    @FindBy(linkText = "Transfer and Currency Conversion")
    private WebElement transferCurrencyLinkMoveMoneyMyBankingHeader;

    @FindBy(linkText = "Future dated transfers")
    private WebElement futureDatedTransferLinkMoveMoneyMyBankingHeader;

    /*
     * My Banking - Statements Header Links
     */
    @FindBy(linkText = "Statements / Advices")
    private WebElement statementOrAdvicesLinkStatementsMyBankingHeader;

    @FindBy(linkText = "Request Account E-Statement and E-Advice")
    private WebElement requestEStatementLinkStatementsMyBankingHeader;

    /*
     * Products & Services
     */
    @FindBy(linkText = "Product Centre")
    private WebElement productCenterLinkProductServicesHeader;

    @FindBy(linkText = "Tariff Of Charges")
    private WebElement tariffChargesLinkProductServicesHeader;

    @FindBy(linkText = "Interest Rate Enquiry")
    private WebElement interestRateLinkProductServicesHeader;

    @FindBy(linkText = "Forex Rate Enquiry")
    private WebElement forexRateLinkProductServicesHeader;

    /*
     * My Investments - Investment Overview Header Links
     */
    @FindBy(linkText = "My Investment Portfolio")
    private WebElement myInvestmentPortfolioLinkOverviewMyInvestmentHeader;

    @FindBy(linkText = "My risk profiler")
    private WebElement myRiskProfilerLinkOverviewMyInvestmentHeader;

    /*
     * My Investments - Investment Product Header Link
     */
    @FindBy(linkText = "Dual Currency Investment")
    private WebElement dualCurrencyLinkProductMyInvestmentHeader;

    @FindBy(linkText = "Online QDII Trading Platform")
    private WebElement onlineQDIITradingLinkProductMyInvestmentHeader;

    @FindBy(linkText = "Online Structured Products Trading Platform")
    private WebElement onlineStructuredTradingLinkProductMyInvestmentHeader;

    /*
     * Contact HSBC - General Support Header Link
     */
    @FindBy(linkText = "Contact Us")
    private WebElement contactUsLinkGeneralSupportContactHSBCHeader;

    @FindBy(linkText = "Find a Branch or ATM")
    private WebElement findBranchOrATMLinkGeneralSupportContactHSBCHeader;

    @FindBy(linkText = "Report a Lost or Stolen Card")
    private WebElement reportLostCardLinkGeneralSupportContactHSBCHeader;

    /*
     * Contact HSBC - Security Header Link
     */
    @FindBy(linkText = "View all messages")
    private WebElement viewAllMessagesLinkSecurityContactHSBCHeader;

    @FindBy(linkText = "New messages")
    private WebElement newMessagesLinkSecurityContactHSBCHeader;

    @FindBy(linkText = "Manage Security Key")
    private WebElement manageSecurityKeyLinkSecurityContactHSBCHeader;

    @FindBy(linkText = "Change Security Settings")
    private WebElement changeSecuritySettingsLinkSecurityContactHSBCHeader;


    /*
     * FOR PREMIER
     */
    /*
     * My Banking - Global View Header Link
     */
    @FindBy(xpath = "Add / Remove a country or territory")
    private WebElement addOrRemoveCountryLinkGlobalViewMyBankingHeader;

    /*
     * Existing Locators
     */
    @FindBy(linkText = "Add / Remove a country or territory")
    public WebElement addRemoveCountryLink;

    @FindBy(linkText = "Manage Internet Banking Limits")
    public WebElement manageInternetBankingLimitsLink;

    @FindBy(linkText = "Open new time deposit")
    public WebElement openNewTimeDeposit;

    @FindBy(linkText = "Future dated transfers")
    public WebElement futurePayment;

    @FindBy(linkText = "Request Replacement PIN for Debit Card / Phone Banking")
    public WebElement requestReplacementPin;

    @FindBy(linkText = "Transfer and Currency Conversion")
    public WebElement payOrTransfer;

    public FlyerMenuNavigation(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    // /*
    // * Change
    // */
    // /*
    // * --------------------------- NAVIGATION FLOWS
    // ---------------------------
    // */
    // public void myBankingOverlay(final WebElement elementLink) {
    // mouseOverOnHeader(myBankingLinkHeader);
    // elementLink.click();
    // }
    //
    // public void myMenuProductNServices(final WebElement elementLink) {
    // mouseOverOnHeader(productAndServicesLinkHeader);
    // elementLink.click();
    // }
    //
    // /*
    // * My Banking
    // */
    // @Override
    // public void navigateToGlobalViewPage() {
    // myBankingOverlay(addOrRemoveCountryLinkGlobalViewMyBankingHeader);
    // }
    //
    // @Override
    // public void navigateToApplyOpenNewTimeDeposit() {
    // myBankingOverlay(openTimeDepositLinkTimeDepositMyBankingHeader);
    // }
    //
    // @Override
    // public void navigateToManageInternetBankingLimits() {
    // myBankingOverlay(manageInternetLimitsLinkLimitsMyBankingHeader);
    // }
    //
    // @Override
    // public void navigateToFutureDatedTransaction() {
    // myBankingOverlay(futureDatedTransferLinkMoveMoneyMyBankingHeader);
    // }
    //
    // @Override
    // public void navigateToRequestReplacementPin() {
    // myBankingOverlay(requestPINLinkMoreServiceMyBankingHeader);
    // }
    //
    // @Override
    // public void navigateToNewTransactionPage() {
    // myBankingOverlay(transferCurrencyLinkMoveMoneyMyBankingHeader);
    // }


    /*
     * --------------------------- NAVIGATION FLOWS ---------------------------
     */
    @Override
    public void navigateToGlobalViewPage() {
        super.myMenu(addRemoveCountryLink);
    }

    @Override
    public void navigateToApplyOpenNewTD() {
        super.myMenu(openNewTimeDeposit);
    }

    @Override
    public void navigateToManageInternetBankingLimits() {
        super.myMenu(manageInternetBankingLimitsLink);
    }

    @Override
    public void navigateToFutureDatedTransaction() {
        super.myMenu(futurePayment);
    }

    @Override
    public void navigateToRequestReplacementPin() {
        super.myMenu(requestReplacementPin);
    }

    @Override
    public void navigateToNewTransactionPage() {
        myMenu(payOrTransfer);
    }

    @Override
    public void navigateToStatementsAndAdvices() {
        super.myMenu(statementOrAdvicesLinkStatementsMyBankingHeader);
    }

    @Override
    public void navigateToMobileAlertService() {
        super.myMenu(mobileAlertsServiceLinkMoreServiceMyBankingHeader);
    }

    @Override
    public void navigateToBillPaymentHistory() {}

    @Override
    public void navigateToUpdateContactDetails() {}

    @Override
    public void navigateToStatementOrNotificationOptions() {
        super.myMenu(statementOrNotificationLinkMyProfileMyBankingHeader);
    }

    @Override
    public void navigateToAlertSettings() {
        super.myMenu(alertSettingsLinkMyProfileMyBankingHeader);
    }

}
