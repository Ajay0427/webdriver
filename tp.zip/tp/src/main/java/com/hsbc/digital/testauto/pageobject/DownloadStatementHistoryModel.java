/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

/***
 * <p>
 * <b> This model class will hold locators and functionality for Download
 * Statement History page. </b>
 * </p>
 * 
 * @author Midde Rajesh Kumar
 * @version 1.0.0
 */

public abstract class DownloadStatementHistoryModel {

    protected final WebDriver driver;
    WebDriverWait wait;
    UICommonUtil uiCommonUtil;

    /* ********** This section is for statement and advice section *********** */

    @FindBy(xpath = "//table[@id='group_gpib_newstmt_bijit_StatementDownload_0_Account']/tbody/tr/td[2]")
    private WebElement accountDropDownIcon;

    @FindBy(xpath = "//div[contains(@class,'dijitSelectMenu')]")
    private WebElement accountDropDownItems;

    @FindBy(xpath = "//div[contains(@id,'StatementDownload')]/following::tr[starts-with(@id,'dijit_MenuItem_')]")
    protected List<WebElement> tempDropdownList;

    @FindBy(xpath = "//table[@id='selectByDate']/tbody/tr/td[2]")
    protected WebElement dateDropDownIcon;

    @FindBy(xpath = "//div[contains(@class,'dijit dijitReset dijitInline dijitLeft dijitDownArrowButton dijitSelectMenu dijitSelect dijitValidationTextBox')]")
    private WebElement dateDropDownItems;

    @FindBy(xpath = "//div[contains(@dijitpopupparent,'selectByDate')]/div/div/div[contains(@id,'selectByDate_')]/table/tbody/tr")
    protected List<WebElement> dateDropdownList;

    @FindBy(xpath = "//a[@class='btnSecondary' and contains(@href,'requestPaperCopy')]")
    private WebElement requestAStatementBtn;

    @FindBy(xpath = "//*[contains(@class,'iconButton viewDownload')]")
    protected WebElement downloadButton;

    @FindBy(xpath = "//div[@class='disclaimer' and @data-dojo-attach-point='_legalDisclaimerAtPt']")
    protected WebElement disclaimer;

    @FindBy(xpath = "//div[contains(@id,'SecureMsgsAccountSelect')]//div[@class='optionItem reqPaperAcct']")
    protected List<WebElement> requestStatementAccounts;

    @FindBy(xpath = "//div[contains(@data-dojo-attach-point,'statementDownloadList')]/span")
    private WebElement downloadStatementList;

    @FindBy(xpath = ".//*[contains(@id,'dateRangeLblArr') and contains(@class,'dijitArrowButtonInner')]")
    private WebElement fromStatementDateIcon;

    @FindBy(xpath = ".//*[contains(@id,'dateRangeLblRet') and contains(@class,'dijitArrowButtonInner')]")
    private WebElement toStatementDateIcon;

    @FindBy(xpath = "//table[contains(@id,'dateRangeLblArr_popup')]")
    private WebElement fromStatementDateTable;

    @FindBy(xpath = "//table[contains(@id,'dateRangeLblRet_popup')]")
    private WebElement toStatementDateTable;

    @FindBy(xpath = ".//input[contains(@id,'stmtPageRangeLblTo') or contains(@id,'StmtPageRangeLblTo')]")
    private WebElement stmtPageRangeLblTo;

    @FindBy(xpath = ".//input[contains(@id,'stmtPageRangeLblFrom') or contains(@id,'StmtPageRangeLblFrom')]")
    private WebElement stmtPageRangeLblFrom;

    @FindBy(xpath = "//div[contains(@class,'requestReasonValidationMessage')]//input[contains(@id,'arrowid_hdx_dijits_form_Select_')]")
    protected WebElement requestReasonValidationMessageDropDwnIcon;

    @FindBy(xpath = "//div[contains(@class,'statementType')]/label[contains(@class,'statementTypeOptnl')]/following-sibling::div//input[@class='dijitReset dijitInputField dijitArrowButtonInner']")
    protected WebElement statementTypeOptnlDropDwnIcon;

    @FindBy(xpath = "//div[contains(@class,'dijitMenuActive')]//tr")
    protected List<WebElement> dropDwnList;

    @FindBy(xpath = ".//h2[@data-dojo-attach-point='headingRequestPaperCopy']")
    private WebElement headingRequestPaperCopy;

    @FindBy(xpath = ".//*[contains(@class,'EdtBtn')]")
    private WebElement editBtn;

    @FindBy(xpath = ".//button[@data-dojo-attach-point='btnCancelVerify']")
    private WebElement cancelBtn;

    @FindBy(xpath = "//div[contains(@class,'cancelPanel ')]//h2[@class='DeleteMessage']")
    private WebElement dialogBox;

    @FindBy(xpath = ".//button[@data-dojo-attach-point='btnCancelDialogNo']")
    private WebElement btnCancelDialogNo;

    @FindBy(xpath = ".//button[@data-dojo-attach-point='btnCancelDialogYes']")
    private WebElement btnCancelDialogYes;

    @FindBy(xpath = "//button[@data-dojo-attach-point='btnSubmit']")
    private WebElement continuebtn;

    // Review Your Request Page
    @FindBy(xpath = "//button[@data-dojo-attach-point='btnSubmitVerify']")
    private WebElement sendBtn;

    // Confirmation Page
    @FindBy(xpath = "//p[@class='fontBldContactR']")
    private WebElement confirmation;

    @FindBy(xpath = "//span[@title='Statements']")
    private WebElement statementPageTitle;

    @FindBy(xpath = "//span[@title='Request a statement']")
    private WebElement requestStatementPageTitle;

    @FindBy(xpath = "//div[@data-dojo-attach-point='_downloadSoftwareAtPt']")
    private WebElement addtionalSoftInfo;

    @FindBy(xpath = "//div[contains(@class,'dijitDialogFixed') and not(contains(@style,'display: none'))]")
    protected List<WebElement> listCancelDialog;

    /* This section is for The result data */
    @FindBy(xpath = "//div[contains(@data-dojo-attach-point,'statementDownloadList')]/div[contains(@id,'StatementDownloadItem_')]")
    protected List<WebElement> resultedList;
    // Not able to capture element due to unavailability of test data

    @FindBy(xpath = "")
    private WebElement noTransactionHistoryMessage;

    @FindBy(xpath = "//button[@data-dojo-attach-point='btnCancel']")
    private WebElement capturePageCancel;

    protected String selectedYear;

    public static final String EXPECTEDERRORMESSAGE = "No Transaction History";

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(DownloadStatementHistoryModel.class);

    public DownloadStatementHistoryModel(final WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, 30);
        uiCommonUtil = new UICommonUtil(driver);
        PageFactory.initElements(driver, this);

    }

    /* @Prateek */
    public void requiredSoftwareInfo() {
        Assert.assertEquals(addtionalSoftInfo.isDisplayed(), true);
        WebElement ele = addtionalSoftInfo.findElement(By.xpath("//a[@class='downloadSoftwareCopy']"));
        Assert.assertEquals(ele.isDisplayed(), true);
        DownloadStatementHistoryModel.logger.info(" Download Additional Software :" + ele.getText());
    }

    public void selectRequestStatementAccountFromDropDownList() {}

    public void legalDisclaimer() {
        if (disclaimer.isDisplayed()) {
            DownloadStatementHistoryModel.logger.info("Legal Disclaimer is Present.");
        } else {
            DownloadStatementHistoryModel.logger.info("Legal Disclaimer is Not Present.");
        }
    }

    public void clickOnCapturePageCancelBtn() {
        Assert.assertEquals(capturePageCancel.isEnabled(), true);
        capturePageCancel.click();
        DownloadStatementHistoryModel.logger.info("Clicked On 'Capture Page Cancel Button' of " + headingRequestPaperCopy.getText()
            + " Page.");
    }

    public void navigateToRequestAStatmentPage() {
        requestAStatementBtn.click();
    }

    public void checkForStatementPage() {
        Assert.assertEquals("Statements".equalsIgnoreCase(statementPageTitle.getText()), true);
        DownloadStatementHistoryModel.logger.info("' " + statementPageTitle.getText() + "' Page is Displayed.");
    }

    public void checkForRequestStatementPage() {
        Assert.assertEquals("Request a statement".equalsIgnoreCase(requestStatementPageTitle.getText()), true);
        DownloadStatementHistoryModel.logger.info("' " + requestStatementPageTitle.getText() + "' Page is Displayed.");
    }

    public void selectFromReasonForRequestDropDownList() {}

    public void selectFromStatementDropDownList() {}

    public Date getPreviousDateString() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -200);
        return cal.getTime();
    }

    public WebElement getFromStatementDateIcon() {
        return fromStatementDateIcon;
    }

    public WebElement getToStatementDateIcon() {
        return toStatementDateIcon;
    }

    public WebElement getFromStatementDateTable() {
        return fromStatementDateTable;
    }

    public WebElement getToStatementDateTable() {
        return toStatementDateTable;
    }

    public void stmtPageRangeLblFrom(final String range) {
        stmtPageRangeLblFrom.clear();
        stmtPageRangeLblFrom.click();
        stmtPageRangeLblFrom.sendKeys(range);
    }

    public void stmtPageRangeLblTo(final String range) {
        stmtPageRangeLblTo.clear();
        stmtPageRangeLblTo.click();
        stmtPageRangeLblTo.sendKeys(range);
    }

    public void clickOnEditBtn() {
        Assert.assertEquals(headingRequestPaperCopy.isDisplayed(), true, headingRequestPaperCopy.getText());
        Assert.assertEquals(editBtn.isEnabled(), true);
        DownloadStatementHistoryModel.logger.info("'" + headingRequestPaperCopy.getText() + "' Page has Displayed.");
        editBtn.click();
    }

    public void clickOnCancelBtn() {
        Assert.assertEquals(cancelBtn.isEnabled(), true);
        cancelBtn.click();
        DownloadStatementHistoryModel.logger.info("Clicked On Cancel button of " + headingRequestPaperCopy.getText() + " Page.");
    }

    public void clickOnContinueBtn() {
        Assert.assertEquals(continuebtn.isEnabled(), true);
        continuebtn.click();
    }

    public void clickOnSendBtn() {
        Assert.assertTrue(sendBtn.isDisplayed());
        sendBtn.click();
        DownloadStatementHistoryModel.logger.info("Clicked On Send button of " + headingRequestPaperCopy.getText() + " Page.");
    }

    public void reviewYourRequestDialogBox(final boolean isCancel) {
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        Assert.assertEquals(dialogBox.isDisplayed(), true);
        Assert.assertEquals(btnCancelDialogNo.isDisplayed(), true);
        Assert.assertEquals(btnCancelDialogYes.isDisplayed(), true);
        if (isCancel) {
            DownloadStatementHistoryModel.logger.info(btnCancelDialogYes.getText() + " is clicked On.");
            btnCancelDialogYes.click();

        } else {
            DownloadStatementHistoryModel.logger.info(btnCancelDialogNo.getText() + " is clicked On.");
            btnCancelDialogNo.click();
        }
    }


    /* Separate method for Request Paper Statement Page... */
    public void requestPaperStatementSubMethod() throws ParseException {

        selectRequestStatementAccountFromDropDownList();
        uiCommonUtil.selectDate(getFromStatementDateIcon(), getFromStatementDateTable(), getPreviousDateString());
        Integer randomNum = RandomUtil.generateIntNumber(5, 10);
        stmtPageRangeLblFrom("" + RandomUtil.generateIntNumber(1, randomNum));
        stmtPageRangeLblTo(randomNum.toString() + "");
        selectFromStatementDropDownList();
        selectFromReasonForRequestDropDownList();
    }

    public void checkForConfirmationPage() {
        Assert.assertTrue(confirmation.isDisplayed());
        DownloadStatementHistoryModel.logger.info(confirmation.getText());
    }

    /**
     * 
     * This method is for selection the Account from the drop down list
     * 
     */
    public void selectAccountFromDropDownList() {

        selectFromDropDown(accountDropDownIcon, tempDropdownList);
    }

    public void selectFromDropDown(final WebElement dropDownIconElement, final List<WebElement> tempDropdownList) {
        dropDownIconElement.click();
        int listCount = tempDropdownList.size();
        int selectedElementNumber = RandomUtil.generateIntNumber(1, listCount);
        for (int count = 1; count < listCount; count++) {
            WebElement tempAccDropDown = tempDropdownList.get(count);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", tempAccDropDown);
            if (count == selectedElementNumber) {
                Reporter.log("Dropdown Selected:" + tempAccDropDown.getText());
                tempAccDropDown.click();
                break;
            }
        }
    }

    public AccountDetails selectYearFromDropdown() {
        AccountDetails accountDetails = new AccountDetails();
        selectedYear = selectYearFromDropDownList(dateDropdownList);
        accountDetails.setSelectedYear(selectedYear);
        Reporter.log("Year: " + selectedYear + " selected from Search By Date List");
        return accountDetails;
    }

    /**
     * 
     * This method is for selection the year from the drop down list
     * 
     */
    public String selectYearFromDropDownList(final List<WebElement> dateList) {
        dateDropDownIcon.click();
        String selectedDate = StringUtils.EMPTY;
        int datelistCount = dateList.size();
        int selectedElementNumber = RandomUtil.generateIntNumber(0, datelistCount);
        for (int count = 0; count < datelistCount; count++) {
            WebElement tempAccDropDown = dateList.get(count);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", tempAccDropDown);
            if (count == selectedElementNumber) {
                selectedDate = tempAccDropDown.getText();
                Reporter.log("Dropdown Selected:" + selectedDate);
                tempAccDropDown.click();
                break;
            }
        }
        return selectedDate;
    }

    /**
     * 
     * This method is to verify the download button functionality
     * 
     * @throws InterruptedException
     * 
     */
    public void clickAndVerifyDownloadTransaction() throws InterruptedException {
        int currentWindowCount = driver.getWindowHandles().size();
        downloadButton.click();
        int newWindowCount = driver.getWindowHandles().size();
        Assert.assertTrue(newWindowCount > currentWindowCount, "DownLoad Page Opened");
    }

    /**
     * 
     * This method is for verifying if no history statements are avialable
     * 
     */
    public void verifyNoTransactionHistoryMessage() {
        Assert.assertTrue(noTransactionHistoryMessage.isDisplayed(), "There are no Transactions avilable");
        Reporter.log("No Statement Transaction History Message displayed");
    }

    /**
     * 
     * This method is to select notification channel preference
     * 
     */

    public void notificationChannelPreference() {
        Reporter.log("Please call the notification prference methods here");
    }

    /**
     * 
     * This method is to notify the user by sms
     * 
     */
    public void userIsNotifiedBySms() {
        Reporter.log("Please check Your Cell for Confirmation");
    }

    /**
     * 
     * This method is to notify the user by email
     * 
     */
    public void userIsNotifiedByEmail() {
        Reporter.log("Please check Your Mail for Confirmation");
    }

    /**
     * This functionality is not yet implemented
     * 
     * 
     */
    public void selectFutrueDateToTerminateAlerts() {

    }

    /**
     * This functionality is to print the List of dates
     * 
     * 
     */

    public void verifyDateDropDownList() {
        dateDropDownIcon.click();
        List<WebElement> datesDropdownList = dateDropdownList;
        for (WebElement elem : datesDropdownList) {
            Reporter.log("Date DropDown Options: " + elem.getText());
        }
    }

    /**
     * This is to get the input format for the respective entity
     * 
     * @return
     */
    public String getOutputFormat() {
        return DateUtil.DATE_FORMAT_DDMMMYYYY;
    }

    /**
     * 
     * This method is for verifying the order of displayed transaction history
     */
    public void verifyOrderofDisplay() {
        String firstDateDisplayes = StringUtils.EMPTY;
        String nextDateDisplayes;
        Date firstDate;
        Date nextDate;
        if (selectedYear.contains(firstDateDisplayes)) {
            for (int i = 0; i < resultedList.size() - 1; i++) {
                firstDateDisplayes = resultedList.get(i).findElement(By.tagName("span")).getText();
                nextDateDisplayes = resultedList.get(i + 1).findElement(By.tagName("span")).getText();
                try {
                    firstDate = DateUtil.getStringToDate(getOutputFormat(), firstDateDisplayes);
                    nextDate = DateUtil.getStringToDate(getOutputFormat(), nextDateDisplayes);
                    if (firstDate.after(nextDate) || firstDate.equals(nextDate)) {
                        Reporter.log("Statement History Displayed in correct Order");
                    } else {
                        Reporter.log("Statement History Displayed is not in correct Order");
                        Assert.fail("Statement history sorting failed.");
                    }
                } catch (ParseException e) {
                    DownloadStatementHistoryModel.logger.error("Date Format Conversion Error", e);
                    Assert.fail("Statement history sorting failed with date parsing error.", e);
                }

            }
        } else if (("Latest").equalsIgnoreCase(selectedYear)) {
            for (int i = 0; i < resultedList.size() - 1; i++) {
                firstDateDisplayes = resultedList.get(i).findElement(By.tagName("span")).getText();
                nextDateDisplayes = resultedList.get(i + 1).findElement(By.tagName("span")).getText();
                try {
                    firstDate = DateUtil.getStringToDate(getOutputFormat(), firstDateDisplayes);
                    nextDate = DateUtil.getStringToDate(getOutputFormat(), nextDateDisplayes);
                    if (firstDate.after(nextDate)) {
                        Reporter.log("Statement History Displayed in correct Order");
                    } else {
                        Reporter.log("Statement History Displayed is not in correct Order");
                        Assert.fail("Statement history sorting failed.");
                    }
                } catch (ParseException e) {
                    DownloadStatementHistoryModel.logger.error("Date Format Conversion Error", e);
                    Assert.fail("Statement history sorting failed with date parsing error.", e);
                }
            }
        }
    }
}