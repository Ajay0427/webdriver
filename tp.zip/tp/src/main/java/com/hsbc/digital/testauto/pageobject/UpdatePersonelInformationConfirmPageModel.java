/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.hsbc.digital.testauto.models.UpdatePersonalInformation;


/***
 * <p>
 * <b> This model class will hold locators and functionality to Update Contact
 * Details confirm page. </b>
 * </p>
 * 
 * @author Neha Rajesh Gupta
 * @version 1.0.0
 */

public abstract class UpdatePersonelInformationConfirmPageModel {
    protected final WebDriver driver;


    public UpdatePersonelInformationConfirmPageModel(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void confirmationMessageDisplayed() {}

    public void validateConfirmPage(UpdatePersonalInformation updatePersonalInformation) {}

    public void myAccountsButtonDisplayed() {}

    public void printButtonDisplayed() {}

    public void validateConfirmPageDetails(UpdatePersonalInformation updatePersonalInformation) {
        confirmationMessageDisplayed();
        validateConfirmPage(updatePersonalInformation);
        myAccountsButtonDisplayed();
        printButtonDisplayed();
    }

    public void verifyErrorMessageFlow() {
        invalidEmailAddressMessageDisplayed();
        clickOnOKButtonOnErrorPage();
    }

    public void clickOnOKButtonOnErrorPage() {}

    public void invalidEmailAddressMessageDisplayed() {}

}
