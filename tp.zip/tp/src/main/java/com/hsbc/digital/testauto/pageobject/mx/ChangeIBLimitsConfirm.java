/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.mx;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.pageobject.ChangeIBLimitsConfirmModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Mexico
 * entity. </b>
 * </p>
 */
public class ChangeIBLimitsConfirm extends ChangeIBLimitsConfirmModel {

    private static final String SUCCESS_MESSAGE = "Your transfer limits have been updated ";

    @FindBy(xpath = "//div[contains(@class,'changeLimit')]//div[contains(@class,'confirmation')]/div")
    private WebElement successMessageBox;

    @FindBy(xpath = "//button[@data-dojo-attach-point='backToAcc']")
    private WebElement myAccountsButton;

    @FindBy(xpath = "//*[@id='_dashboardHeading']/h1/span[text()='My accounts - Dashboard']")
    private WebElement dashboardPage;

    public ChangeIBLimitsConfirm(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    public void validateSuccessMessage() {
        Reporter.log("confirmation message shown is: " + successMessageBox.getText());
        Assert.assertTrue(ChangeIBLimitsConfirm.SUCCESS_MESSAGE.equalsIgnoreCase(successMessageBox.getText()),
            "Success Message does not match. ");
    }

    @Override
    public void clickPrintButton() {
        Reporter.log("Print functionality is not applicable for Mexico. ");
    }

    @Override
    public void clickMyAccountsButton() {
        wait.until(ExpectedConditions.elementToBeClickable(myAccountsButton));
        myAccountsButton.click();
        wait.until(ExpectedConditions.visibilityOf(dashboardPage));
        Reporter.log("My Accounts button clicked and dashboard page shown. ");
    }

}
