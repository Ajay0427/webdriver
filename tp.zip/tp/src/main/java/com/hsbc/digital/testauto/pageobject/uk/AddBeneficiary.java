package com.hsbc.digital.testauto.pageobject.uk;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;

public class AddBeneficiary extends com.hsbc.digital.testauto.pageobject.AddBeneficiaryModel {

    @FindBy(xpath = "//div[@id='hdx_dijits_Dialog_6']")
    private WebElement cannotDeleteDialog;

    @FindBy(xpath = "//button[contains(@class,'btnQuaternary btnIcon')]//span[@class = 'person']")
    protected WebElement personTabsPayees;

    @FindBy(xpath = "//button[contains(@class,'btnQuaternary btnIcon')]//span[@class = 'company']")
    protected WebElement companyTabsPayees;

    public AddBeneficiary(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    public void verifyHSBCPersoPayeeDetails(final WebElement element) {
        String displayName = element.findElement(payeeName).getText();
        WebElement viewButtonElement = element.findElement(viewButton);
        viewButtonElement.isEnabled();
        viewButtonElement.click();
        wait.until(ExpectedConditions.visibilityOf(personPayeeDetailsView));
        String name = verifyPayeeNameField(personPayeeDetailsView, LABEL_PAYEE_NAME);
        Assert.assertTrue(displayName.equals(name), "Person payee name is NOT  matched in Details pane");
        verifyField(personPayeeDetailsView, accountNumberField, accountNumbervalue);
        personPayeeDetailsView.findElement(closeButton).click();
    }

    @Override
    public void deletePayee(final WebElement element) {
        String displayName = element.findElement(payeeName).getText();
        int beforeCnt = getAllpayeesCount();
        WebElement button = element.findElement(deleteButton);
        button.isEnabled();
        button.click();
        wait.until(ExpectedConditions.visibilityOf(delPayeeDialog));
        if (displayName.equalsIgnoreCase(getPayeeNameOnDialog().getText())) {
            Reporter.log("Payee Name is  present on delete popup");
        } else {
            Reporter.log("Payee Name is not present on delete popup");
        }
        delPayeeDialog.findElement(deletBtnOnDialog).isEnabled();
        delPayeeDialog.findElement(deletBtnOnDialog).click();
        if (sucessMsg.isDisplayed()) {
            String payeeDeleted = deletedPayeeName.getText().substring(1, deletedPayeeName.getText().length() - 1);
            Assert.assertTrue(displayName.equalsIgnoreCase(payeeDeleted),
                "Payee name dispalyed in sucess message is not the correct payee");
            Reporter.log("Payee Name " + deletedPayeeName.getText() + "is  present in sucess message");
            Assert.assertTrue(getAllpayeesCount() == beforeCnt - 1, "All Payees count is NOT updated");
            Reporter.log("All Payees count is decremented:" + getAllpayeesCount());
        } else {
            Assert.assertTrue(cannotDeleteDialog.isDisplayed(), "Cannot delete pop up displayed.");
            cannotDeleteDialog.findElement(cancelBtnOnDialog).click();
            wait.until(ExpectedConditions.not(ExpectedConditions.visibilityOf(cannotDeleteDialog)));
            Reporter.log("Payee could not be deleted due to pending transactions on dashboard");
        }
    }

    @Override
    public void verifyIfNoPayeePresent() {
        wait.until(ExpectedConditions.visibilityOf(payeePageTitle));
        if (alertMessageWhenNoPayee.isDisplayed()) {
            Assert.assertTrue(alertMessageWhenNoPayee.isDisplayed(), "Alert message " + alertMessageWhenNoPayee.getText()
                + " for no payees  is NOT displayed correctly in myPayees Tab");
            Reporter.log("Alert message for " + alertMessageWhenNoPayee.getText()
                + "  no payees  is NOT displayed correctly in myPayees Tab");
        } else if (getAllpayeesCount() == 0) {
            personTabsPayees.click();
            Assert.assertTrue(alertMessageWhenNoPayee.isDisplayed(), "Alert message  " + alertMessageWhenNoPayee.getText()
                + " for no Person payees  is NOT displayed correctly in myPayees Tab");

            Reporter.log("Alert message " + alertMessageWhenNoPayee.getText()
                + "  no Person payees  is NOT displayed correctly in myPayees Tab");
        } else if (getAllpayeesCount() == 0) {
            companyTabsPayees.click();
            Assert.assertTrue(alertMessageWhenNoPayee.isDisplayed(), "Alert message " + alertMessageWhenNoPayee.getText()
                + "   for no Company payees  is NOT displayed correctly in myPayees Tab");
            Reporter.log("Alert message for" + alertMessageWhenNoPayee.getText()
                + "   no Comapny  payees  is NOT displayed correctly in myPayees Tab");
        } else {
            Reporter.log("Profile contains payees, please select a different profile");
        }

    }

}
