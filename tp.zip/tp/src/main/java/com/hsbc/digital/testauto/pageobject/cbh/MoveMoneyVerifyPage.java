package com.hsbc.digital.testauto.pageobject.cbh;

import java.text.ParseException;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyVerifyPageModel;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

public class MoveMoneyVerifyPage extends MoveMoneyVerifyPageModel {

    protected final UICommonUtil uiCommonUtil;
    protected static final String LABEL_FROM = "Account";
    protected static String LABEL_TO = "Account";
    protected static final String LABELM2C_TO = "To";
    private final String DATE_FORMAT = "EEEEE, dd MMMMM yyyy";
    protected static final String LABELM2C_START_DATE = "Start Date";
    private static String LABEL_PAYEENAME = StringUtils.EMPTY;
    private static final String LABEL_PAYMENT_DATE = "Transaction date";
    private static String LABEL_PAYEEACCOUNTNUMBER = StringUtils.EMPTY;


    public MoveMoneyVerifyPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        uiCommonUtil = new UICommonUtil(driver);
    }


    @Override
    protected void isFromAccountNameDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_FROM, accountDetail.getAccountName(), UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given From Account Name not found.");
        Reporter.log("From Account Name displayed is :" + accountDetail.getAccountName());
    }

    @Override
    protected void isFromAccountNumberDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_FROM, accountDetail.getAccountNumber(),
            UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given From Account Number not found.");
        Reporter.log("From Account Number displayed is :" + accountDetail.getAccountNumber());
    }


    @Override
    public void verifyLCY2LCYRecurringTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Verify Page.");
    }

    @Override
    public void verifyFCY2FCYNowTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("FCY2FCYNow Transaction Details verified on Verify Page.");
    }

    @Override
    protected void isNumberOfPaymentDisplayed(String valueNOP) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_NUMBER_OF_PAYMENT, valueNOP, UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Number Of Payment not found.");
        Reporter.log("Number Of Payment displayed is :" + valueNOP);
    }

    @Override
    protected void isToAccountNameDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_TO, accountDetail.getAccountName(), UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Name not found.");
        Reporter.log("To Account Name displayed is :" + accountDetail.getAccountName());
    }


    protected void isPayeeAccountNameDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PAYEENAME, accountDetail.getAccountName(),
            UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Name not found.");
        Reporter.log("To Account Name displayed is :" + accountDetail.getAccountName());
    }

    @Override
    public void verifyLCY2LCYNowTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    protected void isM2CToAccountNameDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABELM2C_TO, accountDetail.getAccountName(), UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Name not found.");
        Reporter.log("To Account Name displayed is :" + accountDetail.getAccountName());
    }

    @Override
    public void verifyInlineNonHSBCLCY2LCYNowTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        wait.until(ExpectedConditions.visibilityOf(verifyPageTitle));
        isFromAccountNameDisplayed(transactionDetail.getFromAccount());
        isFromAccountNumberDisplayed(transactionDetail.getFromAccount());
        if (StringUtils.isNotEmpty(transactionDetail.getToAccount().getAccountName())) {
            isPayeeAccountNameDisplayed(transactionDetail.getToAccount());
        }
        isPayeeAccountNumberDisplayed(transactionDetail.getToAccount());
        isPaymentDateDisplayed(DEFAULT_PAYMENT_DATE_VALUE);
        isYourReferenceTextDisplayed(transactionDetail.getYourReference());
        isAmountDisplayed(transactionDetail.getAmount());
        isPayeeReferenceTextDisplayed(transactionDetail.getPayeeReference());
        Reporter.log("InlineLCY2LCYNowNonHSBC Transaction Details verified on Verify Page.");
    }

    @Override
    public void verifyNonHSBCLCY2LCYNowTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        isPayeeReferenceTextDisplayed(transactionDetail.getPayeeReference());
        Reporter.log("LCY2LCYNowNonHSBC Transaction Details verified on Verify Page.");
    }


    @Override
    protected void isToAccountNumberDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_TO, accountDetail.getAccountNumber(), UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Number not found.");
        Reporter.log("To Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    protected void isPayeeAccountNumberDisplayed(final AccountDetails accountDetail) {
        Assert
            .assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PAYEEACCOUNTNUMBER, accountDetail.getAccountNumber(),
                UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
                "Given To Account Number not found.");
        Reporter.log("To Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    @Override
    protected void isPayeeReferenceTextDisplayed(String payeeReference) {
        Reporter.log("Payee Reference is not Applicable for Srilanka");
    }

    @Override
    public void verifyNonHSBCFCY2LCYNowTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isPayeeReferenceTextDisplayed(transactionDetail.getPayeeReference());
        Reporter.log("NonHSBCFCY2LCYNow Transaction Details verified on Verify Page.");
    }


    protected void isM2CToAccountNumberDisplayed(final AccountDetails accountDetail) {
        Assert
            .assertTrue(uiCommonUtil.textByParentAndSibling(LABELM2C_TO, accountDetail.getAccountNumber(), UICommonUtil.verifyPage,
                UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Number not found.");
        Reporter.log("To Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    @Override
    public void verifyM2CLCY2LCYLaterTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Verify Page.");
    }

    @Override
    public void verifyM2CLCY2LCYNowTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        wait.until(ExpectedConditions.visibilityOf(verifyPageTitle));
        isFromAccountNameDisplayed(transactionDetail.getFromAccount());
        isFromAccountNumberDisplayed(transactionDetail.getFromAccount());
        if (!transactionDetail.getToAccount().getAccountName().isEmpty()) {
            isM2CToAccountNameDisplayed(transactionDetail.getToAccount());
        }
        isM2CToAccountNumberDisplayed(transactionDetail.getToAccount());
        isPaymentDateDisplayed(DEFAULT_PAYMENT_DATE_VALUE);
        isYourReferenceTextDisplayed(transactionDetail.getYourReference());
        isAmountDisplayed(transactionDetail.getAmount());

    }

    @Override
    protected void isPaymentDateAsLaterDateDisplayed(final Transaction transaction) {
        String paymentDate;
        try {
            paymentDate = DateUtil.getDateToString(DATE_FORMAT, transaction.getLaterDate());
            Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PAYMENT_DATE, paymentDate, UICommonUtil.verifyPage,
                UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Payment Date not found");
            Reporter.log("Payment Date displayed is :" + paymentDate);
        } catch (ParseException e) {
            Assert.fail("Parsing to Payment Date Fail " + e.getMessage());
            MoveMoneyCapturePageModel.logger.error(e);
        }
    }

    @Override
    public void verifyM2CFCY2LCYLaterTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        this.verifyM2CLCY2LCYNowTransactionDetailsOnVerifyPage(transactionDetail);

    }

    @Override
    public void verifyM2CLCY2LCYRecurringTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        wait.until(ExpectedConditions.visibilityOf(verifyPageTitle));
        isFromAccountNameDisplayed(transactionDetail.getFromAccount());
        isFromAccountNumberDisplayed(transactionDetail.getFromAccount());
        if (!transactionDetail.getToAccount().getAccountName().isEmpty()) {
            isToAccountNameDisplayed(transactionDetail.getToAccount());
        }
        isToAccountNumberDisplayed(transactionDetail.getToAccount());
        isYourReferenceTextDisplayed(transactionDetail.getYourReference());
        isM2CStartDateDisplayed(transactionDetail);
        isFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Verify Page.");
    }


    protected void isM2CStartDateDisplayed(final Transaction transaction) {
        try {
            String startDate = DateUtil.getDateToString(DATE_FORMAT, transaction.getFirstDateOfTransaction());
            Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABELM2C_START_DATE, startDate, UICommonUtil.verifyPage,
                UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Start Date not found.");
            Reporter.log("Start Date displayed is :" + startDate);
        } catch (ParseException e) {
            MoveMoneyCapturePageModel.logger.error(e);
            Assert.fail("Parsing to Payment Date Fail " + e.getMessage(), e);
        }

    }


    @Override
    protected void isStartDateDisplayed(final Transaction transaction) {
        try {
            String startDate = DateUtil.getDateToString(DATE_FORMAT, transaction.getFirstDateOfTransaction());
            Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_START_DATE, startDate, UICommonUtil.verifyPage,
                UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Start Date not found.");
            Reporter.log("Start Date displayed is :" + startDate);
        } catch (ParseException e) {
            MoveMoneyCapturePageModel.logger.error(e);
            Assert.fail("Parsing to Payment Date Fail " + e.getMessage(), e);
        }

    }

    @Override
    public void verifyLCY2LCYLaterTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Verify Page.");
    }

    @Override
    public void verifyM2NMInternationalLCY2LCYNowTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    @Override
    protected void isPaymentDateDisplayed(String paymentDate) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PAYMENT_DATE, "Now", UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Payment Date not found.");
        Reporter.log("Payment Date displayed is :" + paymentDate);
    }
}
