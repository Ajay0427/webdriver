/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

/**
 * <p>
 * <b> This model class will hold locators and functionality for Change
 * Internet Banking Limits Capture page. </b>
 * </p>
 * 
 * @version 1.0.0
 * @author SatyaPrakash S Vyas
 * 
 */
public abstract class ChangeIBLimitsCaptureModel {

    protected final WebDriverWait wait;

    private static List<String> errorMessageAboveMaximumLimit = new ArrayList<>();
    private static List<String> actualErrorMessage = new ArrayList<>();


    /**
     * Transfers to my HSBC accounts section
     */
    @FindBy(xpath = "//div[contains(@id,'ChangeLimits')]//h2[contains(text(),'Daily payment and transfer limits')]")
    private WebElement capturePageHeading;

    @FindBy(xpath = "//div[@data-dojo-attach-point='ownAccountsDiv']//input[contains(@class,'dijitInputInner')]")
    private WebElement m2MlimitEditbox;

    @FindBy(xpath = "//div[@data-dojo-attach-point='ownAccountsDiv']//div[contains(@class,'dijitReset dijitInputField dijitInputContainer')]/input[@type='hidden']")
    private WebElement m2MlimitValue;
    /**
     * Set daily limits by transfer type section
     */
    @FindBy(xpath = "//h2[contains(@class,'toMyAccounts') and text()='Set daily limits by transfer type']")
    private WebElement setDailyLimitBytransferTypeText;

    @FindBy(xpath = "//div[@data-dojo-attach-point='mypyeeDiv']//input[contains(@class,'dijitInputInner')]")
    private WebElement limitToPredesignatedPayeeEditbox;

    @FindBy(xpath = "//div[@data-dojo-attach-point='mypyeeDiv']//div[contains(@class,'dijitReset dijitInputField dijitInputContainer')]/input[@type='hidden']")
    private WebElement predesignatedPayeelimitValue;

    @FindBy(xpath = "//div[@data-dojo-attach-point='newpyeeDiv']//input[contains(@class,'dijitInputInner')]")
    private WebElement limitOtherPayeesEditbox;

    @FindBy(xpath = "//div[@data-dojo-attach-point='newpyeeDiv']//div[contains(@class,'dijitReset dijitInputField dijitInputContainer')]/input[@type='hidden']")
    private WebElement otherpayeeLimitValue;

    @FindBy(xpath = "//div[@data-dojo-attach-point='alipayDiv']//input[contains(@class,'dijitInputInner')]")
    private WebElement alipayExperssLimitEditbox;

    @FindBy(xpath = "//div[@data-dojo-attach-point='alipayDiv']//div[contains(@class,'dijitReset dijitInputField dijitInputContainer')]/input[@type='hidden']")
    private WebElement alipayExpressLimitValue;

    @FindBy(xpath = "//div[@data-dojo-attach-point='unionPaySingleDiv']//input[contains(@class,'dijitInputInner')]")
    private WebElement unionpaySingleTransactionLimitEditbox;

    @FindBy(xpath = "//div[@data-dojo-attach-point='unionPaySingleDiv']//div[contains(@class,'dijitReset dijitInputField dijitInputContainer')]/input[@type='hidden']")
    private WebElement unionpaySingleTransactionLimitValue;

    @FindBy(xpath = "//div[@data-dojo-attach-point='unionPayDailyDiv']//input[contains(@class,'dijitInputInner')]")
    private WebElement unionpayDailyTransferLimitEditbox;

    @FindBy(xpath = "//div[@data-dojo-attach-point='unionPayDailyDiv']//div[contains(@class,'dijitReset dijitInputField dijitInputContainer')]/input[@type='hidden']")
    private WebElement unionpayDailyTransferLimitValue;

    @FindBy(xpath = "//*[contains(@id,'hdx_dijits_form_Form')]")
    protected WebElement changeIBlimitForm;

    @FindBy(xpath = "//button[@data-dojo-attach-point='submitBtn']")
    private WebElement continueButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='cancelBtn']")
    protected WebElement cancelButton;

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_Dialog_') and not (contains(@style,'display: none'))]//button[@title='Yes']")
    private WebElement cancelDialogYes;

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_Dialog_') and not (contains(@style,'display: none'))]//button[@title='No']")
    private WebElement cancelDialogNo;

    @FindBy(xpath = "//div[contains(@class,'errorMsgValidate NodataFound unSuccess')]")
    private WebElement errorMessageForNoChangeInValue;

    @FindBy(className = "validationMessage")
    private WebElement validationMessageForIncorrectValues;

    @FindBy(xpath = "//*[@id='_dashboardHeading']/h1/span[text()='My accounts']")
    private WebElement dashboardPage;

    private static final String ERROR_MESSAGE_M2M = "You cannot increase your Own account transfer limit online.";
    private static final String ERROR_MESSAGE_MYPAYEE = "You cannot increase your Third party transfer to predesignated payee limit online.";
    private static final String ERROR_MESSAGE_NEW_PAYEE = "You cannot increase your Third party transfer to Non-predesignated payee account limit online.";
    private static final String ERROR_MESSAGE_EXCEED_MAX_M2M = "Maximum daily limit is 99999999";
    private static final String ERROR_MESSAGE_EXCEED_MAX_MYPAYEE = "Maximum daily limit is 99999999";
    private static final String ERROR_MESSAGE_EXCEED_MAX_NEW_PAYEE = "Maximum daily limit is 99999999";
    private static final String ERROR_MESSAGE_EXCEED_ALIPAY_LIMIT = "Maximum daily limit is 20000";
    private static final String ERROR_MESSAGE_EXCEED_MAX_UNIONPAY_SINGLE_TRANSACTION = "Maximum daily limit is 50000";
    private static final String ERROR_MESSAGE_EXCEED_MAX_UNIONPAY_DAILYTRANSACTION = "Maximum daily limit is 10000";

    protected static final String INVALID_LIMIT = "999999999";

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(ChangeIBLimitsCaptureModel.class);

    static {
        ChangeIBLimitsCaptureModel.errorMessageAboveMaximumLimit.add(ChangeIBLimitsCaptureModel.ERROR_MESSAGE_EXCEED_MAX_M2M);
        ChangeIBLimitsCaptureModel.errorMessageAboveMaximumLimit.add(ChangeIBLimitsCaptureModel.ERROR_MESSAGE_EXCEED_MAX_MYPAYEE);
        ChangeIBLimitsCaptureModel.errorMessageAboveMaximumLimit.add(ChangeIBLimitsCaptureModel.ERROR_MESSAGE_EXCEED_MAX_NEW_PAYEE);
        ChangeIBLimitsCaptureModel.errorMessageAboveMaximumLimit.add(ChangeIBLimitsCaptureModel.ERROR_MESSAGE_EXCEED_ALIPAY_LIMIT);
        ChangeIBLimitsCaptureModel.errorMessageAboveMaximumLimit
            .add(ChangeIBLimitsCaptureModel.ERROR_MESSAGE_EXCEED_MAX_UNIONPAY_SINGLE_TRANSACTION);
        ChangeIBLimitsCaptureModel.errorMessageAboveMaximumLimit
            .add(ChangeIBLimitsCaptureModel.ERROR_MESSAGE_EXCEED_MAX_UNIONPAY_DAILYTRANSACTION);
        ChangeIBLimitsCaptureModel.errorMessageAboveMaximumLimit.add(ChangeIBLimitsCaptureModel.ERROR_MESSAGE_M2M);
        ChangeIBLimitsCaptureModel.errorMessageAboveMaximumLimit.add(ChangeIBLimitsCaptureModel.ERROR_MESSAGE_MYPAYEE);
        ChangeIBLimitsCaptureModel.errorMessageAboveMaximumLimit.add(ChangeIBLimitsCaptureModel.ERROR_MESSAGE_NEW_PAYEE);
    }

    public ChangeIBLimitsCaptureModel(final WebDriver driver) {
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30000);
    }

    public void isTermsAndConditionsLinkDisplayed() {}

    public List<Double> enterLimits() {
        List<Double> newLimits = new ArrayList<>();
        setNewLimit(m2MlimitEditbox, m2MlimitValue, newLimits, "M2M limit");
        setNewLimit(limitToPredesignatedPayeeEditbox, predesignatedPayeelimitValue, newLimits, "PredesignatedPayee");
        setNewLimit(limitOtherPayeesEditbox, otherpayeeLimitValue, newLimits, "OtherPayees");
        setNewLimit(alipayExperssLimitEditbox, alipayExpressLimitValue, newLimits, "AlipayExperss");
        setNewLimit(unionpaySingleTransactionLimitEditbox, unionpaySingleTransactionLimitValue, newLimits,
            "UnionpaySingleTransaction");
        setNewLimit(unionpayDailyTransferLimitEditbox, unionpayDailyTransferLimitValue, newLimits, "UnionpayDailyTransfer");
        Reporter.log("New limit values entered.");
        return newLimits;
    }

    public void setNewLimit(final WebElement textFieldElement, final WebElement limitValue, final List<Double> newLimits,
        final String setLimitFor) {
        Assert.assertTrue(textFieldElement.isEnabled(), "Amount field is not Editable or Enable");
        String currentvalue = limitValue.getAttribute("value");
        Integer currentLimit = Integer.parseInt(currentvalue);
        if (currentLimit > 0) {
            Integer newLimit = currentLimit - 1;
            String strNewLimit = newLimit.toString();
            textFieldElement.clear();
            textFieldElement.sendKeys(strNewLimit);
            Double dblNewLimit = Double.parseDouble(strNewLimit);
            newLimits.add(dblNewLimit);
        } else {
            Reporter.log(setLimitFor + " textfield value is " + currentvalue + ", hence can not be decreased below this.");
        }
    }

    public void clickContinueButton() {
        wait.until(ExpectedConditions.elementToBeClickable(continueButton));
        continueButton.click();
        Reporter.log("Continue button clicked on capture page.");
    }

    public void clickContinueButtonForValidation() {
        clickContinueButton();
    }

    public void clickCancelButton(final boolean value) {
        wait.until(ExpectedConditions.elementToBeClickable(cancelButton));
        cancelButton.click();
        if (value) {
            cancelDialogYes.click();
            wait.until(ExpectedConditions.visibilityOf(dashboardPage));
            Reporter.log("Cancel button - Yes clicked and Dashboard page shown.");
        } else {
            cancelDialogNo.click();
            if (changeIBlimitForm.isDisplayed()) {
                Reporter.log("User is on change internet banking limits page.");
            } else {
                Reporter.log("User is not on change internet banking limits page.");
                Assert.fail();
            }
        }
    }

    public void validateCapturePageAppearence() {
        wait.until(ExpectedConditions.visibilityOf(changeIBlimitForm));
        Reporter.log("Capture Page is shown.");
    }

    public void enterIncorrectLimits() {
        ChangeIBLimitsCaptureModel.actualErrorMessage.add(enterLimitsAboveMaximum(m2MlimitEditbox));
        ChangeIBLimitsCaptureModel.actualErrorMessage.add(enterLimitsAboveMaximum(limitToPredesignatedPayeeEditbox));
        ChangeIBLimitsCaptureModel.actualErrorMessage.add(enterLimitsAboveMaximum(limitOtherPayeesEditbox));
        ChangeIBLimitsCaptureModel.actualErrorMessage.add(enterLimitsAboveMaximum(alipayExperssLimitEditbox));
        ChangeIBLimitsCaptureModel.actualErrorMessage.add(enterLimitsAboveMaximum(unionpaySingleTransactionLimitEditbox));
        ChangeIBLimitsCaptureModel.actualErrorMessage.add(enterLimitsAboveMaximum(unionpayDailyTransferLimitEditbox));
        Reporter.log("Incorrect values entered.");
    }

    public void verifyErrorMessages() {
        Assert.assertTrue(
            ChangeIBLimitsCaptureModel.errorMessageAboveMaximumLimit.containsAll(ChangeIBLimitsCaptureModel.actualErrorMessage),
            "Error messages not shown.");
        Reporter.log("Error Messages are correctly shown");
    }

    public String enterLimitsAboveMaximum(final WebElement textFieldElement) {
        textFieldElement.clear();
        textFieldElement.sendKeys(ChangeIBLimitsCaptureModel.INVALID_LIMIT);
        return ChangeIBLimitsCaptureModel.INVALID_LIMIT;
    }

    public void clickContinueButtonWithoutChange() {
        /* Value set was 0 but textbox is blank hence hard coded values  */
        // TODO: remove these line once application is working fine.
        alipayExperssLimitEditbox.clear();
        alipayExperssLimitEditbox.sendKeys("0");
        // remove till here once application working correctly
        wait.until(ExpectedConditions.elementToBeClickable(continueButton));
        continueButton.click();
        checkNoChangesError();
    }

    private void checkNoChangesError() {
        wait.until(ExpectedConditions.visibilityOf(errorMessageForNoChangeInValue));
        Reporter.log("Continue button clicked without any change and error messages shown.");
    }
}
