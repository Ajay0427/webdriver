/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

/**
 * <p>
 * <b> This model class will hold locators and functionality for Rename Account
 * page that can be used around all entities. </b>
 * </p>
 * 
 * @version 1.0.0
 * @author SatyaPrakash S Vyas
 */
public abstract class RenameAccountsModel {

    private final WebDriver driver;
    private final WebDriverWait wait;

    @FindBy(xpath = "//h2[text()='Rename accounts']")
    private WebElement renameAccountsTitle;

    @FindBy(xpath = "//button[@type='button' and text()='Save changes']")
    private WebElement saveChangesButton;

    @FindBy(xpath = "//div[@data-dojo-attach-point='success']/p")
    private WebElement successMessage;
    /**
     * Section for Reset button click
     */
    @FindBy(xpath = "//button[@type='button' and text()='Reset all']")
    private WebElement resetAllButton;

    @FindBy(xpath = "//div[@class='submitButtonsPanel']/button[contains(@class,'jsYes')]")
    private WebElement resetButtonResetDialog;

    @FindBy(xpath = "//div[@class='submitButtonsPanel']/button[contains(@class,'jsYes')]")
    private WebElement resetButtonDontResetDialog;
    /**
     * Section for Cancel button click
     */
    @FindBy(xpath = "//button[@type='button' and text()='Cancel']")
    private WebElement cancelButton;

    @FindBy(xpath = "//div[@data-dojo-attach-point='cancelDialogNode']//button[@type='button' and text()='Cancel']")
    private WebElement cancelButtonCancelDialog;

    @FindBy(xpath = "// div[@data-dojo-attach-point='cancelDialogNode']//button[contains(@class,'jsNo')]")
    private WebElement cancelButtonDontCancelDialog;
    /**
     * My Accounts button
     */
    @FindBy(xpath = "//button[@data-dojo-attach-point='backButtonNode']")
    private WebElement myAccountsButton;

    @FindBy(xpath = "//span[@title='Details' and text()='Details']")
    private WebElement detailsButtonDashboard;

    @FindBy(xpath = "//div[contains(@class,'accountDetailsPanel')]//a[@data-dojo-attach-point='editNicknameLink']")
    private WebElement renameAccountLink;

    @FindBy(xpath = "//*[@data-dojo-attach-point='currentNicknameValue']")
    private WebElement currentNicknameValue;

    @FindBy(xpath = "//input[@name='editNickname']")
    private WebElement editNicknameInput;

    @FindBy(xpath = "//div[@class='dashboardTransations']//p[@data-dojo-attach-point='_dapAccountNumber']")
    private WebElement accountTypeActualName;

    @FindBy(xpath = "//input[@class='dijitReset dijitInputInner']")
    private List<WebElement> accountsTextField;

    @FindBy(xpath = "//span[@class='itemTitle']")
    private List<WebElement> accountsTypeAtDashboardPage;

    @FindBy(xpath = "//span[@class='validationMessage']")
    private List<WebElement> errorMessages;

    private static final String ERROR_MESSAGE = "You already have an account with that name. Please choose another name.";

    private static final String DUPLICATE = "duplicate";

    private static final String RENAME_ACCT_NAME = "Renamed account name";

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(RenameAccountsModel.class);

    public RenameAccountsModel(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        this.wait = new WebDriverWait(driver, 30000);
    }

    /**
     * Method to scroll till particular element.
     * 
     * @param element
     * 
     */
    public void scrollToWebElement(final WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
    }

    public List<String> renameAccounts() {
        wait.until(ExpectedConditions.visibilityOf(renameAccountsTitle));
        List<String> renamedAccountNames = new ArrayList<>();
        for (int i = 0; i < accountsTextField.size(); i++) {
            WebElement textField = accountsTextField.get(i);
            scrollToWebElement(textField);
            if (textField.isEnabled()) {
                textField.clear();
                textField.sendKeys("Renamed " + (i + 1));
                renamedAccountNames.add("Renamed " + (i + 1));
            }
        }
        return renamedAccountNames;
    }

    public void clickSaveChanges() {
        wait.until(ExpectedConditions.elementToBeClickable(saveChangesButton));
        saveChangesButton.click();
        Reporter.log("\nSave Changes button clicked.");
    }

    public void validateSuccessMessage() {
        scrollToWebElement(successMessage);
        Assert.assertTrue(successMessage.isDisplayed(), "Success Message not shown.");
        Reporter.log("Success message shown.");
    }

    public void clickMyAccountsButton() {
        wait.until(ExpectedConditions.elementToBeClickable(myAccountsButton));
        myAccountsButton.click();
    }

    /**
     * to check updated Account Names on Dashboard
     */
    public void validateUpdatedAccountNames(final List<String> renamedAccountNames) {
        wait.until(ExpectedConditions.visibilityOf(detailsButtonDashboard));
        List<String> accountNamesAtDashboard = new ArrayList<>();
        for (WebElement accountRow : accountsTypeAtDashboardPage) {
            scrollToWebElement(accountRow);
            accountNamesAtDashboard.add(accountRow.getText());
        }
        Assert.assertTrue(accountNamesAtDashboard.containsAll(renamedAccountNames), "Renamed accounts name don't match.");
        Reporter.log("Account names renamed correctly");
    }

    public void clickResetAllButton() {
        wait.until(ExpectedConditions.elementToBeClickable(resetAllButton));
        resetAllButton.click();
        wait.until(ExpectedConditions.elementToBeClickable(resetButtonResetDialog));
        resetButtonResetDialog.click();
        Reporter.log("Reset all button clicked");
        for (WebElement elem : accountsTextField) {
            Assert.assertTrue(elem.getText().isEmpty(), "All fields not reset.");
        }
    }

    public void clickCancel(final boolean value) {
        wait.until(ExpectedConditions.visibilityOf(renameAccountsTitle));
        if (accountsTextField.size() >= 3) {
            accountsTextField.get(2).isEnabled();
            accountsTextField.get(2).clear();
            accountsTextField.get(2).sendKeys(RenameAccountsModel.DUPLICATE);
        }
        wait.until(ExpectedConditions.elementToBeClickable(cancelButton));
        cancelButton.click();
        if (value) {
            cancelButtonCancelDialog.click();
            Reporter.log("\nCancel button - cancel clicked");
        } else {
            cancelButtonDontCancelDialog.click();
            wait.until(ExpectedConditions.visibilityOf(renameAccountsTitle));
            renameAccountsTitle.isDisplayed();
            Reporter.log("\nCancel button - Don't cancel clicked");
        }
    }

    public void clickDetailsbutton() {
        wait.until(ExpectedConditions.elementToBeClickable(detailsButtonDashboard));
        detailsButtonDashboard.click();
        Reporter.log("\nclickDetailsbutton completed successfully");
    }

    public void clickRenameAccountLink() {
        wait.until(ExpectedConditions.elementToBeClickable(renameAccountLink));
        renameAccountLink.click();
        Reporter.log("\nRename accountlink from details clicked");
    }

    /**
     * Rename account from Details tab
     */
    public void renameAccountFromDetails() {
        editNicknameInput.clear();
        editNicknameInput.sendKeys(RenameAccountsModel.RENAME_ACCT_NAME);
        editNicknameInput.sendKeys(Keys.TAB);

        verifyAccountNameRenamed(RenameAccountsModel.RENAME_ACCT_NAME);
        Reporter.log("\nVerified rename from Details tab.");
    }

    public void verifyAccountNameRenamed(final String newAccountNickname) {
        Assert.assertTrue(newAccountNickname.equalsIgnoreCase(currentNicknameValue.getText()), "Renamed account name not shown");
    }

    public String returnActualAccountName() {
        String actualAccountName = accountTypeActualName.getText();
        actualAccountName = actualAccountName.split(" - ")[1];
        return actualAccountName;
    }

    public void clearRenamedAccountToGetActual() {
        String actualAccountName = returnActualAccountName();
        editNicknameInput.clear();
        editNicknameInput.sendKeys(Keys.TAB);
        verifyAccountNameRenamed(actualAccountName);
        Reporter.log("\nActual account name is restored when textfield is cleared and saved from Details tab.");
    }

    public void enterDuplicateValues() {
        wait.until(ExpectedConditions.visibilityOf(renameAccountsTitle));
        for (int i = 0; i < 2; i++) {
            if (accountsTextField.get(i).isEnabled()) {
                accountsTextField.get(i).clear();
                accountsTextField.get(i).sendKeys(RenameAccountsModel.DUPLICATE);
            }
        }
        Reporter.log("\nDuplicate values entered.");
    }

    public void verifyErrorMessages() {
        wait.until(ExpectedConditions.visibilityOfAllElements(errorMessages));
        scrollToWebElement(errorMessages.get(0));
        for (WebElement elem : errorMessages) {
            Assert.assertTrue(getErrorMessageForDuplicate().equalsIgnoreCase(elem.getText()),
                "Error message does not match with actual error message");
        }
        Reporter.log("\nValidation message shown when duplicate values saved.");
    }


    protected String getErrorMessageForDuplicate() {
        return RenameAccountsModel.ERROR_MESSAGE;
    }


}
