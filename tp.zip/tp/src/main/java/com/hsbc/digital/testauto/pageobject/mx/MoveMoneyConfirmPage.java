package com.hsbc.digital.testauto.pageobject.mx;

import java.text.ParseException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyConfirmPageModel;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

public class MoveMoneyConfirmPage extends MoveMoneyConfirmPageModel {
    private final WebDriverWait wait;
    protected static final String DEFAULT_PAYMENT_DATE_VALUE = "Now";
    protected static final String LABEL_PAYMENT_DATE = "Payment date";
    private static final String LABEL_NUMBER_OF_PAYMENT = "Number of transfers";
    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(MoveMoneyConfirmPage.class);

    public MoveMoneyConfirmPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30000);
        // TODO Auto-generated constructor stub
    }

    @Override
    public void verifyLCY2LCYNowTransactionDetailsOnConfirmPage(final Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        MoveMoneyConfirmPage.logger.info("LCY2LCYNow Transaction Details verified on Confirm Page.");
        Reporter.log("LCY2LCYNow Transaction Details verified on Confirm Page.");
    }

    @Override
    public void validateNowFlow(final Transaction transaction) {
        wait.until(ExpectedConditions.visibilityOf(confirmPageTitle));
        isFromAccountNameDisplayed(transaction.getFromAccount());
        isFromAccountNumberDisplayed(transaction.getFromAccount());
        isToAccountNameDisplayed(transaction.getToAccount());
        isToAccountNumberDisplayed(transaction.getToAccount());
        isPaymentDateDisplayed(MoveMoneyConfirmPage.DEFAULT_PAYMENT_DATE_VALUE);
    }

    @Override
    protected void isFromAccountNameDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyConfirmPageModel.LABEL_FROM, accountDetail.getAccountName(),
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given From Account Name not found.");
        MoveMoneyConfirmPage.logger.info("From Account Name displayed is :" + accountDetail.getAccountName());
        Reporter.log("From Account Name displayed is :" + accountDetail.getAccountName());
    }

    @Override
    protected void isFromAccountNumberDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyConfirmPageModel.LABEL_FROM,
            accountDetail.getAccountNumber(), UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given From Account Number not found.");
        MoveMoneyConfirmPage.logger.info("From Account Number displayed is :" + accountDetail.getAccountNumber());
        Reporter.log("From Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    @Override
    protected void isToAccountNameDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyConfirmPageModel.LABEL_TO, accountDetail.getAccountName(),
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Name not found.");
        MoveMoneyConfirmPage.logger.info("To Account Name displayed is :" + accountDetail.getAccountName());
        Reporter.log("To Account Name displayed is :" + accountDetail.getAccountName());
    }

    @Override
    protected void isToAccountNumberDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyConfirmPageModel.LABEL_TO, accountDetail.getAccountNumber(),
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given To Account Number not found.");
        MoveMoneyConfirmPage.logger.info("To Account Number displayed is :" + accountDetail.getAccountNumber());
        Reporter.log("To Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    @Override
    protected void isAmountDisplayed(final String amount) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyConfirmPageModel.LABEL_AMOUNT, amount,
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Transfer Amount not found.");
        MoveMoneyConfirmPage.logger.info("Amount displayed is :" + amount);
        Reporter.log("Amount displayed is :" + amount);
    }

    @Override
    protected void isDebitAmountDisplayed(final String amount) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_DEBIT_AMOUNT, amount, UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Transfer Amount not found.");
        MoveMoneyConfirmPage.logger.info("Amount displayed is :" + amount);
        Reporter.log("Amount displayed is :" + amount);
    }

    @Override
    protected void isPaymentDateDisplayed(final String paymentDate) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyConfirmPage.LABEL_PAYMENT_DATE, "Now",
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Payment Date not found.");
        MoveMoneyConfirmPage.logger.info("Payment Date displayed is :" + paymentDate);
        Reporter.log("Payment Date displayed is :" + paymentDate);
    }

    @Override
    public void verifyLCY2LCYRecurringTransactionDetailsOnConfirmPage(final Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
        MoveMoneyConfirmPage.logger.info("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }

    @Override
    protected void validateRecurringFlow(final Transaction transaction) {
        wait.until(ExpectedConditions.visibilityOf(confirmPageTitle));
        isFromAccountNameDisplayed(transaction.getFromAccount());
        isFromAccountNumberDisplayed(transaction.getFromAccount());
        isToAccountNameDisplayed(transaction.getToAccount());
        isToAccountNumberDisplayed(transaction.getToAccount());
        isYourReferenceTextDisplayed(transaction.getYourReference());
        isStartDateDisplayed(transaction);
    }

    @Override
    protected void isStartDateDisplayed(final Transaction transaction) {
        try {
            String startDate = DateUtil.getDateToString(MoveMoneyConfirmPageModel.DATE_FORMAT,
                transaction.getFirstDateOfTransaction());
            Assert.assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyConfirmPageModel.LABEL_START_DATE, startDate,
                UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Start Date not found.");
            MoveMoneyConfirmPage.logger.info("Start Date displayed is :" + startDate);
        } catch (ParseException e) {
            MoveMoneyCapturePageModel.logger.error(e);
            Assert.fail("Parsing to Payment Date Fail " + e.getMessage(), e);
        }

    }

    @Override
    protected void isFrequencyDisplayed(final String frequencyValue) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyConfirmPageModel.LABEL_FREQUENCY, frequencyValue,
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Frequency Value not found.");
        Reporter.log("Frequency Value displayed is :" + frequencyValue);
        MoveMoneyConfirmPage.logger.info("Frequency Value displayed is :" + frequencyValue);
    }

    @Override
    protected void isNumberOfPaymentDisplayed(final String valueNOP) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyConfirmPage.LABEL_NUMBER_OF_PAYMENT, valueNOP,
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given Number Of Payment not found.");
        Reporter.log("Number Of Payment displayed is :" + valueNOP);
        MoveMoneyConfirmPage.logger.info("Number Of Payment displayed is :" + valueNOP);
    }

    @Override
    protected void isPaymentDateAsLaterDateDisplayed(Transaction transaction) {
        String paymentDate;
        try {
            paymentDate = DateUtil.getDateToString(DATE_FORMAT, transaction.getLaterDate());
            Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PAYMENT_DATE, paymentDate, UICommonUtil.confirmPage,
                UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Payment Date not found.");
            Reporter.log("Payment Date displayed is :" + paymentDate);
            logger.info("Payment Date displayed is :" + paymentDate);
        } catch (ParseException e) {
            MoveMoneyConfirmPageModel.logger.error(e);
            Assert.fail("Parsing to Payment Date Fail " + e.getMessage(), e);
        }
    }

    @Override
    protected void isYourReferenceTextDisplayed(String yourReference) {
        if (yourReference != null) {
            Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_YOUR_REFERENCE, yourReference, UICommonUtil.confirmPage,
                UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Your Reference Text not found.");
            Reporter.log("Your Reference Text displayed is :" + yourReference);

        } else {
            logger.info("Your Reference Text is not Entered");
        }
    }

}
