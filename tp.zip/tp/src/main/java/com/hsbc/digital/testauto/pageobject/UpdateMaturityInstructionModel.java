/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.UpdateMaturiryInstructionsDetails;


/**
 * <p>
 * <b> This class will hold all common locators and method of story # 85 ,
 * Update Maturity Instruction </b>
 * </p>
 * 
 * @version 1.0.0
 * @author Vaibhav Sharma
 * 
 */


public abstract class UpdateMaturityInstructionModel {


    protected final WebDriver driver;
    protected final WebDriverWait wait;

    @FindBy(xpath = "  //span[@class='title']")
    protected WebElement dashboardtitle;

    @FindBy(xpath = "//div[contains(@id,'TitlePane')]/span[@isgspentity='yes']//span[contains(@class,'itemName')]")
    protected List<WebElement> accountsNumberLists;

    @FindBy(xpath = "//div[contains(@id,'TitlePane')]/span[@isgspentity='yes']")
    private List<WebElement> accountsLists;

    @FindBy(xpath = "//button[@title='Manage']")
	protected WebElement manageButton;

    @FindBy(xpath = "//a[contains(text(),'Update maturity)']")
    protected List<WebElement> updateMaturityLinkManageMenuList;

    @FindBy(xpath = "//a[contains(text(),'Update maturity')]")
    protected WebElement updateMaturityLinkManageMenu;

    @FindBy(xpath = "//div[contains(@class,'heading')]//h2")
    private WebElement updateMaturityHeading;

    @FindBy(xpath = "//li[contains(@class,'onMaturity')]//input[contains(@id,'arrowid') and contains(@id,'form_Select')]")
    private WebElement onMaturityListArrow;

    @FindBy(xpath = " //div[contains(@class,'onMaturity')]//table//tr")
    protected List<WebElement> onMaturityList;

    @FindBy(xpath = " //li[contains(@class,'onMaturityLbl')]//div[contains(@class,'DownArrowButton')]//table//span")
    protected WebElement onMaturitySelectedItem;

    @FindBy(xpath = "//div[contains(@class,'accountSelect') and contains(@widgetid,'addFundsToAccount')]//input[contains(@id,'addFundsToAccount')]")
    private WebElement addMoneyToArrow;

    @FindBy(xpath = "//div[contains(text(),'Add funds from')]//following-sibling::div[contains(@class,'accountSelect') and not (contains(@style,'display: none'))]//input[contains(@id,'addFundsFromAccount')]")
    private WebElement addMoneyFromAccountArrow;

    @FindBy(xpath = "//div[contains(@id,'addFundsFromAccount')]//table//tr")
    protected List<WebElement> addMoneyFromAccountList;

    @FindBy(xpath = "  //table[contains(@id,'addFundsFromAccount')]//span[@class='accountDetails']")
    private List<WebElement> selectedAccountNumberAddFundsFrom;

    @FindBy(xpath = "//div[contains(@id,'addFundsToAccount')]//table//tr")
    private List<WebElement> addMoneyToList;

    @FindBy(xpath = "//div[contains(@id,'newFixedTerm')]/following-sibling::div[1]//input[contains(@id,'arrowid')]")
    protected WebElement newFixedTermArrow;

    @FindBy(xpath = "//div[contains(@class,'newFixedTerm')]//table//tr")
	protected List<WebElement> newFixedTermList;

    @FindBy(xpath = " //span[contains(text(),'Fixed') and contains(@id,'singleOption')]")
    protected WebElement newFixedTermFixed;

    @FindBy(xpath = "//li[@data-dojo-attach-point='newFixedTerm']//table//span[1]")
    private List<WebElement> selectedNewTerm;

    @FindBy(xpath = "//input[contains(@id,'amountToAdd_CurrencyTextBox')]")
	protected WebElement amountToAddInput;

    @FindBy(xpath = "//input[contains(@id,'withdrawAmount_CurrencyTextBox')]")
    private WebElement amountToWithdrawInput;

    @FindBy(xpath = "//button[@type='submit' and text()='Continue']")
    private WebElement continueButton;

    @FindBy(xpath = "//div[@class='submitButtonsPanel']//button[@data-dojo-attach-point='_cancelEdtmBtnNode']")
    private WebElement cancelButton;

    @FindBy(xpath = "//div[@class='accountSummaryHeadContainer']//h2[@data-dojo-attach-point='_title']")
    private WebElement selectedAccountName;

    @FindBy(xpath = "//table[contains(@id,'addFundsToAccount')]//span[@class='accountDetails']")
    protected WebElement selectedAccountNumberAddFundsTo;

    @FindBy(xpath = "//table[contains(@id,'addFundsToAccount')]//span[@class='balance']")
    private WebElement selectedAccountBalanceAddFundsTo;

    // Locators on Maturity Instructions Section
    @FindBy(xpath = "//div[@class='accountSummaryHeadContainer']//th[text()='Balance']//following-sibling::td")
    protected WebElement selectedAccountBalance;

    @FindBy(xpath = "//div[@class='accountSummaryHeadContainer']//th[text()='Start date']//following-sibling::td")
	protected WebElement selectedAccountStartDate;

    @FindBy(xpath = "//div[@class='accountSummaryHeadContainer']//th[text()='Term']//following-sibling::td")
    protected WebElement selectedAccountTerm;

    @FindBy(xpath = "//div[@class='accountSummaryHeadContainer']//th[text()='Maturity date']//following-sibling::td")
    protected WebElement selectedAccountMaturityDate;

    @FindBy(xpath = "//div[@class='accountSummaryHeadContainer']//th[text()='Interest paid']//following-sibling::td")
    protected WebElement selectedAccountInterestpaid;

    @FindBy(xpath = "//div[@class='accountSummaryHeadContainer']//th[text()='Interest rate']//following-sibling::td")
    protected WebElement selectedAccountInterestrate;

    @FindBy(xpath = "//div[@class='accountSummaryHeadContainer']//th[text()='Interest at maturity']//following-sibling::td")
    protected WebElement selectedAccountInterestMaturity;

    @FindBy(xpath = "//div[@class='accountSummaryHeadContainer']//th[text()='Maturity transfer account']//following-sibling::td")
    private WebElement selectedAccountInterestTransferAccount;

    @FindBy(xpath = "//div[@class='accountSummaryHeadContainer']//span[contains(@id,'accountNumber')]")
    private WebElement selectedAccountNumber;

    @FindBy(xpath = "//div[@class='accountSummaryHeadContainer']//th[text()='Interest rate']//following-sibling::td")
    private WebElement selectedAccountInterestRate;

    @FindBy(xpath = "//div[@class='accountSummaryHeadContainer']//th[text()='Interest at maturity']//following-sibling::td")
    private WebElement selectedAccountInterestAtMaturity;

    @FindBy(xpath = "//div[contains(@id,'EditMaturityInstructions')]//p[text()='Maturity amount']//following-sibling::div//span[@class='currencyTypeValue']")
    private WebElement selectedMaturityAmount;

    @FindBy(xpath = "//div[contains(@id,'EditMaturityInstructions')]//a[text()='Options when your term deposit matures']")
    private WebElement optionsWhenYourTermDepositMatureLink;

    @FindBy(xpath = "//span[contains(@data-dojo-attach-point,'matAmount')]")
    private WebElement maturityAmountCapture;

    // Locators on Update Maturity Details Review page

    @FindBy(xpath = "//h2[text()='Verify']")
    protected WebElement headingVerify;

    @FindBy(xpath = "//div[contains(@id,'ReviewMaturityInstructions')]//dt[text()='Account']//following-sibling::dd[1]//div//span[1]")
    private WebElement accountNumberReview;

    @FindBy(xpath = "//div[contains(@id,'ReviewMaturityInstructions')]//dt[text()='Add funds to']//following-sibling::dd[1]//div//span[1]")
	protected WebElement AddFundsToAccountReview;

    @FindBy(xpath = "//div[contains(@id,'ReviewMaturityInstructions')]//dd[@class='onMaturity']")
    protected WebElement onMaturityReview;

    @FindBy(xpath = "  //dt[text()='Total amount']/following-sibling::dd[1]")
    private WebElement totalAmountReview;

    @FindBy(xpath = "   //dt[text()='Amount to add']/following-sibling::dd[1]")
    protected WebElement amountToAddReview;

    @FindBy(xpath = " //dt[text()='Withdraw amount']/following-sibling::dd[1]")
    protected WebElement amountToWithdraw;

    @FindBy(xpath = " //dt[text()='New fixed term']/following-sibling::dd")
    protected WebElement newFixedTermReview;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_editBtnNode']")
    private WebElement editDetailsButton;

    @FindBy(xpath = "//button[contains(@data-dojo-attach-point,'printContent')]")
    private WebElement printButtonReview;

    @FindBy(xpath = "//div[@class='submitButtonsPanel']//button[@data-dojo-attach-point='_cancelEdtmBtnNode']")
    private WebElement cancelButtonReview;

    @FindBy(xpath = "//div[@class='containerNode']//a[@data-dojo-attach-point='confirmanchortag']")
    private WebElement cancelButtonOnPopUpReview;

    @FindBy(xpath = "//button[@type='submit' and text()='Confirm']")
    protected WebElement confirmButton;

    // Locators on Confirmation page

    @FindBy(xpath = "//h2[text()='Confirmation']")
    private WebElement confirmationHeading;

    @FindBy(xpath = "//input[@value='Back to My accounts']")
    protected WebElement backToMyAccountButton;

    @FindBy(xpath = "//button[contains(@class,'confirmPrint')]")
    private WebElement printButtonConfirmation;

    @FindBy(xpath = "//button[@type='button' and text()='Print']")
    private WebElement printButtonOnPopUpConfirmation;

    @FindBy(xpath = "//div[contains(@id,'PrintFriendlyFormatDialog')]//button[@type='button' and text()='Cancel']")
    private WebElement cancelButtonOnPopUpConfirmation;

    // Locators on confirmation page

    @FindBy(xpath = "//p[text()='Update successful']")
    protected WebElement updateSuccessfulHeading;

    @FindBy(xpath = "//p[@data-dojo-attach-point='_confMsg']")
    protected WebElement confirmationMessage;

    protected static final String maturityOptionRenewTotalBalance = "Renew for a new term";
    protected static final String maturityOptionDoNotRenew = "Do not renew";
    protected static final String maturityOptionRenewPrincipleAmount = "Renew principal amount with new term";
    protected static final String maturityOptionAddFunds = "Add funds on maturity";
    protected static final String maturityOptionAWithdrawFunds = "Withdraw funds";
    protected static final String maturityOptionAWithdraw = "Withdraw";

    public UpdateMaturityInstructionModel(final WebDriver driver) {
        PageFactory.initElements(driver, this);
        this.driver = driver;
        wait = new WebDriverWait(driver, 30000);
    }

    public String updateMaturityInstructionEndToEndFlow(final boolean continueLoop) {
        String accountNumber = StringUtils.EMPTY;
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        for (int i = 0; i < accountsNumberLists.size(); i++) {

            WebElement lists = driver.findElement(By.xpath("//span[contains(text(),'" + accountsNumberLists.get(i).getText()
                + "')]"));

            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", lists);
            lists.click();

            Assert.assertTrue(manageButton.isDisplayed(), "Manage button is not displayed on Dashboard page");
            manageButton.click();
            Reporter.log("Manage button clicked");

            if (isUpdateMaturityLinkDisplayed()) {
                accountNumber = accountsNumberLists.get(i).getText();
                
                

                Reporter.log("Update Maturity link is displayed for selected account i.e. " + accountsNumberLists.get(i).getText());
                clickUpdateMaturityLink();
                Reporter.log("Update Maturity link click for account " + accountNumber);

                if (continueLoop == false) {
                    break;
                }

                verifyUpdateMaturityCapturePage(accountNumber);
                verifyCurrentMaturityInstruction();
                UpdateMaturiryInstructionsDetails objMaturityDetails = captureUpdateMaturityDetails();
                clicksContinueButton();
                verifyUpdateMaturityReviewPage(objMaturityDetails);
                clicksConfirmButton();
                verifyUpdateMaturityConfirmationPage();
                verifyBackToMYAccountFunctionality();

            }
        }
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        return accountNumber;
    }

    protected boolean isUpdateMaturityLinkDisplayed() {
        return !updateMaturityLinkManageMenuList.isEmpty() && updateMaturityLinkManageMenu.isDisplayed();
    }

    protected void clickUpdateMaturityLink() {
        updateMaturityLinkManageMenuList.get(0).click();
    }

    public void verifyUpdateMaturityCapturePage(final String accountNumber) {
        Assert.assertTrue(updateMaturityHeading.isDisplayed(), "Update maturity heading is not displayed");
        Reporter.log("Update Maturity page is displayed with heading as " + updateMaturityHeading.getText());

        Assert.assertTrue(accountNumber.contains(selectedAccountNumber.getText()),
            "Selected account is not displayed on Maturity Instruction capture page");
        Reporter.log("Selected account is displayed on Maturity Instruction capture page");

    }

    public void verifyCurrentMaturityInstruction() {

        Assert.assertTrue(selectedAccountBalance.isDisplayed(),
            "Account Balance field is not displayed under Current maturity instructions section");
        Reporter.log("Account Balance field is displayed as " + selectedAccountBalance.getText()
            + " under Current maturity instructions section");

        Assert.assertTrue(selectedAccountStartDate.isDisplayed(),
            "Start Date field is not displayed under Current maturity instructions section");
        Reporter.log("Start Date field is displayed as " + selectedAccountStartDate.getText()
            + " under Current maturity instructions section");

        Assert.assertTrue(selectedAccountTerm.isDisplayed(),
            "Account term field is not displayed under Current maturity instructions section");
        Reporter.log("Account term field is displayed as" + selectedAccountTerm.getText()
            + "  under Current maturity instructions section");

        Assert.assertTrue(selectedAccountMaturityDate.isDisplayed(),
            "Account maturity date field is not displayed under Current maturity instructions section");
        Reporter.log("Account maturity date field is displayed as" + selectedAccountMaturityDate.getText()
            + "   under Current maturity instructions section");

        Assert.assertTrue(selectedAccountInterestpaid.isDisplayed(),
            "Account Interest paid field is not displayed under Current maturity instructions section");
        Reporter.log("Account Interest paid field is displayed as" + selectedAccountInterestpaid.getText()
            + "   under Current maturity instructions section");

        Assert.assertTrue(selectedAccountInterestrate.isDisplayed(),
            "Account Interest rate field is not displayed under Current maturity instructions section");
        Reporter.log("Account Interest rate field is displayed as" + selectedAccountInterestrate.getText()
            + "   under Current maturity instructions section");

        Assert.assertTrue(selectedAccountInterestMaturity.isDisplayed(),
            "Account Interest maturity field is not displayed under Current maturity instructions section");
        Reporter.log("Account Interest maturity field is displayed as" + selectedAccountInterestMaturity.getText()
            + "   under Current maturity instructions section");

    }

    public String selectOnMaturity() {
        onMaturityListArrow.click();
        int randomIndex = RandomUtil.generateIntNumber(1, onMaturityList.size());
        WebElement row = onMaturityList.get(randomIndex);
        row.click();
        return onMaturitySelectedItem.getText();
    }

    public String selectAddFundsToAccount() {
        addMoneyToArrow.click();
        int randomIndex = RandomUtil.generateIntNumber(1, addMoneyToList.size());
        WebElement row = addMoneyToList.get(randomIndex);
       ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", row);
        row.click();
        return selectedAccountNumberAddFundsTo.getText();
    }

    public String selectAddFundsFromAccount() {
        addMoneyFromAccountArrow.click();
        int randomIndex = RandomUtil.generateIntNumber(1, addMoneyFromAccountList.size());
        WebElement row = addMoneyFromAccountList.get(randomIndex);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", row);
        row.click();
        return selectedAccountNumberAddFundsTo.getText();
    }


    public String selectNewFixedTerm() {

        if (newFixedTermArrow.isDisplayed()) {

            newFixedTermArrow.click();
	
            int randomIndex = RandomUtil.generateIntNumber(1, newFixedTermList.size());
            WebElement row = newFixedTermList.get(randomIndex);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", row);
            row.click();
            return newFixedTermFixed.getText();
        }

        if (newFixedTermFixed.isDisplayed()) {
            Reporter.log("Term is fixed and displayed as " + newFixedTermFixed.getText());
            return newFixedTermFixed.getText();
        }

        return newFixedTermFixed.getText();
    }

    public String getselectedAccountBalanceAddFundTo() {

        return selectedAccountBalanceAddFundsTo.getText();

    }

    public String enterAmountToAdd() {
        Assert.assertTrue(amountToAddInput.isDisplayed(), "Amount to add text field is not displayed");
        Reporter.log("Amount to add text field is displayed");
        int randomAmount = RandomUtil.generateIntNumber(1100, 11000);
        String strRandomAmount = Integer.toString(randomAmount);
        amountToAddInput.click();
        amountToAddInput.sendKeys(strRandomAmount);
        return strRandomAmount;
    }

    public String enterAmountToWithdraw() {
        Assert.assertTrue(amountToWithdrawInput.isDisplayed(), "Amount to withdrawtext field is not displayed");
        Reporter.log("Amount to withdraw text field is displayed");
        String amt = maturityAmountCapture.getText().replace(",", "");
        Double maturityAmount = Double.parseDouble(amt);
        Double maxWithdrawLimit = (maturityAmount - 1000);
        int newMaxLimit = maxWithdrawLimit.intValue();
        int randomAmount = RandomUtil.generateIntNumber(1, newMaxLimit);
        String strRandomAmountToWithdraw = Integer.toString(randomAmount);
        amountToWithdrawInput.sendKeys(strRandomAmountToWithdraw);
        return strRandomAmountToWithdraw;
    }

    public void clicksContinueButton() {

        Assert.assertTrue(continueButton.isDisplayed(), "Continue button is not displayed");
        Reporter.log("Continue button is displayed");
        continueButton.click();
        Reporter.log("Clicks on Continue button");
    }

    public void clicksConfirmButton() {

        Assert.assertTrue(confirmButton.isDisplayed(), "Confirm button is not displayed");
        Reporter.log("Confirm button is displayed");
        confirmButton.click();
        Reporter.log("Clicks on Confirm button");
    }

    public UpdateMaturiryInstructionsDetails captureUpdateMaturityDetails() {
        UpdateMaturiryInstructionsDetails objUpdateMaturiryInstructionsDetails = new UpdateMaturiryInstructionsDetails();
        String maturityType = selectOnMaturity();


        if (maturityType.contains(UpdateMaturityInstructionModel.maturityOptionRenewTotalBalance)) {
            objUpdateMaturiryInstructionsDetails.setnewFixedTerm(selectNewFixedTerm());
        }

        if (maturityType.contains(UpdateMaturityInstructionModel.maturityOptionDoNotRenew)) {
            objUpdateMaturiryInstructionsDetails.setSelectAddFundAccount(selectAddFundsToAccount());
        }

        if (maturityType.contains(UpdateMaturityInstructionModel.maturityOptionRenewPrincipleAmount)) {
            objUpdateMaturiryInstructionsDetails.setSelectAddFundAccount(selectAddFundsToAccount());
            objUpdateMaturiryInstructionsDetails.setnewFixedTerm(selectNewFixedTerm());
        }

        if (maturityType.contains(UpdateMaturityInstructionModel.maturityOptionAddFunds)) {
            objUpdateMaturiryInstructionsDetails.setSelectAddFundAccount(selectAddFundsFromAccount());
            objUpdateMaturiryInstructionsDetails.setnewFixedTerm(selectNewFixedTerm());
            objUpdateMaturiryInstructionsDetails.setAmountToAdd(enterAmountToAdd());
        }

        if (maturityType.contains(UpdateMaturityInstructionModel.maturityOptionAWithdrawFunds)) {
            objUpdateMaturiryInstructionsDetails.setSelectAddFundAccount(selectAddFundsToAccount());
            objUpdateMaturiryInstructionsDetails.setnewFixedTerm(selectNewFixedTerm());
            objUpdateMaturiryInstructionsDetails.setAmountWithDraw(enterAmountToWithdraw());
        }
        return objUpdateMaturiryInstructionsDetails;
    }

    public void verifyUpdateMaturityReviewPage(final UpdateMaturiryInstructionsDetails objUpdateMaturiryInstructionsDetails) {

        Assert.assertTrue(headingVerify.isDisplayed(), "Verify Update Maturity page is not displayed");
        Reporter.log("Verify Maturity page is displayed");

        String onMaturityReviewPage = onMaturityReview.getText();

        if (onMaturityReviewPage.contains(UpdateMaturityInstructionModel.maturityOptionRenewTotalBalance)) {

            Assert.assertTrue(newFixedTermReview.getText().contains(objUpdateMaturiryInstructionsDetails.getnewFixedTerm()),
                "Fixed term did not match");
        }


        if (onMaturityReviewPage.contains(UpdateMaturityInstructionModel.maturityOptionDoNotRenew)) {

            Assert.assertTrue(
                AddFundsToAccountReview.getText().contains(objUpdateMaturiryInstructionsDetails.getSelectAddFundAccount()),
                "Add Funds To Account did not match");
        }

        if (onMaturityReviewPage.contains(UpdateMaturityInstructionModel.maturityOptionRenewPrincipleAmount)) {

            Assert.assertTrue(newFixedTermReview.getText().contains(objUpdateMaturiryInstructionsDetails.getnewFixedTerm()),
                "Fixed term did not match");
            Assert.assertTrue(
                AddFundsToAccountReview.getText().contains(objUpdateMaturiryInstructionsDetails.getSelectAddFundAccount()),
                "Add Funds To Account did not match");
        }

        if (onMaturityReviewPage.contains(UpdateMaturityInstructionModel.maturityOptionAddFunds)) {

            Assert.assertTrue(newFixedTermReview.getText().contains(objUpdateMaturiryInstructionsDetails.getnewFixedTerm()),
                "Fixed term did not match");
            Assert.assertTrue(
                AddFundsToAccountReview.getText().contains(objUpdateMaturiryInstructionsDetails.getSelectAddFundAccount()),
                "Add Funds To Account did not match");
            Assert.assertTrue(amountToAddReview.getText().contains(objUpdateMaturiryInstructionsDetails.getAmountToAdd()),
                "Add Funds amount did not match");
        }

        if (onMaturityReviewPage.contains(UpdateMaturityInstructionModel.maturityOptionAWithdraw)) {

            Assert.assertTrue(newFixedTermReview.getText().contains(objUpdateMaturiryInstructionsDetails.getnewFixedTerm()),
                "Fixed term did not match");
            Assert.assertTrue(
                AddFundsToAccountReview.getText().contains(objUpdateMaturiryInstructionsDetails.getSelectAddFundAccount()),
                "Add Funds To Account did not match");
            Assert.assertTrue(amountToWithdraw.getText().contains(objUpdateMaturiryInstructionsDetails.getAmountWithdraw()),
                "Add Funds amount did not match");
        }
    }

    public void verifyBackToMYAccountFunctionality() {
        Assert.assertTrue(backToMyAccountButton.isDisplayed(), "Back to My Account button is not displayed");
        Reporter.log("Back To My Account button is displayed");
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", backToMyAccountButton);
        backToMyAccountButton.click();
        Reporter.log("Back to My Account button clicked");

        Assert.assertTrue(dashboardtitle.isDisplayed(),
            "Dashboard page is not displayed after clicking on Back to My Account button");
        Reporter.log("Dashboard page is displayed after clicking on Back To My Account button");
    }


    public void verifyfunctionalityofPrintButtonConfirmation() {

        Assert.assertTrue(printButtonConfirmation.isDisplayed(), "Print button is not displayed on confirmation page");
        Reporter.log("Print button is displayed on Confirmation page");

        printButtonConfirmation.click();
        Reporter.log("Print button clicked");

        Assert.assertTrue(printButtonOnPopUpConfirmation.isDisplayed(), "Print friedly pop up is not displayed");
        Reporter.log("Print friedly pop up is displayed after clciking on Print button");
    }

    public void verifyEditDetailsButtonFunctionality() {
        Assert.assertTrue(editDetailsButton.isDisplayed(), "Edit Details button is not displayed");
        Reporter.log("Edit Details button is displayed");

        editDetailsButton.click();
        Reporter.log("Edit Details button clicked");

        Assert.assertTrue(updateMaturityHeading.isDisplayed(),
            "Update Maturity capture page is not  displayed after clicking on Edit Details button");
        Reporter.log("Update Maturity capture page is displayed after clicking on Edit Details button");
    }

    public void cancelFlowFromReviewPage() {
        Assert.assertTrue(cancelButtonReview.isDisplayed(), "Cancel button is not displayed on Review page");
        Reporter.log("Cancel button is displayed on Update Maturity Review page");

        cancelButtonReview.click();
        Reporter.log("Cancel button is click from Review page");

        Assert.assertTrue(cancelButtonOnPopUpReview.isDisplayed(), "CAncel pop up is not displayed on review page");
        cancelButtonOnPopUpReview.click();
        Reporter.log("Click on Cancel button on pop up");


        Assert.assertTrue(updateMaturityHeading.isDisplayed(),
            "Update matutiry capture page is not displayed afte cancel the flow from review page");
        Reporter.log("Update matutiry capture page is displayed afte cancel the flow from review page");
    }

    public void cancelFlowFromCapturePage() {
        Assert.assertTrue(cancelButton.isDisplayed(), "Cancel button is not displayed on capture page");
        Reporter.log("Cancel button is displayed on Update Maturity capture page");

        cancelButton.click();
        Reporter.log("Cancel button is click from capture page");

        Assert.assertTrue(dashboardtitle.isDisplayed(), "Dashboard page is not displayed afte cancel the flow from capture page");
        Reporter.log("Dashboard page is displayed afte cancel the flow from capture page");
    }

    public void verifyUpdateMaturityConfirmationPage() {

        Assert
            .assertTrue(updateSuccessfulHeading.isDisplayed(), "Upadet suuccessful heading is not displayed on Confirmation page");
        Reporter.log("Upadet suuccessful heading is displayed as" + updateSuccessfulHeading.getText());

        Assert.assertTrue(confirmationMessage.isDisplayed(), "Confirmation message is not displayed on confirmation page");
        Reporter.log("Confirmation message is displayed as " + confirmationMessage.getText());

    }
}
