/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.uk;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.pageobject.TargetedMarketingModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Targeted
 * Marketing for UK entity. </b>
 * </p>
 */
public class TargetedMarketing extends TargetedMarketingModel {

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(TargetedMarketing.class);

    /** Locators which have changed on the dashboard page **/

    @FindBy(id = "GSP_MyaccountWest")
    private WebElement leftContentSlotDashboardPage;

    @FindBy(id = "GSP_MyaccountEast")
    private WebElement rightContentSlotDashboardPage;


    public TargetedMarketing(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    public void verifyMoveMoneyPageTopContentSlot() {
        TargetedMarketing.logger.error("NA for UK");
    }

    @Override
    public WebElement getLeftContentSlotDashboardPage() {
        return leftContentSlotDashboardPage;
    }

    /** Specifically added as to replace the FX calculator **/

    @Override
    public void verifyDashboardRightContentSlot() {
        Reporter.log("Verifying the Right Content Slot of the Dashboard Page");
        verifyRightContentSlot(rightContentSlotDashboardPage);
    }

    @Override
    public void verifyDashboardBottomContentSlot() {
        TargetedMarketing.logger.error("NA for UK");
    }

    /**
     * This is to check the Content Slot at the Right location in the Page.
     * (for UK)
     */

    @Override
    public void verifyRightContentSlot(final WebElement rightContentSlot) {
        scrollWebElementIntoView(rightContentSlot);
        Assert.assertTrue(rightContentSlot.isDisplayed(), "Right Content Slot is not displayed on the page");
        Reporter.log("Right Content Slot is displayed on the page");
    }

    @Override
    public void verifyGlobalViewPageBottomContentSlot() {
        TargetedMarketing.logger.error("NA for UK");
    }

    @Override
    public void verifyMoveMoneyConfirmationPageTopContentSlot() {
        TargetedMarketing.logger.error("NA for UK");
    }

    @Override
    public void verifyMoveMoneyConfirmationPageBottomContentSlot() {
        TargetedMarketing.logger.error("NA for UK");
    }
}
