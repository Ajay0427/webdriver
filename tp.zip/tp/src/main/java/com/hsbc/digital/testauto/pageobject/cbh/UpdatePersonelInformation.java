/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.cbh;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.library.TokenGenerator;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.pageobject.UpdatePersonelInformationModel;

/**
 * <p>
 * <b> Contains locators and functions for Story - Update Personal Information
 * for CBH entity </b>
 * </p>
 */
public class UpdatePersonelInformation extends UpdatePersonelInformationModel {

    @FindBy(xpath = "//h2[text()='Edit personal details']")
    private WebElement editPersonalDetailsHeading;

    @FindBy(xpath = "//input[contains(@id,'email')]")
    private WebElement emailInput;

    @FindBy(xpath = "//input[contains(@id,'mobilePhNo')]")
    private WebElement mobilePhoneInput;

    @FindBy(xpath = "//input[contains(@id,'homefaxNo')]")
    private WebElement homeFaxNumberInput;

    @FindBy(xpath = "//input[contains(@id,'officefaxNo')]")
    private WebElement officeFaxNumberInput;

    @FindBy(xpath = "//input[contains(@id,'workPhNo')]")
    private WebElement workPhoneNumberInput;

    @FindBy(xpath = "//input[contains(@id,'arrowid') and contains(@id,'dependents')]")
    private WebElement dependentDropnDownIcon;

    @FindBy(xpath = "//div[contains(@id,'dependents')]//table//tr")
    private List<WebElement> numberOfDependentDropnDownIconList;

    @FindBy(xpath = "//div[contains(@class,'dijitReset dijitInputField dijitButtonText')]//span")
    private WebElement numberOfDependentSelectedRandomValue;

    @FindBy(xpath = "//div[contains(@class,'dijitReset dijitInputField dijitButtonText')]//span")
    private WebElement occupationSelectedRandomValue;

    @FindBy(xpath = "//a[text()='Employment details']")
    private WebElement employmentDetailsLink;

    @FindBy(xpath = "//input[contains(@id,'arrowid') and contains(@id,'jobTitle')]")
    private WebElement occupationDropDownIcon;

    @FindBy(xpath = "//div[contains(@id,'jobTitle')]//table//tr")
    private List<WebElement> occupationDropDownIconList;

    @FindBy(xpath = "//div[contains(@class,'InputContainer')]//input[contains(@id,'salary')]")
    private WebElement annualSalaryInput;

    @FindBy(xpath = "//input[contains(@id,'employer')]")
    private WebElement employerInput;

    // Update Personal Information Review page x paths

    @FindBy(xpath = "//dt[text()='Email']/following-sibling::dd[1]")
    private WebElement eMailReview;

    @FindBy(xpath = "//dt[text()='Home phone number']/following-sibling::dd[1]")
    private WebElement homePhoneNumberReview;

    @FindBy(xpath = "//dt[text()='Mobile phone number']/following-sibling::dd[1]")
    private WebElement mobilePhoneNumberReview;

    @FindBy(xpath = "//dt[text()='Number of dependents']/following-sibling::dd[1]")
    private WebElement noOfDependentsReview;

    @FindBy(xpath = "//dt[text()='Occupation']/following-sibling::dd[1]")
    private WebElement occupationReview;

    @FindBy(xpath = "//dt[text()='Work phone number']/following-sibling::dd[1]")
    private WebElement workPhoneNumberReview;

    @FindBy(xpath = "//dt[text()='Fax number']/following-sibling::dd[1]")
    private WebElement faxNumberReview;

    @FindBy(xpath = "//dt[text()='Office fax number']/following-sibling::dd[1]")
    private WebElement officeFaxNumberReview;

    @FindBy(xpath = "//dd[@data-dojo-attach-point='dapVerifySalary']")
    private WebElement annualSalaryReview;

    @FindBy(xpath = "//input[contains(@id,'reauthOTP')]")
    private WebElement reauthIputFiled;

    @FindBy(xpath = "//span[contains(@widgetid,'Button')]/following-sibling::button[text()='Cancel']")
    private WebElement cancelButtonReview;

    @FindBy(xpath = "//button[text()='Update details']/following-sibling::button[text()='Cancel']")
    private WebElement cancelButtonCapture;

    @FindBy(xpath = "//a[contains(@id,'ContactInformationForm') and text()='Cancel']")
    private WebElement cancelButtonPopUpCapture;

    @FindBy(xpath = "//a[contains(@id,'ContactInformationForm') and contains(@id,'ok')]")
    private WebElement popUpCancelButtonReview;

    @FindBy(xpath = "//span[contains(@id,'Button') and contains(text(),'Don')]")
    private WebElement popUpDontCancelButton;

    private final TokenGenerator tokenGenerator;

    private static final String MOBILE_PHONE = "0740630704";

    public UpdatePersonelInformation(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        tokenGenerator = new TokenGenerator();
    }

    @Override
    public AccountDetails inputContactDetails() {

        AccountDetails accountDetails = new AccountDetails();

        Assert.assertTrue(emailInput.isDisplayed(), "eMail is not displayed");
        emailInput.clear();
        String email = RandomUtil.generateAlphabatic(5) + "@gmail.com";
        emailInput.sendKeys(email);
        Reporter.log("eMail is inputed as : " + email);
        accountDetails.setEmail(email);

        Assert.assertTrue(homePhoneInput.isDisplayed(), "Home phone number is not displayed");
        homePhoneInput.clear();
        String homePhone = "0" + Integer.toString(RandomUtil.generateIntNumber(100000000, 999999999));
        homePhoneInput.sendKeys(homePhone);
        Reporter.log("Home phone number is inputed as : " + homePhone);
        accountDetails.setHomePhoneNumber(homePhone);

        Assert.assertTrue(mobilePhoneInput.isDisplayed(), "Mobile phone number is not displayed");
        mobilePhoneInput.clear();

        mobilePhoneInput.sendKeys(UpdatePersonelInformation.MOBILE_PHONE);
        Reporter.log("Home phone number is inputed as : " + UpdatePersonelInformation.MOBILE_PHONE);
        accountDetails.setMobilePhoneNumber(UpdatePersonelInformation.MOBILE_PHONE);

        Assert.assertTrue(workPhoneNumberInput.isDisplayed(), "Work phone number is not displayed");
        workPhoneNumberInput.clear();
        String workPhone = "0" + Integer.toString(RandomUtil.generateIntNumber(100000000, 999999999));
        workPhoneNumberInput.sendKeys(workPhone);
        Reporter.log("Work phone number is inputed as : " + workPhone);
        accountDetails.setWorkPhoneNumber(workPhone);

        Assert.assertTrue(homeFaxNumberInput.isDisplayed(), "Home fax number is not displayed");
        homeFaxNumberInput.clear();
        String homeFax = "0" + Integer.toString(RandomUtil.generateIntNumber(100000000, 999999999));
        homeFaxNumberInput.sendKeys(homeFax);
        Reporter.log("Home fax number is inputed as : " + homeFax);
        accountDetails.setFaxNumber(homeFax);

        Assert.assertTrue(officeFaxNumberInput.isDisplayed(), "Office fax number is not displayed");
        officeFaxNumberInput.clear();
        String officeFax = "0" + Integer.toString(RandomUtil.generateIntNumber(100000000, 999999999));
        officeFaxNumberInput.sendKeys(officeFax);
        Reporter.log("Office fax number is inputed as : " + officeFax);
        accountDetails.setWorkFaxNumber(officeFax);

        Assert.assertTrue(dependentDropnDownIcon.isDisplayed(), "Dependent drop down icon is not displayed");
        dependentDropnDownIcon.click();
        Reporter.log("Click on Dependent drop down icon");

        int randomIndex = RandomUtil.generateIntNumber(1, numberOfDependentDropnDownIconList.size());
        WebElement noOfDepedantValue = numberOfDependentDropnDownIconList.get(randomIndex);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", noOfDepedantValue);
        noOfDepedantValue.click();
        accountDetails.setNoOfDependents(numberOfDependentSelectedRandomValue.getText());

        Assert.assertTrue(employmentDetailsLink.isDisplayed(), "Employement Details link is not displayed");
        employmentDetailsLink.click();

        Assert.assertTrue(occupationDropDownIcon.isDisplayed(), "Occupation drop down icon is not displayed");
        occupationDropDownIcon.click();
        Reporter.log("Click on Occupation drop down icon");

        int randomIndexForOccupation = RandomUtil.generateIntNumber(1, occupationDropDownIconList.size());
        WebElement occupationRow = occupationDropDownIconList.get(randomIndexForOccupation);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", occupationRow);
        occupationRow.click();
        accountDetails.setOccupation(occupationSelectedRandomValue.getText());

        Assert.assertTrue(annualSalaryInput.isDisplayed(), "Annuam Salary text field is not displayed");
        String annualSalary = Integer.toString(RandomUtil.generateIntNumber(100000, 1000000));
        annualSalaryInput.clear();
        annualSalaryInput.sendKeys(annualSalary);
        Reporter.log("Salary is inputted ");
        accountDetails.setAnualSalary(annualSalary);

        Assert.assertTrue(employerInput.isDisplayed(), "Employer text field is not displayed");
        String employeName = RandomUtil.generateAlphabatic(10);
        employerInput.clear();
        employerInput.sendKeys(employeName);
        accountDetails.setEmployerName(employeName);
        Reporter.log("Name is inputted");

        return accountDetails;

    }

    @Override
    public void verifyReviewPage(final Map<String, String> profileProperties, final AccountDetails objAccountDetails)
        throws IOException {

        Assert.assertTrue(eMailReview.getText().contains(objAccountDetails.getEmail()), "eMail did not match");
        Assert.assertTrue(homePhoneNumberReview.getText().contains(objAccountDetails.getHomePhoneNumber()),
            "home phone number did not match");
        /*
         * Assert.assertTrue(mobilePhoneNumberReview.getText().contains(
         * objAccountDetails.getMobilePhoneNumber()),
         * "Mobile phone number did not match");
         */
        Assert.assertTrue(workPhoneNumberReview.getText().contains(objAccountDetails.getWorkPhoneNumber()),
            "Work phone number did not match");
        Assert.assertTrue(faxNumberReview.getText().contains(objAccountDetails.getFaxNumber()), "Fax number did not match");
        Assert.assertTrue(officeFaxNumberReview.getText().contains(objAccountDetails.getWorkFaxNumber()),
            "Office Fax number did not match");
        Assert.assertTrue(annualSalaryReview.getText().replace(",", "").contains(objAccountDetails.getAnnualSalary()),
            "Annual Salary did not match");
        Assert.assertTrue(noOfDependentsReview.getText().contains(objAccountDetails.getNoOfDependents()),
            "No of dependent value did not match");
        Assert.assertTrue(occupationReview.getText().contains(objAccountDetails.getOccupation()), "Occupation value did not match");

        String userName = profileProperties.get("userName");
        String serialNumber = profileProperties.get("serialNumber");
        String otpkey = profileProperties.get("otpKey");
        String reauthCode = tokenGenerator.generateReauthCode(userName, serialNumber, otpkey);

        Assert.assertTrue(reauthIputFiled.isDisplayed(), "Field to enter reauth code is not displayed");
        reauthIputFiled.sendKeys(reauthCode);

    }

    @Override
    public void verifyEditDetailsFunctionality() {
        Assert.assertTrue(editPersonalDetailsHeading.isDisplayed(), "Edit button functionality not working");
    }

    public void verifyDetailCapturePage(final WebElement locator, final String value) {
        Assert.assertTrue(locator.getAttribute("value").equalsIgnoreCase(value),
            "Updated value is i.e." + locator.getAttribute("value") + " is not correct");
        Reporter.log("Displayed value i.e." + locator.getAttribute("value") + " is correct");

    }

    public void verifyNoOfDependantsNOccupation(final WebElement locator, final String value) {
        Assert.assertTrue(locator.getText().equalsIgnoreCase(value), "Updated value is i.e." + locator.getText()
            + " is not correct");
        Reporter.log("Displayed value i.e." + locator.getText() + " is correct");
    }

    @Override
    public void verifyUpdatedDetailsOnCapturePage(AccountDetails objAccountDetails) {
        verifyDetailCapturePage(emailInput, objAccountDetails.getEmail());
        verifyDetailCapturePage(homePhoneInput, objAccountDetails.getHomePhoneNumber());
        verifyDetailCapturePage(homeFaxNumberInput, objAccountDetails.getFaxNumber());
        verifyDetailCapturePage(officeFaxNumberInput, objAccountDetails.getWorkFaxNumber());
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", numberOfDependentSelectedRandomValue);
        verifyNoOfDependantsNOccupation(numberOfDependentSelectedRandomValue, objAccountDetails.getNoOfDependents());
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", employmentDetailsLink);
        employmentDetailsLink.click();
        verifyNoOfDependantsNOccupation(occupationSelectedRandomValue, objAccountDetails.getOccupation());
        annualSalaryInput.click();
        verifyDetailCapturePage(annualSalaryInput, objAccountDetails.getAnnualSalary());
        verifyDetailCapturePage(employerInput, objAccountDetails.getEmployerName());
    }

    @Override
    public void CancelFlowFromCapturePage() {
        Assert.assertTrue(cancelButtonCapture.isDisplayed(), "Cancel button is not displayed on Captutre page");
        cancelButtonCapture.click();
        Reporter.log("Cancel button clicked on capture page");
        Assert.assertTrue(cancelButtonPopUpCapture.isDisplayed(), "Cancel button is not displayed on op up on Captutre page");
        cancelButtonPopUpCapture.click();
        Reporter.log("Click on Cancel button  on popup page");
    }

    @Override
    public void CancelFlowFromReviewPage() {
        Assert.assertTrue(cancelButtonReview.isDisplayed(), "Cancel button is not displayed on Review page");
        cancelButtonReview.click();
        Reporter.log("Cancel clicked on review page");
        Assert.assertTrue(popUpCancelButtonReview.isDisplayed(), "Cancel button is not displayed on op up on Review page");
        popUpCancelButtonReview.click();
        Reporter.log("Click on Cancel button on popup page");
    }

    @Override
    public void clickOnCancel() {
        Assert.assertTrue(cancelButtonReview.isDisplayed(), "Cancel button is not displayed on Review page");
        cancelButtonReview.click();
    }

    @Override
    public void clickAndVerifyPopUpDontCancel() {
        popUpDontCancelButton.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ediDetailsButton);
        Assert.assertTrue(ediDetailsButton.isDisplayed(), UpdatePersonelInformationModel.ERROR_MESSAGE);
        Reporter.log("Successfully Verified PopUpDontCancel Button");

    }
}
