/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.us;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.hsbc.digital.testauto.pageobject.LoginModel;


/**
 * <p>
 * <b> Login Specific changes to US Entity. </b>
 * 
 * @author Shrikant Joshi
 * @version 1.0.0
 *          </p>
 */
public class LoginPage extends LoginModel {

    @FindBy(xpath = "//input[@id='secureCode']")
    private WebElement secureCode;

    @FindBy(xpath = "//*[contains(@name,'pass') and @type='password']")
    private WebElement passwordField;

    @FindBy(xpath = "//div[contains(@id, 'viewNo') and contains(@class, 'showStep')]//input[contains(@class, 'submit_input')]")
    private WebElement submitButton;


    public LoginPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.hsbc.digital.testauto.pageobject.LoginModel#loginWithoutOtp(java
     * .lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public void loginWithoutOtp(final String userName, final String memorableAnswer, final String password) {
        // waitAndCloseLoginPopUp();
        loginToUserNamePage(userName, password);
        wait.until(ExpectedConditions.visibilityOf(passwordField));
        passwordField.sendKeys(password);
    }


    public void typePassword(final String password) {
        wait.until(ExpectedConditions.visibilityOf(passwordField));
        passwordField.sendKeys(password);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.hsbc.digital.testauto.pageobject.LoginModel#waitAndClickSubmit()
     */
    @Override
    public void waitAndClickSubmit() {
        wait.until(ExpectedConditions.visibilityOf(submitButton));
        submitButton.click();
    }

    private final By popUpOverLay = By.cssSelector("a.close");
    private final By popUpWindow = By.xpath("//*[contains(@class, 'lightboxInner')]");

    @Override
    protected void waitAndCloseLoginPopUp() {

        wait.until(ExpectedConditions.visibilityOf(driver.findElement(popUpWindow)));
        if (driver.findElements(popUpWindow).size() > 0 && driver.findElement(popUpWindow).isDisplayed()) {
            driver.findElement(popUpOverLay).click();
        }
    }

    @Override
    public void loginWithOtp(final String userName, final String memorableAnswer, final String otpKey, final String serialNumber,
        final String password) {

        waitAndCloseLoginPopUp();
        super.loginToUserNamePage(userName, password);
        String otp = StringUtils.EMPTY;
        try {
            otp = super.tokenGenerator.generateOTP(userName, serialNumber, otpKey);
            super.wait.until(ExpectedConditions.visibilityOf(secureCode));
            secureCode.clear();
            secureCode.sendKeys(otp);

        } catch (IOException e) {
            LoginModel.logger.error("Exception thrown LoginModel:loginWithOtp :", e);
        }
    }

}
