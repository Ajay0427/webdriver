/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.us;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Flyover
 * Menu for Canada entity. </b>
 * </p>
 */
public class FlyerMenuNavigation extends FlyerMenuNavigationModel {

    /*
     * My Banking Header Links
     */
    @FindBy(xpath = "//span[text()='My Accounts']")
    private WebElement myAccountLinkMyBankingHeader;

    /*
     * My Banking - Move Money Header Links
     */
    @FindBy(linkText = "Bill payment history")
    private WebElement billPaymentHistoryLinkMoveMoneyMyBankingHeader;

    /*
     * My Banking - My profile Links by Bhargav Choudhury
     */
    @FindBy(linkText = "My contact information")
    private WebElement updatePersonalDetailsLinkMyProfileMyBankingHeader;

    @FindBy(linkText = "Communication preferences")
    private WebElement communicationPreferencesLinkMyProfileMyBankingHeader;

    /*
     * Products & Services - Account Opening Links
     */

    @FindBy(linkText = "Order cheques")
    private WebElement orderChequesLinkChequesMyBankingHeader;

    /*
     * My Banking - Travel Links
     */
    @FindBy(linkText = "Notify us of travel")
    private WebElement notifyUsOfTravelLinkTravelMyBankingHeader;

    /*
     * My Banking - Account services Links
     */
    @FindBy(linkText = "Rename accounts")
    private WebElement renameAccountsLinkAccountServicesMyBankingHeader;

    @FindBy(linkText = "View foreign exchange rates")
    private WebElement viewForeignExchangeLinkAccountServicesMyBankingHeader;

    /*
     * My Banking - Documents Links
     */
    @FindBy(linkText = "View and print statements")
    private WebElement viewAndPrintStatementsLinkDocumentsMyBankingHeader;

    @FindBy(linkText = "View terms and conditions")
    private WebElement viewTermsAndConditionsLinkDocumentsMyBankingHeader;

    @FindBy(linkText = "My documents")
    private WebElement myDocumentsLink;

    /*
     * Products & Services - Account Opening Links
     */
    @FindBy(xpath = "//a[text()='Everyday Banking']")
    private WebElement everydayBankingLinkAccountOpeningProductAndServicesHeader;

    @FindBy(xpath = "//a[text()='GICs and Term Deposits']")
    private WebElement gicAndTermDepositsLinkAccountOpeningProductAndServicesHeader;

    @FindBy(xpath = "//a[text()='Tax-Free Savings Accounts (TFSA)']")
    private WebElement taxFreeSavingsLinkAccountOpeningProductAndServicesHeader;

    /*
     * Existing Locators
     */

    @FindBy(linkText = "Add or remove a country")
    private WebElement addRemoveCountryLink;

    @FindBy(xpath = "//a[text()='Rename accounts']")
    private WebElement renameAccountsLink;

    @FindBy(xpath = "//*[@data-uid= 'lostStolenCard']")
    private WebElement reportLostStolenCard;

    @FindBy(linkText = "Pending payments or transfers")
    private WebElement futurePayment;

    @FindBy(xpath = ".//a[@data-uid='payeemanagement']")
    private WebElement linkMyPayees;

    /*
     * My Banking - Statements Header Links
     */
    @FindBy(linkText = "Statements / Advices")
    private WebElement statementOrAdvicesLinkStatementsMyBankingHeader;

    @FindBy(linkText = "My statements and other documents")
    private WebElement statementorDocumentsLinkStatementsMyBankingHeader;

    /* Communication preferences Link */
    @FindBy(linkText = "Edit personal details")
    private WebElement personalContactDetailsLink;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(FlyerMenuNavigation.class);

    public FlyerMenuNavigation(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    /*
     * --------------------------- NAVIGATION FLOWS ---------------------------
     */
    @Override
    public void navigateToGlobalViewPage() {
        super.myMenu(this.addRemoveCountryLink);
    }

    @Override
    public void navigateToRenameAccountsPage() {
        super.myMenu(this.renameAccountsLink);
    }

    @Override
    public void navigateToReportLostOrStolenCardPage() {
        super.myMenu(this.reportLostStolenCard);
    }

    @Override
    public void navigateToFutureDatedTransaction() {
        super.myMenu(this.futurePayment);
    }

    @Override
    public void navigateToApplyOpenNewTD() {
        super.myMenuProductAndServices(this.gicAndTermDepositsLinkAccountOpeningProductAndServicesHeader);
    }

    @Override
    public void navigateToTFSA() {
        super.myMenuProductAndServices(taxFreeSavingsLinkAccountOpeningProductAndServicesHeader);
    }

    @Override
    public void navigateToEverydayBanking() {
        super.myMenuProductAndServices(everydayBankingLinkAccountOpeningProductAndServicesHeader);
    }

    @Override
    public void navigateToMypayeesPage() {
        super.myMenu(this.linkMyPayees);
    }

    @Override
    public void navigateToBillPaymentHistory() {
        super.myMenu(billPaymentHistoryLinkMoveMoneyMyBankingHeader);
    }

    @Override
    public void navigateToUpdateContactDetails() {
        navigateToCP();
        personalContactDetailsLink.click();
    }

    @Override
    public void navigateToCP() {
        super.myMenu(communicationPreferencesLinkMyProfileMyBankingHeader);
    }

    @Override
    public void navigateToMyDocuments() {
        myMenu(this.myDocumentsLink);
    }

    @Override
    public void navigateToStatementsAndAdvices() {

        super.myMenu(statementorDocumentsLinkStatementsMyBankingHeader);
    }

    /* By Prateek2 */
    @Override
    public void navigateToMyStatementsAndOtherDocuments() {
        super.myMenu(this.statementorDocumentsLinkStatementsMyBankingHeader);
    }

    @Override
    public void mouseOverOnMyBanking() {
        Actions action = new Actions(driver);
        action.moveToElement(myBankingLinkHeader).build().perform();
    }
}
