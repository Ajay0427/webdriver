package com.hsbc.digital.testauto.pageobject.au;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModelNew;

public class MoveMoneyCapturePageAU extends MoveMoneyCapturePageModelNew {

    private final static Map<String, String> companyReferenceValue = new HashMap<>();

    @FindBy(xpath = "//div[@data-dojo-attach-point='_pyeChargesNode']//div[contains(@class,'dijitDownArrowButton')]//input[contains(@id,'arrowid')]")
    private WebElement payeeChargeIcon;

    @FindBy(xpath = "//div[@data-dojo-attach-point='_purOfPymtbijit']//div[contains(@class,'dijitDownArrowButton')]//input[contains(@id,'arrowid')]")
    private WebElement reasonForTransactionIcon;


    public MoveMoneyCapturePageAU(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);

    }
    static {
        companyReferenceValue.put("SRI LANKA TELECOM ( ALL SERVICES )", "12");
        companyReferenceValue.put("MOBITEL (PVT) LTD", "10");
    }

    @Override
    public String selectFeesPaidBy() {
        return selectRandamValue(payeeChargeIcon, listDropdown);
    }

    @Override
    public String selectReasonForTransaction(Transaction transaction) {
        return selectRandamValue(reasonForTransactionIcon, listDropdown);
    }

    @Override
    public AccountDetails enterNewCompanyPayeeDetails() {
        AccountDetails accountDetails = new AccountDetails();
        clickTabsToOpenNewCompanyPayeeDetails();
        Object[] values = companyReferenceValue.keySet().toArray();
        Object key = values[new Random().nextInt(values.length)];
        selectValue(companyListDropIcon, listMenuItems, key.toString());
        accountDetails.setAccountName(key.toString());
        String companyReference = RandomUtil.generateIntNumber(Integer.parseInt(companyReferenceValue.get(key)));
        companyReferenceText.clear();
        companyReferenceText.sendKeys(companyReference);
        companyReferenceText.sendKeys(Keys.RETURN);
        accountDetails.setAccountNumber(companyReference);
        return accountDetails;
    }

    @Override
    protected AccountDetails enterNewPayeeDetails(String payeeName, String payeeAccountNumber) {
        AccountDetails accountDetails = new AccountDetails();
        accountNumberText.clear();
        accountNumberText.sendKeys(payeeAccountNumber);
        accountDetails.setAccountNumber(payeeAccountNumber);
        accountNumberText.sendKeys(Keys.RETURN);
        return accountDetails;
    }

    @Override
    public String enterPayeeReferenceText() {
        return StringUtils.EMPTY;

    }

    @Override
    public String enterAddress() {
        return StringUtils.EMPTY;
    }
}
