/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.uk;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.pageobject.QuickMoveMoneyCaptureModel;

/**
 * 
 * This model class will hold locators and functionality for Quick move
 * money widget for UK entity .This widget is present on Dashboard page. 
 * @author Vaibhav Sharma
 * @version 1.0.0
 */

public class QuickMoveMoney extends QuickMoveMoneyCaptureModel {

    private static final String FROM_ACCOUNT_TEXT = "From";
    private static final String TO_ACCOUNT_TEXT = "To";

    @FindBy(xpath = "//table[contains(@id, 'SelectDropDown_0')]//span[@class='balance presentation']")
    private WebElement fromAccountBalance;


    /**
    * To Account Number
    */
    @FindBy(xpath = " //div[starts-with(@id,'group_gpib_mvmny_bijit_SelectAccount_') and not(contains(@id,'_accountLabel'))][2]//div[contains(@class,'dijitSelectMenu')]/table//span[contains(@class,'row') and not(contains(@class,'noDisplay'))]//span[contains(@class,'accountDetailsactSlOption')]")
    private WebElement toAccountNumber;

    /**
     * To Account Balance
     */
    @FindBy(xpath = "//div[starts-with(@id,'group_gpib_mvmny_bijit_SelectAccount_') and not(contains(@id,'_accountLabel'))][2]//table[contains(@id, 'SelectDropDown')]//span[@class='balance presentation']")
    protected WebElement toAccountBalance;


    public QuickMoveMoney(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    public WebElement getfromAccountBalanceElement() {
        return this.fromAccountBalance;
    }


    /**
     * Select the To Account Randomly and set AccountName,AccountNumber and
     * Balance
     * 
     * @return AccountDetails Object
     */
    public AccountDetails selectToAccount() {
        AccountDetails accountDetails = new AccountDetails();
        selectAccount(toDropDownIcon, dropDownItems, null);
        accountDetails.setAccountName(toAccountName.getText());
        accountDetails.setAccountNumber(toAccountNumber.getText());
        accountDetails.setAccountBalance(toAccountBalance.getText());
        Reporter.log("Account :" + toAccountName.getText() + ":: " + toAccountNumber.getText() + " selected in To Drop down :");
        return accountDetails;
    }

    /**
     * Select the From Account Based on Details
     * 
     * @param accountDetails
     *            :AccountDetails Object
     * @return AccountDetails Object
     */
    public AccountDetails selectFromAccount(final AccountDetails accountDetails) {
        AccountDetails accDetails = new AccountDetails();
        selectAccount(fromDropDownIcon, dropDownItems, accountDetails);
        accDetails.setAccountBalance(fromAccountBalance.getText());
        return accDetails;
    }


    public AccountDetails selectToAccount(final AccountDetails accountDetails) {
        AccountDetails accDetails = new AccountDetails();
        selectAccount(toDropDownIcon, dropDownItems, accountDetails);
        accDetails.setAccountBalance(toAccountBalance.getText());
        return accDetails;
    }


    /**
     * Check that Default From Account is Selected
     * 
     * @return whether default from account is selected or not
     */
    @Override
    public boolean isDefaultFromAccountSelected() {
        return FROM_ACCOUNT_TEXT.equals(defaultFromAccount.getText());
    }

    /**
     * Check that Default To Account is selected
     * 
     * @return whether default to account is selected or not
     */
    @Override
    public boolean isDefaultToAccountSelected() {
        return TO_ACCOUNT_TEXT.equals(defaultToAccount.getText());
    }


}
