/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.ManageFutureDatedDetails;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

/**
 * <p>
 * <b> This model class will hold locators and functionality for Manage Future
 * Dated Payment of the Application </b> <br>
 * </p>
 * 
 * @author Nirmal
 * @version 1.0.0
 */
public abstract class ManageFutureDatedPaymentModel {

    protected final WebDriver driver;
    protected WebDriverWait wait;

    protected static final String VERIFY_DOMESTIC_VALUE = "Domestic";
    protected static final String VERIFY_RECURRING_VALUE = "Recurring Payment";
    private static final String VERIFY_INTERNATIONAL_VALUE = "Wire";
    private static final String INPUT_FORMAT = "MM/dd/yyyy";
    private static final String DISPLAY_LIST_FORMAT = "dd MMM yyyy";

    /*
     * Processing Overlay
     */
    protected By processingOverlayDialog = By.xpath("//div[@class='pageLoadingOverlay']");

    /*
     * No Transaction Message
     */
    @FindBy(xpath = "//div[@class='alertPanel']")
    private List<WebElement> noTransactionMessage;

    /*
     * For View Tab of the list
     */
    @FindBy(xpath = "//span[contains(text(),'Date')]")
    private WebElement tabDateForListView;

    @FindBy(xpath = "//label/span[contains(text(),'Account')]")
    private WebElement tabAccountForListView;

    @FindBy(css = "span[id^= 'dijit_form_ToggleButton']")
    private WebElement filterTransactionsButton;

    @FindBy(xpath = "//div[contains(@id,'Dialog') and contains(@class,'dijitDialogFixed')]//button[contains(@title,'Close')]")
    protected WebElement crossTickButton;

    /*
     * Print Buttons
     */
    @FindBy(xpath = "//span[contains(@class,'print')]")
    private WebElement printWholeList;

    @FindBy(xpath = "//div[contains(@class,'dijitTitlePaneTitleOpen')]//following-sibling::div/descendant::span[contains(text(),'Print')]")
    private WebElement printTransactionButton;

    @FindBy(xpath = "//*[contains(text(),'Future dated')]/..")
    private List<WebElement> printPopupPanel;

    @FindBy(xpath = "//*[contains(text(),'Future dated')]/../div[contains(@class,'submitButtonsPanel')]/button[@class='btnTertiary']")
    private List<WebElement> printPopupCancelButton;

    /*
     * After Clicking on Filter Button
     */
    /*
     * Dropdown Icons
     */
    @FindBy(xpath = "//div[contains(text(),'account')]//following-sibling::div//input[contains(@id,'SelectDropDown')]")
    private WebElement searchByAccountDropdownIcon;

    @FindBy(xpath = "//div[contains(text(),'type')]//following-sibling::div//input[contains(@id,'Select')]")
    private WebElement searchByTransferTypeDropdownIcon;

    @FindBy(xpath = "//div[contains(text(),'frequency')]//following-sibling::div//input[contains(@id,'Select')]")
    private WebElement searchByTransferFrequencyDropdownIcon;

    /*
     * Default Values in the dropdowns
     */
    @FindBy(xpath = "//div[contains(text(),'account')]//following-sibling::div//span[contains(@class,'SelectLabel')]")
    private WebElement valueInByAccountDropdown;

    @FindBy(xpath = "//div[contains(text(),'type')]//following-sibling::div//span[contains(@class,'SelectLabel')]")
    private WebElement valueInByTransferTypeDropdown;

    @FindBy(xpath = "//div[contains(text(),'frequency')]//following-sibling::div//span[contains(@class,'SelectLabel')]")
    private WebElement valueInByTransferFrequencyDropdown;

    /*
     * Fields of Date and Amount
     */
    @FindBy(xpath = "//input[contains(@id,'_dateFrom') and contains(@class,'InputInner')]")
    private WebElement searchByDateFromInput;

    @FindBy(xpath = "//input[contains(@id,'_dateTo') and contains(@class,'InputInner')]")
    private WebElement searchByDateToInput;

    @FindBy(css = "input[id$='fromAmount_CurrencyTextBox']")
    private WebElement searchByFromAmount;

    @FindBy(css = "input[id$='toAmount_CurrencyTextBox']")
    private WebElement searchByToAmount;

    /*
     * Buttons on Filter pane
     */
    @FindBy(css = "li.submitButtonsPanel>input")
    private WebElement showResultButton;

    @FindBy(xpath = "//span[contains(text(), 'result')]")
    private WebElement cancelResultButton;

    /*
     * Select from dropdown
     */
    @FindBy(xpath = "//div[contains(@class,'account')]//tr[starts-with(@id,'dijit_MenuItem')]")
    private List<WebElement> allAccountDropDownItems;

    @FindBy(xpath = "//div[contains(@class,'Type')]//tr[starts-with(@id,'dijit_MenuItem')]//td[@class='dijitReset dijitMenuItemLabel']")
    private List<WebElement> allTransferTypeDropDownItems;

    @FindBy(xpath = "//div[contains(@class,'Frequency')]//tr[starts-with(@id,'dijit_MenuItem')]//td[@class='dijitReset dijitMenuItemLabel']")
    private List<WebElement> allTransferFrequencyDropDownItems;

    /*
     * For Edit Functionality
     */
    @FindBy(xpath = "//div[contains(@class,'dijitTitlePaneTitleOpen')]//following-sibling::div/descendant::span[contains(text(),'Edit')]")
    protected WebElement editDetailsButton;

    @FindBy(xpath = "//form[starts-with(@id,'uniqName') and @class='formPanel']//dt[contains(text(),'Amount')]//following-sibling::dd[1]//input[contains(@class,'dijitReset dijitInputInner')]")
    private WebElement editAmount;

    @FindBy(xpath = "//form[starts-with(@id,'uniqName') and @class='formPanel']//span[contains(@id,'dijit_form_Button') and contains(text(),'Save')]")
    private WebElement saveEditDetails;

    @FindBy(xpath = "//form[starts-with(@id,'uniqName') and @class='formPanel']//span[contains(@id,'dijit_form_Button') and contains(text(),'Cancel')]")
    protected WebElement cancelEditDetails;

    @FindBy(xpath = "//form[starts-with(@id,'uniqName') and @class='formPanel']//span[contains(@id,'dijit_form_Button') and contains(text(),'Delete')]")
    private WebElement editDetialsDeleteButton;

    @FindBy(xpath = "//div[@class='dijitDialogFixed dijitDialog']//button[@class='btnSecondary']")
    private WebElement cancelEditDetailsYesButton;

    @FindBy(xpath = "//div[@class='dijitDialogFixed dijitDialog']//div[contains(@class,'alertButton')]//button[@class='btnTertiary']")
    private WebElement cancelEditDetailsNoButton;

    @FindBy(xpath = "//div[contains(@id,'FutureTransactionEditReview') and not (contains(@style,'display: none'))]//span[contains(@class,'subTitleField')]")
    protected WebElement paymentSummaryLabelOnEditDetailsReviewPage;

    @FindBy(xpath = "//div[contains(@id,'FutureTransactionEditReview') and not (contains(@style,'display: none'))]//button[contains(@class,'btnPrimary')]")
    protected WebElement confirmEditDetailsContinueButton;

    @FindBy(xpath = "//div[contains(@class,'hdx_bijits_mvmny_bijit_FutureTransactionEditReview')]")
    private List<WebElement> findDiv;

    @FindBy(xpath = "//div[contains(@id,'FutureTransactionEditConfirm') and not (contains(@style,'display: none'))]//div[contains(@class,'alertPanel')]")
    protected WebElement confirmMessageOnEditDetailsConfirmationPage;

    @FindBy(xpath = "//div[contains(@id,'FutureTransactionEditConfirm') and not (contains(@style,'display: none'))]//button[contains(@class,'btnTertiary')]")
    private WebElement editDetailsConfirmationPageCloseButton;

    @FindBy(xpath = "//div[contains(@id,'FutureTransactionEditConfirm') and not (contains(@style,'display: none'))]//button[contains(@title,'Close')]")
    protected WebElement editDetailsConfirmationPageCrossTickButton;

    @FindBy(xpath = "//div[contains(@id,'FutureTransactionEditConfirm') and not (contains(@style,'display: none'))]//button[contains(@class,'btnSecondary')]")
    private WebElement editDetailsConfirmationPagePrintButton;

    @FindBy(xpath = "//div[contains(@id,'FutureTransactionEditReview') and not (contains(@style,'display: none'))]//button[contains(@class,'btnTertiary')]")
    private WebElement editDetailsReviewPageCancelButton;

    @FindBy(xpath = "//div[contains(@id,'FutureTransactionEditReview') and not (contains(@style,'display: none'))]//button[contains(@title,'Close')]")
    private WebElement confirmEditDetailsCrossTickButton;

    /*
     * Verification for show details gettext
     */
    @FindBy(xpath = "//div[contains(@class,'dijitTitlePaneTitleOpen')]//following-sibling::div/descendant::dt[contains(text(),'From')]/following::dd")
    protected WebElement fromAccountValueInShowDetails;

    @FindBy(xpath = "//div[contains(@class,'dijitTitlePaneTitleOpen')]/../../preceding-sibling::div//div[@class='account']/span[@class='number'] | //div[contains(@class,'dijitTitlePaneTitleOpen')]/ancestor::div[contains(@id,'uniqName')]//span[contains(@class,'Number')]")
    private WebElement fromAccountValueOnShowDetails;

    @FindBy(xpath = "//div[contains(@class,'dijitTitlePaneTitleOpen')]//following-sibling::div/descendant::dt[contains(text(),'Amount')]/following::dd/span[@data-dojo-attach-point='_amountData']")
    protected WebElement amountValueInShowDetails;

    @FindBy(xpath = "//div[contains(@class,'dijitTitlePaneTitleOpen')]/../../preceding-sibling::div//span[@class='amountText']")
    protected WebElement amountValueOnShowDetails;

    @FindBy(xpath = "//div[contains(@class,'dijitTitlePaneTitleOpen')]//following-sibling::div/descendant::dt[contains(text(),'To')]/following::dd")
    protected WebElement toAccountValueInShowDetails;

    @FindBy(xpath = "//div[contains(@class,'dijitTitlePaneTitleOpen')]/../../preceding-sibling::div//span[@class='number']")
    private WebElement toAccountValueOnShowDetails;

    @FindBy(xpath = "//div[contains(@class,'dijitTitlePaneTitleOpen')]//following-sibling::div/descendant::dt[contains(text(),'date')]/following::dd")
    private WebElement transferDateValueInShowDetails;

    @FindBy(xpath = "//div[contains(@class,'dijitTitlePaneTitleOpen')]/../../preceding-sibling::div//span[@class='date'] | //div[contains(@class,'dijitTitlePaneTitleOpen')]/../../preceding-sibling::div//div[@data-dojo-attach-point='_paymentDateData']")
    private WebElement transferDateValueOnShowDetails;

    /*
     * Delete Functionality Buttons
     */
    @FindBy(xpath = "//div[contains(@class,'dijitTitlePaneTitleOpen')]//following-sibling::div/descendant::span[contains(text(),'Delete')]")
    private WebElement deleteTransactionButton;

    @FindBy(xpath = "//div[@class='alertPanel confirmation']//p[contains(text(),'payment has been deleted')]")
    private WebElement deleteSuccessfulMessage;

    @FindBy(xpath = "//div[contains(@id,'Dialog') and contains(@class,'dijitDialogFixed')]//button[contains(text(),'Delete')]")
    private WebElement deleteButtonDialogYes;

    @FindBy(xpath = "//div[contains(@id,'Dialog') and contains(@class,'dijitDialogFixed')]//button[contains(text(),'delete')]")
    private WebElement deleteButtonDialogNo;

    /*
     * Verification of elements on show details
     */
    @FindBy(xpath = "//div[@data-dojo-attach-point='listDataNode']/*[contains(@id,'WidgetsInTemplateMixin')]//div[@class='account']/span[@class='number'] | //div[@data-dojo-attach-point='_futureDatePaymentList']//span[@class='accountNumber']")
    private List<WebElement> allFromAccountOnShowDetails;

    @FindBy(xpath = "//div[@data-dojo-attach-point='listDataNode']/*[contains(@id,'WidgetsInTemplateMixin')]//span[@class='amountText']")
    protected List<WebElement> allAmountOnShowDetails;

    @FindBy(xpath = "//div[@data-dojo-attach-point='listDataNode']/*[contains(@id,'WidgetsInTemplateMixin')]//span[@class='date'] | //div[@data-dojo-attach-point='listDataNode']/*[contains(@id,'WidgetsInTemplateMixin')]//div[@data-dojo-attach-point='_paymentDateData']")
    private List<WebElement> allDateOnShowDetails;

    @FindBy(xpath = "//div[@data-dojo-attach-point='listDataNode']/*[contains(@id,'WidgetsInTemplateMixin')]//span[@class='paymentType']/preceding-sibling::span[@class='number']")
    private List<WebElement> allToAccountOnShowDetails;

    @FindBy(xpath = "//div[@data-dojo-attach-point='listDataNode']/*[contains(@id,'WidgetsInTemplateMixin')]//span[@class='paymentType']")
    protected List<WebElement> allPayeeTypeOnShowDetails;

    @FindBy(xpath = "//div[@data-dojo-attach-point='listDataNode']/*[contains(@id,'WidgetsInTemplateMixin')]//span[@class='standingOrderLabel']")
    protected List<WebElement> allRecurringOnShowDetails;

    @FindBy(xpath = "//div[@data-dojo-attach-point='listDataNode']/*[contains(@id,'WidgetsInTemplateMixin')]//span[@class='dijitTitlePaneTextNode']")
    private List<WebElement> allShowDetailsLinkInList;

    @FindBy(xpath = "//div[contains(@id, 'FutureTransactions')]//div[contains(@class, 'futureDatedPaymentsHeading')]")
    private WebElement pageTitle;

    @FindBy(xpath = "//div[contains(@id, 'uniqName')]//div[contains(@class, 'futurePaymentItem')]")
    private List<WebElement> futurePaymentRows;

    @FindBy(xpath = "//div[starts-with(@id, 'hdx_dijits_Dialog')]//div[contains(@class, 'deleteButtonWrapper')]//button[contains(@class, 'btnSecondary')]")
    private WebElement deleteButtonOnConfirmationDialog;

    private final By locatorFuturePaymentDescription = By.xpath(".//span[contains(@class, 'title')]");

    private final By locatorShowDetails = By
        .xpath(".//div[contains(@data-dojo-attach-point, 'titleBarNode')]//span[contains(@data-dojo-attach-point, 'titleNode')]");

    private final By locatorDetailsPane = By.xpath(".//div[contains(@class, 'dijitTitlePaneContentOuter')]");

    private final By locatorDeleteTransaction = By
        .xpath(".//div[contains(@class, 'buttonRow')]//span[contains(@id, 'Button') and contains(text(), 'Delete')]");

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(ManageFutureDatedPaymentModel.class);

    protected JavascriptExecutor executor;
    protected final UICommonUtil uiCommonUtil;

    /**
     * Constructor to instantiate locators with driver.Will be invoked from
     * Children only.
     * 
     * @param driver
     */
    public ManageFutureDatedPaymentModel(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30);
        executor = (JavascriptExecutor) driver;
        uiCommonUtil = new UICommonUtil(driver);
    }

    /*
     * Generic Methods
     */
    /**
     * This is to check the text of show details from the expected s
     */
    public void getTextAssertEqualsAndReportLog(final WebElement element, final String expectedText) {
        Assert.assertEquals(element.getText(), expectedText);
        Reporter.log(expectedText);
    }

    /**
     * 
     * This method is to Assert and Report to logger whether the webelement is
     * displayed or not on the page
     * 
     * @param element
     * @param passMessage
     * @param errorMessage
     */
    public void assertAndReportElementisDisplayed(final WebElement element, final String passMessage, final String errorMessage) {
        wait.until(ExpectedConditions.visibilityOf(element));
        Assert.assertTrue(element.isDisplayed(), errorMessage);
        Reporter.log(passMessage);
    }

    /**
     * This is to delete the transaction from the list and click on No
     */
    public void clickAndReportButtonOnDeleteTransaction(final WebElement element) {
        assertAndReportElementisDisplayed(element, "Delete dialog box is displayed", "Delete dialog box is not displayed");
        element.click();
        Reporter.log("Button is clicked on the dialog box");
    }

    /*
     * Getter Methods
     */
    /**
     * This is to get the Date Format of the specific entity for input
     * 
     * @return String - Format of the input field
     */
    public String getDefaultInputFormatDate() {
        return ManageFutureDatedPaymentModel.INPUT_FORMAT;
    }

    /**
     * This is to get the Date Format of the specific entity for list that is
     * displayed
     * 
     * @return String - Format of the date that is displayed in the list
     */
    public String getDefaultDisplayListFormatDate() {
        return ManageFutureDatedPaymentModel.DISPLAY_LIST_FORMAT;
    }

    /**
     * This is to get the No transaction Message Element entity specific
     * 
     * @return
     */
    public List<WebElement> getNoTransactionWebElement() {
        return noTransactionMessage;
    }

    /*
     * Dropdown Selection
     */
    /**
     * This is to get the text condition for the domestic type
     * 
     * @param conditionValue
     * @return String
     */
    public String getDomesticTypeCondition() {
        return ManageFutureDatedPaymentModel.VERIFY_DOMESTIC_VALUE;
    }

    /*
     * Common Methods
     */
    /**
     * This is to verify the Output List when no filter is applied
     */
    public void verifyOutputListIsDisplayed() {
        Assert.assertFalse(checkNoTransactionMessageDisplayed(), "Future Dated Transaction List is not displayed");
        Reporter.log("Future Dated Transaction List is displayed");
    }

    /**
     * This is to get the maximum and minimum date from the list according to
     * the format of the entity
     * 
     */
    public ManageFutureDatedDetails getMaximumAndMinimumDateFromList() {
        return findMaximumAndMinimumDateFromList(getDefaultDisplayListFormatDate());
    };

    /**
     * This is to select a particular transaction from the list of transaction
     * displayed.
     */
    public ManageFutureDatedDetails selectTransactionFromList() {

        ManageFutureDatedDetails manageFDT = new ManageFutureDatedDetails();

        int randomValue = allShowDetailsLinkInList.size();
        randomValue = RandomUtil.generateIntNumber(0, randomValue);
        allShowDetailsLinkInList.get(randomValue).click();
        assertAndReportElementisDisplayed(editDetailsButton, "Show Details pane is displayed", "Show Detials pane is not displayed");

        manageFDT.setFromAccountSelected(getFromAccountValueInShowDetails().getText());
        manageFDT.setToAccountSelected(getToAccountValueInShowDetails().getText());
        manageFDT.setAmountSelected(amountValueInShowDetails.getText());
        manageFDT.setTransferDate(getTransferDateValueInShowDetails().getText());

        return manageFDT;
    }

    /**
     * This is to verify the Deleted transaction is displayed or not in the
     * list
     * 
     * @param toDisplay
     *            - true/false
     */
    public void transactionDisplayInList(final boolean toDisplay, final ManageFutureDatedDetails manageFDT) {
        boolean displayListFlag = false;
        for (int eachElement = 0; eachElement < allAmountOnShowDetails.size(); eachElement++) {
            if (allAmountOnShowDetails.get(eachElement).getText().equalsIgnoreCase(manageFDT.getAmountSelected())
                && allDateOnShowDetails.get(eachElement).getText().equalsIgnoreCase(manageFDT.getTransferDate())) {
                displayListFlag = true;
                break;
            }
        }
        if (toDisplay) {
            if (displayListFlag) {
                Reporter
                    .log("Transaction selected for delete is not deleted and still present in the Transaction List displayed. Expected: Transaction should be visible/true.");
            } else {
                ManageFutureDatedPaymentModel.logger
                    .error("Transaction selected for delete is deleted and not present in the Transaction List displayed. Expected: Transaction should be visible/true.");
                Assert
                    .fail("Transaction selected for delete is deleted and not present in the Transaction List displayed. Expected: Transaction should be visible/true.");
            }
        } else {
            if (displayListFlag) {
                ManageFutureDatedPaymentModel.logger
                    .error("Transaction selected for delete is not deleted and still present in the Transaction List displayed. Expected: Transaction should not be visible/false.");
                Assert
                    .fail("Transaction selected for delete is not deleted and still present in the Transaction List displayed. Expected: Transaction should not be visible/false.");
            } else {
                Reporter
                    .log("Transaction selected for delete is deleted and not present in the Transaction List displayed. Expected: Transaction should not be visible/false.");
            }
        }

    }

    /**
     * To find the Maximum and Minimum amount from the existing list displayed
     */
    public ManageFutureDatedDetails findMaximumAndMinimumAmountFromList() {
        ManageFutureDatedDetails manageFDT = new ManageFutureDatedDetails();
        ArrayList<Double> amountArrayList = new ArrayList<>();
        if (allAmountOnShowDetails.size() >= 0) {
            for (int eachElement = 0; eachElement < allAmountOnShowDetails.size(); eachElement++) {
                Double tempAmount = Double.parseDouble(allAmountOnShowDetails.get(eachElement).getText());
                amountArrayList.add(tempAmount);
            }
        } else {
            ManageFutureDatedPaymentModel.logger.error("Future Transaction Dated list is not displayed.");
            Assert.fail("Future Transaction Dated list is not displayed.");
        }

        manageFDT.setMinimumAmountInList(Double.toString(Collections.min(amountArrayList)));
        manageFDT.setMaximumAmountInList(Double.toString(Collections.max(amountArrayList)));
        return manageFDT;
    }

    /**
     * To find the Maximum and Minimum Date from the existing list displayed
     * 
     * @param dateFormat
     */
    public ManageFutureDatedDetails findMaximumAndMinimumDateFromList(final String dateFormat) {
        ManageFutureDatedDetails manageFDT = new ManageFutureDatedDetails();
        ArrayList<Date> dateArrayList = new ArrayList<>();

        if (allDateOnShowDetails.size() >= 0) {
            try {
                for (int eachElement = 0; eachElement < allDateOnShowDetails.size(); eachElement++) {
                    Date tempDate = DateUtil.getStringToDate(dateFormat, allDateOnShowDetails.get(eachElement).getText());
                    dateArrayList.add(tempDate);
                }
                manageFDT.setMinimumDateInList(DateUtil.getDateToString(dateFormat, Collections.min(dateArrayList)));
                manageFDT.setMaximumDateInList(DateUtil.getDateToString(dateFormat, Collections.max(dateArrayList)));
            } catch (ParseException e) {
                ManageFutureDatedPaymentModel.logger.error("Date Format Conversion Error: ", e);
                Assert.fail("Date Format Conversion Error: ", e);
            }
        } else {
            ManageFutureDatedPaymentModel.logger.error("Future Transaction Dated list is not displayed.");
            Assert.fail("Future Transaction Dated list is not displayed.");
        }
        return manageFDT;
    }

    /**
     * This is to check if the date displayed between the range of From Date
     * and To Date
     * 
     * @param dateFormat
     * @param fromDate
     * @param toDate
     */
    public void checkDateBetweenRange(final String dateFormat, final String fromDate, final String toDate) {
        boolean dateFlag = false;
        Date tempDate;

        try {
            Date tempFromDate = DateUtil.getStringToDate(dateFormat, fromDate);
            Date tempToDate = DateUtil.getStringToDate(dateFormat, toDate);

            for (int eachDate = 0; eachDate < allDateOnShowDetails.size(); eachDate++) {
                tempDate = DateUtil.getStringToDate(dateFormat, allDateOnShowDetails.get(eachDate).getText());
                if (!((tempDate.after(tempFromDate) && tempDate.before(tempToDate)) || tempDate.equals(tempFromDate) || tempDate
                    .equals(tempToDate))) {
                    dateFlag = true;
                }
            }
        } catch (ParseException e) {
            ManageFutureDatedPaymentModel.logger.error("Date Format Conversion Error: ", e);
            Assert.fail("Date Format Conversion Error: ", e);
        }

        if (dateFlag) {
            ManageFutureDatedPaymentModel.logger.error("All the date displayed in the list is not between the range : " + fromDate
                + " - " + toDate);
            Assert.fail("All the date displayed in the list is not between the range : " + fromDate + " - " + toDate);
        } else {
            Reporter.log("All the date displayed in the list is between the range : " + fromDate + " - " + toDate);
        }
    }

    /**
     * This is to check if the date displayed After From Date
     * 
     * @param dateFormat
     * @param fromDate
     */
    public void checkDateAfterFromDate(final String dateFormat, final String fromDate) {
        boolean dateFlag = false;
        Date tempDate;

        try {
            Date tempFromDate = DateUtil.getStringToDate(dateFormat, fromDate);
            for (int eachDate = 0; eachDate < allDateOnShowDetails.size(); eachDate++) {
                tempDate = DateUtil.getStringToDate(dateFormat, allDateOnShowDetails.get(eachDate).getText());

                if (!(tempDate.after(tempFromDate) || tempDate.equals(tempFromDate))) {
                    dateFlag = true;
                }
            }
        } catch (ParseException e) {
            ManageFutureDatedPaymentModel.logger.error("Date Format Conversion Error: ", e);
            Assert.fail("Date Format Conversion Error: ", e);
        }

        if (dateFlag) {
            ManageFutureDatedPaymentModel.logger.error("All the date displayed in the list is not after From Date : " + fromDate);
            Assert.fail("All the date displayed in the list is not after From Date : " + fromDate);
        } else {
            Reporter.log("All the date displayed in the list is after From Date : " + fromDate);
        }
    }

    /**
     * This is to check if the date displayed Before To Date
     * 
     * @param dateFormat
     * @param toDate
     */
    public void checkDateBeforeToDate(final String dateFormat, final String toDate) {
        boolean dateFlag = false;
        Date tempDate;

        try {
            Date tempToDate = DateUtil.getStringToDate(dateFormat, toDate);

            for (int eachDate = 0; eachDate < allDateOnShowDetails.size(); eachDate++) {
                tempDate = DateUtil.getStringToDate(dateFormat, allDateOnShowDetails.get(eachDate).getText());
                if (!(tempDate.before(tempToDate) || tempDate.equals(tempToDate))) {
                    dateFlag = true;
                }
            }
        } catch (ParseException e) {
            ManageFutureDatedPaymentModel.logger.error("Date Format Conversion Error: ", e);
            Assert.fail("Date Format Conversion Error: ", e);
        }

        if (dateFlag) {
            ManageFutureDatedPaymentModel.logger.error("All the date displayed in the list is not before To Date : " + toDate);
            Assert.fail("All the date displayed in the list is not before To Date : " + toDate);
        } else {
            Reporter.log("All the date displayed in the list is before To Date : " + toDate);
        }
    }

    /**
     * To Report the condition values to reporter log
     */
    public ManageFutureDatedDetails getConditionValuesAndLog() {
        ManageFutureDatedDetails manageFDT = new ManageFutureDatedDetails();
        manageFDT.setAccountFromDropdown(valueInByAccountDropdown.getText().trim());
        manageFDT.setTransferTypeFromDropdown(valueInByTransferTypeDropdown.getText().trim());
        manageFDT.setTransferFrequencyFromDropdown(valueInByTransferFrequencyDropdown.getText().trim());
        getDateConditionValues(getDefaultDisplayListFormatDate(), getDefaultInputFormatDate(), manageFDT);
        getAmountConditionValues(manageFDT);

        Reporter.log("The filter condition values are :- ");
        Reporter.log("Account: " + manageFDT.getAccountFromDropdown());
        Reporter.log("Transfer/Payment Type: " + manageFDT.getTransferTypeFromDropdown());
        Reporter.log("Transfer/Payment Frequency: " + manageFDT.getTransferFrequencyFromDropdown());
        Reporter.log("From Date: " + manageFDT.getFromDateFilter());
        Reporter.log("To Date: " + manageFDT.getToDateFilter());
        Reporter.log("From Amount: " + manageFDT.getFromAmountFilter());
        Reporter.log("To Amount: " + manageFDT.getToAmountFilter());
        return manageFDT;
    }

    public void getDateConditionValues(final String displayFormat, final String inputFormat,
        final ManageFutureDatedDetails manageFDT) {
        String fromDate = searchByDateFromInput.getAttribute("value");
        String toDate = searchByDateToInput.getAttribute("value");
        try {
            if (!fromDate.isEmpty()) {
                fromDate = DateUtil.getDateToString(displayFormat, DateUtil.getStringToDate(inputFormat, fromDate));
                manageFDT.setFromDateFilter(fromDate);
            }
            if (!toDate.isEmpty()) {
                toDate = DateUtil.getDateToString(displayFormat, DateUtil.getStringToDate(inputFormat, toDate));
                manageFDT.setToDateFilter(toDate);
            }
        } catch (ParseException e) {
            ManageFutureDatedPaymentModel.logger.error("Date Format Conversion Error: " + e);
            Assert.fail("Date Format Conversion Error: " + e);
        }
    }

    /**
     * This is to check the amount in the transaction list is between the
     * Amount Range
     * 
     * @param fromAmount
     * @param toAmount
     */
    private void checkAmountBetweenRange(final String fromAmount, final String toAmount) {
        boolean amountFlag = false;
        Double tempAmount;
        for (int eachAmount = 0; eachAmount < allAmountOnShowDetails.size(); eachAmount++) {
            tempAmount = Double.parseDouble(allAmountOnShowDetails.get(eachAmount).getText().trim());
            if (!(tempAmount >= Double.parseDouble(fromAmount) && tempAmount <= Double.parseDouble(toAmount))) {
                amountFlag = true;
            }
        }
        if (amountFlag) {
            ManageFutureDatedPaymentModel.logger
                .error("All the amount displayed in the list is not between the range, From Amount : " + fromAmount
                    + " - To Amount : " + toAmount);
            Assert.fail("All the amount displayed in the list is not between the range, From Amount : " + fromAmount
                + " - To Amount : " + toAmount);
        } else {
            Reporter.log("All the amount displayed in the list is between the range, From Amount : " + fromAmount
                + " - To Amount : " + toAmount);
        }
    }

    /**
     * This is to check the amount in the transaction list is more then from
     * amount
     * 
     * @param fromAmount
     */
    private void checkAmountMoreThenFromAmount(final String fromAmount) {
        boolean amountFlag = false;
        Double tempAmount;
        for (int eachAmount = 0; eachAmount < allAmountOnShowDetails.size(); eachAmount++) {
            tempAmount = Double.parseDouble(allAmountOnShowDetails.get(eachAmount).getText().trim());
            if (!(tempAmount >= Double.parseDouble(fromAmount))) {
                amountFlag = true;
            }
        }

        if (amountFlag) {
            ManageFutureDatedPaymentModel.logger.error("All the amount displayed in the list is not more then From Amount :"
                + fromAmount);
            Assert.fail("All the amount displayed in the list is not more then From Amount :" + fromAmount);
        } else {
            Reporter.log("All the amount displayed in the list is more then From Amount :" + fromAmount);
        }
    }

    /**
     * This is to check the amount in the transaction list is less then to
     * Amount
     * 
     * @param toAmount
     */
    private void checkAmountLessThenToAmount(final String toAmount) {
        boolean amountFlag = false;
        Double tempAmount;
        for (int eachAmount = 0; eachAmount < allAmountOnShowDetails.size(); eachAmount++) {
            tempAmount = Double.parseDouble(allAmountOnShowDetails.get(eachAmount).getText().trim());
            if (!(tempAmount <= Double.parseDouble(toAmount))) {
                amountFlag = true;
            }
        }
        if (amountFlag) {
            ManageFutureDatedPaymentModel.logger.error("All the amount displayed in the list is not less then To Amount :"
                + toAmount);
            Assert.fail("All the amount displayed in the list is not less then To Amount :" + toAmount);
        } else {
            Reporter.log("All the amount displayed in the list is less then To Amount :" + toAmount);
        }
    }

    /*
     * Print Functionality
     */
    /**
     * This is to verify the print functionality of the whole transaction list.
     * 
     */
    public void verifyPrintForWholeList() {
        getPrintWholeList().click();
        checkPrintPopupAndCancelButton();
    }

    /**
     * This is to verify the print functionality from the show details for each
     * transaction.
     */
    public void verifyPrintFromShowDetails() {
        printTransactionButton.click();
        checkPrintPopupAndCancelButton();
    }

    /**
     * This is to check the print pop up and the cancel button on the pop up.
     * 
     */
    public void checkPrintPopupAndCancelButton() {
        if (!getPrintPopupPanel().isEmpty()) {
            Reporter.log("Print Popup is displayed.");
            for (WebElement cancelbutton : getPrintPopupCancelButton()) {
                if (cancelbutton.isDisplayed()) {
                    cancelbutton.click();
                    Reporter.log("Cancel Button on Print Popup is Clicked.");
                    break;
                }
            }
        } else {
            ManageFutureDatedPaymentModel.logger.error("Print popup is not displayed");
            Assert.fail("Print popup is not displayed");
        }
    }

    /*
     * Show Details
     */
    /**
     * This is to verify the contents from the Show Details of each transaction
     */
    public void verifyShowDetailsContent(final ManageFutureDatedDetails manageFDT) {
        Reporter.log("Verifying Show Details Pane : ");
        Reporter.log("From Account: ");
        getTextAssertEqualsAndReportLog(fromAccountValueOnShowDetails, manageFDT.getFromAccountSelected());
        Assert.assertTrue(manageFDT.getToAccountSelected().contains(toAccountValueOnShowDetails.getText()),
            "To Account is not matching with expected");
        Reporter.log("To Account: " + manageFDT.getToAccountSelected());
        Reporter.log("Amount: ");
        getTextAssertEqualsAndReportLog(amountValueOnShowDetails, manageFDT.getAmountSelected());
        Reporter.log("Transfer Date: ");
        getTextAssertEqualsAndReportLog(transferDateValueOnShowDetails, manageFDT.getTransferDate());
    }

    /*
     * Dropdown Selection Code
     */
    /**
     * This is to get the text that is displayed in the dropdown from the
     * condition value given for Type
     * 
     * @param conditionValue
     * @return String
     */
    public String getTypeCondition(final String conditionValue) {
        String expectedConditionValueText = StringUtils.EMPTY;

        switch (conditionValue.toUpperCase()) {
        case "ALL":
            expectedConditionValueText = "All";
            break;
        case "DOMESTIC":
            getDomesticTypeCondition();
            break;
        case "INTERNATIONAL":
            expectedConditionValueText = "Global";
            break;
        default:
            ManageFutureDatedPaymentModel.logger.error("Wrong Value passed.");
            Assert.fail("Wrong Value passed.");
        }
        return expectedConditionValueText;
    }

    /**
     * This is to get the text that is displayed in the dropdown from the
     * condition value given for Frequency
     * 
     * @param conditionValue
     * @return String
     */
    public String getFrequencyCondition(final String conditionValue) {
        String expectedConditionValueText = StringUtils.EMPTY;

        switch (conditionValue.toUpperCase()) {
        case "ALL":
            expectedConditionValueText = "All";
            break;
        case "ONETIME":
            expectedConditionValueText = "One time";
            break;
        case "RECURRING":
            expectedConditionValueText = "Recurring";
            break;
        default:
            ManageFutureDatedPaymentModel.logger.error("Wrong Value passed.");
            Assert.fail("Wrong Value passed.");
        }
        return expectedConditionValueText;
    }

    /**
     * This is to select the option from the dropdown for the respective
     * condition given from the dropdownItem Element
     * 
     * @param dropDownIconElement
     * @param dropDownItemsElement
     * @param conditionValue
     */
    public void selectFromDropDown(final WebElement dropDownIconElement, final List<WebElement> dropDownItemsElement,
        final String conditionValue) {
        dropDownIconElement.click();

        if (conditionValue.isEmpty()) {
            selectDropdownByRandomValue(dropDownItemsElement);
        } else {
            selectDropdownByText(dropDownItemsElement, conditionValue);
        }
    }

    /**
     * This is to select item randomly from the dropdown
     * 
     * @param dropDownItemsElement
     */
    public void selectDropdownByRandomValue(final List<WebElement> dropDownItemsElement) {
        int randomValue = dropDownItemsElement.size();
        randomValue = RandomUtil.generateIntNumber(0, randomValue);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", dropDownItemsElement.get(randomValue));
        dropDownItemsElement.get(randomValue).click();
    }

    /**
     * This is to select item by the text that is provided
     * 
     * @param dropDownItemsElement
     * @param conditionValue
     */
    public void selectDropdownByText(final List<WebElement> dropDownItemsElement, final String conditionValue) {
        for (WebElement eachElement : dropDownItemsElement) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", eachElement);

            if (eachElement.getText().contains(conditionValue)) {
                eachElement.click();
                break;
            }
        }
    }

    /*
     * Dropdown Selection Methods
     */
    /**
     * This is to select the option from the dropdown for Account
     */
    public void selectOptionFromAccount() {
        selectFromDropDown(searchByAccountDropdownIcon, allAccountDropDownItems, StringUtils.EMPTY);
    }

    /**
     * This is to select the option from the dropdown for Transfer Type for
     * given condition
     */
    public void selectOptionFromTransferType(final String condition) {
        selectFromDropDown(searchByTransferTypeDropdownIcon, allTransferTypeDropDownItems, condition);
    }

    /**
     * This is to select the option from the dropdown forTransfer Frequency for
     * given condition
     */
    public void selectOptionFromTransferFrequency(final String condition) {
        selectFromDropDown(searchByTransferFrequencyDropdownIcon, allTransferFrequencyDropDownItems, condition);
    }

    public void selectTypeAll() {
        selectOptionFromTransferType(getTypeCondition("All"));
    }

    public void selectTypeDomestic() {
        selectOptionFromTransferType(getTypeCondition("Domestic"));
    }

    public void selectTypeInternational() {
        selectOptionFromTransferType(getTypeCondition("International"));
    }

    public void selectFrequencyAll() {
        selectOptionFromTransferFrequency(getFrequencyCondition("All"));
    }

    public void selectFrequencyOneTime() {
        selectOptionFromTransferFrequency(getFrequencyCondition("OneTime"));
    }

    public void selectFrequencyRecurring() {
        selectOptionFromTransferFrequency(getFrequencyCondition("Recurring"));
    }

    public void enterAccountAllTypeFrequencyFromDate(final ManageFutureDatedDetails manageFDTDate) {
        selectOptionFromAccount();
        selectTypeAll();
        selectFrequencyAll();
        inputFromDate(manageFDTDate);
    }

    public void enterAccountToDateAndClearFromDate(final ManageFutureDatedDetails manageFDTDate) {
        clearFromDate();
        selectOptionFromAccount();
        inputToDate(manageFDTDate);
    }

    public void enterAccountFromAndToDateAndClearToDate(final ManageFutureDatedDetails manageFDTDate) {
        clearToDate();
        selectOptionFromAccount();
        inputFromDate(manageFDTDate);
        inputToDate(manageFDTDate);
    }

    public void enterAccountAllTypeFrequencyFromAmount(final ManageFutureDatedDetails manageFDTAmount) {
        selectOptionFromAccount();
        selectTypeAll();
        selectFrequencyAll();
        inputFromAmount(manageFDTAmount);
    }

    public void enterAccountToAmountAndClearFromAmount(final ManageFutureDatedDetails manageFDTAmount) {
        clearFromAmount();
        selectOptionFromAccount();
        inputToAmount(manageFDTAmount);
    }

    public void enterAccountFromAndToAmountAndClearToAmount(final ManageFutureDatedDetails manageFDTAmount) {
        clearToAmount();
        selectOptionFromAccount();
        inputFromAmount(manageFDTAmount);
        inputToAmount(manageFDTAmount);
    }

    public void enterAccountTypeAllFrequencyOneTime() {
        selectOptionFromAccount();
        selectTypeAll();
        selectFrequencyOneTime();
    }

    public void enterAccountTypeAllFrequencyRecurring() {
        selectOptionFromAccount();
        selectTypeAll();
        selectFrequencyRecurring();
    }

    public void enterAccountTypeDomesticFrequencyAll() {
        selectOptionFromAccount();
        selectTypeDomestic();
        selectFrequencyAll();
    }

    public void enterAccountTypeDomesticFrequencyOneTime() {
        selectOptionFromAccount();
        selectTypeDomestic();
        selectFrequencyOneTime();
    }

    public void enterAccountTypeDomesticFrequencyRecurring() {
        selectOptionFromAccount();
        selectTypeDomestic();
        selectFrequencyRecurring();
    }

    public void enterAccountTypeInternationalFrequencyAll() {
        selectOptionFromAccount();
        selectTypeInternational();
        selectFrequencyAll();
    }

    public void enterAccountTypeInternationalFrequencyOneTime() {
        selectOptionFromAccount();
        selectTypeInternational();
        selectFrequencyOneTime();
    }

    public void enterAccountTypeInternationalFrequencyRecurring() {
        selectOptionFromAccount();
        selectTypeInternational();
        selectFrequencyRecurring();
    }

    public void enterRandomAccountTypeFrequency() {
        selectOptionFromAccount();
        selectOptionFromTransferType(StringUtils.EMPTY);
        selectOptionFromTransferFrequency(StringUtils.EMPTY);
    }

    /*
     * Date
     */
    /**
     * This is to enter date in the From Date field
     */
    public void enterFromDate(final String inputFormat, final String listDisplayFormat, final String date) {
        try {
            String tempDate = DateUtil.getDateToString(inputFormat, DateUtil.getStringToDate(listDisplayFormat, date));
            searchByDateFromInput.clear();
            searchByDateFromInput.sendKeys(tempDate);
        } catch (ParseException e) {
            ManageFutureDatedPaymentModel.logger.error("Date Format Conversion Error in enterFromDate: " + e);
            Assert.fail("Date Format Conversion Error in enterFromDate: " + e);
        }
    }

    /**
     * This is to enter date in the To Date field
     */
    public void enterToDate(final String inputFormat, final String listDisplayFormat, final String date) {
        try {
            String tempDate = DateUtil.getDateToString(inputFormat, DateUtil.getStringToDate(listDisplayFormat, date));
            searchByDateToInput.clear();
            searchByDateToInput.sendKeys(tempDate);
        } catch (ParseException e) {
            ManageFutureDatedPaymentModel.logger.error("Date Format Conversion Error in enterToDate: " + e);
            Assert.fail("Date Format Conversion Error in enterToDate: " + e);
        }
    }

    /**
     * This is to input from date
     * 
     * @param manageFDT
     */
    public void inputFromDate(final ManageFutureDatedDetails manageFDT) {
        enterFromDate(getDefaultInputFormatDate(), getDefaultDisplayListFormatDate(), manageFDT.getMinimumDateInList());
    }

    /**
     * This it to clear From Date
     * 
     */
    public void clearFromDate() {
        searchByDateFromInput.clear();
    }

    /**
     * This is to input To Date
     * 
     * @param manageFDT
     */
    public void inputToDate(final ManageFutureDatedDetails manageFDT) {
        enterToDate(getDefaultInputFormatDate(), getDefaultDisplayListFormatDate(), manageFDT.getMaximumDateInList());
    }

    /**
     * This is to clear To Date
     * 
     */
    public void clearToDate() {
        searchByDateToInput.clear();
    }

    /**
     * This is to enter date in future for having no transaction message
     * displayed
     */
    public void enterFromDateForNoTransaction() {
        try {
            Date tempInputDateFormat;
            String tempDate;

            tempInputDateFormat = DateUtil.getStringToDate(getDefaultDisplayListFormatDate(),
                String.valueOf(allDateOnShowDetails.get(allDateOnShowDetails.size() - 1).getText()));
            tempDate = DateUtil.getDateToString(getDefaultDisplayListFormatDate(), DateUtil.addDays(tempInputDateFormat, 7));

            enterFromDate(getDefaultInputFormatDate(), getDefaultDisplayListFormatDate(), tempDate);
        } catch (ParseException e) {
            ManageFutureDatedPaymentModel.logger.error("Date Format Conversion Error: " + e);
            Assert.fail("Date Format Conversion Error: " + e);
        }
    }

    /*
     * Clicks
     */
    /**
     * This is to click on the Date option at the right for the view of the
     * list when no filter is applied.
     */
    public void clickDateTabForViewList() {
        tabDateForListView.click();
    }

    /**
     * This is to click on Account option at the right side for the view of the
     * list when no filter is applied
     */
    public void clickAccountTabForViewList() {
        tabAccountForListView.click();
    }

    /**
     * This is to click on filter button
     */
    public void clickFilterButton() {
        getFilterTransactionsButton().click();
    }

    /**
     * This is to click on the Show Results Button
     */
    public void clickShowResultsButton() {
        showResultButton.click();
    }

    /**
     * This is to click on cancel on the filter pane.
     */
    public void clickCancelInFilter() {
        cancelResultButton.click();
    }

    /**
     * This is to click on save details in the Edit transaction
     */
    public void clickEditTransactionSaveDetails() {
        saveEditDetails.click();
    }

    /**
     * This is to click on the cancel button on the edit transaction
     */
    public void clickCancelInEditTransaction() {
        cancelEditDetails.click();
    }

    /**
     * This is to click on the edit button on the transaction
     */
    public void clickEditButtonInTransaction() {
        editDetailsButton.click();
    }

    /**
     * This is to click on the delete button on the edit transaction
     */
    public void clickDeleteButtonInEditTransaction() {
        editDetialsDeleteButton.click();
    }

    /**
     * This is to click on the delete button on the transaction
     */
    public void clickDeleteButtonOnTransaction() {
        deleteTransactionButton.click();
    }

    /*
     * Amount Functionality
     */
    /**
     * This is to enter the Amount in From Amount
     */
    public void inputFromAmount(final ManageFutureDatedDetails manageFDT) {
        enterFromAmount(manageFDT.getMinimumAmountInList());
    }

    /**
     * This is to enter the Amount in To Amount
     */
    public void inputToAmount(final ManageFutureDatedDetails manageFDT) {
        enterToAmount(manageFDT.getMaximumAmountInList());
    }

    /**
     * This is to enter the amount field in the filter pane
     */
    public void enterFromAmount(final String amount) {
        searchByFromAmount.clear();
        searchByFromAmount.sendKeys(String.format("%.2f", Double.parseDouble(amount)));
    }

    /**
     * This is to enter the amount field in the filter pane
     */
    public void enterToAmount(final String amount) {
        searchByToAmount.clear();
        searchByToAmount.sendKeys(String.format("%.2f", Double.parseDouble(amount)));
    }

    /**
     * This is to clear the From amount field
     */
    public void clearFromAmount() {
        searchByFromAmount.clear();
    }

    /**
     * This is to clear the To amount field
     */
    public void clearToAmount() {
        searchByToAmount.clear();
    }

    /*
     * Transaction Message
     */
    /**
     * This is to check if the No Transaction Message is displayed or not
     * 
     * @return true/false - Message displayed
     */
    public boolean checkNoTransactionMessageDisplayed() {
        boolean messageFlag = true;
        List<WebElement> elementMessage = getNoTransactionWebElement();
        if (elementMessage.isEmpty()) {
            ManageFutureDatedPaymentModel.logger.info("No Transaction Message is not displayed.");
            messageFlag = false;
        } else {
            Reporter.log("No Transaction Message is displayed. Message is: " + elementMessage.get(0).getText());
        }
        return messageFlag;
    }

    /**
     * This is to verify that No Transaction Message is displayed
     */
    public void verifyNoTransactionMessage() {
        Assert.assertTrue(checkNoTransactionMessageDisplayed(), "Transaction list is displayed.");
        Reporter.log("No Transaction Message is displayed.");
    }

    /*
     * Output Verification Code
     */
    /**
     * This is to verify the output list after applying the filter.
     */
    public void verifyFilterOutputList() {
        ManageFutureDatedDetails manageFDT;
        if (checkNoTransactionMessageDisplayed()) {
            Reporter.log("No Transaction List is displayed for the selected criteria");
        } else {
            manageFDT = getConditionValuesAndLog();
            checkDropdownDataDisplayedInOutputList(manageFDT);
            checkDateDataDisplayedInList(manageFDT);
            checkAmountDataDisplayedInList(manageFDT);
        }
    }

    /**
     * This is to verify the data that is displayed according to the dropdown
     * selected and the data displayed for the selection
     */
    public void checkDropdownDataDisplayedInOutputList(final ManageFutureDatedDetails manageFDT) {
        ManageFutureDatedDetails manageFDTShowDetails;

        int childcount = allFromAccountOnShowDetails.size();
        ManageFutureDatedPaymentModel.logger.info("No of transactions displayed in list: " + childcount);

        for (int eachSection = 0; eachSection < childcount; eachSection++) {
            verifyTranferType(manageFDT, eachSection);
            verifyTransferFrequency(manageFDT, eachSection);
            verifyDataList(eachSection);
        }
        manageFDTShowDetails = selectTransactionFromList();
        verifyShowDetailsContent(manageFDTShowDetails);
        Reporter.log("Data displayed from dropdown in the transaction list is correct.");
    }

    /**
     * This is to the check if Account, Amount and Date is displayed in the
     * List
     * 
     * @param eachSection
     */
    public void verifyDataList(final int eachSection) {
        Assert.assertTrue(!allFromAccountOnShowDetails.get(eachSection).getText().trim().isEmpty(), "From Account is not present.");
        Assert.assertTrue(!allToAccountOnShowDetails.get(eachSection).getText().trim().isEmpty(), "To Account is not present.");
        Assert.assertTrue(!allAmountOnShowDetails.get(eachSection).getText().trim().isEmpty(), "Amount is not present.");
        Assert.assertTrue(!allDateOnShowDetails.get(eachSection).getText().trim().isEmpty(), "Date is not present.");
    }

    /**
     * This is to check the date displayed in the transaction list
     */
    public void checkDateDataDisplayedInList(final ManageFutureDatedDetails manageFDT) {
        if (!manageFDT.getFromDateFilter().isEmpty() && !manageFDT.getToDateFilter().isEmpty()) {
            checkDateBetweenRange(getDefaultDisplayListFormatDate(), manageFDT.getFromDateFilter(), manageFDT.getToDateFilter());
        } else if (!manageFDT.getFromDateFilter().isEmpty()) {
            checkDateAfterFromDate(getDefaultDisplayListFormatDate(), manageFDT.getFromDateFilter());
        } else if (!manageFDT.getToDateFilter().isEmpty()) {
            checkDateBeforeToDate(getDefaultDisplayListFormatDate(), manageFDT.getToDateFilter());
        }
    }

    /**
     * This is to get the Amount Condition Values for the filter condition
     * 
     * @param manageFDT
     */
    public void getAmountConditionValues(final ManageFutureDatedDetails manageFDT) {
        String fromAmount = searchByFromAmount.getAttribute("value");
        String toAmount = searchByToAmount.getAttribute("value");

        if (!fromAmount.isEmpty()) {
            manageFDT.setFromAmountFilter(fromAmount);
        }
        if (!toAmount.isEmpty()) {
            manageFDT.setToAmountFilter(toAmount);
        }
    }

    /**
     * This is to check the amount displayed in the transaction list
     */
    public void checkAmountDataDisplayedInList(final ManageFutureDatedDetails manageFDT) {
        if (!manageFDT.getFromAmountFilter().isEmpty() && !manageFDT.getToAmountFilter().isEmpty()) {
            checkAmountBetweenRange(manageFDT.getFromAmountFilter(), manageFDT.getToAmountFilter());
        } else if (!manageFDT.getFromAmountFilter().isEmpty()) {
            checkAmountMoreThenFromAmount(manageFDT.getFromAmountFilter());
        } else if (!manageFDT.getToAmountFilter().isEmpty()) {
            checkAmountLessThenToAmount(manageFDT.getToAmountFilter());
        }

    }

    /**
     * This is to verify the data that is displayed for the Transfer Type
     * 
     * @param manageFDT
     * @param eachSection
     */
    public void verifyTranferType(final ManageFutureDatedDetails manageFDT, final int eachSection) {
        switch (manageFDT.getTransferTypeFromDropdown()) {
        case "Domestic Transfers and Bill Payments":
            Assert.assertEquals(allPayeeTypeOnShowDetails.get(eachSection).getText(),
                ManageFutureDatedPaymentModel.VERIFY_DOMESTIC_VALUE);
            break;
        case "Global Transfers and Wires":
            Assert.assertEquals(allPayeeTypeOnShowDetails.get(eachSection).getText(),
                ManageFutureDatedPaymentModel.VERIFY_INTERNATIONAL_VALUE);
            break;
        default:
            String tempValue = allPayeeTypeOnShowDetails.get(eachSection).getText();
            if (!(tempValue.equalsIgnoreCase(ManageFutureDatedPaymentModel.VERIFY_DOMESTIC_VALUE) || tempValue
                .equalsIgnoreCase(ManageFutureDatedPaymentModel.VERIFY_INTERNATIONAL_VALUE))) {
                Assert.fail("The transfer/ payment type is incorrect.");
            }
        }
    }

    /**
     * This is to verify the data that is displayed fo the Transfer Frequency
     * 
     * @param manageFDT
     * @param eachSection
     */
    public void verifyTransferFrequency(final ManageFutureDatedDetails manageFDT, final int eachSection) {
        switch (manageFDT.getTransferFrequencyFromDropdown()) {
        case "One time payments":
            Assert.assertFalse(
                allRecurringOnShowDetails.get(eachSection).getText().trim()
                    .equalsIgnoreCase(ManageFutureDatedPaymentModel.VERIFY_RECURRING_VALUE),
                "Recurring Payment is displayed for One Time Payments");
            break;
        case "Recurring payment":
            Assert.assertEquals(allRecurringOnShowDetails.get(eachSection).getText().trim(),
                ManageFutureDatedPaymentModel.VERIFY_RECURRING_VALUE);
            break;
        default:
            String tempValue = allRecurringOnShowDetails.get(eachSection).getText();
            if (!(tempValue.equalsIgnoreCase(ManageFutureDatedPaymentModel.VERIFY_RECURRING_VALUE) || tempValue.isEmpty())) {
                Assert.fail("The transfer/ payment frequency is incorrect.");
            }
        }
    }

    /*
     * Cancel Functionality
     */
    /**
     * This is to get the default values from the dropdown for verify the
     * cancel filter condition
     */
    public ManageFutureDatedDetails getDefaultValuesOfDropdowns() {
        ManageFutureDatedDetails manageFDT = new ManageFutureDatedDetails();
        manageFDT.setDefaultValueInByAccount(valueInByAccountDropdown.getText());
        manageFDT.setDefaultValueInByType(valueInByTransferTypeDropdown.getText());
        manageFDT.setDefaultValueInByFrequency(valueInByTransferFrequencyDropdown.getText());
        return manageFDT;
    }

    /**
     * This is to verify the condition after clicking on cancel from the filter
     * pane, where all the fields will set to default conditions.
     */
    public void verifyCancelFilterCondition(final ManageFutureDatedDetails manageFDT) {
        Reporter.log("Default values in Filter");
        Reporter.log("Account: ");
        getTextAssertEqualsAndReportLog(valueInByAccountDropdown, manageFDT.getDefaultValueInByAccount());
        Reporter.log("Transfer Type: ");
        getTextAssertEqualsAndReportLog(valueInByTransferTypeDropdown, manageFDT.getDefaultValueInByType());
        Reporter.log("Transfer Frequency: ");
        getTextAssertEqualsAndReportLog(valueInByTransferFrequencyDropdown, manageFDT.getDefaultValueInByFrequency());
        Assert.assertEquals(searchByDateFromInput.getText().trim().length(), 0);
        Assert.assertEquals(searchByDateToInput.getText().trim().length(), 0);
        Reporter.log("After clicking Clear/Cancel on filter, default values are set to the filters");
    }

    /*
     * Edit Functionality
     */
    /**
     * This is to enter amount in the edit transaction pane
     */
    public ManageFutureDatedDetails enterValueInEditAmount(final ManageFutureDatedDetails manageFDT) {
        ManageFutureDatedDetails manageFDTRandomAmount = new ManageFutureDatedDetails();
        wait.until(ExpectedConditions.visibilityOf(editAmount));
        String randomAmount = RandomUtil.generateDoubleNumber(1, (int) Double.parseDouble(manageFDT.getAmountSelected()) + 10, 2);
        editAmount.clear();
        editAmount.sendKeys(randomAmount);
        manageFDTRandomAmount.setRandomAmount(randomAmount);
        return manageFDTRandomAmount;
    }

    /**
     * This is to edit the transaction from the list and click yes button on
     * cancel popup
     */
    public void clickButtonOnCancelEditTransaction(final WebElement elementToClick, final WebElement elementToDisplay) {
        wait.until(ExpectedConditions.visibilityOf(elementToClick));
        elementToClick.click();
        assertAndReportElementisDisplayed(elementToDisplay, "Button on Cancel Popup of Edit transaction is clicked",
            "Button on Cancel Popup of Edit transaction is not clicked");
    }

    /**
     * This is to edit the transaction from the list and click yes button on
     * cancel popup
     */
    public void clickYesCancelEditTransaction() {
        clickButtonOnCancelEditTransaction(cancelEditDetailsYesButton, editDetailsButton);
    }

    /**
     * This is to edit the transaction from the list and click no button on
     * cancel popup
     */
    public void clickNoCancelEditTransaction() {
        clickButtonOnCancelEditTransaction(cancelEditDetailsNoButton, cancelEditDetails);
    }

    /**
     * This is to verify yes button on cancel of edit transaction
     */
    public void verifyYesCancelEditTransaction(final ManageFutureDatedDetails manageFDT) {
        getTextAssertEqualsAndReportLog(amountValueInShowDetails, manageFDT.getAmountSelected());
        getTextAssertEqualsAndReportLog(amountValueOnShowDetails, manageFDT.getAmountSelected());
        Reporter.log("Amount is not changed with the new amount as the transaction was cancelled");
    }

    /**
     * This is to verify No button on cancel of edit transaction
     */
    public void verifyNoCancelEditTransaction() {
        assertAndReportElementisDisplayed(editAmount, "Edit transaction is displayed", "Edit transaction is not displayed");
    }

    /**
     * This is to change the value in the edit transaction
     */
    public ManageFutureDatedDetails changeValueInEditTransaction(final ManageFutureDatedDetails manageFDT) {
        return enterValueInEditAmount(manageFDT);
    }

    /**
     * This is to verify the Edit Transaction functionality from the list and
     * the value that was edited
     */
    public void verifyConfirmEditTransaction(final ManageFutureDatedDetails manageFDTRandomAmount) {

        wait.until(ExpectedConditions.invisibilityOfElementLocated(processingOverlayDialog));

        verifyAmountOnShowDetailsChanged(manageFDTRandomAmount.getRandomAmount());
    }

    /**
     * This is to verify whether the expected amount is displayed in the List
     * or not in List
     * 
     * @param expectedAmount
     */
    protected void verifyAmountOnShowDetailsChanged(final String expectedAmount) {
        boolean amountFlag = false;
        wait.until(ExpectedConditions.visibilityOfAllElements(allAmountOnShowDetails));
        for (int eachAmount = 0; eachAmount < allAmountOnShowDetails.size(); eachAmount++) {
            if (allAmountOnShowDetails.get(eachAmount).getText().trim().equalsIgnoreCase(expectedAmount)) {
                amountFlag = true;
            }
        }
        if (amountFlag) {
            Reporter.log("Amount is changed with the new amount: " + expectedAmount);
        } else {
            ManageFutureDatedPaymentModel.logger.error("Amount is not changed with the new amount: " + expectedAmount);
            Assert.fail("Amount is not changed with the new amount: " + expectedAmount);
        }
    }

    /**
     * This is to verify the cancel Edit Transaction functionality from the
     * list
     */
    public void verifyCancelConfirmEditTransaction() {
        wait.until(ExpectedConditions.visibilityOf(editAmount));
        assertAndReportElementisDisplayed(editAmount, "Cancel button is click on the review page for Edit Transaction.",
            "Cancel button is not click on the review page for Edit Transaction.");
    }

    /**
     * This is to click on cancel on the Edit Transaction Save changes review
     * page
     */
    public void cancelConfirmEditTransaction() {
        checkCrossTickOnOverlayReviewPageEditTransaction();
        clickEditTransactionSaveDetails();
        editDetailsReviewPageCancelButton.click();
    }

    /**
     * This is to edit a particular transaction from the list and confirm the
     * editing.
     */
    public void confirmEditTransaction() {
        assertAndReportElementisDisplayed(paymentSummaryLabelOnEditDetailsReviewPage, "Review page of Edit Details is displayed",
            "Review page of Edit Details is not displayed");
        confirmEditDetailsContinueButton.click();
        assertAndReportElementisDisplayed(confirmMessageOnEditDetailsConfirmationPage,
            "Confirmation page of Edit Details is displayed", "Confirmation page of Edit Details is not displayed");
        assertAndReportElementisDisplayed(getEditDetailsConfirmationPagePrintButton(),
            "Print button is displayed on Confirmation page of Edit Details",
            "Print button is not displayed on Confirmation page of Edit Details");
        editDetailsConfirmationPageCloseButton.click();
    }

    /**
     * This is to edit a particular transaction from the list and confirm the
     * editing.
     */
    public void confirmEditTransactionCheckCrossTick() {
        assertAndReportElementisDisplayed(paymentSummaryLabelOnEditDetailsReviewPage, "Review page of Edit Details is displayed",
            "Review page of Edit Details is not displayed");
        confirmEditDetailsContinueButton.click();
        assertAndReportElementisDisplayed(confirmMessageOnEditDetailsConfirmationPage,
            "Confirmation page of Edit Details is displayed", "Confirmation page of Edit Details is not displayed");
        editDetailsConfirmationPageCrossTickButton.click();
    }

    /**
     * This is to delete the transaction from the list and click on Cross tick
     * button at the right hand corner
     */
    public void checkCrossTickOnOverlayReviewPageEditTransaction() {
        confirmEditDetailsCrossTickButton = uiCommonUtil
            .activeElement(By
                .xpath("//div[contains(@id,'FutureTransactionEditReview') and not (contains(@style,'display: none'))]//button[contains(@title,'Close')]"));
        assertAndReportElementisDisplayed(confirmEditDetailsCrossTickButton,
            "Cross Tick Button is displayed on Edit Transaction Review overlay",
            "Cross Tick Button is not displayed on Edit Transaction Review overlay");
        confirmEditDetailsCrossTickButton.click();
        Reporter.log("Cross Tick button is clicked on the Edit Transaction Review Overlay");
    }

    /*
     * Delete Functionality
     */
    /**
     * This is to delete the transaction from the list and click on Cross tick
     * button at the right hand corner
     */
    public void checkCrossTickOnOverlay() {
        assertAndReportElementisDisplayed(getCrossTickButton(), "Cross Tick Button is displayed on overlay",
            "Cross Tick Button is not displayed on overlay");
        crossTickButton.click();
        Reporter.log("Cross Tick button is clicked on the Overlay");
    }

    /**
     * This is to delete the transaction from the list and click on Yes
     */
    public void confirmDeleteTransaction() {
        clickAndReportButtonOnDeleteTransaction(deleteButtonDialogYes);
    }

    /**
     * This is to delete the transaction from the list and click on No
     */
    public void cancelDeleteTransaction() {
        clickAndReportButtonOnDeleteTransaction(deleteButtonDialogNo);
    }

    public WebElement getPrintWholeList() {
        return printWholeList;
    }

    public List<WebElement> getPrintPopupCancelButton() {
        return printPopupCancelButton;
    }

    public List<WebElement> getPrintPopupPanel() {
        return printPopupPanel;
    }

    public WebElement getFromAccountValueInShowDetails() {
        return fromAccountValueInShowDetails;
    }

    public WebElement getToAccountValueInShowDetails() {
        return toAccountValueInShowDetails;
    }

    public WebElement getTransferDateValueInShowDetails() {
        return transferDateValueInShowDetails;
    }

    public WebElement getFilterTransactionsButton() {
        return filterTransactionsButton;
    }

    public WebElement getEditDetailsConfirmationPagePrintButton() {
        return editDetailsConfirmationPagePrintButton;
    }

    public WebElement getCrossTickButton() {
        return crossTickButton;
    }

    public void deletePayeeTransaction(AccountDetails accountDetail) {
        wait.until(ExpectedConditions.visibilityOf(pageTitle));
        for (WebElement futurePaymentRow : futurePaymentRows) {
            String payeeName = futurePaymentRow.findElement(locatorFuturePaymentDescription).getText();
            if (payeeName.equalsIgnoreCase(accountDetail.getAccountName())) {
                wait.until(ExpectedConditions.elementToBeClickable(futurePaymentRow.findElement(locatorShowDetails)));
                futurePaymentRow.findElement(locatorShowDetails).click();
                WebElement detailPane = futurePaymentRow.findElement(locatorDetailsPane);
                wait.until(ExpectedConditions.visibilityOf(detailPane));
                detailPane.findElement(locatorDeleteTransaction).click();
                wait.until(ExpectedConditions.elementToBeClickable(deleteButtonOnConfirmationDialog));
                deleteButtonOnConfirmationDialog.click();
            }
        }
    }
}
