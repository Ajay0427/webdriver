/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.uk;


import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.AccountTypes;
import com.hsbc.digital.testauto.pageobject.LandingPageModel;


/**
 * <p>
 * <b> This class will hold locators and functionality related methods for
 * Account Summary and Overview story 34 & 35 specific to Canada Entity </b>
 * </p>
 * 
 * @author Deepti Patil
 * 
 */
public class LandingPage extends LandingPageModel {

    JavascriptExecutor jsx;

    // Locators for account information on overview section of retirement
    // account
    @FindBy(xpath = "//p[contains(text(),'Plan number')]")
    private WebElement retirementAccountPlanNumber;

    @FindBy(xpath = "//p[contains(text(),'Plan Type')]")
    private WebElement retirementAccountPlanType;

    @FindBy(xpath = "//span[contains(text(),'Plan Holder')]")
    private WebElement retirementAccountPlanHolder;

    @FindBy(xpath = "//span[contains(text(),'Contributor')]")
    private WebElement retirementAccountPlanContributer;

    @FindBy(xpath = "//span[contains(text(),'Beneficiary information')]")
    private WebElement retirementAccountBeneficiary;

    @FindBy(xpath = "//a[@id='dapAcctDtlsPrintBtn']")
    private WebElement retirementAccountPrintButton;

    @FindBy(xpath = "//div[contains(@id,'CertificateListItem')]")
    private List<WebElement> accountOverviewRetirementAccountTransactions;

    // Locators on print preview page of retirement account
    @FindBy(xpath = "//div[contains(@id,'CertificateListItem')]")
    private List<WebElement> printPreviewRetirementAccountTransactions;

    // Locators for RRSP account transaction table headers
    @FindBy(xpath = "//div[contains(@id,'RRSPTransactionGrid')]//div[@role='columnheader']")
    public List<WebElement> rrspTransactionTableHeaders;

    // Locators for buttons on overview section of retirement account
    @FindBy(xpath = "//ul[contains(@id,'makeAContribution')]//span[text()='Make a contribution']")
    private WebElement makeContributionButton;

    @FindBy(xpath = "//ul[contains(@id,'ourRates')]//span[text()='Our rates']")
    private WebElement ourRatesButton;

    // Locators for account information on overview section of Mortgage account
    @FindBy(xpath = "//span[text()='Overdue interest']")
    private WebElement mortgageAccountOverdueInterest;

    @FindBy(xpath = "//span[contains(text(),'overdue payment')]")
    private WebElement mortgageAccountOverduePayment;

    @FindBy(xpath = "//span[text()='Overdue balance']")
    private WebElement mortgageAccountOverdueBalance;

    // Locators for Rename Link in details section
    @FindBy(xpath = "//a[text()='Rename Account']")
    private WebElement renameAccountLink;

    // Locators for Rename account text box in details section
    @FindBy(xpath = "//input[contains(@id,'EditNickname')]")
    private WebElement renameAccountTextBox;

    // Locators for Account Nickname in details section
    @FindBy(xpath = "//div[contains(@id,'EditNickname')]//p")
    private WebElement accountNickname;

    // Locators for Account Nickname label in details section
    @FindBy(xpath = "//dt[contains(@class,'nickname')]")
    private WebElement accountNicknameLabel;

    // Locators for links in manage section of overview
    @FindBy(xpath = "//div[@class='manageSection']//a[text()='Pay or transfer']")
    private WebElement payOrTransferLink;

    @FindBy(xpath = "//div[@class='manageSection']//a[text()='Direct Debits']")
    private WebElement directDebit;

    @FindBy(xpath = "//div[@class='manageSection']//a[text()='Standing orders and future payments']")
    private WebElement standingOrderFuturePamenyt;

    @FindBy(xpath = "//div[@class='manageSection']//a[text()='My payees']")
    private WebElement myPayeesLink;

    @FindBy(xpath = "//div[@class='manageSection']//a[text()='Activate card']")
    private WebElement activateCard;

    @FindBy(xpath = "//div[@class='manageSection']//a[text()='Report lost or stolen card']")
    private WebElement reportLostCardLink;

    @FindBy(xpath = "//div[@class='manageSection']//a[text()='Order cheques']")
    private WebElement orderChequesLink;

    @FindBy(xpath = "//div[@class='manageSection']//a[text()='Stop cheque']")
    private WebElement stopChequeLink;

    @FindBy(xpath = "//div[@class='manageSection']//a[text()='Annual Summaries']")
    private WebElement annualSummaries;

    @FindBy(xpath = "//div[@class='manageSection']//a[text()='Download midata']")
    private WebElement downloadMidata;

    @FindBy(xpath = "//div[@class='manageSection']//a[text()='Send me my PIN']")
    private WebElement sendMeMyPIN;

    @FindBy(xpath = "//div[@class='manageSection']//a[text()='Verified by Visa']")
    private WebElement verifiedByVisa;

    @FindBy(xpath = "//div[contains(@class,'anageSection')]//a[text()='Statements']")
    private WebElement statementLink;

    @FindBy(xpath = "//div[contains(@class,'anageSection')]//a[text()='Statement delivery options']")
    private WebElement statementDeliveryLink;

    @FindBy(xpath = "//div[contains(@class,'anageSection')]//a[text()='My documents']")
    private WebElement myDocuments;

    @FindBy(xpath = "//div[contains(@class,'anageSection')]//a[text()='Important documents and client consent']")
    private WebElement importantDocumentsLink;

    @FindBy(xpath = "//div[contains(@class,'anageSection')]//a[text()='Manage my mortgage']")
    private WebElement manageMyMortgage;

    @FindBy(xpath = "//div[contains(@class,'anageSection')]//a[text()='Credit Card Repayment Options']")
    private WebElement creditCardReplaymentLink;

    @FindBy(xpath = "//div[contains(@class,'anageSection')]//a[text()='Verified by Visa / Mastercard SecureCode']")
    private WebElement masterCardSecureCardLink;

    @FindBy(xpath = "//div[@class='manageSection']//a[text()='Balance transfers']")
    private WebElement balanceTransferLink;

    @FindBy(xpath = "//div[@class='manageSection']//a[text()='Request a higher limit']")
    private WebElement requestHigerLimitLink;

    @FindBy(xpath = "//div[@class='manageSection']//a[text()='Request a lower limit']")
    private WebElement requestLowerLimitLink;

    @FindBy(xpath = "//div[@class='manageSection']//a[text()='Opt out of auto limit increase']")
    private WebElement autoLimitIncreaseLink;

    @FindBy(xpath = "//*[@id='_dashboardHeading']/h1/span[text()='My accounts']")
    private WebElement dashboardPage;

    @FindBy(xpath = "//span[contains(@class,'itemName')]")
    private List<WebElement> accountsTypeAtDashboardPage;

    @FindBy(xpath = "//button[contains(@class,'viewMoreBtn') and @aria-hidden='false']")
    private List<WebElement> viewMoreButtonList;

    @FindBy(xpath = "//div[starts-with(@id,'gridx_Grid_')]//span[contains(@class,'payeeItem')][1]")
    private List<WebElement> transactionDetailsDescription;

    // No Transaction error message
    @FindBy(xpath = "//div[@class='alertPanel error']//span[contains(text(),'no transactions')]")
    private WebElement errorMessageText;

    // x-path for Clear Results button
    @FindBy(xpath = "//button[@data-dojo-attach-point='dapClearResults']")
    private WebElement clearResultsButton;

    // Error for Invalid Account name
    @FindBy(xpath = "  //p[contains(text(),'No transactions')]")
    private WebElement errorInvalidAccountName;

    @FindBy(xpath = "//a[@id='helpIconLink']")
    private List<WebElement> helpButtonAccountOverview;

    @FindBy(xpath = "//span[@id='dapMoveMoneyLabel' and @title='Move money']")
    private WebElement moveMoneyButton;

    @FindBy(xpath = "//div[@class='accountBalanceMsg']//a[contains(text(),'charges and interest')]")
    private WebElement viewChargesAndIntrestLink;

    @FindBy(xpath = "//div[@class='accountBalanceMsg']//a[contains(text(),'Change overdraft')]")
    private WebElement chnagesOverDraftLink;

    @FindBy(xpath = "//div[contains(@class,'nonBalanceFigures')]//span[text()='Credit limit']")
    private WebElement creditLimitLink;

    @FindBy(xpath = "//span[contains(text(),'Credit available')]")
    private WebElement creditAvaible;

    @FindBy(xpath = "//span[contains(text(),'Statement date')]")
    private WebElement statementDate;

    @FindBy(xpath = "//span[contains(text(),'Last statement balance')]")
    private WebElement lastStatementBalanceLink;

    @FindBy(xpath = "//div[contains(@class,'accountBalancesHead')]//span[text()='Balance as at']")
    private WebElement balanceAsAtLink;

    @FindBy(xpath = "//div[contains(@class,'accountBalance')]//a[contains(text(),'Points balance')]")
    private WebElement pointsBalance;

    @FindBy(xpath = "//div[contains(@id,'group_gpib')]//div[contains(@class,'dashboardTransations')]//h2[@data-dojo-attach-point='_title']")
    private WebElement investmentPensionAccountDesription;

    @FindBy(xpath = "//div[contains(@id,'group_gpib')]//div[contains(@class,'dashboardTransations')]//p[@id='accountNumber']")
    private WebElement investmentPensionAccountnumber;

    @FindBy(xpath = "//div[contains(@id,'group_gpib')]//div[contains(@class,'dashboardTransations')]//p[@data-dojo-attach-point='_ccyLabel']")
    private WebElement investmentPensionAccountCCY;

    @FindBy(xpath = "//div[contains(@id,'group_gpib')]//div[contains(@class,'accountBalancesHead ')]//span[text()='Balance/Valuation']")
    private WebElement investmentPensionValuation;

    @FindBy(xpath = "//div[contains(@id,'group_gpib')]//div[contains(@class,'accountBalancesHead ')]//span[text()='Valuation as at']")
    private WebElement investmentPensionBalanceValuation;

    @FindBy(xpath = "//div[contains(@id,'group_gpib')]//div[contains(@class,'accountBalancesHead ')]//span[text()='Balance as at']")
    private WebElement balanceAsAtLabel;

    @FindBy(xpath = "//div[contains(@id,'dashboardHeading')]//span[text()='My accounts']")
    protected WebElement accountSummaryTitle;

    // Other entity button
    @FindBy(xpath = "//div[@class='currentButtonPanel']//button[not(contains(@class,'Hidden'))]")
    protected WebElement otherEntityLogonButton;


    private static final String[] mortgageAccountExpectedLabels = {"Original Loan", ""};
    private static final String[] HCAAccountExpectedLabels = {"International Bank Account Number", "Branch Identifier Code", ""};
    private static final String[] loanAccountExpectedLabels = {"Remaining payments", ""};
    private static final String[] expectedRRSPTransactionHeaders = {" Issue Date ", " Certificate Number ", " Issue Value ",
        " Current Value ", " Maturity Value "};
    protected static final String SCROLL_TO_VIEW = "arguments[0].scrollIntoView(true);";

    public LandingPage(final WebDriver driver) {
        super(driver);
        jsx = (JavascriptExecutor) driver;
        PageFactory.initElements(driver, this);
    }

    /**
     * Method to verify fields on account summary section.
     * 
     */
    @Override
    public void verifyAccountSummarySection() {
        isElementDisplayed(accountSummaryTitle);
        Reporter.log("Summary Section Title is displayed. ");
    }

    /**
     * Method to verify Mortgage Account Overview section.
     * 
     */
    @Override
    public void verifyMortgageAccountOverviewInfo(final AccountDetails accountDetails) {
        verifyAccountInfo(accountDetails);
        isElementDisplayed(moveMoneyButtons.get(0));
        Reporter.log("Move Money Button on overview section displayed. ");
        isElementDisplayed(manageButton);
        Reporter.log("Manage Button on overview section displayed. ");
        isElementDisplayed(searchButton);
        Reporter.log("Search Button on overview section displayed. ");
        isElementDisplayed(detailsButton);
        Reporter.log("Details Button on overview section displayed. ");
    }


    /**
     * Method to verify Retirement Account Overview section.
     * 
     */
    @Override
    public void verifyRetirementAccountOverviewInfo(final AccountDetails accountDetails) {
        isElementDisplayed(retirementAccountPlanNumber);
        Reporter.log("Plan number on overview section displayed. ");
        isElementDisplayed(retirementAccountPlanType);
        Reporter.log("Plan type on overview section displayed. ");
        isElementDisplayed(retirementAccountPlanHolder);
        Reporter.log("Plan holder on overview section displayed. ");
        isElementDisplayed(retirementAccountPlanContributer);
        Reporter.log("Plan contributer on overview section displayed. ");
        isElementDisplayed(retirementAccountBeneficiary);
        Reporter.log("Account Beneficiary on overview section displayed. ");
        isElementDisplayed(makeContributionButton);
        Reporter.log("Make Contribution Button on overview section displayed. ");
        isElementDisplayed(ourRatesButton);
        Reporter.log("Our Rates Button on overview section displayed. ");

        verifyFields(Arrays.asList(LandingPage.expectedRRSPTransactionHeaders), rrspTransactionTableHeaders);
    }

    /**
     * Method to verify Loan Account Overview section.
     * 
     */
    @Override
    public void verifyLoanAccountOverviewInfo(final AccountDetails accountDetails) {
        verifyAccountInfo(accountDetails);
        isElementDisplayed(manageButton);
        Reporter.log("Manage Button on overview section displayed. ");
        isElementDisplayed(searchButton);
        Reporter.log("Search Button on overview section displayed. ");
    }

    /**
     * Method to verify Savings and Current Account Overview section.
     * 
     */
    @Override
    public void verifyAccountOverviewInfo(final AccountDetails accountDetails) {

        verifyAccountInfo(accountDetails);
        String productCode = productCodes.get(accountDetails.getProductCode());

        isElementDisplayed(moveMoneyButtons.get(0));
        Reporter.log("Move Money Button on overview section displayed. ");
        isElementDisplayed(manageButton);
        Reporter.log("Manage Button on overview section displayed. ");
        isElementDisplayed(searchButton);
        Reporter.log("Search Button on overview section displayed. ");

        if (productCode.contains("HCA")) {
            isElementDisplayed(detailsButton);
            Reporter.log("Details Button on overview section displayed. ");
        }
    }

    @Override
    public void verifyCreditCardAccountOverviewInfo(final AccountDetails accountDetails) {

        verifyAccountInfo(accountDetails);
        isElementDisplayed(moveMoneyButtons.get(0));
        Reporter.log("Move Money Button on overview section displayed. ");
        isElementDisplayed(manageButton);
        Reporter.log("Manage Button on overview section displayed. ");
        isElementDisplayed(searchButton);
        Reporter.log("Search Button on overview section displayed. ");
    }

    @Override
    public void verifyInsuranceAccountOverviewInfo(final AccountDetails accountDetails) {
        verifyAccountInfo(accountDetails);
    }

    @Override
    public void verifyInvestmentAccountOverviewInfo(final AccountDetails accountDetails) {
        verifyAccountInfoForInvestmentPension(accountDetails);
    }

    @Override
    public void verifyAccountInfoForInvestmentPension(final AccountDetails accountDetails) {
        isElementDisplayed(investmentPensionAccountDesription);
        Reporter.log("Investment Pension Account Description is displayed");
        isElementDisplayed(investmentPensionAccountnumber);
        Reporter.log("Investment Pension Account number is displayed");
        isElementDisplayed(investmentPensionAccountCCY);
        Reporter.log("Investment Pension Account ccy is displayed");
        isElementDisplayed(investmentPensionValuation);
        Reporter.log("Investment Pension Account ccy is displayed");
    }

    @Override
    public void verifyAccountInfo(final AccountDetails accountDetails) {
        String productCode = productCodes.get(accountDetails.getProductCode());
        verifyAccountDescription(accountDetails);
        verifyAccountNumber(accountDetails);
        verifyAccountCurrency(accountDetails);
        isBalanceDisplayed(accountDetails);
        Reporter.log("Balance on overview Page displayed. ");

        if (productCode.contains("Chequing") || productCode.contains("Saving")) {
            Assert.assertTrue(viewChargesAndIntrestLink.isDisplayed() || chnagesOverDraftLink.isDisplayed(),
                "Charges and Intrest or Chnages Overdraft link is not displayed");
            Reporter.log("Charges and Intrest and Chnages Overdraft links are displayed");
        }

        if (productCode.contains("Credit")) {
            isElementDisplayed(pointsBalance);
            Reporter.log("Point Balance links is displayed");
            isElementDisplayed(creditLimitLink);
            Reporter.log("Credit Limit links is displayed");
            isElementDisplayed(creditAvaible);
            Reporter.log("Credit Available links is displayed");
            isElementDisplayed(statementDate);
            Reporter.log("statement Date links is displayed");
            isElementDisplayed(lastStatementBalanceLink);
            Reporter.log("Last statement Balance links is displayed");
            isElementDisplayed(balanceAsAtLink);
            Reporter.log("balanceAsAtLink is displayed");
        }
        if (!transactionGrid.isEmpty()) {
            verifyTransactionHistoryWidget();
        } else {
            Reporter.log("There are no transactions performed for this account. ");
        }
    }

    @Override
    public void verifyTDManageLinks() {
        manageButton.click();
        Reporter.log("Manage Button Clicked. ");
        isElementDisplayed(statementLink);
        Reporter.log("Statements Link on manage section displayed. ");
        isElementDisplayed(statementDeliveryLink);
        Reporter.log("Statement delivery options Link on manage section displayed. ");
        isElementDisplayed(myDocuments);
        Reporter.log("My documents Link on manage section displayed. ");
        manageButton.click();
    }

    @Override
    public void verifyMortgageManageLinks() {
        manageButton.click();
        isElementDisplayed(manageMyMortgage);
        Reporter.log("Manage My Mortgage Link on manage section displayed. ");
        isElementDisplayed(statementLink);
        Reporter.log("Statements Link on manage section displayed. ");
        isElementDisplayed(statementDeliveryLink);
        Reporter.log("Statement delivery options Link on manage section displayed. ");
        isElementDisplayed(myDocuments);
        Reporter.log("My documents Link on manage section displayed. ");
        manageButton.click();
    }

    @Override
    public void verifyCreditCardManageLinks() {
        manageButton.click();
        isElementDisplayed(activateCard);
        Reporter.log("Activate Card Link on manage section displayed. ");
        isElementDisplayed(reportLostCardLink);
        Reporter.log("Report Lost Card Link on manage section displayed. ");
        isElementDisplayed(sendMeMyPIN);
        Reporter.log("Send me My PIN Link on manage section displayed. ");
        isElementDisplayed(statementLink);
        Reporter.log("Statements Link on manage section displayed. ");
        isElementDisplayed(statementDeliveryLink);
        Reporter.log("Statement delivery options Link on manage section displayed. ");
        isElementDisplayed(myDocuments);
        Reporter.log("My documents Link on manage section displayed. ");
        isElementDisplayed(creditCardReplaymentLink);
        Reporter.log("Credit card repayment options Link on manage section displayed. ");
        isElementDisplayed(masterCardSecureCardLink);
        Reporter.log("Verified by Visa / Mastercard SecureCode Link on manage section displayed. ");
        isElementDisplayed(balanceTransferLink);
        Reporter.log("Balance transfe Link on manage section displayed. ");
        isElementDisplayed(requestHigerLimitLink);
        Reporter.log("Request a higher limit Link on manage section displayed. ");
        isElementDisplayed(requestLowerLimitLink);
        Reporter.log("Request a lower limit Link on manage section displayed. ");
        isElementDisplayed(autoLimitIncreaseLink);
        Reporter.log("Opt out of auto limit increase Link on manage section displayed. ");
        manageButton.click();
    }


    @Override
    public void verifyLoanManageLinks() {
        manageButton.click();
        isElementDisplayed(myDocuments);
        Reporter.log("My documents Link on manage section displayed. ");
        manageButton.click();
    }

    public void verifyManageCommonLinks() {
        isElementDisplayed(payOrTransferLink);
        Reporter.log("Pay or Transfer Link on manage section displayed. ");
        isElementDisplayed(directDebit);
        Reporter.log("Direct Debit Link on manage section displayed. ");
        isElementDisplayed(standingOrderFuturePamenyt);
        Reporter.log("Standing orders and future payments Link on manage section displayed. ");
        isElementDisplayed(myPayeesLink);
        Reporter.log("My Payees Link on manage section displayed. ");
        isElementDisplayed(activateCard);
        Reporter.log("Activate Card Link on manage section displayed. ");
        isElementDisplayed(reportLostCardLink);
        Reporter.log("Report Lost Card Link on manage section displayed. ");
        isElementDisplayed(sendMeMyPIN);
        Reporter.log("Senbd me My PIN Link on manage section displayed. ");
        isElementDisplayed(verifiedByVisa);
        Reporter.log("Verified by VISA Link on manage section displayed. ");
        isElementDisplayed(statementLink);
        Reporter.log("Statements Link on manage section displayed. ");
        isElementDisplayed(statementDeliveryLink);
        Reporter.log("Statement delivery options Link on manage section displayed. ");
        isElementDisplayed(myDocuments);
        Reporter.log("My documents Link on manage section displayed. ");

    }

    @Override
    public void verifyCurrentManageLinks() {
        manageButton.click();
        Reporter.log("Manage Button Clicked. ");
        verifyManageCommonLinks();
        isElementDisplayed(stopChequeLink);
        Reporter.log("Stop Cheques Link on manage section displayed. ");
        isElementDisplayed(downloadMidata);
        Reporter.log("Download Midata Link on manage section displayed. ");
        isElementDisplayed(annualSummaries);
        Reporter.log("Annual Summaries Link on manage section displayed. ");
        manageButton.click();
    }

    @Override
    public void verifySavingsManageLinks() {
        manageButton.click();
        Reporter.log("Manage Button Clicked. ");
        verifyManageCommonLinks();
        manageButton.click();
    }

    /**
     * Method to verify TD Account Overview section.
     * 
     * @param accountDetails
     */
    @Override
    public void verifyTDAccountOverviewInfo(final AccountDetails accountDetails) {
        verifyAccountInfo(accountDetails);
        isElementDisplayed(manageButton);
        Reporter.log("Manage Button on overview section displayed. ");
        isElementDisplayed(searchButton);
        Reporter.log("Search Button on overview section displayed. ");
    }


    /**
     * Method to verify Move money button on account overview section.
     * 
     * @param accountDetails
     * 
     */
    @Override
    public void verifyMoveMoneyNavigation(final AccountDetails accountDetails) {
        AccountTypes accountTypes = checkAccountType(accountDetails);
        if (!accountTypes.name().equals("TERMDEPOSIT") && !accountTypes.name().equals("LOAN")) {
            if (!moveMoneyButtons.isEmpty()) {
                clickElement(moveMoneyButtons.get(0));
                Reporter.log("Move Money Button is clicked. ");

                clickElement(primaryTransactionCancelButton);
                Reporter.log("New Transaction Cancel Button is clicked. ");

                clickElement(secondaryTransactionCancelButton);
                Reporter.log("Transaction Cancel Button is clicked to return to 'My Accounts' page. ");
            } else {
                Reporter.log("Move Money button not displayed for this account type. ");
            }
        } else {
            Reporter.log("Move Money button not displayed for this account type. ");
        }
    }

    /**
     * Method to add labels in details section of Mortgage account in a list.
     * 
     */
    public List<String> addLabelsInMortgageAccountDetails() {
        return Arrays.asList(LandingPage.mortgageAccountExpectedLabels);
    }

    /**
     * Method to add labels in details section of HCA account in a list.
     * 
     */
    public List<String> addLabelsInHCAAccountDetails() {
        return Arrays.asList(LandingPage.HCAAccountExpectedLabels);
    }

    /**
     * Method to add labels in details section of Loan account in a list.
     * 
     */
    public List<String> addLabelsInLoanAccountDetails() {
        return Arrays.asList(LandingPage.loanAccountExpectedLabels);
    }

    /**
     * Method to verify Mortgage Account Details section.
     * 
     */
    @Override
    public void verifyMortgageAccountDetails() {
        verifyFields(addLabelsInMortgageAccountDetails(), detailsLabels);
    }

    /**
     * Method to verify HCA Account Details section.
     * 
     */

    public void verifyHCAAccountDetails() {
        verifyFields(addLabelsInHCAAccountDetails(), detailsLabels);
    }

    /**
     * Method to verify Loan Account Details section.
     * 
     */
    @Override
    public void verifyLoanAccountDetails() {
        verifyFields(addLabelsInLoanAccountDetails(), detailsLabels);
    }

    /**
     * Method to verify real time update on overview section. No applicable in
     * UK
     */
    @Override
    public void verifyRealTimeUpdate(final AccountDetails accDetail) {}

    /**
     * Method to verify if print for retirement account overview section
     * 
     */
    @Override
    public void verifyRetirementAccountPrint(final AccountDetails accountDetails) {
        int size = accountOverviewRetirementAccountTransactions.size();
        retirementAccountPrintButton.click();
        Reporter.log("Retirement account print button clicked. ");
        verifyRetirementPrintPreviewDetails(accountDetails, size);
        isAccountOverviewPrintPreviewButtonsDisplayed();
    }

    /**
     * Method to verify details on Print Preview Page of retirement account.
     * 
     */
    public void verifyRetirementPrintPreviewDetails(final AccountDetails accountDetails, final int size) {
        Assert.assertTrue(accountDetails.getAccountNumber().equalsIgnoreCase(accountOverviewPrintPreviewAccountNumber.getText())
            && accountDetails.getAccountName().equalsIgnoreCase(accountOverviewPrintPreviewAccountName.getText())
            && size == printPreviewRetirementAccountTransactions.size(), "Details on preview page not verified");
        Reporter.log("Details on preview page verified. ");
    }

    @Override
    public void verifyOrderOfAccounts() {
        List<Integer> actualAccountOrderList = new ArrayList<>();
        Map<String, String> actualAccountDetailsMap = new LinkedHashMap<>();
        Map<String, ArrayList<String>> accountNumbersSortedMap = new LinkedHashMap<>();
        Map<String, ArrayList<String>> productCodeSortedMap = new LinkedHashMap<>();

        for (WebElement account : accountsLists) {
            AccountDetails accDetail = new AccountDetails();
            jsx.executeScript(SCROLL_TO_VIEW, account);
            storeProductCode(accDetail, account);
            String accountType = accDetail.getProductCode();
            String accountNumber = accDetail.getAccountNumber();
            AccountTypes accountTypes = checkAccountType(accDetail);
            switch (accountTypes) {
            case CURRENT:
                actualAccountOrderList.add(1);
                break;
            case HCA:
                actualAccountOrderList.add(2);
                break;
            case SAVINGS:
                actualAccountOrderList.add(3);
                break;
            case TERMDEPOSIT:
                actualAccountOrderList.add(4);
                break;
            case CREDIT:
                actualAccountOrderList.add(5);
                break;
            case INVESTMENT:
                actualAccountOrderList.add(6);
                break;
            case LOAN:
                actualAccountOrderList.add(7);
                break;
            case MORTGAGE:
                actualAccountOrderList.add(8);
                break;
            case INSURANCE:
                actualAccountOrderList.add(9);
                break;
            case PENSION:
                actualAccountOrderList.add(10);
                break;
            default:
                actualAccountOrderList.add(11);
                break;
            }
            actualAccountDetailsMap.put(accountNumber, accountTypes.toString() + "#" + accountType);
        }

        Assert.assertTrue(isSorted(actualAccountOrderList), "Account Summary List was not sorted as per product type");
        Reporter.log("Account Summary List is sorted as per product type");

        Iterator<Entry<String, String>> actualAccountDetailsMapIterator = actualAccountDetailsMap.entrySet().iterator();
        while (actualAccountDetailsMapIterator.hasNext()) {
            Map.Entry<String, String> tempMap = actualAccountDetailsMapIterator.next();
            ArrayList<String> accountNumbersTempList;
            ArrayList<String> productCodesTempList;

            String[] accountDetailsList = tempMap.getValue().split("#");
            String accountType = accountDetailsList[0];

            if (accountNumbersSortedMap.containsKey(tempMap.getValue())) {
                accountNumbersTempList = accountNumbersSortedMap.get(tempMap.getValue());
                accountNumbersTempList.add(tempMap.getKey());
                Collections.sort(accountNumbersTempList);
            } else {
                accountNumbersTempList = new ArrayList<>();
                accountNumbersTempList.add(tempMap.getKey());
                accountNumbersSortedMap.put(tempMap.getValue(), accountNumbersTempList);
            }

            if (productCodeSortedMap.containsKey(accountType)) {
                productCodesTempList = productCodeSortedMap.get(accountType);
                productCodesTempList.add(accountDetailsList[1]);
                Collections.sort(productCodesTempList);
            } else {
                productCodesTempList = new ArrayList<>();
                productCodesTempList.add(accountDetailsList[1]);
                productCodeSortedMap.put(accountType, productCodesTempList);
            }
        }

        Iterator<Entry<String, ArrayList<String>>> productCodeSortedMapIterator = productCodeSortedMap.entrySet().iterator();
        actualAccountDetailsMapIterator = actualAccountDetailsMap.entrySet().iterator();
        while (productCodeSortedMapIterator.hasNext()) {
            ArrayList<String> list;
            Map.Entry<String, ArrayList<String>> mesorted = productCodeSortedMapIterator.next();
            list = mesorted.getValue();
            for (int i = 0; i < list.size(); i++) {
                Map.Entry<String, String> mesorte = actualAccountDetailsMapIterator.next();
                String actualValue = mesorted.getKey() + "#" + list.get(i);
                String expectedValue = mesorte.getValue();
                Assert.assertTrue(actualValue.equals(expectedValue), "Account Summary List was not sorted as per Product Code");
            }
        }
        Reporter.log("Account Summary List is sorted as per Product Code");

        Map<String, String> expectedAccountDetailsMap = new LinkedHashMap<>();
        Iterator<Entry<String, ArrayList<String>>> accountNumbersSortedMapIterator = accountNumbersSortedMap.entrySet().iterator();
        while (accountNumbersSortedMapIterator.hasNext()) {
            ArrayList<String> accountNumberTempList;
            Map.Entry<String, ArrayList<String>> tempNext = accountNumbersSortedMapIterator.next();
            accountNumberTempList = tempNext.getValue();
            for (int i = 0; i < accountNumberTempList.size(); i++) {
                expectedAccountDetailsMap.put(accountNumberTempList.get(i), tempNext.getKey());
            }
        }
        boolean isSorted = equalMaps(actualAccountDetailsMap, expectedAccountDetailsMap);
        Assert.assertTrue(isSorted, "Account Summary List was not sorted as per Account Number");
        Reporter.log("Account Summary List is sorted as per Account Number");
    }

    @Override
    public void verifyMultipleEntityAccounts() {
        if (linkedEntities.size() > 1 || arrowButton.size() > 0) {
            Reporter.log("Profile linked with multiple entities");
            int randomIndex = RandomUtil.generateIntNumber(1, linkedEntities.size());
            WebElement element = arrowButton.get(randomIndex);
            element.click();
            verifyDifferentEntityOverviewSection(otherEntityAccountLists);
        } else {
            Reporter.log("Linked entities not found.");
        }
    }


    /**
     * Method to verify Account Details Section after clicking on details
     * button on account overview section.
     * 
     */
    @Override
    public void verifyAccountDetails(final AccountDetails accountDetails) {
        AccountTypes accountTypes = checkAccountType(accountDetails);
        if ((accountTypes.equals(AccountTypes.LOAN) || accountTypes.equals(AccountTypes.MORTGAGE))) {
            Assert.assertTrue(detailsButton.isDisplayed(), "Details Button is displayed and verified");
            Reporter.log("Details Button is displayed and verified. ");
            clickElement(detailsButton);
            Reporter.log("Details Button is clicked to expand the details section. ");
            switch (accountTypes) {
            case MORTGAGE:
                verifyMortgageAccountDetails();
                break;
            case LOAN:
                verifyLoanAccountDetails();
                break;
            case HCA:
                verifyHCAAccountDetails();
                break;
            default:
                break;
            }
            verifyDisclaimerDisplayedInDetailsSection();
            clickElement(detailsButton);
            Reporter.log("Details Button is clicked to close the details section. ");
        } else {
            Reporter.log("Selected Account does not support Details Section.");
        }
    }

    @Override
    public void verifyDifferentEntityOverviewSection(final List<WebElement> listOfAccounts) {
        int i = 0;
        List<WebElement> listOfAccount = driver.findElements(By
            .xpath("//div[contains(@id,'TitlePane') and (@aria-hidden='false')]/span[@isgspentity='no']"));
        WebElement account = listOfAccount.get(i);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", account);
        account.click();
        String accDetails[] = account.getAttribute("unique-account-number").split("\\|\\|");
        String countryCode = accDetails[3];

        List<WebElement> accounts = driver.findElements(By
            .xpath("//div[contains(@id,'TitlePane')]/span[@isgspentity='no' and contains(@unique-account-number,'" + countryCode
                + "')]"));
        int totalAccounts = accounts.size();
        while (true) {
            WebElement otherEntityAccount = accounts.get(i);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", otherEntityAccount);
            otherEntityAccount.click();
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", investmentPensionAccountDesription);
            isElementDisplayed(investmentPensionAccountDesription);
            Reporter.log("Account Description is Label is displayed in Account overview section for different entity account");
            isElementDisplayed(investmentPensionAccountnumber);
            Reporter.log("Account number is Label is displayed in Account overview section for different entity account");
            isElementDisplayed(investmentPensionAccountCCY);
            Reporter.log("Account currency is Label is displayed in Account overview section for different entity account");
            isElementDisplayed(investmentPensionValuation);
            Reporter.log("Balance is Label is displayed in Account overview section for different entity account");
            isElementDisplayed(otherEntityLogonButton);
            Reporter.log("Logon button of other entity is displayed in Account overview section for different entity account");
            i++;
            if (i == totalAccounts) {
                break;
            }
        }
    }

    public AccountDetails selectOtherEntityAccount() {
        if (otherEntityAccountLists.size() > 0) {
            AccountDetails accountDetails = new AccountDetails();
            String accDetail = selectAccount(null, otherEntityAccountLists);
            String[] details = accDetail.split("\\r?\\n");
            accountDetails.setAccountName(details[0]);
            accountDetails.setAccountNumber(details[1]);
            accountDetails.setCurrency(details[3]);
            Reporter.log("Account :" + details[0] + " selected from account summary list");
            return accountDetails;
        }
        return null;
    }


    @Override
    public boolean equalMaps(final Map<String, String> actualMap, final Map<String, String> expectedMap) {
        if (actualMap.size() != expectedMap.size()) {
            return false;
        }
        Iterator<Entry<String, String>> itr1 = actualMap.entrySet().iterator();
        Iterator<Entry<String, String>> itr2 = expectedMap.entrySet().iterator();
        while (itr1.hasNext() && itr2.hasNext()) {
            Map.Entry<String, String> mesorted1 = itr1.next();
            Map.Entry<String, String> mesorted2 = itr2.next();
            if (!mesorted1.getKey().equals(mesorted2.getKey())) {
                return false;
            }
        }
        return true;
    }

    @Override
    public boolean isSorted(final List<Integer> list) {
        boolean sorted = true;
        for (int i = 1; i < list.size(); i++) {
            if (list.get(i).compareTo(list.get(i - 1)) < 0) {
                return false;
            }
        }
        return sorted;
    }

    @Override
    public AccountTypes checkAccountType(final AccountDetails accountDetails) {
        String productCode = productCodes.get(accountDetails.getProductCode());
        Assert.assertTrue(!productCode.isEmpty(), "Product Code: " + accountDetails.getProductCode()
            + " :not found in product mapping sheet");
        if (productCode.contains("Chequing")) {
            return AccountTypes.CURRENT;
        } else if (productCode.equalsIgnoreCase("Savings")) {
            return AccountTypes.SAVINGS;
        } else if (productCode.equalsIgnoreCase("Registered TFSA Savings")) {
            return AccountTypes.TFSASAVINGS;
        } else if (productCode.equalsIgnoreCase("Credit Card")) {
            return AccountTypes.CREDIT;
        } else if (productCode.contains("Term Deposit")) {
            return AccountTypes.TERMDEPOSIT;
        } else if (productCode.equalsIgnoreCase("Registered TFSA Term Deposit")) {
            return AccountTypes.TFSATERMDEPOSIT;
        } else if (productCode.equalsIgnoreCase("Loan")) {
            return AccountTypes.LOAN;
        } else if (productCode.equalsIgnoreCase("Mortgage")) {
            return AccountTypes.MORTGAGE;
        } else if (productCode.equalsIgnoreCase("Registered RRSP Investment Bundle")) {
            return AccountTypes.RRSP;
        } else if (productCode.equalsIgnoreCase("Investment")) {
            return AccountTypes.INVESTMENT;
        } else if (productCode.equalsIgnoreCase("Insurance")) {
            return AccountTypes.INSURANCE;
        } else if (productCode.equalsIgnoreCase("Pension")) {
            return AccountTypes.PENSION;
        } else if (productCode.equalsIgnoreCase("HIDC \\(Non GSP Bijit\\)")) {
            return AccountTypes.HIDC;
        } else {
            Reporter.log("Account Selected does not match any criteria.");
        }
        return null;
    }

    @Override
    public void storeProductCode(final AccountDetails accountDetails, final WebElement account) {
        String accountNumber = account.getText().split("\\r?\\n")[1];
        String uniqueAccountNumber = account.getAttribute("unique-account-number");
        String productCode = uniqueAccountNumber.split("\\|\\|")[2];
        Assert.assertTrue(!productCode.isEmpty(), "Product Code attribute is not found.");
        accountDetails.setProductCode(productCode);
        accountDetails.setAccountNumber(accountNumber);
    }

    @Override
    public void validateNewAccount(final String newAccountNumber) {
        wait.until(ExpectedConditions.visibilityOf(dashboardPage));
        Reporter.log("Dashboard page shown. | ");
        boolean flag = false;
        for (WebElement accountRow : accountsTypeAtDashboardPage) {
            jsx.executeScript(SCROLL_TO_VIEW, accountRow);
            if (newAccountNumber.equals(accountRow.getText())) {
                Reporter.log("New Account present on Landing page. | ");
                flag = true;
                break;
            }
        }
        if (!flag) {
            Assert.fail("New Account not present on Landing page.");
        }
    }

    // -------------------Download Transaction History------------------
    @Override
    public void downloadTransactionHistory(final boolean isDownload) {
        super.clickDownloadButton();
        Assert.assertTrue(!super.radioButtonList.isEmpty(), "File format not available to download. ");
        for (int count = 0; count < super.radioButtonList.size(); count++) {
            if (isDownload) {
                radioButtonList.get(count).click();
                Reporter.log("Selected : " + radioButtonList.get(count).getText() + " : file format to download. | ");
                clickDownloadButtonOnPopup();
                verifyDownloadChoiceWindow();
            } else {
                clickCancelButtonOnPopup();
            }
            super.clickDownloadButton();
        }
    }

    @Override
    protected void verifyDownloadChoiceWindow() {
        if (driver.getWindowHandles().size() > 1) {
            Reporter.log("Download choice window shown. | ");
        }
    }

    // -------------------Transaction History------------------
    /**
     * This method is to sort the transactions by date
     */
    @Override
    public boolean dateSorting() {
        boolean flag = false;
        try {
            List<Date> beforeSort = new ArrayList<>();
            for (WebElement element : super.dateColumnAll) {
                beforeSort.add(DateUtil.getStringToDate(super.getDisplayDateFormat(), element.getText()));
            }
            Collections.sort(beforeSort);
            dateSortArrowButton.click();
            Reporter.log("Clicked on Date column for sort.");
            List<Date> afterSort = new ArrayList<>();
            for (WebElement element : super.dateColumnAll) {
                jsx.executeScript(SCROLL_TO_VIEW, element);
                afterSort.add(DateUtil.getStringToDate(super.getDisplayDateFormat(), element.getText()));
            }
            Iterator<Date> targetIt = beforeSort.iterator();
            for (Date uiSortedDate : afterSort) {
                if (uiSortedDate.equals(targetIt.next())) {
                    flag = true;
                }
            }
        } catch (ParseException e) {
            LandingPageModel.logger.error("Date Format Conversion Error: ", e);
            Assert.fail("Date Format Conversion Error." + e);
        }
        return flag;
    }

    @Override
    public void verifyTransactionHistoryInDateRage(final String fromDate, final String toDate) {
        super.checkTransactionAvailability();
        if (!viewMoreButtonList.isEmpty()) {
            viewMoreButtonList.get(0).click();
            Reporter.log("Click on View More button");
        }
        try {
            Date dateFromDate = DateUtil.getStringToDate(getInputDateFormat(), fromDate);
            Date dateToDate = DateUtil.getStringToDate(getInputDateFormat(), toDate);
            super.checkDateBetweenRange(super.getDisplayDateFormat(), dateFromDate, dateToDate);
        } catch (ParseException e) {
            LandingPageModel.logger.error("Date parsing Exception for verifyTransactionHistoryInDateRage", e);
            Assert.fail("Date parsing Exception for verifyTransactionHistoryInDateRage", e);
        }
    }

    /**
     * Compare results by name
     * 
     */
    @Override
    public void compareResultByName(final String expectedName) {
        super.checkTransactionAvailability();
        while (true) {
            for (WebElement eachTransaction : transactionDetailsDescription) {
                jsx.executeScript(SCROLL_TO_VIEW, eachTransaction);
                Assert.assertTrue(eachTransaction.getText().contains(expectedName), "Expected name: " + expectedName
                    + " Actual name: " + eachTransaction.getText());
            }
            if (!viewMoreButtonList.isEmpty() && viewMoreButtonList.get(0).isDisplayed()) {
                viewMoreButtonList.get(0).click();
            } else {
                break;
            }
        }
        Reporter.log("As expected historic transactions are displayed by account name filter");
    }

    @Override
    public void compareResultAmount(final int fromAmt, final int toAmt) {
        super.checkTransactionAvailability();
        while (true) {
            for (WebElement amountValue : super.transactionDetailsListAmountCol) {
                jsx.executeScript(SCROLL_TO_VIEW, amountValue);
                String amountValueString = amountValue.getText();
                Double actualAmount = Double.valueOf(amountValueString.replace("-", "").replace(",", ""));
                Assert.assertTrue(actualAmount >= fromAmt && actualAmount <= toAmt, "Amount: " + actualAmount
                    + " shown doesn't lie between + " + fromAmt + " and " + toAmt);
            }
            if (!viewMoreButtonList.isEmpty() && viewMoreButtonList.get(0).isDisplayed()) {
                viewMoreButtonList.get(0).click();
            } else {
                break;
            }
        }
        Reporter.log("Displayed Transactions Amounts lie between " + fromAmt + " and " + toAmt + " range. ");
    }

    @Override
    public void verifyPrintButtonOnPopup() {
        Assert.assertTrue(accountOverviewPreviewPrintButton.isDisplayed(), "Print button is not displayed on popup. ");
        Reporter.log("Print Popup shown. | ");
        accountOverviewPreviewPrintButton.click();
        Reporter.log("Print button clicked in Popup. | ");
        if (driver.getWindowHandles().size() > 1) {
            Reporter.log("Print preview Popup shown. | ");
        }
    }

    /**
     * Method to verify Transaction are sorted by Amount
     */
    @Override
    public boolean sortAmount() {
        boolean flag = true;
        List<Double> expectedAmount = new ArrayList<>();
        for (WebElement element : super.amountColAll) {
            String amount = element.getText();
            if (element.getText().contains(",")) {
                amount = amount.replace(",", "");
            }
            expectedAmount.add(Double.parseDouble(amount));
        }
        Collections.sort(expectedAmount);
        Iterator<Double> iteratorExpected = expectedAmount.iterator();
        amountSort.click();
        Reporter.log("Click on Amount column for sort");
        for (WebElement element : super.amountColAll) {
            String amount = element.getText();
            if (element.getText().contains(",")) {
                amount = amount.replace(",", "");
            }
            if (!iteratorExpected.next().equals(Double.parseDouble(amount))) {
                flag = false;
                break;
            }
        }
        return flag;
    }

    /**
     * Method to verify Transactions are sorted by Description .
     */
    @Override
    public boolean sortDescriptions() {
        boolean flag = true;
        List<String> expecteddescription = new ArrayList<>();
        for (WebElement element : super.descriptionColumnAll) {
            expecteddescription.add(element.getText());
        }
        Collections.sort(expecteddescription);
        Iterator<String> iteratorExpected = expecteddescription.iterator();
        super.descriptionSort.click();
        Reporter.log("Click on Description column for sort");
        for (WebElement element : super.descriptionColumnAll) {
            if (!iteratorExpected.next().equalsIgnoreCase(element.getText())) {
                flag = false;
                break;
            }
        }
        return flag;
    }

    @Override
    public void verifyErrorMessageForInvalidDetails() {
        errorMessageText.isDisplayed();
        Reporter.log("\"No Transaction Error message\" is displayed. Error message is: " + errorMessageText.getText());
    }

    /**
     * Method to verify No transaction message for invalid Account Name
     */
    @Override
    public void verifyErrorForInvalidAccountName() {
        Assert.assertTrue(errorInvalidAccountName.isDisplayed(), "Transactions displayed for invalid account. ");
        String errorMessage = errorInvalidAccountName.getText();
        Reporter.log("Error is displayed as :" + errorMessage);
    }

    @Override
    public void verifyClearSearchButton(final List<String> transactionsList) {
        Assert.assertTrue(super.clearSearchButton.isDisplayed(), "Clear Search button is not present");
        super.clearSearchButton.click();
        Reporter.log("Clear Search button clicked");
        super.defaultOrderCheck();
        List<String> transactionListAfterClear = super.transactionsList();
        if (super.transactionsList().size() <= 5 && transactionsList.equals(transactionListAfterClear)) {
            Reporter.log("\"Clear Search\" button functionality working properly. | ");
        }
    }

    @Override
    public void verifyTransactionNotListedButton() {
        Assert.assertTrue(super.transactionNotListedButton.isDisplayed(), "TransactionNotListed button is not present. | ");
        super.transactionNotListedButton.click();
        Reporter.log("\"TransactionNotListed\" button clicked. | ");
        Assert.assertTrue(super.reportingAProblemDialogueCloseIcon.isDisplayed(),
            "\'Reporting A Problem\' PopUp is not present. | ");
        Reporter.log("\'Reporting A Problem\' PopUp is present. | ");
        super.reportingAProblemDialogueCloseIcon.click();
        Reporter.log("\'Reporting A Problem\' PopUp is closed. | ");
    }

    @Override
    public void verifyVisibilityOfViewMoreButton() {
        if (super.descriptionColumnAll.size() < 5) {
            Assert.assertTrue(viewMoreButtonList.isEmpty(), "View More button is visible for less transaction");
            Reporter.log("View More button is not visible");
        } else {
            if (!viewMoreButtonList.isEmpty() && viewMoreButtonList.get(0).isDisplayed()) {
                viewMoreButtonList.get(0).click();
                Assert.assertTrue(super.descriptionColumnAll.size() > 5,
                    "View More button displayed even if the transactions are not more than 5");
                Reporter.log("As Expected View More button displayed. | ");
            } else {
                Reporter.log("As Expected View More button not displayed. | ");
            }
        }
    }

    @Override
    protected WebElement getMoveMoneyButton() {
        return moveMoneyButton;
    }

    // functions for story transaction search, split used to get the first word
    // from the whole string
    @Override
    public String getDescriptionName() {
        return transactionDetailsDescription.get(0).getText().split(" ")[0];
    }

    // functions for story transaction search, get date in dd/mm/yyyy format

    @Override
    public String getFromDate() throws ParseException {
        return DateUtil.getDateToString("dd/MM/yyyy",
            DateUtil.getStringToDate("dd MMM yyyy", dateColumnAll.get(dateColumnAll.size() - 1).getText()));
    }

    @Override
    public String getToDate() throws ParseException {
        return DateUtil.getDateToString("dd/MM/yyyy", DateUtil.getStringToDate("dd MMM yyyy", dateColumnAll.get(0).getText()));
    }

    @Override
    protected String getDisplayDateFormat() {
        return DateUtil.DATE_FORMAT_DDMMYYYY;
    }

    @Override
    protected String getInputDateFormat() {
        return DateUtil.DATE_FORMAT_DDMMYYYY;
    }

    @Override
    public WebElement getClearResultsButton() {
        return clearResultsButton;
    }

    // Bundle account are not applicable for UK entity
    @Override
    public void verifyBundledAccountSummary() {}
}
