/**
 * <p>
 * <b> This class will hold page object model for story 11 - Communication
 * Preferences </b>
 * </p>
 * 
 * @version 1.0.0
 * @author Bhargav Choudhury
 * 
 */

package com.hsbc.digital.testauto.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.hsbc.digital.testauto.models.CommunicationPreferencess;

public abstract class CommunicationPreferencesConfirmPageModel {

    protected final WebDriver driver;

    public CommunicationPreferencesConfirmPageModel(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void confirmMessageDisplayed() {}

    public void confirmPageFlow(CommunicationPreferencess communicationPreferences) {
        confirmMessageDisplayed();
        validatemessagesNDocumentsField(communicationPreferences);
        validateTelephoneField(communicationPreferences);
        validateMobileField(communicationPreferences);
        validatePostField(communicationPreferences);
        validateEmailField(communicationPreferences);
        printButtonDisplayed();
        myAccountsButtonDisplayed();
    }

    public void printButtonDisplayed() {}

    public void myAccountsButtonDisplayed() {}

    public boolean validatemessagesNDocumentsField(CommunicationPreferencess communicationPreferences) {
        return false;
    }

    public boolean validateTelephoneField(CommunicationPreferencess communicationPreferences) {
        return false;
    }

    public boolean validateMobileField(CommunicationPreferencess communicationPreferences) {
        return false;
    }

    public boolean validatePostField(CommunicationPreferencess communicationPreferences) {
        return false;
    }

    public boolean validateEmailField(CommunicationPreferencess communicationPreferences) {
        return false;
    }

    public boolean validateField(WebElement field, boolean reviewPageValueSet) {
        return false;
    }


}
