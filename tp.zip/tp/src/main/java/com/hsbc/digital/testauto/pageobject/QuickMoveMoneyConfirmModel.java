/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.Transaction;

/**
 * <p>
 * <b> This class is holding locators and functionality for quick move money
 * confirmation page.After transaction using Quick move money this class will
 * have method to verify response.</b>
 * </p>
 * 
 * @author Pramesh G
 * @version 1.0.0
 */
public abstract class QuickMoveMoneyConfirmModel {

    private final WebDriver driver;
    private final String REFERENCE_REGULAREXPRESSION = "^[a-zA-Z0-9]*$";

    /**
     * Transaction Failed Error Message
     */
    @FindBy(xpath = "//div[contains(@id,'ContentPane')]//div[@class='alertPanel error']")
    private List<WebElement> widgetErrors;

    /**
     * From Account Name
     */
    @FindBy(xpath = "//div[contains(@id,'ContentPane')]//*[contains(text(), 'From') and not(contains(@class,'accessible'))]/following::*[1]/*[1]")
    private WebElement fromAccountName;

    /**
     * From Account Number
     */
    @FindBy(xpath = "//div[contains(@id,'ContentPane')]//*[contains(text(), 'From') and not(contains(@class,'accessible'))]/following::*[1]/*[2]")
    private WebElement fromAccountNumber;

    /**
     * To Account Name
     */
    @FindBy(xpath = "//div[contains(@id,'ContentPane')]//*[contains(text(), 'To') and not(contains(@class,'accessible'))]/following::*[1]/*[1]")
    private WebElement toAccountName;

    /**
     * To Account Number
     */
    @FindBy(xpath = "//div[contains(@id,'ContentPane')]//*[contains(text(), 'To') and not(contains(@class,'accessible'))]/following::*[1]/*[2]")
    private WebElement toAccountNumber;

    /**
     * Amount
     */
    @FindBy(xpath = "//div[contains(@id,'ContentPane')]//*[contains(text(), 'Amount') and not(contains(@class,'accessible'))]/following::*[1]/*[2]")
    private WebElement tranferedBalance;

    /**
     * Reference Number
     */
    @FindBy(xpath = "//div[contains(@id,'ContentPane')]//*[contains(text(), 'Reference')]//following::*[1]")
    private WebElement referenceNumber;

    /**
     * New Transaction Button
     */
    @FindBy(xpath = "//button[text()=' New transaction ' and @class='btnPrimary']")
    private WebElement newTransactionButton;

    /**
     * Transfer limit Messages
     */
    @FindBy(xpath = "//div[contains(@class,'fl')]//div[@class='quickMoveMoney']//div[contains(@class,'quickTransferText')]//p")
    protected List<WebElement> transferLimitMsgs;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(QuickMoveMoneyCaptureModel.class);

    public QuickMoveMoneyConfirmModel(final WebDriver webDriver) {
        this.driver = webDriver;
        PageFactory.initElements(driver, this);
    }


    /**
     * Verify all Details of Confirmation Page
     * 
     * @param fromAccDetails
     *            :From Account Details
     * @param toAccDetails
     *            : To Account Details
     */
    public void validateConfirmationPage(final Transaction transaction) {

        if (!widgetErrors.isEmpty()) {
            String errors = StringUtils.EMPTY;
            for (WebElement element : widgetErrors) {
                errors += element.getText();
            }
            Reporter.log("Errors found:" + errors);
            Assert.fail("Error response received");
        } else {
            checkFromAccount(transaction.getFromAccount());
            checkToAccount(transaction.getToAccount());
            checkTransferedAmount(transaction.getAmount());
            checkReferenceNumber();
        }
    }

    /**
     * This method is used to check the To Account Field
     */
    public void checkToAccount(final AccountDetails toAcctDetails) {
        Assert.assertTrue(isAccountVerified(toAcctDetails, toAccountName, toAccountNumber),
            "From Account Number is Not Same. Expected :-" + toAccountName + "," + toAccountNumber + " & Actual is :-"
                + toAccountName.getText() + "," + toAccountNumber.getText());
        Reporter.log("To Account Details :" + toAcctDetails.getAccountName() + " :: " + toAcctDetails.getAccountNumber());
    }

    /**
     * This method is used to check the From Account Field
     */
    public void checkFromAccount(final AccountDetails fromAcctDetails) {
        Assert.assertTrue(
            isAccountVerified(fromAcctDetails, fromAccountName, fromAccountNumber),
            "From Account Number is Not Same. Expected :-" + fromAcctDetails.getAccountName() + ","
                + fromAcctDetails.getAccountNumber() + " & Actual is :-" + fromAccountName.getText() + ","
                + fromAccountNumber.getText());
        Reporter.log("From Account Details :" + fromAcctDetails.getAccountName() + " :: " + fromAcctDetails.getAccountNumber());
    }

    /**
     * This Method is used to check the transfered Amount
     * 
     * @param amount
     */
    public void checkTransferedAmount(final String amount) {
        Assert.assertTrue(amount.equals(tranferedBalance.getText()), "Transfer amount not Matched");
        Reporter.log("Transfered amount matches");
    }

    /**
     * This Method is Used to Check the Reference Field
     */
    public void checkReferenceNumber() {

        Assert.assertTrue(isValidReferenceNo(referenceNumber.getText()),
            "Reference Number is not valid. Ref No:" + referenceNumber.getText());
        Reporter.log("Reference Number :" + referenceNumber.getText());
    }

    /**
     * Verified the Transfer Limit Messages
     */
    public void verifyTransferLimitMessage() {
        Assert.assertTrue(isTransferLimitMessageDisplayed(), "Transfer Limit Error Message is Not Found");
        Reporter.log("Transfer Limit Error Message is Verified");
    }

    /**
     * This is Generic Method to Verify Account Details
     * 
     * @param accountDetails
     *            : Account Details
     * @param accountName
     *            :Confirmation Account Name
     * @param accountNumber
     *            : Confirmation Account Number
     * @return
     */
    protected boolean isAccountVerified(final AccountDetails accountDetails, final WebElement accountName,
        final WebElement accountNumber) {
        return accountDetails.getAccountName().equalsIgnoreCase(accountName.getText())
            && accountDetails.getAccountNumber().equalsIgnoreCase(accountNumber.getText());
    }

    /**
     * Validate the Reference Text
     * 
     * @param text
     *            :
     * @return
     */
    private boolean isValidReferenceNo(final String text) {
        return text.length() > 0 && text.matches(REFERENCE_REGULAREXPRESSION);
    }

    /**
     * Click the New Transaction Button
     */
    public void clickNewTransaction() {
        newTransactionButton.click();
        Reporter.log("New transaction button clicked.");
    }

    /**
     * Verify the Transfer Limit Error Message
     */
    public boolean isTransferLimitMessageDisplayed() {
        return !transferLimitMsgs.isEmpty() && transferLimitMsgs.get(0).getText().contains("exceeds your daily limit");
    }


}
