package com.hsbc.digital.testauto.pageobject.uk;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.hsbc.digital.testauto.pageobject.MoveMoneyVerifyPageModel;

public class MoveMoneyVerifyPage extends MoveMoneyVerifyPageModel {

    public MoveMoneyVerifyPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }
}
