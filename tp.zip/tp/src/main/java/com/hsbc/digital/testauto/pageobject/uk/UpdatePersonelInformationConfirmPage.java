/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.uk;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.models.UpdatePersonalInformation;
import com.hsbc.digital.testauto.pageobject.UpdatePersonelInformationConfirmPageModel;

/**
 * <p>
 * <b> Contains locators and functions for Story - Update Personal Information
 * for UK entity </b>
 * </p>
 */
public class UpdatePersonelInformationConfirmPage extends UpdatePersonelInformationConfirmPageModel {

    /* Locators for error page */

    @FindBy(xpath = "//div[contains(@class,'whiteBackground')]//p")
    private WebElement errorMessageOnErrorPage;

    @FindBy(xpath = "//div[contains(@class,'hsbcButtonCenter')]/a")
    private WebElement okButtonOnErrorPage;

    /* Locators for Confirm Page */

    @FindBy(xpath = "//p[contains(@class,'hsbcTextHighlight')]")
    private WebElement confirmationMessageOnConfirmPage;

    @FindBy(xpath = "//strong[text()='Number of dependent children:']//parent::td//following::td[1]")
    private WebElement noOfDependentOnConfirmPage;

    @FindBy(xpath = "//strong[text()='Email Address:']//parent::td//following::td[1]/div")
    private WebElement emailAddressOnConfirmPage;

    @FindBy(xpath = "//strong[text()='Online greeting:']//parent::td//following::td[1]")
    private WebElement onlineGreetingOnConfirmPage;

    @FindBy(xpath = "//strong[text()='Marital status:']//parent::td//following::td[1]")
    private WebElement maritalStatusOnConfirmPage;

    @FindBy(xpath = "//div[contains(@class,'hsbcButtonCenter')]/a[contains(@title,'accounts')]")
    private WebElement myAccountsButtonOnConfirmPage;

    @FindBy(xpath = "//div[contains(@class,'hsbcButtonCenter')]/a[contains(@title,'print')]")
    private WebElement printButtonOnConfirmPage;

    public UpdatePersonelInformationConfirmPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    public void printButtonDisplayed() {
        Assert.assertTrue(printButtonOnConfirmPage.isDisplayed(), "Print button is not displayed on the confirm page.");
    }

    @Override
    public void myAccountsButtonDisplayed() {
        Assert.assertTrue(myAccountsButtonOnConfirmPage.isDisplayed(), "My Accounts button is not displayed on the confirm page.");
    }

    @Override
    public void confirmationMessageDisplayed() {
        Assert.assertTrue(confirmationMessageOnConfirmPage.isDisplayed(),
            "Confirmation message is not displayed on the confirm page.");
    }

    @Override
    public void validateConfirmPage(UpdatePersonalInformation updatePersonalInformation) {
        checkOnlineGreeting(updatePersonalInformation.getOnlineGreeting());
        checkNoOfDependent(updatePersonalInformation.getNoOfDependent());
        checkMaritalStatus(updatePersonalInformation.getMaritalStatus());
        checkEmailAddress(updatePersonalInformation.getEmailAddress());
        Reporter.log("Values on capture and confirm page are matching");
    }

    private void checkMaritalStatus(String maritalStatusDetails) {
        Assert.assertTrue(maritalStatusDetails.equalsIgnoreCase(maritalStatusOnConfirmPage.getText().trim()),
            "Marital Status does not match on capture and confirm page");
    }

    private void checkEmailAddress(String emailAddressDetails) {
        Assert.assertTrue(emailAddressDetails.equalsIgnoreCase(emailAddressOnConfirmPage.getText().trim()),
            "Email address does not match on capture and confirm page");
    }

    private void checkNoOfDependent(String noOfDependentDetails) {
        Assert.assertTrue(noOfDependentDetails.equalsIgnoreCase(noOfDependentOnConfirmPage.getText().trim()),
            "No of dependent does not match on capture and confirm page");
    }

    private void checkOnlineGreeting(String onlineGreetingDetails) {
        Assert.assertTrue(onlineGreetingDetails.equalsIgnoreCase(onlineGreetingOnConfirmPage.getText().trim()),
            "Online Greeting does not match on capture and confirm page");

    }

    @Override
    public void invalidEmailAddressMessageDisplayed() {
        Assert.assertTrue(errorMessageOnErrorPage.isDisplayed(), "Error message is not displayed on the error page.");
    }

    @Override
    public void clickOnOKButtonOnErrorPage() {
        okButtonOnErrorPage.click();
        Reporter.log("Ok button on the error page clicked successfully");
    }
}
