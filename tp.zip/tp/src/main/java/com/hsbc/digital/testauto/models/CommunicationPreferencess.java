/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.models;

/* Contains getters and setters for story Communication Preferences */

public class CommunicationPreferencess {

    Boolean email;
    Boolean post;
    Boolean telephone;
    Boolean messagesNDocments;
    Boolean mobileMessaging;

    public Boolean getEmail() {
        return email;
    }

    public void setEmail(Boolean email) {
        this.email = email;
    }

    public Boolean getPost() {
        return post;
    }

    public void setPost(Boolean post) {
        this.post = post;
    }

    public Boolean getTelephone() {
        return telephone;
    }

    public void setTelephone(Boolean telephone) {
        this.telephone = telephone;
    }

    public Boolean getMessagesNDocments() {
        return messagesNDocments;
    }

    public void setMessagesNDocments(Boolean messagesNDocments) {
        this.messagesNDocments = messagesNDocments;
    }

    public Boolean getMobileMessaging() {
        return mobileMessaging;
    }

    public void setMobileMessaging(Boolean mobileMessaging) {
        this.mobileMessaging = mobileMessaging;
    }


}
