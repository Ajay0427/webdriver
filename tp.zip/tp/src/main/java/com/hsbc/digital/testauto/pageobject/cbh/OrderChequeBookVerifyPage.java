/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.cbh;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.pageobject.OrderChequeBookVerifyPageModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Order
 * Cheque Book for US entity. </b>
 * </p>
 */
public class OrderChequeBookVerifyPage extends OrderChequeBookVerifyPageModel {

    @FindBy(xpath = "//dd[@data-dojo-attach-point='_verifyNumberOfPagesInChequeBook']")
    private WebElement noOfPagesReview;

    @FindBy(xpath = "//div[@class='submitButtonsPanel']//span[@data-dojo-attach-point='containerNode']")
    private WebElement submitRequestButton;

    @FindBy(xpath = "//div[@data-dojo-attach-point='_verifyCancelDialog']//div[@class='formWrapper']")
    private WebElement verifyPageCancelMessage2;

    @FindBy(xpath = "//li[@class='error']//span[2]")
    private WebElement errorMessageDuplicate;


    public OrderChequeBookVerifyPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    public void verifyNumberOfPagesVerifyPage(final AccountDetails accountDetails) {
        Assert.assertTrue(accountDetails.getNumberOfPages().equals(noOfPagesReview.getText()),
            "Number of Cheques on verify page does not match. ");
        Reporter.log("Number of Pages in Cheque Book on verify page are same as selected. ");
    }

    @Override
    public void verifyAccountDetailsVerifyPage(final AccountDetails accountDetails) {
        Assert.assertTrue(accountNameVerifyPage.getText().contains(accountDetails.getAccountNumber()),
            "Account Details on verify page does not match. ");
        Reporter.log("Account Details on verify page are same as selected. ");
    }

    @Override
    public void clickConfirmButton() {
        submitRequestButton.click();
        Reporter.log("Submit request button clicked.");
    }

    /**
     * Method to verify number of cheque books on verify page
     * 
     * @param accountDetails
     */
    @Override
    public void verifyNumberOfChequeBookVerifyPage(final AccountDetails accountDetails) {
        Assert.assertTrue(accountDetails.getNumberOfChequeBooks().equals(numberOfChequeBookVerifyPage.getText()),
            "Number of Cheque Books on verify page does not match. ");
        Reporter.log("Number of Cheque Books on verify page are same as selected. ");
    }


    @Override
    public void isCancelMessageOnVerifyPageDisplayed() {
        Assert.assertTrue(verifyPageCancelMessage1.isDisplayed() && verifyPageCancelMessage2.isDisplayed()
            && !verifyPageCancelMessage1.getText().isEmpty() && !verifyPageCancelMessage2.getText().isEmpty(),
            "Cancel message on cancel dialog of verify page is not displayed. ");
        Reporter.log("Cancel message on cancel dialog of Verify Page is displayed. ");
    }

    @Override
    public void isDuplicateErrorMessage() {

        Assert.assertTrue(errorMessageDuplicate.isDisplayed(),
            "Error message is not displayed for while ordering cheque two time more than one time");
        Reporter.log("Error message os displayed as " + errorMessageDuplicate.getText());

    }

}
