/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.models;

import java.util.Date;

public class AccountDetails {

    private String accountNumber;
    private String accountName;
    private String accountNickName;
    private String accountBalance;
    private String currency;
    private String accountCountry;
    private Double doubleAccountBalance;
    private String bankAndBranchName;
    private String transferAmount;
    private String yourReference;
    private String selectedYear;
    private Date laterDate;
    private Date firstDateOfTransaction;
    private Date finalDateOfTransaction;
    private String reasonForTransaction;
    private String frequencyValue;
    private String numberOfPayment;
    private String referenceNumber;
    private String accountTypeCode;
    private String checkStartRange;
    private String checkEndRange;
    private String numberOfChequeBooks;
    private AccountTypes accountTypes;
    private String numberOfPages;
    private String balanceAsOf;
    private boolean isBundledAccount;
    private String productCode;
    private int accountSequence;

    private String email;
    private String homePhoneNumber;
    private String mobilePhoneNumber;
    private String workPhoneNumber;
    private String faxNumber;
    private String workFaxNumber;
    private String grossAnnualSalary;
    private String employerName;
    private String noOfDependents;
    private String occupation;
    private String streetName;
    private String streetNumber;
    private String cityName;
    private String postalCode;
    private String employeeStatus;
    private String typeOfBussiness;
    private String address;
    private String jobTitle;
    private String state;

    private String payeeName;
    private String emailAddress;
    private String lang;
    private String securityQue;
    private String securityAns;
    private String notifyMeBy;
    private String emailAddressSender;
    private String fee;
    private String date;
    
    public void setState(final String state) {
    	this.state= state;
    }
    
    public String getState() {
    	return state;
    }
    

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(final String occupation) {
        this.occupation = occupation;
    }

    public String getNoOfDependents() {
        return noOfDependents;
    }

    public void setNoOfDependents(final String noOfDependents) {
        this.noOfDependents = noOfDependents;
    }

    public AccountTypes getAccountTypes() {
        return accountTypes;
    }

    public void setAccountTypes(final AccountTypes accountTypes) {
        this.accountTypes = accountTypes;
    }

    /**
     * @return the checkStartRange
     */
    public String getCheckStartRange() {
        return checkStartRange;
    }

    /**
     * @param checkStartRange
     *            the checkStartRange to set
     */
    public void setCheckStartRange(final String checkStartRange) {
        this.checkStartRange = checkStartRange;
    }

    /**
     * @return the checkEndRange
     */
    public String getCheckEndRange() {
        return checkEndRange;
    }

    /**
     * @param checkEndRange
     *            the checkEndRange to set
     */
    public void setCheckEndRange(final String checkEndRange) {
        this.checkEndRange = checkEndRange;
    }

    public String getAccountTypeCode() {
        return accountTypeCode;
    }

    public void setAccountTypeCode(final String accountCode) {
        accountTypeCode = accountCode;
    }

    public String getAccountCountry() {
        return accountCountry;
    }

    public void setAccountCountry(final String accountCountry) {
        this.accountCountry = accountCountry;
    }

    public String getReferenceNumber() {
        return referenceNumber;
    }

    public String getBankAndBranchName() {
        return bankAndBranchName;
    }

    public void setBankAndBranchName(final String bankAndBranchName) {
        this.bankAndBranchName = bankAndBranchName;
    }

    public void setReferenceNumber(final String referenceNumber) {
        this.referenceNumber = referenceNumber;
    }

    public String getNumberOfPayment() {
        return numberOfPayment;
    }

    public void setNumberOfPayment(final String numberOfPayment) {
        this.numberOfPayment = numberOfPayment;
    }

    public String getFrequencyValue() {
        return frequencyValue;
    }

    public void setFrequencyValue(final String frequencyValue) {
        this.frequencyValue = frequencyValue;
    }

    public String getReasonForTransaction() {
        return reasonForTransaction;
    }

    public void setReasonForTransaction(final String reasonForTransaction) {
        this.reasonForTransaction = reasonForTransaction;
    }

    public Date getFinalDateOfTransaction() {
        return finalDateOfTransaction;
    }

    public void setFinalDateOfTransaction(final Date finalDateOfTransaction) {
        this.finalDateOfTransaction = finalDateOfTransaction;
    }

    public Date getFirstDateOfTransaction() {
        return firstDateOfTransaction;
    }

    public void setFirstDateOfTransaction(final Date firstDateOfTransaction) {
        this.firstDateOfTransaction = firstDateOfTransaction;
    }

    public Date getLaterDate() {
        return laterDate;
    }

    public void setLaterDate(final Date laterDate) {
        this.laterDate = laterDate;
    }

    public String getYourReference() {
        return yourReference;
    }

    public void setYourReference(final String yourReference) {
        this.yourReference = yourReference;
    }

    public String getTransferAmount() {
        return transferAmount;
    }

    public void setTransferAmount(final String transferAmount) {
        this.transferAmount = transferAmount;
    }

    public Double getDoubleAccountBalance() {
        return doubleAccountBalance;
    }

    public void setDoubleAccountBalance(final Double doubleAccountBalance) {
        this.doubleAccountBalance = doubleAccountBalance;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(final String currency) {
        this.currency = currency;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(final String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(final String accountName) {
        this.accountName = accountName;
    }

    public String getAccountNickName() {
        return accountNickName;
    }

    public void setAccountNickName(final String accountNickName) {
        this.accountNickName = accountNickName;
    }

    public String getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(final String accountBalance) {
        this.accountBalance = accountBalance;
    }

    public void setSelectedYear(final String selectedYear) {
        this.selectedYear = selectedYear;
    }

    public String getSelectedYear() {
        return selectedYear;
    }

    public String getFormattedAccountBal() {
        return accountBalance.replace(",", "");
    }

    public void setNumberOfChequeBooks(final String numberOfChequeBooks) {
        this.numberOfChequeBooks = numberOfChequeBooks;
    }

    public String getNumberOfChequeBooks() {
        return numberOfChequeBooks;
    }

    /**
     * @return the numberOfPages
     */
    public String getNumberOfPages() {
        return numberOfPages;
    }

    /**
     * @param numberOfPages
     *            the numberOfPages to set
     */
    public void setNumberOfPages(final String numberOfPages) {
        this.numberOfPages = numberOfPages;
    }

    public String getBalanceAsOf() {
        return balanceAsOf;
    }

    public void setBalanceAsOf(final String balanceAsOf) {
        this.balanceAsOf = balanceAsOf;
    }

    public boolean isBundledAccount() {
        return isBundledAccount;
    }

    public void setBundledAccount(final boolean isBundledAccount) {
        this.isBundledAccount = isBundledAccount;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(final String productCode) {
        this.productCode = productCode;
    }

    /**
     * @Getter setter for Story 13 & 14 : Update Customer Information
     */

    public void setEmail(final String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setHomePhoneNumber(final String homePhoneNumber) {
        this.homePhoneNumber = homePhoneNumber;
    }

    public String getHomePhoneNumber() {
        return homePhoneNumber;
    }

    public void setMobilePhoneNumber(final String mobilePhoneNumber) {
        this.mobilePhoneNumber = mobilePhoneNumber;
    }

    public String getMobilePhoneNumber() {
        return mobilePhoneNumber;
    }

    public void setWorkPhoneNumber(final String workPhoneNumber) {
        this.workPhoneNumber = workPhoneNumber;
    }

    public String getWorkPhoneNumber() {
        return workPhoneNumber;
    }

    public String getFaxNumber() {
        return faxNumber;
    }

    public void setFaxNumber(final String faxNumber) {
        this.faxNumber = faxNumber;
    }

    public String getWorkFaxNumber() {
        return workFaxNumber;
    }

    public void setWorkFaxNumber(final String workFaxNumber) {
        this.workFaxNumber = workFaxNumber;
    }

    public void setAnualSalary(final String grossAnnualSalary) {
        this.grossAnnualSalary = grossAnnualSalary;
    }

    public String getAnnualSalary() {
        return grossAnnualSalary;
    }

    public void setEmployerName(final String employerName) {
        this.employerName = employerName;
    }

    public String getEmployerName() {
        return employerName;
    }

    public void setStreeName(final String streetName) {
        this.streetName = streetName;
    }

    public String getStreeName() {
        return streetName;
    }

    public void setStreetNumber(final String streetNumber) {
        this.streetNumber = streetNumber;
    }

    public String getStreetNumber() {
        return streetNumber;
    }

    public void setCityName(final String cityName) {
        this.cityName = cityName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setPostalCode(final String postalCode) {
        this.postalCode = postalCode;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setEmplyoeeStatus(final String emplyoeeStatus) {
        this.employeeStatus = emplyoeeStatus;
    }

    public String getEmplyoeeStatus() {
        return employeeStatus;
    }

    public void setTypeOfBussiness(final String typeOfBussiness) {
        this.typeOfBussiness = typeOfBussiness;
    }

    public String getTypeOfBussiness() {
        return typeOfBussiness;
    }

    public void setAddress(final String address) {
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public void setJobTitle(final String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    /**
     * @return the accountSequence
     */
    public int getAccountSequence() {
        return this.accountSequence;
    }

    /**
     * @param accountSequence
     *            the accountSequence to set
     */
    public void setAccountSequence(final int accountSequence) {
        this.accountSequence = accountSequence;
    }

    /**
     * @Getter setter for Story 316: Update IE Information
     */

    public String getPayeeName() {
        return payeeName;
    }

    public void setPayeeName(final String payeeName) {

        this.payeeName = payeeName;
    }

    public String getEmailName() {
        return email;
    }

    public void setEmailName(final String email) {
        this.email = email;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(final String lang) {
        this.lang = lang;
    }

    public String getSecurityQue() {
        return securityQue;
    }

    public void setSecurityQue(final String securityQue) {
        this.securityQue = securityQue;
    }


    public String getSecurityAns() {
        return securityAns;
    }

    public void setSecurityAns(final String securityAns) {
        this.securityAns = securityAns;
    }

    public String getNotifyMeBy() {
        return notifyMeBy;
    }

    public void setNotifyMeBy(final String notifyMeBy) {
        this.notifyMeBy = notifyMeBy;
    }

    public String getEmailAddressSender() {
        return emailAddressSender;
    }

    public void setEmailAddressSender(final String emailAddressSender) {
        this.emailAddressSender = emailAddressSender;
    }

    public String getFee() {
        return fee;
    }

    public void setFee(final String fee) {
        this.fee = fee;
    }

    public String getDate() {
        return date;
    }

    public void setDate(final String date) {
        this.date = date;
    }

    public void setEmailAddress(final String emailAddress) {
        this.emailAddress = emailAddress;
    }


    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "AccountDetails [accountNumber=" + this.accountNumber + ", accountName=" + this.accountName + ", accountBalance="
            + this.accountBalance + ", currency=" + this.currency + ", accountCountry=" + this.accountCountry
            + ", doubleAccountBalance=" + this.doubleAccountBalance + ", bankAndBranchName=" + this.bankAndBranchName
            + ", transferAmount=" + this.transferAmount + ", yourReference=" + this.yourReference + ", selectedYear="
            + this.selectedYear + ", laterDate=" + this.laterDate + ", firstDateOfTransaction=" + this.firstDateOfTransaction
            + ", finalDateOfTransaction=" + this.finalDateOfTransaction + ", reasonForTransaction=" + this.reasonForTransaction
            + ", frequencyValue=" + this.frequencyValue + ", numberOfPayment=" + this.numberOfPayment + ", referenceNumber="
            + this.referenceNumber + ", accountTypeCode=" + this.accountTypeCode + ", checkStartRange=" + this.checkStartRange
            + ", checkEndRange=" + this.checkEndRange + ", numberOfChequeBooks=" + this.numberOfChequeBooks + ", accountTypes="
            + this.accountTypes + ", numberOfPages=" + this.numberOfPages + ", balanceAsOf=" + this.balanceAsOf
            + ", isBundledAccount=" + this.isBundledAccount + ", productCode=" + this.productCode + ", accountSequence="
            + this.accountSequence + ", email=" + this.email + ", homePhoneNumber=" + this.homePhoneNumber + ", mobilePhoneNumber="
            + this.mobilePhoneNumber + ", workPhoneNumber=" + this.workPhoneNumber + ", faxNumber=" + this.faxNumber
            + ", workFaxNumber=" + this.workFaxNumber + ", grossAnnualSalary=" + this.grossAnnualSalary + ", employerName="
            + this.employerName + ", noOfDependents=" + this.noOfDependents + ", occupation=" + this.occupation + ", streetName="
            + this.streetName + ", streetNumber=" + this.streetNumber + ", cityName=" + this.cityName + ", postalCode="
            + this.postalCode + ", employeeStatus=" + this.employeeStatus + ", typeOfBussiness=" + this.typeOfBussiness
            + ", address=" + this.address + ", jobTitle=" + this.jobTitle + "]";
    }
}
