/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.mx;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.OpenAccountDetails;
import com.hsbc.digital.testauto.pageobject.OpenAccountOptionsModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Mexico
 * entity. </b>
 * </p>
 */
public class OpenAccountOptions extends OpenAccountOptionsModel {

    final WebDriver driver;
    final WebDriverWait wait;

    @FindBy(xpath = "//li[contains(@class,'padinDebit')]//input[contains(@class,'dijitArrowButtonInner')]")
    private List<WebElement> accountDropDownIcon;

    @FindBy(xpath = "//div[contains(@class,'dijitSelectMenu')]//tr[contains(@id,'dijit_MenuItem')]")
    private List<WebElement> debitAccountDropDownItems;

    @FindBy(xpath = "//li[contains(@class,'padinDebit')]//span[@class='balance']")
    protected WebElement debitAccountBalance;

    @FindBy(xpath = "//div[contains(@id,'_investmentAccount')]//input[contains(@class,'dijitArrowButtonInner')]")
    private List<WebElement> investmentAccDropDownIcon;

    @FindBy(xpath = "//div[contains(@class,'invAccountSelectMenu')]//tr[contains(@id,'dijit_MenuItem_')]")
    private List<WebElement> investmentAccDropDownItems;

    @FindBy(xpath = "//div[contains(@id,'_investmentAccount')]//span[contains(@class,'dijitSelectLabel ')]")
    private WebElement investmentAccOptionSelected;

    @FindBy(xpath = "//span[@class='singleOptionContainer']")
    private WebElement investmentAccLabel;

    @FindBy(xpath = "//span[@class='currency-text']")
    private WebElement newAccountCurrency;

    @FindBy(xpath = "//div[@data-dojo-attach-point='_maturityInstructionLabel']/following-sibling::div/descendant::td/input[contains(@class,'dijitArrowButtonInner')]")
    private List<WebElement> maturityInstructionDropDownIcon;

    @FindBy(xpath = "//div[contains(@class,'maturityInstructionPopup')]//tr")
    private List<WebElement> maturityInstructionDropDownItems;

    @FindBy(xpath = "//div[@data-dojo-attach-point='_maturityInstructionLabel']/following-sibling::div/descendant::div[contains(@class,'dijitInputField')]")
    private WebElement maturityInstructionOptionSelected;

    @FindBy(xpath = "//div[@data-dojo-attach-point='_maturityInstructionLabel']/following-sibling::span[contains(@id,'singleOption')]")
    private WebElement maturityInstructionText;

    @FindBy(xpath = "//input[contains(@id,'CurrencyTextBox')]")
    private WebElement amountField;

    @FindBy(xpath = "//span[@data-dojo-attach-point='_minimumAmount']")
    private List<WebElement> minAmountLabelList;

    @FindBy(xpath = "//span[@data-dojo-attach-point='_minimumAmount']")
    private WebElement minAmountLabel;

    @FindBy(xpath = "//li[@data-dojo-attach-point='accountTerm']//input[contains(@id,'arrowid_hdx_dijits_form_Select')]")
    protected WebElement termOptionsDropDown;

    @FindBy(xpath = "//div[@data-dojo-attach-point='_disclaimerForTFSA' and not (contains(@class,'dijitHidden'))]//input[contains(@id,'disclaimerchkboxforTFSA')]")
    private List<WebElement> disclaimerCheckboxforTFSA;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(OpenAccountOptions.class);

    public OpenAccountOptions(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        this.driver = driver;
        this.wait = new WebDriverWait(driver, 30);
    }

    @Override
    protected AccountDetails selectDebitAccount(final Map<String, String> profileProperties, final Boolean selectOnlySoleAccount) {
        AccountDetails accountDetails = null;
        if (!accountDropDownIcon.isEmpty() && accountDropDownIcon.get(0).isDisplayed()) {
            accountDetails = new AccountDetails();
            accountDetails = selectAccount(accountDropDownIcon.get(0), minAmount());
            Reporter.log(OpenAccountOptionsModel.LOG_MESSAGE_DEBIT_ACCT_SELECTED + super.debitAccountNameList.get(0).getText()
                + " :: " + super.accountNumberList.get(0).getText() + ". | ");
        } else if (Double.parseDouble(minAmount()) <= Double.parseDouble(super.debitAccountBalance.getText().split(" ")[0].replace(
            ",", ""))) {
            accountDetails = new AccountDetails();
            accountDetails.setAccountName(super.debitAccountName.getText());
            accountDetails.setAccountNumber(super.debitAccountNumber.getText());
            accountDetails.setAccountBalance(super.debitAccountBalance.getText().split(" ")[0]);
            Reporter.log(OpenAccountOptionsModel.LOG_MESSAGE_DEBIT_ACCT_SELECTED + super.debitAccountName.getText() + " :: "
                + super.debitAccountNumber.getText() + ". | ");
        } else {
            Assert.fail("No account present in Debit account with minimum balance. | ");
        }
        return accountDetails;
    }

    private AccountDetails selectAccount(final WebElement accountDropIcon, final String minBalance) {
        int index = 0;
        List<AccountDetails> accountValue = validAccountDetails(accountDropIcon, listDropdown, minBalance);
        Assert.assertTrue(!accountValue.isEmpty(), "No valid account found.");
        if (accountValue.size() != 1) {
            index = RandomUtil.generateIntNumber(0, accountValue.size());
        }
        selectAccountByAccountDetail(accountDropIcon, accountValue.get(index));
        return accountValue.get(index);
    }

    private List<AccountDetails> validAccountDetails(final WebElement accountDropIcon, final WebElement menuDrop,
        final String minBalance) {
        List<AccountDetails> storeAccountValue = new ArrayList<>();
        accountDropIcon.click();
        wait.until(ExpectedConditions.visibilityOf(menuDrop));
        List<WebElement> accountRows = menuDrop.findElements(menuText);
        for (WebElement accountRow : accountRows) {
            jsx.executeScript(SCROLL_INTO_VIEW, accountRow);
            WebElement accName = accountRow.findElements(accountName1).isEmpty() ? accountRow.findElement(accountName2)
                : accountRow.findElement(accountName1);
            String accountName = (String) jsx.executeScript(GET_HIDDEN_TEXT, accName);
            WebElement optItem = accountRow.findElements(accountDetails1).isEmpty() ? accountRow.findElement(accountDetails2)
                : accountRow.findElement(accountDetails1);
            WebElement accNumber = optItem.findElement(accountNum);
            String strAccountNumber = accNumber.getText();
            String accountBalance = (String) jsx.executeScript(GET_HIDDEN_TEXT, optItem.findElement(locatorAccountBalance));
            Double balance = Double.parseDouble(accountBalance.replace(",", ""));
            if (balance >= Double.parseDouble(minBalance)) {
                AccountDetails accountInformations = new AccountDetails();
                accountInformations.setAccountName(accountName);
                accountInformations.setAccountNumber(strAccountNumber);
                accountInformations.setAccountBalance(accountBalance);
                accountInformations.setDoubleAccountBalance(balance);
                storeAccountValue.add(accountInformations);
            }
        }
        jsx.executeScript(SCROLL_INTO_VIEW, accountDropIcon);
        accountDropIcon.click();
        return storeAccountValue;
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.OpenAccountOptionsModel#selectInvestmentAccount()
     */
    @Override
    public String selectInvestmentAccount(final boolean isNewInvestmentAcct) {
        String investmentAccountSelected = StringUtils.EMPTY;
        if (!investmentAccDropDownIcon.isEmpty() && investmentAccDropDownIcon.get(0).isDisplayed()) {
            wait.until(ExpectedConditions.elementToBeClickable(investmentAccDropDownIcon.get(0)));
            investmentAccDropDownIcon.get(0).click();
            int selectedElementNumber = (!isNewInvestmentAcct ? 1 : 0);
            if (!isNewInvestmentAcct && investmentAccDropDownItems.size() > 2) {
                selectedElementNumber = RandomUtil.generateIntNumber(1, investmentAccDropDownItems.size() - 1);
            }
            WebElement selectedItem = investmentAccDropDownItems.get(selectedElementNumber);
            super.jsx.executeScript(SCROLL_INTO_VIEW, selectedItem);
            selectedItem.click();
            investmentAccountSelected = investmentAccOptionSelected.getText();
            Reporter.log("Investment Account: " + investmentAccountSelected + ". | ");
        } else {
            investmentAccountSelected = investmentAccLabel.getText();
            Reporter.log("Investment account is New. | ");
        }
        return investmentAccountSelected;
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.OpenAccountOptionsModel#selectNewAccountCurrency()
     */
    @Override
    public String selectNewAccountCurrency() {
        Reporter.log("Currency Stored is: " + newAccountCurrency.getText() + ". | ");
        return newAccountCurrency.getText();
    }

    /**
     * Clicks disclaimer checkbox if displayed
     */
    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.OpenAccountOptionsModel#clickTnCCheckbox()
     */
    @Override
    public void clickTnCCheckbox() {
        if (!disclaimerCheckboxforTFSA.isEmpty()) {
            disclaimerCheckboxforTFSA.get(0).click();
            Reporter.log("disclaimerCheckboxforTFSA clicked. | ");
        }
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.OpenAccountOptionsModel#selectAccountTerm()
     */
    @Override
    public String selectAccountTerm(final Map<String, String> envProperties) {
        wait.until(ExpectedConditions.elementToBeClickable(termOptionsDropDown));
        termOptionsDropDown.click();
        int selectedElementNumber = 1;
        jsx.executeScript(OpenAccountOptionsModel.MAKE_ELEMENT_VISIBLE, super.termDropDownItems.get(0));
        if (super.termDropDownItems.size() == 1) {
            Assert.fail("No valid Term duration present. | ");
        } else if (super.termDropDownItems.size() > 2) {
            selectedElementNumber = RandomUtil.generateIntNumber(1, super.termDropDownItems.size() - 1);
        }
        WebElement termInList = super.termDropDownItems.get(selectedElementNumber);
        jsx.executeScript(SCROLL_INTO_VIEW, termInList);
        termInList.click();
        selectValidTerm(envProperties, super.termDropDownItems.size());
        String termSelected = super.termOptionSelected.getText();
        Reporter.log("Term Selected is: " + termSelected + ". | ");
        return termSelected;
    }

    private void selectValidTerm(final Map<String, String> envProperties, final int totalValues) {
        int eachTerm = 1;
        boolean isCorrectTermFound = false;
        while (!isCorrectTermFound) {
            if (eachTerm <= totalValues) {
                String termSelected = super.termOptionSelected.getText();
                Reporter.log("\"" + termSelected + "\" term selected. | ");
                int termDuration = Integer.parseInt(termSelected.split(" ")[0]);
                Date calcMaturityDate = DateUtil.addDays(new Date(), termDuration);
                if (checkForHoliday(setTimeToZero(calcMaturityDate), envProperties)) {
                    Reporter.log("Maturity date is on holiday. | ");
                    selectAccountTermWithoutRandom(eachTerm);
                } else if (checkForWeekends(setTimeToZero(calcMaturityDate)) > 0) {
                    Reporter.log("Maturity date is on Weekend. | ");
                    selectAccountTermWithoutRandom(eachTerm);
                } else {
                    isCorrectTermFound = true;
                }
                eachTerm++;
            } else {
                Assert.fail("No Valid term preasent. All term duration has maturity date on Weekend/Holiday. | ");
            }
        }
    }

    private void selectAccountTermWithoutRandom(final int eachTerm) {
        wait.until(ExpectedConditions.elementToBeClickable(termOptionsDropDown));
        termOptionsDropDown.click();
        jsx.executeScript(OpenAccountOptionsModel.MAKE_ELEMENT_VISIBLE, termDropDownItems.get(0));
        WebElement termInList = termDropDownItems.get(eachTerm);
        jsx.executeScript(SCROLL_INTO_VIEW, termInList);
        termInList.click();
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.OpenAccountOptionsModel#storeMaturityInstruction()
     */
    @Override
    public String selectMaturityInstruction() {
        String maturityInstructionSelected = StringUtils.EMPTY;
        if (!maturityInstructionDropDownIcon.isEmpty() && maturityInstructionDropDownIcon.get(0).isDisplayed()) {
            wait.until(ExpectedConditions.elementToBeClickable(maturityInstructionDropDownIcon.get(0)));
            maturityInstructionDropDownIcon.get(0).click();
            jsx.executeScript(OpenAccountOptionsModel.MAKE_ELEMENT_VISIBLE, maturityInstructionDropDownItems.get(0));
            int selectedElementNumber = 1;
            if (maturityInstructionDropDownItems.size() == 1) {
                Assert.fail("No valid Maturity Instruction present. | ");
            } else if (maturityInstructionDropDownItems.size() > 2) {
                selectedElementNumber = RandomUtil.generateIntNumber(1, maturityInstructionDropDownItems.size() - 1);
            }
            WebElement selectedItem = maturityInstructionDropDownItems.get(selectedElementNumber);
            super.jsx.executeScript(SCROLL_INTO_VIEW, selectedItem);
            selectedItem.click();
            maturityInstructionSelected = maturityInstructionOptionSelected.getText();
        } else {
            maturityInstructionSelected = maturityInstructionText.getText();
        }
        Reporter.log("Maturity Instruction is: " + maturityInstructionSelected + ". | ");
        return maturityInstructionSelected;
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.OpenAccountOptionsModel#enterAmount()
     */
    @Override
    public Double enterAmount(final String product) {
        amountField.clear();
        amountField.sendKeys(minAmount(product));
        Reporter.log(minAmount(product) + " entered in amount field. | ");
        return Double.parseDouble(minAmount(product).replace(",", ""));
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.OpenAccountOptionsModel#getMinAmountLabelList()
     */
    @Override
    protected String minAmount() {
        String amount = "0.00";
        if (!minAmountLabelList.isEmpty() && minAmountLabelList.get(0).isDisplayed()) {
            amount = minAmountLabelList.get(0).getText().split(" ")[1];
        }
        return amount.replace(",", "");
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.OpenAccountOptionsModel#minAmount(java.lang.String)
     */
    @Override
    public String minAmount(final String product) {
        String amount = StringUtils.EMPTY;
        if (minAmountLabel.isDisplayed()) {
            amount = minAmountLabel.getText().split(" ")[1];
            BigDecimal amountDecimal = BigDecimal.valueOf(Double.parseDouble(amount.replace(",", "")));
            BigDecimal minAmountDecimal = BigDecimal.valueOf(minAmountForProduct(product));
            if (!amountDecimal.equals(minAmountDecimal)) {
                Assert.fail("Minimum amount shown is not correct. | ");
            }
        }
        return amount;
    }

    private Double minAmountForProduct(final String product) {
        Double minAmount = 0.00;
        switch (product) {
        case OpenAccountOptionsModel.PAGARE_MONEDA_NACIONAL:
            minAmount = 1000.00;
            break;
        case OpenAccountOptionsModel.INVERSION_EXPRESS:
            minAmount = 5000.00;
            break;
        case OpenAccountOptionsModel.CEDE_TASA_FIJA:
            minAmount = 10000.00;
            break;
        default:
            minAmount = 50000.00;
            break;
        }
        return minAmount;
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.OpenAccountOptionsModel#getInterestRate(com.hsbc.digital.testauto.models.OpenAccountDetails, boolean)
     */
    @Override
    public String getInterestRate(final OpenAccountDetails openAccount, final boolean isTermInMonths) {
        return null;
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.OpenAccountOptionsModel#selectInterestPaid(java.lang.String)
     */
    @Override
    public String selectInterestPaid(final String termSelected) {
        return null;
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.OpenAccountOptionsModel#selectCreditAccount(com.hsbc.digital.testauto.models.OpenAccountDetails, java.util.Map, boolean)
     */
    @Override
    public AccountDetails selectCreditAccount(final OpenAccountDetails openAccount, final Map<String, String> profileProperties,
        final boolean selectOnlySoleAccount) {
        return null;
    }
}
