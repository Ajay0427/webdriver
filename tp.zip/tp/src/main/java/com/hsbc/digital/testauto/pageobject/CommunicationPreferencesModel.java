/**
 * <p>
 * <b> This class will hold page object model for story 11 - Communication
 * Preferences </b>
 * </p>
 * 
 * @version 1.0.0
 * @author Bhargav Choudhury
 * 
 */

package com.hsbc.digital.testauto.pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.hsbc.digital.testauto.models.CommunicationPreferencess;

public abstract class CommunicationPreferencesModel {

    protected final WebDriver driver;

    public static final String CP_PAGE_TITLE = "Communication Preferences";

    public static final String LANDING_PAGE_TITLE = "My Accounts";

    @FindBy(xpath = "//span[@id='userMenu_label']")
    protected WebElement userLabel;

    @FindBy(xpath = "//a[contains(@href,'preferences')]")
    protected WebElement commPreferencesLink;

    @FindBy(xpath = "//div[@class='row commPreferencesTable commPreferencesStmtTable fourColumn']//input[@aria-checked='true']")
    private WebElement radioChecked;

    @FindBy(xpath = "//div[@class='row commPreferencesTable commPreferencesStmtTable fourColumn']//input[@aria-checked='false']")
    protected WebElement radioUnChecked;

    @FindBy(xpath = "//div[@class='row commPreferencesTable commPreferencesStmtTable fourColumn']//input[@value='electronic']")
    protected WebElement onlineType;

    @FindBy(xpath = "//div[@class='row commPreferencesTable commPreferencesStmtTable fourColumn']//input[@value='paper']")
    protected WebElement paperType;

    @FindBy(xpath = "//span[@class='link longTextWrapTermsAndConditions']/u")
    private WebElement tNcLink;

    @FindBy(xpath = "//input[contains(@id,'hdx_bijits_form_TermsAndConditions')][@aria-checked='false']")
    private WebElement tNcCheckbox;

    @FindBy(xpath = "//h2[contains(text(),'HSBC terms & Conditions')]//ancestor::div//button[@data-dojo-attach-point='closeButtonNode'][contains(text(),'Close')]")
    private WebElement closeBtn;

    @FindBy(xpath = "//button[@data-dojo-attach-point='submitBtn']")
    private WebElement saveBtn;

    @FindBy(xpath = "//button[@data-dojo-attach-point='cancelBtn']")
    private WebElement cancelBtn;

    @FindBy(xpath = "//div[@data-dojo-attach-point='saveSuccessNode']//p")
    private WebElement confirmMsg;

    @FindBy(xpath = "//div[@data-dojo-attach-point='saveFailNode']//p")
    private WebElement errorMsg;

    @FindBy(xpath = "//button[@data-dojo-attach-point='cancelDialogYes']")
    private WebElement popupCancel;

    @FindBy(xpath = "//button[@data-dojo-attach-point='cancelDialogNo']")
    private WebElement popupDontCancel;

    @FindBy(xpath = ".//*[@id='communicationPreferencesBijit']/h2")
    private WebElement commPreferenceTitle;

    @FindBy(xpath = "//*[@id='_dashboardHeading']/h1/span")
    private WebElement landingPageTitle;

    @FindBy(xpath = "//*[@id='emailField']")
    protected WebElement email;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(CommunicationPreferencesModel.class);

    public CommunicationPreferencesModel(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void defaultStatementPreference() {
        CommunicationPreferencesModel.logger.info("Default Statement Type: " + radioChecked.getAttribute("value"));
    }

    public void clicknCloseTnC() {

        if (tNcLink.isDisplayed()) {

            tNcLink.click();
            CommunicationPreferencesModel.logger.info("Terms & Conditions Clicked");
            closeBtn.click();
            tNcCheckbox.click();
            tNcCheckbox.click();
        } else {

            CommunicationPreferencesModel.logger.info("No Terms & COndition Present");
        }
    }

    public void clickCheckBox() {

        if (tNcCheckbox.isDisplayed()) {

            tNcCheckbox.click();

        } else {

            CommunicationPreferencesModel.logger.info("No T&C Checkbox Present");
        }
    }

    public void verifySaveButtonActions() {

        try {

            if (saveBtn.isDisplayed()) {
                CommunicationPreferencesModel.logger.info("Save Button is visible");
            } else {
                CommunicationPreferencesModel.logger.error("Save Button is not visible");
            }

            if (saveBtn.isEnabled()) {
                CommunicationPreferencesModel.logger.info("Save Button is enabled");
                saveBtn.click();
                if (confirmMsg.isDisplayed()) {
                    CommunicationPreferencesModel.logger.info("Message: " + confirmMsg.getText());
                } else {
                    CommunicationPreferencesModel.logger.info("Message: " + errorMsg.getText());
                    Assert.fail("No Message found");
                }

            } else {
                CommunicationPreferencesModel.logger.info("Save Button is not enabled");
                Assert.fail("Save Button is not enabled");

            }

        } catch (Exception e) {
            logger.info(e);
            CommunicationPreferencesModel.logger.error("Error", e);
        }

    }

    public void clickCancelBtn() {
        try {
            cancelBtn.click();
            CommunicationPreferencesModel.logger.info("Clicked on cancel Button");
        } catch (Exception e) {
            logger.info(e);
            CommunicationPreferencesModel.logger.info("Didn't Click on cancel Button");
        }
    }

    public void clickPopUpCancelBtn() {

        try {
            popupCancel.click();
            CommunicationPreferencesModel.logger.info("Clicked on Pop Up cancel Button");
        } catch (Exception e) {
            logger.info(e);
            CommunicationPreferencesModel.logger.info("Didn't Click on POP up cancel Button");
        }
    }

    public void clickPopUpDontCancelBtn() {

        try {
            popupDontCancel.click();
            CommunicationPreferencesModel.logger.info("Clicked on Pop Up Don't cancel Button");
        } catch (Exception e) {
            logger.info(e);
            CommunicationPreferencesModel.logger.info("Didn't Click on POP up Don't cancel Button");
        }
    }

    public void getCommPageTitle() {

        if (commPreferenceTitle.equals(CP_PAGE_TITLE)) {

            logger.info("Current Page: " + commPreferenceTitle.getText());

        } else {

            logger.info("Current Page is not: " + commPreferenceTitle.getText());

        }

    }

    public void getMyBankingPageTitle() {

        if (landingPageTitle.equals(LANDING_PAGE_TITLE)) {

            logger.info("Current Page: " + landingPageTitle.getText());

        } else {

            logger.info("Current Page is not: " + landingPageTitle.getText());

        }

    }

    public void clickUncheckedRadioBtn() {
        radioUnChecked.click();
    }

    public void verifyDetails() {}

    public void verifyLevel() {}

    public void changeDefaultStatementType() {}

    public void navigateToCP() {}

    /** Blank implementations for specific to UK entity (Capture Page) **/

    public void capturePageHeadingDisplayed() {}

    public void clickOnConfirmButton() {}

    public boolean selectEmailRadioButtonCapturePage() {
        return false;
    }

    public boolean selectMessagesNDocumentRadioButtonCapturePage() {
        return false;
    }

    public boolean selectTelephoneRadioButtonCapturePage() {
        return false;
    }

    public boolean selectMobileMessagingRadioButtonCapturePage() {
        return false;
    }

    public boolean selectPostRadioButtonCapturePage() {
        return false;
    }

    public boolean selectRadioButton(By webElement) {
        return false;
    }

    public CommunicationPreferencess capturePageFlow() {
        capturePageHeadingDisplayed();
        CommunicationPreferencess communicationPreferences = new CommunicationPreferencess();
        communicationPreferences.setEmail(selectEmailRadioButtonCapturePage());
        communicationPreferences.setMessagesNDocments(selectMessagesNDocumentRadioButtonCapturePage());
        communicationPreferences.setTelephone(selectTelephoneRadioButtonCapturePage());
        communicationPreferences.setMobileMessaging(selectMobileMessagingRadioButtonCapturePage());
        communicationPreferences.setPost(selectPostRadioButtonCapturePage());
        clickOnConfirmButton();
        return communicationPreferences;
    }

    /*********************/

}
