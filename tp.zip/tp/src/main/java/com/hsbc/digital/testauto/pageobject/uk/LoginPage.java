/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.uk;

import java.io.IOException;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.pageobject.LoginModel;


/**
 * <p>
 * <b> Login Specific changes to UK Entity. </b>
 * 
 * @author Shrikant Joshi
 * @version 1.0.0
 *          </p>
 */
public class LoginPage extends LoginModel {

    @FindBy(xpath = "//*[contains(@name,'pass') and @type='password']")
    private WebElement passwordField;

    @FindBy(xpath = "//div[contains(@id, 'viewNo') and contains(@class, 'showStep')]//input[contains(@class, 'submit_input')]")
    private WebElement submitButton;

    @FindBy(xpath = "//span[@class='listStyle02inner' and contains(text(),'With ')]")
    public WebElement WISecure;

    @FindBy(xpath = "//*[@id='memorableAnswer']")
    public WebElement MemoAns;

    @FindBy(xpath = ".//*[@id='idv_OtpCredential']")
    public WebElement OtpCode;

    @FindBy(partialLinkText = "Without ")
    public WebElement WOSecure;

    @FindBy(css = "input.submit_input")
    public WebElement loginsubmit;


    public LoginPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    public void loginToUserNamePage(final String userName, final String password) {
        waitAndCloseLoginPopUp();
        super.loginToUserNamePage(userName, password);
    }

    /*
     * Commenting code because there might be changes in Canada cam30 login
     * page. (non-Javadoc)
     * 
     * @see
     * com.hsbc.digital.testauto.pageobject.LoginModel#loginWithoutOtp(java
     * .lang.String, java.lang.String, java.lang.String)
     */
    public void enterUsername(final String userName, final String memorableAnswer, final String password) {
        super.loginToUserNamePage(userName, password);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.hsbc.digital.testauto.pageobject.LoginModel#waitAndClickSubmit()
     */
    @Override
    public void waitAndClickSubmit() {
        this.wait.until(ExpectedConditions.visibilityOf(this.submitButton));
        this.submitButton.click();
    }


    @Override
    public void login(final String profile, final Map<String, String> envProperties) throws IOException {
        try {

            Map<String, String> profileProperties = FileUtil.getTestDataProperties(envProperties.get("countryCode"), profile);
            String camLevel = profileProperties.get("camLevel");
            String userName = profileProperties.get("userName");
            String serialNumber = profileProperties.get("serialNumber");
            String otpkey = profileProperties.get("otpKey");
            String memorableAnswer = profileProperties.get("memorableAnswer");
            String password = profileProperties.get("password");
            String guid = profileProperties.get("guid");
            String url = envProperties.get("url");
            String saasUrl = envProperties.get("saasUrl");
            String otp = StringUtils.EMPTY;
            if (StringUtils.isNotEmpty(saasUrl)) {
                driver.get(saasUrl);
            }
            this.driver.get(url);
            if (LoginModel.ACC_LVL_CAM30.equalsIgnoreCase(camLevel)) {
                enterUsername(userName, memorableAnswer, password);
                LogintoDash(camLevel, memorableAnswer, password);
            } else if (LoginModel.ACC_LVL_CAM40.equalsIgnoreCase(camLevel)) {
                otp = tokenGenerator.generateOTP(userName, serialNumber, otpkey);
                enterUsername(userName, memorableAnswer, password);
                LogintoDash(camLevel, memorableAnswer, otp);
            } else if (camLevel.equalsIgnoreCase("")) {
                loginToUserNamePage(guid, password);
            }
            waitForDashboardPage();
        } catch (Exception e) {
            LoginModel.logger.error("Excption thrown at LoginModel:login() :", e);
        }
    }

    public void LogintoDash(final String userCAMlevel, final String strMemans, final String strSecure_orotp) {


        if (userCAMlevel.equalsIgnoreCase("CAM40")) {

            this.clickWISecure();
            this.wait.until(ExpectedConditions.visibilityOf(MemoAns));
            this.setLogin(strMemans);
            this.wait.until(ExpectedConditions.visibilityOf(OtpCode));
            this.setOtp(strSecure_orotp);
        } else if (userCAMlevel.equalsIgnoreCase("CAM30")) {
            try {
                this.clickWOSecure();
            } catch (NoSuchElementException e) {
                LoginModel.logger.error("Excption thrown at LoginModel:LogintoDash() :", e);
            }
            this.wait.until(ExpectedConditions.visibilityOf(MemoAns));
            this.setLogin(strMemans);
            for (int i = 0; i < strSecure_orotp.length(); i++) {
                WebElement Passkey = driver.findElement(By.id("pass" + (i + 1)));
                if (Passkey.isEnabled()) {
                    Passkey.sendKeys(strSecure_orotp.substring(i, i + 1));
                }
            }
        }
        this.wait.until(ExpectedConditions.elementToBeClickable(loginsubmit));
        loginsubmit.click();
    }

    public void clickWISecure() {
        this.WISecure.click();
    }

    public void setLogin(final String strMemans) {
        MemoAns.clear();
        MemoAns.sendKeys(strMemans);
    }

    public void clickWOSecure() {
        WOSecure.click();
    }
}
