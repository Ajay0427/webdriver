/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.us;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.UserInterfaceRequirementDashboardModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for User
 * Interface Requirement Dashboard for Canada entity. </b>
 * </p>
 */
public class UserInterfaceRequirementDashboard extends UserInterfaceRequirementDashboardModel {

    private final WebDriverWait wait;
    /*
     * Masthead
     */
    @FindBy(xpath = "//span[contains(@id,'LanguageToggle')]")
    private WebElement languageToggleText;

    /*
     * HSBC LOGO
     */
    @FindBy(xpath = "//*[@alt='HSBC Retail']")
    private WebElement hsbcLogoForMass;

    @FindBy(xpath = "//*[@alt='HSBC Advance']")
    private WebElement hsbcLogoForAdvance;

    /*
     * -------- HEADER LINKS --------
     */
    @FindBy(xpath = "//a[contains(@class,'navigation-link')]/span[text()='My banking']")
    protected WebElement myBankingLinkHeader;

    @FindBy(xpath = "//a[contains(@class,'navigation-link')]/span[text()='Banking']")
    private WebElement bankingLinkHeader;

    @FindBy(xpath = "//a[contains(@class,'navigation-link')]/span[text()='Borrowing']")
    private WebElement borrowingLinkHeader;

    @FindBy(xpath = "//a[contains(@class,'navigation-link')]/span[text()='Investing & Insurance']")
    private WebElement investingAndInsuranceLinkHeader;

    @FindBy(xpath = "//a[contains(@class,'navigation-link')]/span[text()='Ways to bank']")
    private WebElement waysToBankLinkHeader;

    /*
     * My Banking FlyerMenu - Column wise Links
     */
    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='My banking']]/descendant::ul[preceding-sibling::h3/span[text()='Account dashboard']]/li")
    private List<WebElement> firstColumnLinksMyBankingHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='My banking']]/descendant::ul[preceding-sibling::h3//span[text()='Card services']]/li")
    private List<WebElement> secondColumnLinksMyBankingHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='My banking']]/descendant::ul[preceding-sibling::h3//span[text()='Security']]/li")
    private List<WebElement> thirdColumnLinksMyBankingHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='My banking']]/descendant::ul[preceding-sibling::h3//span[text()='Check']]/li/a")
    private List<WebElement> fourthColumnLinksMyBankingHeader;

    /*
     * Banking FlyerMenu - Column wise Links
     */
    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Banking']]/descendant::li[preceding-sibling::li/span/h3/span[text()='Products']]")
    private List<WebElement> firstColumnLinksBankingHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Banking']]/descendant::ul[preceding-sibling::h3//span[text()='International Banking']]/li")
    private List<WebElement> secondColumnLinksBankingHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Banking']]/descendant::ul[preceding-sibling::h3//span[text()='Advice and Tools']]/li")
    private List<WebElement> thirdColumnLinksBankingHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Banking']]/descendant::ul[preceding-sibling::h3/span[text()='HSBC Premier']]/li")
    private List<WebElement> fourthColumnHSBCPremierHeadingLinksBankingHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Banking']]/descendant::ul[preceding-sibling::h3/span[text()='HSBC Advance']]/li")
    private List<WebElement> fourthColumnHSBCAdvanceHeadingLinksBankingHeader;

    /*
     * Borrowing FlyerMenu - Column wise Links
     */
    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Borrowing']]/descendant::ul[preceding-sibling::h3/span[text()='Home loans']]/li")
    private List<WebElement> firstColumnLinksBorrowingHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Borrowing']]/descendant::ul[preceding-sibling::h3//span[text()='Resources and tools']]/li")
    private List<WebElement> secondColumnLinksBorrowingHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Borrowing']]/descendant::ul[preceding-sibling::h3//span[text()='HSBC Premier']]/li")
    private List<WebElement> thirdColumnLinksBorrowingHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Borrowing']]/descendant::ul[preceding-sibling::h3//span[text()='HSBC Advance']]/li")
    private List<WebElement> fourthColumnLinksBorrowingHeader;

    /*
     * Investing & Insurance FlyerMenu - Column wise Links
     */
    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Investing & Insurance']]/descendant::ul[preceding-sibling::h3/span[text()='Investing']]/li")
    private List<WebElement> firstColumnLinksInvestingAndInsuranceHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Investing & Insurance']]/descendant::li[preceding-sibling::li//span[text()='Advice']]")
    private List<WebElement> secondColumnLinksInvestingAndInsuranceHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Investing & Insurance']]/descendant::ul[preceding-sibling::h3/span[text()='Investment products']]/li")
    private List<WebElement> thirdColumnLinksInvestingAndInsuranceHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Investing & Insurance']]/descendant::div[preceding-sibling::h3/span[text()='Retiring and Education']]/div")
    private List<WebElement> fourthColumnLinksInvestingAndInsuranceHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Investing & Insurance']]/descendant::div[preceding-sibling::h3/span[text()='HSBC Premier']]/div")
    private List<WebElement> fourthColumnHSBCPremierHeadingLinksInvestingAndInsuranceHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Investing & Insurance']]/descendant::div[preceding-sibling::h3/span[text()='HSBC Advance']]/div")
    private List<WebElement> fourthColumnHSBCAdvanceHeadingLinksInvestingAndInsuranceHeader;


    /*
     * Ways to bank FlyerMenu - Column wise Links
     */
    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Ways to bank']]/descendant::ul[preceding-sibling::h3/span[text()='Ways to bank']]/li")
    private List<WebElement> firstColumnLinksWaysToBankHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Ways to bank']]/descendant::ul[preceding-sibling::h3/span[text()='Tools']]/li")
    private List<WebElement> secondColumnLinksWaysToBankHeader;

    /*
     * -------- FOOTER LINKS --------
     *  Above Footer Links
     */
    @FindBy(xpath = "//div[contains(@class,'footerTopLine')]//li")
    private List<WebElement> aboveFooterLinks;

    /*
     * Below Footer Links list
     */
    @FindBy(xpath = "//div[@class='footer clearfix']//li")
    private List<WebElement> belowFooterLinks;

    /*
     * My banking Links list
     */
    private static final List<String> FIRST_COLUMN_LINKS_TEXT_MYBANKING = Arrays.asList("My accounts", "Global view",
        "Add or remove a country/territory", "Global Transfers", "Move money", "Pay or transfer", "Pending payments or transfers",
        "My payees", "Bill payment history", "Bank to Bank transfers");
    private static final List<String> SECOND_COLUMN_LINKS_TEXT_MYBANKING = Arrays.asList("My Rewards", "Documents",
        "My statements and other documents", "Maintain Statement / Alerts / Advices", "My documents");
    private static final List<String> THIRD_COLUMN_LINKS_TEXT_MYBANKING = Arrays.asList("Edit profile",
        "Manage my Security Device", "Help with my Security Device", "Rename accounts", "Travel notification",
        "Verify by Mastercard secure code");
    private static final List<String> FOURTH_COLUMN_LINKS_TEXT_MYBANKING = Arrays.asList("Order checkbook", "Request stop check",
        "View stop check requests");

    /*
     * Banking Links list
     */
    private static final List<String> FIRST_COLUMN_LINKS_TEXT_BANKING = Arrays.asList("Checking accounts", "Savings accounts",
        "Certificates of Deposit", "Debit cards", "Credit cards", "Overdraft Protection");
    private static final List<String> SECOND_COLUMN_LINKS_TEXT_BANKING = Arrays.asList("International account opening",
        "International Mortgages", "Global View and Global Transfers", "Wire Transfers", "International relocation");
    private static final List<String> THIRD_COLUMN_LINKS_TEXT_BANKING = Arrays.asList("View rates", "Videos and demos",
        "Banking FAQs", "Deposit products terms and charges", "How much will my savings be worth?",
        "What will it take to save for home/vehicle?", "Other financial tools");
    private static final List<String> FOURTH_COLUMN_HSBC_PREMIER_LINKS_TEXT_BANKING = Arrays.asList("Learn more");
    private static final List<String> FOURTH_COLUMN_HSBC_ADVANCE_LINKS_TEXT_BANKING = Arrays.asList("Learn more");

    /*
     * Borrowing Links list
     */
    private static final List<String> FIRST_COLUMN_LINKS_TEXT_BORROWING = Arrays.asList("Domestic mortgages", "Home equity loans",
        "International mortgages");
    private static final List<String> SECOND_COLUMN_LINKS_TEXT_BORROWING = Arrays.asList("Mortgage rates", "Home equity rates",
        "Mortgage calculators", "Mortgage FAQs", "Help for existing customers", "Videos and demos");
    private static final List<String> THIRD_COLUMN_LINKS_TEXT_BORROWING = Arrays.asList("Learn more");
    private static final List<String> FOURTH_COLUMN_LINKS_TEXT_BORROWING = Arrays.asList("Learn more");

    /*
     * Investing & Insurance Links list
     */
    private static final List<String> FIRST_COLUMN_LINKS_TEXT_INVESTMENT_AND_INSURANCE = Arrays.asList("Why invest with HSBC?",
        "Financial review", "Investing and retiring FAQs", "Important disclosures", "Compensation and Conflicts",
        "Insurance products", "Life insurance", "Long-term care coverage", "Disability insurance");
    private static final List<String> SECOND_COLUMN_LINKS_TEXT_INVESTMENT_AND_INSURANCE = Arrays.asList(
        "HSBC guide to choosing life insurance", "Life insurance FAQs", "Life insurance glossary",
        "Life insurance customer service", "Why HSBC");
    private static final List<String> THIRD_COLUMN_LINKS_TEXT_INVESTMENT_AND_INSURANCE = Arrays.asList(
        "Asset allocation solutions", "Fixed income products", "Equities and ETFs", "Structured products", "Mutual funds", "Tools",
        "Plan your retirement", "Living in retirement", "Grow your wealth", "Protect your family - Loss of life",
        "Protect your family - Loss of income", "Videos and demos", "Other financial tools");
    private static final List<String> FOURTH_COLUMN_LINKS_TEXT_INVESTMENT_AND_INSURANCE = Arrays.asList("Annuities");
    private static final List<String> FOURTH_COLUMN_HSBC_PREMIER_LINKS_TEXT_INVESTMENT_AND_INSURANCE = Arrays.asList("Learn more");
    private static final List<String> FOURTH_COLUMN_HSBC_ADVANCE_LINKS_TEXT_INVESTMENT_AND_INSURANCE = Arrays.asList("Learn more");

    /*
     * Ways to bank Links list
     */
    private static final List<String> FIRST_COLUMN_LINKS_TEXT_WAYS_TO_BANK_PREMIER = Arrays.asList("Internet Banking",
        "Report a transactional problem", "Submit a Billing Dispute", "Contact Relationship Manager", "Mobile Banking",
        "ATM Banking", "Find a branch or ATM", "Contact us", "Live Chat", "Appointment booking", "Online Guarantee", "eStatements",
        "Move money", "HSBC Security Device", "Money Management Tools", "Internet Banking FAQs", "Terms and Conditions");
    private static final List<String> FIRST_COLUMN_LINKS_TEXT_WAYS_TO_BANK = Arrays.asList("Internet Banking",
        "Report a transactional problem", "Submit a Billing Dispute", "Mobile Banking", "ATM Banking", "Find a branch or ATM",
        "Contact us", "Live Chat", "Appointment booking", "Online Guarantee", "eStatements", "Move money", "HSBC Security Device",
        "Money Management Tools", "Internet Banking FAQs", "Terms and Conditions");
    private static final List<String> SECOND_COLUMN_LINKS_TEXT_WAYS_TO_BANK = Arrays.asList("Videos and demos", "Banking FAQs",
        "Other financial tools");

    private static final List<String> ABOVE_FOOTER_LINKS_TEXT = Arrays.asList("Contact us", "Find a branch or ATM");
    private static final List<String> BELOW_FOOTER_LINKS_TEXT = Arrays.asList("Legal", "Cookie policy", "Accessibility", "Careers",
        "Security information", "HSBC Group", "�HSBC Bank plc 2015");

    public UserInterfaceRequirementDashboard(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30);
    }

    /**
     * This is to verify the Country Toggle in the Masthead on the dashboard
     */
    @Override
    public void languageToggle() {
        assertAndReportElementIsDisplayed(languageToggleText, "Country/language toggle text on Masthead is displayed",
            "Country/language toggle text on Masthead is not displayed");
    }

    /**
     * This is to verify the All the Header links for the Premier on the
     * dashboard
     */
    @Override
    public void verifyAllHeaderLinksForPremier(FlyerMenuNavigationModel navigationModel) {
        verifyMyBankingLinksHeader(navigationModel);
        verifyBankingLinksHeader(navigationModel);
        verifyBorrowingLinksHeader(navigationModel);
        verifyInvestingAndInsuranceLinksHeader(navigationModel);
        verifyWaysToBankLinksHeader(navigationModel, UserInterfaceRequirementDashboardModel.PREMIER);
    }

    /**
     * This is to verify the All the Header links for the Mass on the dashboard
     */
    public void verifyAllHeaderLinksForMass(FlyerMenuNavigationModel navigationModel) {
        verifyMyBankingLinksHeader(navigationModel);
        verifyBankingLinksHeader(navigationModel);
        verifyBorrowingLinksHeader(navigationModel);
        verifyInvestingAndInsuranceLinksHeader(navigationModel);
        verifyWaysToBankLinksHeader(navigationModel, UserInterfaceRequirementDashboardModel.MASS);
    }

    /**
     * This is to verify the All the Header links for the Advance on the
     * dashboard
     */
    public void verifyAllHeaderLinksForAdvance(FlyerMenuNavigationModel navigationModel) {
        verifyMyBankingLinksHeader(navigationModel);
        verifyBankingLinksHeader(navigationModel);
        verifyBorrowingLinksHeader(navigationModel);
        verifyInvestingAndInsuranceLinksHeader(navigationModel);
        verifyWaysToBankLinksHeader(navigationModel, UserInterfaceRequirementDashboardModel.ADVANCE);
    }

    /**
     * This is to verify All My Banking Links in Header for Premier on the
     * dashboard
     */
    private void verifyMyBankingLinksHeader(FlyerMenuNavigationModel navigationModel) {
        navigationModel.mouseOverOnMyBanking();
        super.validateAndCompareElement(firstColumnLinksMyBankingHeader, FIRST_COLUMN_LINKS_TEXT_MYBANKING,
            "My Banking Header first column");
        super.validateAndCompareElement(secondColumnLinksMyBankingHeader, SECOND_COLUMN_LINKS_TEXT_MYBANKING,
            "My Banking Header second column");
        super.validateAndCompareElement(thirdColumnLinksMyBankingHeader, THIRD_COLUMN_LINKS_TEXT_MYBANKING,
            "My Banking Header third column");
        super.validateAndCompareElement(fourthColumnLinksMyBankingHeader, FOURTH_COLUMN_LINKS_TEXT_MYBANKING,
            "My Banking Header fourth column");
    }

    /**
     * This is to verify All Banking Links in Header for Premier on the
     * dashboard
     */
    private void verifyBankingLinksHeader(FlyerMenuNavigationModel navigationModel) {
        navigationModel.mouseOverOnHeader(bankingLinkHeader);
        wait.until(ExpectedConditions.visibilityOf(navigationModel.flyerMenu));
        super.validateAndCompareElement(firstColumnLinksBankingHeader, FIRST_COLUMN_LINKS_TEXT_BANKING,
            "Banking Header first column");
        super.validateAndCompareElement(secondColumnLinksBankingHeader, SECOND_COLUMN_LINKS_TEXT_BANKING,
            "Banking Header second column");
        super.validateAndCompareElement(thirdColumnLinksBankingHeader, THIRD_COLUMN_LINKS_TEXT_BANKING,
            "Banking Header third column");
        super.validateAndCompareElement(fourthColumnHSBCPremierHeadingLinksBankingHeader,
            FOURTH_COLUMN_HSBC_PREMIER_LINKS_TEXT_BANKING, "Banking Header fourth column HSBC Premier");
        super.validateAndCompareElement(fourthColumnHSBCAdvanceHeadingLinksBankingHeader,
            FOURTH_COLUMN_HSBC_ADVANCE_LINKS_TEXT_BANKING, "Banking fourth column HSBC Advance");
    }

    /**
     * This is to verify All borrowing Links in Header for Premier on the
     * dashboard
     */
    private void verifyBorrowingLinksHeader(FlyerMenuNavigationModel navigationModel) {
        navigationModel.mouseOverOnHeader(borrowingLinkHeader);
        wait.until(ExpectedConditions.visibilityOf(navigationModel.flyerMenu));
        super.validateAndCompareElement(firstColumnLinksBorrowingHeader, FIRST_COLUMN_LINKS_TEXT_BORROWING,
            "Borrowing Header first column");
        super.validateAndCompareElement(secondColumnLinksBorrowingHeader, SECOND_COLUMN_LINKS_TEXT_BORROWING,
            "Borrowing Header second column");
        super.validateAndCompareElement(thirdColumnLinksBorrowingHeader, THIRD_COLUMN_LINKS_TEXT_BORROWING,
            "Borrowing Header third column");
        super.validateAndCompareElement(fourthColumnLinksBorrowingHeader, FOURTH_COLUMN_LINKS_TEXT_BORROWING,
            "Borrowing Header fourth column");
    }

    /**
     * This is to verify All Investing And Insurance Links in Header for
     * Premier on the dashboard
     */
    private void verifyInvestingAndInsuranceLinksHeader(FlyerMenuNavigationModel navigationModel) {
        navigationModel.mouseOverOnHeader(investingAndInsuranceLinkHeader);
        wait.until(ExpectedConditions.visibilityOf(navigationModel.flyerMenu));
        super.validateAndCompareElement(firstColumnLinksInvestingAndInsuranceHeader,
            FIRST_COLUMN_LINKS_TEXT_INVESTMENT_AND_INSURANCE, "Investing And Insurance Header first column");
        super.validateAndCompareElement(secondColumnLinksInvestingAndInsuranceHeader,
            SECOND_COLUMN_LINKS_TEXT_INVESTMENT_AND_INSURANCE, "Investing And Insurance Header second column");
        super.validateAndCompareElement(thirdColumnLinksInvestingAndInsuranceHeader,
            THIRD_COLUMN_LINKS_TEXT_INVESTMENT_AND_INSURANCE, "Investing And Insurance Header third column");
        super.validateAndCompareElement(fourthColumnLinksInvestingAndInsuranceHeader,
            FOURTH_COLUMN_LINKS_TEXT_INVESTMENT_AND_INSURANCE, "Investing And Insurance Header fourth column");
        super.validateAndCompareElement(fourthColumnHSBCPremierHeadingLinksInvestingAndInsuranceHeader,
            FOURTH_COLUMN_HSBC_PREMIER_LINKS_TEXT_INVESTMENT_AND_INSURANCE,
            "Investing And Insurance Header fourth column HSBC Premier");
        super.validateAndCompareElement(fourthColumnHSBCAdvanceHeadingLinksInvestingAndInsuranceHeader,
            FOURTH_COLUMN_HSBC_ADVANCE_LINKS_TEXT_INVESTMENT_AND_INSURANCE,
            "Investing And Insurance Header fourth column HSBC Advance");
    }

    private List<String> getFirstColumnLinksTextOfWaysToBankHeaderList(String customerSegment) {
        List<String> firstColumnLinksText;
        if (UserInterfaceRequirementDashboardModel.PREMIER.equals(customerSegment)) {
            firstColumnLinksText = FIRST_COLUMN_LINKS_TEXT_WAYS_TO_BANK_PREMIER;
        } else {
            firstColumnLinksText = FIRST_COLUMN_LINKS_TEXT_WAYS_TO_BANK;
        }
        return firstColumnLinksText;
    }

    /**
     * This is to verify All Ways to bank Links in Header for Premier on the
     * dashboard
     */
    private void verifyWaysToBankLinksHeader(FlyerMenuNavigationModel navigationModel, String customerSegment) {
        navigationModel.mouseOverOnHeader(waysToBankLinkHeader);
        wait.until(ExpectedConditions.visibilityOf(navigationModel.flyerMenu));
        super.validateAndCompareElement(firstColumnLinksWaysToBankHeader,
            getFirstColumnLinksTextOfWaysToBankHeaderList(customerSegment), "Ways to bank Header first column");
        super.validateAndCompareElement(secondColumnLinksWaysToBankHeader, SECOND_COLUMN_LINKS_TEXT_WAYS_TO_BANK,
            "Ways to bank Header second column");
    }

    /* Footer Methods */
    /**
     * This is to verify the Middle layer in the Footer on the dashboard
     */
    @Override
    public void footerLink() {
        // Do nothing because not in US
    }

    /*
     * Above footer Methods
     */
    public List<WebElement> aboveFooterLinksList() {
        return aboveFooterLinks;
    }

    public List<String> aboveFooterLinkText() {
        return ABOVE_FOOTER_LINKS_TEXT;
    }

    /*
     * Below footer Methods
     */
    @Override
    public List<WebElement> belowFooterLinksList() {
        return belowFooterLinks;
    }

    @Override
    public List<String> belowFooterLinkText() {
        return BELOW_FOOTER_LINKS_TEXT;
    }
}
