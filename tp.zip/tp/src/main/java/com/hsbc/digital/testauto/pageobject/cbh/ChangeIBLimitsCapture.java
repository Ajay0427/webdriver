/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.cbh;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.pageobject.ChangeIBLimitsCaptureModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Canada
 * entity. </b>
 * </p>
 */
public class ChangeIBLimitsCapture extends ChangeIBLimitsCaptureModel {

    @FindBy(xpath = "//button[@data-dojo-attach-point='editLimit']")
    private List<WebElement> editLinks;

    @FindBy(xpath = "//div[@data-dojo-attach-point='changeLimitsTableNode']//input[contains(@id,'CurrencyTextBox')]/following-sibling::input")
    private List<WebElement> currentLimits;

    @FindBy(xpath = "//div[@data-dojo-attach-point='changeLimitsTableNode']//input[contains(@id,'CurrencyTextBox')]")
    private List<WebElement> textFields;

    @FindBy(xpath = "//button[@class='btnSecondary' and @title='Cancel']")
    private WebElement cancelDialogYes;

    @FindBy(xpath = "//button[@class='btnTertiary' and @title=\"Don't Cancel\"]")
    private WebElement cancelDialogNo;

    @FindBy(xpath = "//*[@id='_dashboardHeading']/h1/span[text()='My New accounts']")
    private WebElement dashboardPage;

    @FindBy(xpath = "//span[contains(@id,'CurrencyTextBox_validationMessage')]")
    private List<WebElement> errorMessages;

    private static final String LIMIT_MSG = "You can set a limit between zero and your current limit.";

    public ChangeIBLimitsCapture(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }


    @Override
    public List<Double> enterLimits() {
        List<Double> newLimits = new ArrayList<>();
        for (int i = 0; i < editLinks.size(); i++) {
            editLinks.get(i).click();
            Integer currentLimit = Integer.parseInt(currentLimits.get(i).getAttribute("value"));
            String newLimit = String.valueOf(currentLimit - 1);
            textFields.get(i).clear();
            textFields.get(i).sendKeys(newLimit);
            newLimits.add(Double.parseDouble(newLimit));
        }
        Reporter.log("New limit values entered.");
        return newLimits;
    }

    @Override
    public void clickCancelButton(final boolean value) {
        wait.until(ExpectedConditions.elementToBeClickable(cancelButton));
        cancelButton.click();
        if (value) {
            cancelDialogYes.click();
            wait.until(ExpectedConditions.visibilityOf(dashboardPage));
            Reporter.log("Cancel button - Yes clicked and Dashboard page shown.");
        } else {
            cancelDialogNo.click();
            if (changeIBlimitForm.isDisplayed()) {
                Reporter.log("User is on change internet banking limits page.");
            } else {
                Reporter.log("User is not on change internet banking limits page.");
                Assert.fail();
            }
        }
    }


    @Override
    public void clickContinueButtonWithoutChange() {
        Reporter.log("Continue without changes : Not applicable in cbh");
    }

    @Override
    public void enterIncorrectLimits() {
        for (int i = 0; i < editLinks.size(); i++) {
            editLinks.get(i).click();
            textFields.get(i).clear();
            textFields.get(i).sendKeys(ChangeIBLimitsCaptureModel.INVALID_LIMIT);
        }
    }

    @Override
    public void verifyErrorMessages() {
        for (WebElement errorMessage : errorMessages) {
            if (!errorMessage.getText().contains(ChangeIBLimitsCapture.LIMIT_MSG)) {
                Assert.fail("Limit message did not matched.");
            }
        }
        Reporter.log("Error messages displayed correctly.");
    }

    @Override
    public void clickContinueButtonForValidation() {
        Reporter.log("No operation required to continue for cbh if there is validation errors.");
    }

}