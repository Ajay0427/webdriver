/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.uk;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.pageobject.QuickMoveMoneyConfirmModel;

/**
/**
 * 
 * This model class will hold locators and functionality for Quick move
 * money confirm page for UK entity. 
 * @author Vaibhav Sharma
 * @version 1.0.0
 */

public class QuickMoveMoneyConfirm extends QuickMoveMoneyConfirmModel {


    /**
     * To Account Name
     */
    @FindBy(xpath = "//div[contains(@id,'ContentPane')]//dt[contains(text(), 'To') and not(contains(@class,'accessible'))]/following::*[1]/*[1]")
    private WebElement toAccountName;

    /**
     * To Account Number
     */
    @FindBy(xpath = "//div[contains(@id,'ContentPane')]//dt[contains(text(), 'To') and not(contains(@class,'accessible'))]/following::*[1]/*[2]")
    private WebElement toAccountNumber;

    public QuickMoveMoneyConfirm(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    /**
     * This method is used to check the To Account Field
     */
    public void checkToAccount(final AccountDetails toAcctDetails) {
        Assert.assertTrue(isAccountVerified(toAcctDetails, toAccountName, toAccountNumber),
            "From Account Number is Not Same. Expected :-" + toAccountName + "," + toAccountNumber + " & Actual is :-"
                + toAccountName.getText() + "," + toAccountNumber.getText());
        Reporter.log("To Account Details :" + toAcctDetails.getAccountName() + " :: " + toAcctDetails.getAccountNumber());
    }

    /**
     * This Method is Used to Check the Reference Field NA for UK entity
     */
    public void checkReferenceNumber() {}


}
