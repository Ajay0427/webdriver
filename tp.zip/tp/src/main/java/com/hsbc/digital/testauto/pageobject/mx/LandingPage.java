/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.mx;


import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.AccountTypes;
import com.hsbc.digital.testauto.pageobject.LandingPageModel;


/**
 * <p>
 * <b> This class will hold locators and functionality related methods for
 * Account Summary and Overview story 34 & 35 specific to MX Entity </b>
 * </p>
 * 
 * @author
 * 
 */
public class LandingPage extends LandingPageModel {

    JavascriptExecutor jsx;
    WebDriverWait wait;

    // Locators for account information on Account Overview Section
    @FindBy(xpath = "//div[(contains(@id,'accountsummary') or contains(@id,'nonGSPTransaction')) and  not(contains(@class,'dijitHidden'))]//*[@data-dojo-attach-point='_dapNickname' or @data-dojo-attach-point='_title' ]")
    protected WebElement accountDescription;

    @FindBy(xpath = "//div[(contains(@id,'accountsummary') or contains(@id,'nonGSPTransaction')) and  not(contains(@class,'dijitHidden'))]//*[@data-dojo-attach-point='_dapAccountNumber' or @data-dojo-attach-point='_accountNumber' ]")
    private WebElement overviewAccountNumber;

    @FindBy(xpath = "//div[(contains(@id,'accountsummary') or contains(@id,'nonGSPTransaction')) and  not(contains(@class,'dijitHidden'))]//*[@data-dojo-attach-point='_dapCurrencyType' or @data-dojo-attach-point='_acctCcy' ]")
    private WebElement accountCurrency;

    @FindBy(xpath = "//h2[contains(@class,'accountBalance')]//span[@class='label']")
    private WebElement availableBalance;

    @FindBy(xpath = "//h2[contains(@class,'accountBalance')]//following-sibling::span[3]")
    private WebElement balanceAmount;

    @FindBy(xpath = "//*[contains(text(),'Clabe')]")
    private WebElement clabeLabel;

    @FindBy(xpath = "//*[contains(@class,'accountBalance')]//span[contains(text(),'Balance')]")
    private WebElement availableBalanceField;

    @FindBy(xpath = "//*[contains(@class,'accountBalance')]//span[contains(text(),'Credit limit')]")
    private WebElement creditLimit;

    @FindBy(xpath = "//*[contains(@class,'accountBalance')]//span[contains(text(),'Available credit')]")
    private WebElement availableCredit;

    @FindBy(xpath = "//*[contains(@class,'accountBalance')]//span[contains(text(),'Maturity date')]")
    private WebElement maturityDateLabel;

    @FindBy(xpath = "//*[contains(@class,'accountBalance')]//span[contains(text(),'Current minimum payment due')]")
    private WebElement currentMinimumPaymentDueLabel;

    @FindBy(xpath = "//*[contains(@class,'accountBalance')]//span[contains(text(),'Last statement payment due date')]")
    private WebElement lastStatementPaymentDueDateLabel;

    @FindBy(xpath = "//*[contains(@class,'accountBalance')]//span[contains(text(),'Payment to not generate interests')]")
    private WebElement paymentNotGenerateInterestsLabel;

    @FindBy(xpath = "//p[contains(@class,'dueChargeLink')]/a")
    private List<WebElement> rewardPointsLinkList;

    @FindBy(xpath = "//*[contains(@class,'accountBalance')]//span[contains(text(),'Dividends year to date')]")
    private WebElement dividentsYearToDate;

    @FindBy(xpath = "//*[contains(@class,'accountBalance')]//span[contains(text(),'Market value change amount')]")
    private WebElement marketValueChangeAmount;

    @FindBy(xpath = "//div[contains(@id,'NonGSPTransactions')]")
    private WebElement nonGSPAccountContent;

    @FindBy(xpath = "//span[@id='dapViewAcctDetlsLabel']")
    private WebElement viewAccountDetailsOrTrading;

    // Locators for account information on overview section of Mortgage account
    @FindBy(xpath = "//span[text()='Overdue interest']")
    private WebElement mortgageAccountOverdueInterest;

    @FindBy(xpath = "//span[contains(text(),'overdue payment')]")
    private WebElement mortgageAccountOverduePayment;

    @FindBy(xpath = "//span[text()='Overdue balance']")
    private WebElement mortgageAccountOverdueBalance;

    // Locators for Rename Link in details section
    @FindBy(xpath = "//a[text()='Rename Account']")
    private WebElement renameAccountLink;

    // Locators for Rename account text box in details section
    @FindBy(xpath = "//input[contains(@id,'EditNickname')]")
    private WebElement renameAccountTextBox;

    // Locators for Account Nickname in details section
    @FindBy(xpath = "//div[contains(@id,'EditNickname')]//p")
    private WebElement accountNickname;

    // Locators for Account Nickname label in details section
    @FindBy(xpath = "//dt[contains(@class,'nickname')]")
    private WebElement accountNicknameLabel;

    // Locators for links in manage section of overview
    @FindBy(xpath = "//div[contains(@id,'dapManageAccContainer')]//a")
    private List<WebElement> accountManageLinks;

    @FindBy(xpath = "//th[contains(@id,'colDate')]")
    private WebElement dateSortArrowButton;

    // xpath to get list of decription name
    @FindBy(xpath = "//div[starts-with(@id,'gridx_Grid_')]//span[contains(@class,'payeeItem')][1]")
    private List<WebElement> transactionDetailsDescription;

    // No Transaction error message
    @FindBy(xpath = "//div[@class='alertPanel error']//span[contains(text(),'no historic transactions')]")
    private WebElement errorMessageText;

    // View More button on Transaction History Widget
    @FindBy(xpath = "//button[contains(@class,'viewMoreBtn') and @aria-hidden='false']")
    private List<WebElement> viewMoreButtonList;

    @FindBy(xpath = "//div[@class='gridxSortNode' and contains(text(),'Amount')]")
    private WebElement balanceSort;

    @FindBy(xpath = "//div[@class='manageContainer']//a[text()='Stop a cheque']")
    private List<WebElement> stopChequeLinkManageMenuList;

    // Error for Invalid Account name
    @FindBy(xpath = "  //span[contains(text(),'No transactions')]")
    private WebElement errorInvalidAccountName;

    @FindBy(xpath = "//span[@id='dapMoveMoneyLabel' and @title='Move money']")
    private WebElement moveMoneyButton;

    @FindBy(xpath = "//div[@id='accountsummary']//*[contains(text(),'Pay credit card')]")
    private WebElement payCreditCardButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_reviewClearSearch']")
    private WebElement clearSearchButton;

    @FindBy(xpath = "//div[contains(@id,'accountDetails_')]//p[contains(@class,'paragraph')]")
    private WebElement disclaimerTextDetails;

    @FindBy(xpath = "//a[@id='helpIconLink']")
    private List<WebElement> helpButtonAccountOverview;

    @FindBy(xpath = "//div[contains(@id,'HelpLinkDialog')]//button[contains(@class,'btnSecondary')]")
    private WebElement cancelButtonHelpPopup;

    @FindBy(xpath = "//span[@class='countryAccount']")
    private WebElement dashboardPage;

    @FindBy(xpath = "//span[contains(@class,'itemName')]")
    private List<WebElement> accountsTypeAtDashboardPage;

    /*
     * List of Expected labels in the Details Section
     */
    private static final String[] CURRENTACCOUNT_EXPECTEDLABELS = {"Total hold", "Available balance", "Debit interest accrued",
        "VAT", "Fees + VAT"};
    private static final String[] TDACCOUNT_EXPECTEDLABELS = {"Term", "Effective Date", "Interest rate", "Interest at maturity",
        "Maturity amount", "Maturity transfer account", "Additional rate", "Total rate"};
    private static final String[] CREDITCARD_EXPECTEDLABELS = {"Minimum payment + months without interests of the period",
        "Cash withdrawal limit", "Cash withdrawal Amount available", "Payment amount to be applied",
        "Reward points to Last statement", "Rewards points expiring in the next 3 months", "Cash withdrawals Amount",
        "Payments and credits", "Information Period (From and To dates)", "Days of the period - Days in Total", "New charges",
        "Interests Amount"};
    private static final String[] LOANACCOUNT_EXPECTEDLABELS = {"Maturity date", "Next payment date", "Next balance payment",
        "Next interest payment", "Overdue balance", "Interest VAT - NEW", "Next total balance", "Original amount of loan",
        "Outstanding balance", "Loan opening date", "Current installment"};
    private static final String[] MORTGAGEACCOUNT_EXPECTEDLABELS = {"Interest VAT - NEW", "Overdue interest VAT", "Expenses",
        "Fees", "Fee VAT", "Total Overdue balance", "Current account linked", "Current installment", "Insurance amount",
        "Net financial outstanding balance", "Net overdue balance"};

    /*
     * List of Expected Links in the Manage Section
     */
    private static final String[] CURRENTACCOUNT_EXPECTEDLINKS = {"Activate new card", "Link your mobile to your account",
        "Modify or cancel mobile linked", "Activate chequebook", "Order chequebook", "Protect chequebook", "Unprotect chequebook",
        "Release cheque", "Modify cheque", "See terms and conditions", "Report a lost or stolen card"};
    private static final String[] TDACCOUNT_EXPECTEDLINKS = {"Update maturity instruction", "Open a term deposit",
        "See terms and conditions"};
    private static final String[] CREDITCARD_EXPECTEDLINKS = {"Cash Advance", "Months without interests", "Large purchases",
        "Balance installments", "Balance transfer", "Promotions and discounts", "View my points", "Redeem points",
        "Enroll to the programme", "Activate new card", "Report a lost or stolen card", "Notify us of travel",
        "Personalized credit limit", "Block / Unblock Cards", "SMS purchase alerts", "See terms and conditions"};
    private static final String[] LOANACCOUNT_EXPECTEDLINKS = {"Pay", "Future transfers and payments", "See terms and conditions"};
    private static final String[] MORTGAGEACCOUNT_EXPECTEDLINKS = {"Pay", "Future transfers and payments",
        "See terms and conditions"};
    private static final String[] INVESTMENT_EXPECTEDLINKS = {"Open an investment contract", "Operate my investment portfolio",
        "Stockmarket receipt", "See terms and conditions", "Global Asset Management", "IPC inquiry"};

    // Transaction Headers
    private static final String[] TRANSACTION_HEADERS_EXPECTED = {"Date", "Post Date", "Description", "Amount", "Balance"};

    // constants
    private static final String SCROLL_TO_VIEW = "arguments[0].scrollIntoView(true);";
    private static final String INVALID_FROMDATE = "14 02 2016";
    private static final String INVALID_TODATE = "15 02 2016";

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(LandingPage.class);

    public LandingPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30);
        jsx = (JavascriptExecutor) driver;
    }

    /**
     * Method to set account details of selected account.
     * 
     * @param account
     *            details
     * 
     */
    @Override
    public AccountDetails setAccountInfo(final String accountText) {
        AccountDetails accountDetails = new AccountDetails();
        String[] details = accountText.split("\\r?\\n");
        accountDetails.setAccountName(details[0]);
        accountDetails.setAccountNumber(details[1]);
        accountDetails.setAccountBalance(details[2]);
        accountDetails.setCurrency(details[3]);
        return accountDetails;
    }

    /**
     * Method to verify fields on account summary section.
     * 
     */
    @Override
    public void verifyAccountSummarySection() {
        isElementDisplayed(accountSummaryTitle);
        Reporter.log("Summary Section Title is displayed. ");
    }

    /**
     * Method to verify account description/type/name on account overview
     * section.
     * 
     * @param object
     *            of AccountDetails class
     */
    @Override
    public void verifyAccountDescription(final AccountDetails accountDetails) {
        jsx.executeScript(SCROLL_TO_VIEW, accountDescription);
        Assert.assertTrue(
            accountDescription.isDisplayed() && accountDetails.getAccountName().equalsIgnoreCase(accountDescription.getText()),
            "Account description not displayed and incorrect");
        Reporter.log("Account Name: " + accountDescription.getText() + " displayed and verified. ");
    }

    /**
     * Method to verify account number on account overview section.
     * 
     * @param object
     *            of AccountDetails class
     */
    @Override
    public void verifyAccountNumber(final AccountDetails accountDetails) {
        Assert.assertTrue(
            overviewAccountNumber.isDisplayed()
                && accountDetails.getAccountNumber().equalsIgnoreCase(overviewAccountNumber.getText()),
            "Account Number not displayed and incorrect");
        Reporter.log("Account Number: " + overviewAccountNumber.getText() + " displayed and verified. ");
    }

    /**
     * Method to verify account Currency on account overview section.
     * 
     * @param object
     *            of AccountDetails class
     */
    @Override
    public void verifyAccountCurrency(final AccountDetails accountDetails) {
        Assert.assertTrue(
            accountCurrency.isDisplayed() && accountDetails.getCurrency().equalsIgnoreCase(accountCurrency.getText()),
            "Account Currency not displayed");
        Reporter.log("Account Currency: " + accountCurrency.getText() + " displayed and verified. ");
    }

    /**
     * Method to verify the Brokerage Account Info
     * 
     */
    @Override
    public void verifyBrokerageAccountInfo(final AccountDetails accountDetails) {
        verifyAccountInfo(accountDetails);
        isElementDisplayed(viewAccountDetailsOrTrading);
        Reporter.log("View account details/ trading on overview section displayed.");
    }

    /**
     * Method to verify Mortgage Account Overview section.
     * 
     */
    @Override
    public void verifyMortgageAccountOverviewInfo(final AccountDetails accountDetails) {
        verifyAccountInfo(accountDetails);
        isElementDisplayed(manageButton);
        Reporter.log("Manage Button on overview section displayed. ");
        isElementDisplayed(detailsButton);
        Reporter.log("Details Button on overview section displayed. ");
    }

    /**
     * Method to verify Loan Account Overview section.
     * 
     */
    @Override
    public void verifyLoanAccountOverviewInfo(final AccountDetails accountDetails) {
        verifyAccountInfo(accountDetails);
        isElementDisplayed(manageButton);
        Reporter.log("Manage Button on overview section displayed. ");
        isElementDisplayed(detailsButton);
        Reporter.log("Details Button on overview section displayed. ");
    }

    /**
     * Method to verify Savings and Current Account Overview section.
     * 
     */
    @Override
    public void verifyAccountOverviewInfo(final AccountDetails accountDetails) {
        verifyAccountInfo(accountDetails);
        isElementDisplayed(clabeLabel);
        Reporter.log("Clabe on overview section displayed. ");
        isElementDisplayed(moveMoneyButtons.get(0));
        Reporter.log("Move Money Button on overview section displayed. ");
        isElementDisplayed(manageButton);
        Reporter.log("Manage Button on overview section displayed. ");
        isElementDisplayed(searchButton);
        Reporter.log("Search Button on overview section displayed. ");
        isElementDisplayed(detailsButton);
        Reporter.log("Details Button on overview section displayed. ");
    }

    /**
     * Method to verify account information on account overview section.
     * 
     * @param object
     *            of AccountDetails class
     */
    @Override
    public void verifyAccountInfo(final AccountDetails accountDetails) {
        verifyAccountDescription(accountDetails);
        verifyAccountNumber(accountDetails);
        verifyAccountCurrency(accountDetails);
        isBalanceDisplayed(accountDetails);
        Reporter.log("Balance on overview Page displayed. ");
        if (!transactionGrid.isEmpty()) {
            verifyTransactionHistoryWidget();
        } else {
            Reporter.log("There are no transactions performed for this account. ");
        }

    }

    /**
     * To verify the Transaction Header Column Names and the View more button
     */
    @Override
    public void verifyTransactionHistoryWidget() {
        if (!transactionTableHeaders.isEmpty()) {
            verifyFields(Arrays.asList(TRANSACTION_HEADERS_EXPECTED), transactionTableHeaders);
        }
        if (dateColumnAll.size() > 5) {
            verifyViewMoreFunctionality(dateColumnAll.size());
        } else if (dateColumnAll.size() < 5) {
            Assert.assertTrue(viewMoreButtonList.isEmpty(), "View More Button is Displayed");
            Reporter.log("Transactions in history are less then 5. Hence, View More button is not displayed. ");
        }

    }

    @Override
    public void verifyViewMoreFunctionality(final int size) {
        isElementDisplayed(viewMoreButtonList.get(0));
        Reporter.log("View more button is displayed. ");
        while (!viewMoreButtonList.isEmpty()) {
            viewMoreButtonList.get(0).click();
        }
        if (dateColumnAll.size() > size) {
            Reporter.log("More Transactions are displayed. View More Button Functionality is working");
        }
    }

    @Override
    public void verifyTDManageLinks() {
        manageButton.click();
        Reporter.log("Manage Button Clicked. ");
        verifyFields(Arrays.asList(TDACCOUNT_EXPECTEDLINKS), accountManageLinks);
    }


    @Override
    public void verifyMortgageManageLinks() {
        manageButton.click();
        Reporter.log("Manage Button Clicked. ");
        verifyFields(Arrays.asList(MORTGAGEACCOUNT_EXPECTEDLINKS), accountManageLinks);
    }

    @Override
    public void verifyInvestmentManageLinks() {
        manageButton.click();
        Reporter.log("Manage Button Clicked. ");
        verifyFields(Arrays.asList(INVESTMENT_EXPECTEDLINKS), accountManageLinks);
    }

    @Override
    public void verifyCreditCardManageLinks() {
        manageButton.click();
        Reporter.log("Manage Button Clicked. ");
        verifyFields(Arrays.asList(CREDITCARD_EXPECTEDLINKS), accountManageLinks);
    }

    @Override
    public void verifyLoanManageLinks() {
        manageButton.click();
        Reporter.log("Manage Button Clicked. ");
        verifyFields(Arrays.asList(LOANACCOUNT_EXPECTEDLINKS), accountManageLinks);
    }

    @Override
    public void verifyCurrentManageLinks() {
        manageButton.click();
        Reporter.log("Manage Button Clicked. ");
        verifyFields(Arrays.asList(CURRENTACCOUNT_EXPECTEDLINKS), accountManageLinks);
    }

    /**
     * Method to verify TD Account Overview section.
     * 
     * @param accountDetails
     */
    @Override
    public void verifyTDAccountOverviewInfo(final AccountDetails accountDetails) {
        verifyAccountInfo(accountDetails);
        isElementDisplayed(maturityDateLabel);
        Reporter.log("Maturity date on overview section displayed. ");
        isElementDisplayed(manageButton);
        Reporter.log("Manage Button on overview section displayed. ");
        isElementDisplayed(detailsButton);
        Reporter.log("Details Button on overview section displayed. ");
    }

    /**
     * Method to verify Investment Account Overview section
     * 
     * @param accountDetails
     */
    @Override
    public void verifyInvestmentAccountOverviewInfo(final AccountDetails accountDetails) {
        verifyAccountInfo(accountDetails);
        isElementDisplayed(dividentsYearToDate);
        Reporter.log("Dividends year to date on overview section displayed. ");
        isElementDisplayed(marketValueChangeAmount);
        Reporter.log("Market value change amount on overview section displayed. ");
    }

    /**
     * Method to verify Credit card Account Overview section.
     */
    @Override
    public void verifyCreditCardAccountOverviewInfo(final AccountDetails accountDetails) {
        verifyAccountInfo(accountDetails);
        isElementDisplayed(creditLimit);
        Reporter.log("Credit Limit on overview section displayed. ");
        isElementDisplayed(availableCredit);
        Reporter.log("Available Credit on overview section displayed. ");
        isElementDisplayed(currentMinimumPaymentDueLabel);
        Reporter.log("Current minimum payment due on overview section displayed. ");
        isElementDisplayed(lastStatementPaymentDueDateLabel);
        Reporter.log("Last statement payment due date on overview section displayed. ");
        isElementDisplayed(paymentNotGenerateInterestsLabel);
        Reporter.log("Payment to not generate interests on overview section displayed. ");
        // TODO: No link displayed, Need confirmation
        /*
         * isRewardPointsLinkDisplayed; Reporter.log(
         * "Premier Reward Points link on overview section displayed. ");
         */
        isElementDisplayed(payCreditCardButton);
        Reporter.log("Pay credit card Button on overview section displayed. ");
        isElementDisplayed(manageButton);
        Reporter.log("Manage Button on overview section displayed. ");
        isElementDisplayed(searchButton);
        Reporter.log("Search Button on overview section displayed. ");
        isElementDisplayed(detailsButton);
        Reporter.log("Details Button on overview section displayed. ");
    }

    /**
     * Method to verify Move money button on account overview section.
     * 
     * @param accountDetails
     * 
     */
    @Override
    public void verifyMoveMoneyNavigation(final AccountDetails accountDetails) {
        AccountTypes accountTypes = checkAccountType(accountDetails);
        if (!(accountTypes.equals(AccountTypes.BROKERAGE) || accountTypes.equals(AccountTypes.LOAN) || accountTypes
            .equals(AccountTypes.INVESTMENT))) {
            if (!moveMoneyButtons.isEmpty()) {
                clickElement(moveMoneyButtons.get(0));
                Reporter.log("Move Money Button is clicked. ");
                clickElement(primaryTransactionCancelButton);
                Reporter.log("New Transaction Cancel Button is clicked. ");
                clickElement(secondaryTransactionCancelButton);
                Reporter.log("Transaction Cancel Button is clicked to return to 'My Accounts' page. ");
            } else {
                Assert.fail("Move Money button not Displayed");
            }
        } else {
            if (moveMoneyButtons.isEmpty()) {
                Reporter.log("Selected Account does not support Move Money navigation. Hence Button is hidden");
            } else {
                Assert.fail("Selected Account does not support Move Money navigation. Still Move Money button Displayed");
            }
        }
    }

    /**
     * Verify the disclaimer displayed in the details section
     */
    @Override
    public void verifyDisclaimerDisplayedInDetailsSection() {
        // TODO Currently disclaimer is not displayed, Need confirmation
        /*
         * Assert.assertTrue(disclaimerTextDetails.isDisplayed,
         * "Disclaimer is not displayed in the Details Section.");
         * Reporter.log("Disclaimer is displayed. Message is: " +
         * disclaimerTextDetails.getText());
         */
    }

    /**
     * Method to verify Details section.
     * 
     */
    @Override
    public void verifyCurrentAccountDetails() {
        verifyFields(Arrays.asList(CURRENTACCOUNT_EXPECTEDLABELS), detailsLabels);
    }

    @Override
    public void verifyCreditCardDetails() {
        verifyFields(Arrays.asList(CREDITCARD_EXPECTEDLABELS), detailsLabels);
    }

    @Override
    public void verifyTDAccountDetails() {
        verifyFields(Arrays.asList(TDACCOUNT_EXPECTEDLABELS), detailsLabels);
    }

    @Override
    public void verifyMortgageAccountDetails() {
        verifyFields(Arrays.asList(MORTGAGEACCOUNT_EXPECTEDLABELS), detailsLabels);
    }

    @Override
    public void verifyLoanAccountDetails() {
        verifyFields(Arrays.asList(LOANACCOUNT_EXPECTEDLABELS), detailsLabels);
    }

    /**
     * Method to verify fields in details section.
     * 
     * @param expectedLabels
     */
    @Override
    public void verifyFields(final List<String> expectedLabels, final List<WebElement> actualLabelList) {
        List<String> actualLabels = new ArrayList<>();
        for (WebElement actualLabel : actualLabelList) {
            if (!actualLabel.getText().trim().isEmpty()) {
                actualLabels.add(actualLabel.getText());
            }
        }
        if (expectedLabels.size() == actualLabels.size() && expectedLabels.containsAll(actualLabels)) {
            Reporter.log("Field labels are displayed as expected: " + expectedLabels);
        } else {
            Reporter.log("There is a mismatch in the Expected and Actual List in the section.");
            Reporter.log("The number of fields in the Expected List: " + expectedLabels.size());
            Reporter.log("The number of fields in the Actual List: " + actualLabels.size());
            Reporter.log("The Expected List: " + expectedLabels);
            Reporter.log("The Actual List: " + actualLabels);
            Assert.fail("Mismatch in Labels in Section");
        }
    }

    /**
     * Method to verify Print button on account overview section.
     * 
     * @param object
     *            of AccountDetails class
     */
    @Override
    public void verifyAccountOverviewPrint(final AccountDetails accountDetails) {
        AccountTypes accountTypes = checkAccountType(accountDetails);
        if (!accountTypes.equals(AccountTypes.BROKERAGE)) {
            verifyAccountOverviewPrintPreviewPage(accountDetails);
        } else {
            Reporter.log("Selected Account is Brokerage Account and Print Option is not avialable.");
        }
    }

    /**
     * Method to verify Available Balance on account overview section.
     * 
     */
    @Override
    public void isBalanceDisplayed(final AccountDetails accountDetails) {
        Assert.assertTrue(
            availableBalance.isDisplayed() && accountDetails.getAccountBalance().equalsIgnoreCase(balanceAmount.getText()),
            "Account balance not displayed and incorrect");
        Reporter.log("Account balance: " + balanceAmount.getText() + " displayed and verified. ");
    }

    /**
     * Method to verify Premier Reward Points on account overview section.
     */
    public void isRewardPointsLinkDisplayed() {
        if (!rewardPointsLinkList.isEmpty()) {
            Assert.assertTrue(rewardPointsLinkList.get(0).isDisplayed(), "Premier Reward Points Link is not displayed");
            Assert.assertTrue(rewardPointsLinkList.get(0).isEnabled(), "Premier Reward Points Link is not enabled");
            Reporter.log(rewardPointsLinkList.get(0).getText() + "is dispalyed and enabled");
        } else {
            Reporter.log("Rewards Point link is not  dispalyed and enabled");
        }
    }


    /**
     * Method to enter nickname in details section.
     * 
     * 
     */
    public void enterNickname() {
        int maxlength = Integer.parseInt(renameAccountTextBox.getAttribute("maxlength"));
        String randomText = RandomUtil.generateAlphaNumericText(maxlength);
        renameAccountTextBox.clear();
        renameAccountTextBox.sendKeys(randomText);
        renameAccountTextBox.click();
        accountNicknameLabel.click();
    }

    /**
     * Method to verify if nickname is updated in overview section
     * 
     */
    public void verifyAccountNickname() {
        Assert.assertTrue(accountDescription.getText().equals(accountNickname.getText()), "nickname not updated");
        Reporter.log("Nickname updated properly. ");
        renameAccountLink.click();
        renameAccountTextBox.clear();
        renameAccountTextBox.click();
        accountNicknameLabel.click();
    }

    /**
     * Method to verify Print button on Account Summary section.
     * 
     */
    @Override
    public void verifyAccountSummaryPrint() {
        int size = accountsLists.size();
        accountSummaryPrintButton.click();
        Reporter.log("Print Button is clicked");
        verifyAccountSummaryPrintPreviewDetails(size);
        verifyAccountSummaryPrintPreviewPage();
    }


    @Override
    public void verifyOrderOfAccounts() {
        List<Integer> actualAccountOrderList = new ArrayList<>();
        Map<String, String> actualAccountDetailsMap = new LinkedHashMap<>();
        Map<String, ArrayList<String>> accountNumbersSortedMap = new LinkedHashMap<>();
        Map<String, ArrayList<String>> productCodeSortedMap = new LinkedHashMap<>();

        for (WebElement account : accountsLists) {
            AccountDetails accDetail = new AccountDetails();
            jsx.executeScript(SCROLL_TO_VIEW, account);
            storeProductCode(accDetail, account);
            String accountType = accDetail.getProductCode();
            String accountNumber = accDetail.getAccountNumber();
            AccountTypes accountTypes = checkAccountType(accDetail);
            switch (accountTypes) {
            case CURRENT:
                actualAccountOrderList.add(1);
                break;
            case TERMDEPOSIT:
                actualAccountOrderList.add(2);
                break;
            case INVESTMENT:
                actualAccountOrderList.add(3);
                break;
            case CREDIT:
                actualAccountOrderList.add(4);
                break;
            case LOAN:
                actualAccountOrderList.add(5);
                break;
            case MORTGAGE:
                actualAccountOrderList.add(6);
                break;
            case EMPRE:
                actualAccountOrderList.add(7);
                break;
            default:
                actualAccountOrderList.add(8);
                break;
            }
            actualAccountDetailsMap.put(accountNumber, accountTypes.toString() + "#" + accountType);
        }

        Assert.assertTrue(isSorted(actualAccountOrderList), "Account Summary List was not sorted as per product type");
        Reporter.log("Account Summary List is sorted as per Product Type");

        Iterator<Entry<String, String>> actualAccountDetailsMapIterator = actualAccountDetailsMap.entrySet().iterator();
        while (actualAccountDetailsMapIterator.hasNext()) {
            Map.Entry<String, String> tempMap = actualAccountDetailsMapIterator.next();
            ArrayList<String> accountNumbersTempList;
            ArrayList<String> productCodesTempList;

            String[] accountDetailsList = tempMap.getValue().split("#");
            String accountType = accountDetailsList[0];

            if (accountNumbersSortedMap.containsKey(tempMap.getValue())) {
                accountNumbersTempList = accountNumbersSortedMap.get(tempMap.getValue());
                accountNumbersTempList.add(tempMap.getKey());
                Collections.sort(accountNumbersTempList);
            } else {
                accountNumbersTempList = new ArrayList<>();
                accountNumbersTempList.add(tempMap.getKey());
                accountNumbersSortedMap.put(tempMap.getValue(), accountNumbersTempList);
            }

            if (productCodeSortedMap.containsKey(accountType)) {
                productCodesTempList = productCodeSortedMap.get(accountType);
                productCodesTempList.add(accountDetailsList[1]);
                Collections.sort(productCodesTempList);
            } else {
                productCodesTempList = new ArrayList<>();
                productCodesTempList.add(accountDetailsList[1]);
                productCodeSortedMap.put(accountType, productCodesTempList);
            }
        }

        Iterator<Entry<String, ArrayList<String>>> productCodeSortedMapIterator = productCodeSortedMap.entrySet().iterator();
        actualAccountDetailsMapIterator = actualAccountDetailsMap.entrySet().iterator();
        while (productCodeSortedMapIterator.hasNext()) {
            ArrayList<String> list;
            Map.Entry<String, ArrayList<String>> mesorted = productCodeSortedMapIterator.next();
            list = mesorted.getValue();
            for (int i = 0; i < list.size(); i++) {
                Map.Entry<String, String> mesorte = actualAccountDetailsMapIterator.next();
                String actualValue = mesorted.getKey() + "#" + list.get(i);
                String expectedValue = mesorte.getValue();
                Assert.assertTrue(actualValue.equals(expectedValue), "Account Summary List was not sorted as per Product Code");
            }
        }
        Reporter.log("Account Summary List is sorted as per Product Code");

        Map<String, String> expectedAccountDetailsMap = new LinkedHashMap<>();
        Iterator<Entry<String, ArrayList<String>>> accountNumbersSortedMapIterator = accountNumbersSortedMap.entrySet().iterator();
        while (accountNumbersSortedMapIterator.hasNext()) {
            ArrayList<String> accountNumberTempList;
            Map.Entry<String, ArrayList<String>> tempNext = accountNumbersSortedMapIterator.next();
            accountNumberTempList = tempNext.getValue();
            for (int i = 0; i < accountNumberTempList.size(); i++) {
                expectedAccountDetailsMap.put(accountNumberTempList.get(i), tempNext.getKey());
            }
        }
        boolean isSorted = equalMaps(actualAccountDetailsMap, expectedAccountDetailsMap);
        Assert.assertTrue(isSorted, "Account Summary List was not sorted as per Account Number");
        Reporter.log("Account Summary List is sorted as per Account Number");
    }

    @Override
    public boolean equalMaps(final Map<String, String> actualMap, final Map<String, String> expectedMap) {
        if (actualMap.size() != expectedMap.size()) {
            return false;
        }
        Iterator<Entry<String, String>> actualMapIterator = actualMap.entrySet().iterator();
        Iterator<Entry<String, String>> expectedMapIterator = expectedMap.entrySet().iterator();
        while (actualMapIterator.hasNext() && expectedMapIterator.hasNext()) {
            Map.Entry<String, String> actualMapTemp = actualMapIterator.next();
            Map.Entry<String, String> expectedMapTemp = expectedMapIterator.next();
            if (!actualMapTemp.getKey().equals(expectedMapTemp.getKey())) {
                return false;
            }
        }
        return true;
    }

    @Override
    public boolean isSorted(final List<Integer> list) {
        boolean sorted = true;
        for (int i = 1; i < list.size(); i++) {
            if (list.get(i).compareTo(list.get(i - 1)) < 0) {
                return false;
            }
        }
        return sorted;
    }

    @Override
    public void verifyTransactionHistoryInDateRage(final String fromDate, final String toDate) {
        super.checkTransactionAvailability();
        try {
            Date dateFromDate = DateUtil.getStringToDate(getInputDateFormat(), fromDate);
            Date dateToDate = DateUtil.getStringToDate(getInputDateFormat(), toDate);
            super.checkDateBetweenRange(super.getDisplayDateFormat(), dateFromDate, dateToDate);
        } catch (ParseException e) {
            LandingPage.logger.error("Date parsing Exception for verifyTransactionHistoryInDateRage", e);
            Assert.fail("Date parsing Exception for verifyTransactionHistoryInDateRage", e);
        }
    }

    /**
     * This method is to sort the transactions by date
     */
    @Override
    public boolean dateSorting() {
        boolean flag = false;
        try {
            List<Date> beforeSort = new ArrayList<>();
            for (WebElement element : super.dateColumnAll) {
                beforeSort.add(DateUtil.getStringToDate(DateUtil.DATE_FORMAT_DDMMMYYYY, element.getText()));
            }
            Collections.sort(beforeSort);
            dateSortArrowButton.click();
            Reporter.log("Clicked on Date column for sort.");
            List<Date> afterSort = new ArrayList<>();
            for (WebElement element : super.dateColumnAll) {
                jsx.executeScript(SCROLL_TO_VIEW, element);
                afterSort.add(DateUtil.getStringToDate(DateUtil.DATE_FORMAT_DDMMMYYYY, element.getText()));
            }
            Iterator<Date> targetIt = beforeSort.iterator();
            for (Date uiSortedDate : afterSort) {
                if (uiSortedDate.equals(targetIt.next())) {
                    flag = true;
                }
            }
        } catch (ParseException e) {
            LandingPage.logger.error("Date Format Conversion Error: ", e);
            Assert.fail("Date Format Conversion Error." + e);
        }
        return flag;
    }

    /**
     * Compare results by name
     * 
     */
    @Override
    public void compareResultByName(final String expectedName) {
        super.checkTransactionAvailability();
        while (true) {
            for (WebElement eachTransaction : transactionDetailsDescription) {
                jsx.executeScript(SCROLL_TO_VIEW, eachTransaction);
                Assert.assertTrue(eachTransaction.getText().contains(expectedName), "Expected name: " + expectedName
                    + " Actual name: " + eachTransaction.getText());
            }
            if (!viewMoreButtonList.isEmpty() && viewMoreButtonList.get(0).isDisplayed()) {
                viewMoreButtonList.get(0).click();
            } else {
                break;
            }
        }
        Reporter.log("As expected historic transactions are displayed by account name filter");
    }

    @Override
    public void compareResultAmount(final int fromAmt, final int toAmt) {
        super.checkTransactionAvailability();
        while (true) {
            for (WebElement amountValue : super.transactionDetailsListAmountCol) {
                jsx.executeScript(SCROLL_TO_VIEW, amountValue);
                String amountValueString = amountValue.getText();
                Double actualAmount = Double.valueOf(amountValueString.replace("-", "").replace(",", ""));
                Assert.assertTrue(actualAmount >= fromAmt && actualAmount <= toAmt, "Amount: " + actualAmount
                    + " shown doesn't lie between + " + fromAmt + " and " + toAmt);
            }
            if (!viewMoreButtonList.isEmpty() && viewMoreButtonList.get(0).isDisplayed()) {
                viewMoreButtonList.get(0).click();
            } else {
                break;
            }
        }
        Reporter.log("Amounts present lie between " + fromAmt + " and " + toAmt + " range. ");
    }

    @Override
    public void verifyPrintButtonOnPopup() {
        Assert.assertTrue(accountOverviewPreviewPrintButton.isDisplayed(), "Print button is not displayed on popup. ");
        Reporter.log("Print Popup shown. | ");
        accountOverviewPreviewPrintButton.click();
        Reporter.log("Print button clicked in Popup. | ");
        if (driver.getWindowHandles().size() > 1) {
            Reporter.log("Print preview Popup shown. | ");
        }
    }

    @Override
    public void verifyErrorMessageForInvalidDetails() {
        errorMessageText.isDisplayed();
        Reporter.log("\"No Transaction Error message\" is displayed. Error message is: " + errorMessageText.getText());
    }

    /**
     * Method to verify Transaction are sorted by Amount
     */
    @Override
    public boolean sortAmount() {
        boolean flag = true;
        List<Double> expectedAmount = new ArrayList<>();
        for (WebElement element : super.amountColAll) {
            String amount = element.getText();
            if (element.getText().contains(",")) {
                amount = amount.replace(",", "");
            }
            expectedAmount.add(Double.parseDouble(amount));
        }
        Collections.sort(expectedAmount);
        Iterator<Double> iteratorExpected = expectedAmount.iterator();
        getBalanceSort().click();
        Reporter.log("Click on Amount column for sort");
        for (WebElement element : super.amountColAll) {
            String amount = element.getText();
            if (element.getText().contains(",")) {
                amount = amount.replace(",", "");
            }
            if (!iteratorExpected.next().equals(Double.parseDouble(amount))) {
                flag = false;
                break;
            }
        }
        return flag;
    }

    /**
     * Method to verify Transactions are sorted by Description .
     */
    @Override
    public boolean sortDescriptions() {
        boolean flag = true;
        List<String> expecteddescription = new ArrayList<>();
        for (WebElement element : super.descriptionColumnAll) {
            expecteddescription.add(element.getText());
        }
        Collections.sort(expecteddescription);
        Iterator<String> iteratorExpected = expecteddescription.iterator();
        super.descriptionSort.click();//
        Reporter.log("Click on Description column for sort");
        for (WebElement element : super.descriptionColumnAll) {
            if (!iteratorExpected.next().equalsIgnoreCase(element.getText())) {
                flag = false;
                break;
            }
        }
        return flag;
    }

    /**
     * Method to get web element.
     */
    @Override
    public WebElement getBalanceSort() {
        return balanceSort;
    }

    @Override
    public boolean isStopChequeLinkPresent() {
        return !stopChequeLinkManageMenuList.isEmpty();
    }

    @Override
    public void clickStopChequeLink() {
        stopChequeLinkManageMenuList.get(0).click();
    }

    /**
     * Method to get invalidFromDate as String.
     */
    @Override
    public String getInvalidFromDate() {
        return INVALID_FROMDATE;
    }

    /**
     * Method to get invalidToDate as String.
     */
    @Override
    public String getInvalidToDate() {
        return INVALID_TODATE;
    }

    /**
     * Method to verify No transaction message for invalid Account Name
     */
    @Override
    public void verifyErrorForInvalidAccountName() {
        Assert.assertTrue(errorInvalidAccountName.isDisplayed(), "Transactions displayed for invalid account. ");
        String errorMessage = errorInvalidAccountName.getText();
        Reporter.log("Error is displayed as :" + errorMessage);
    }

    @Override
    protected WebElement getMoveMoneyButton() {
        return moveMoneyButton;
    }

    @Override
    public void verifyVisibilityOfViewMoreButton() {
        if (descriptionColumnAll.size() < 5) {
            Assert.assertTrue(viewMoreButtonList.isEmpty(), "View More button is visible for less transaction");
            Reporter.log("View More button is not visible");
        } else {
            if (!viewMoreButtonList.isEmpty() && viewMoreButtonList.get(0).isDisplayed()) {
                viewMoreButtonList.get(0).click();
                Assert.assertTrue(descriptionColumnAll.size() > 5,
                    "View More button displayed even if the transactions are not more than 5");
                Reporter.log("As Expected View More button displayed. | ");
            } else {
                Reporter.log("As Expected View More button not displayed. | ");
            }
        }
    }

    @Override
    public void verifyClearSearchButton(final List<String> transactionsList) {
        Assert.assertTrue(clearSearchButton.isDisplayed(), "Clear Search button is not present");
        clearSearchButton.click();
        Reporter.log("Clear Search button clicked");
        defaultOrderCheck();
        List<String> transactionListAfterClear = super.transactionsList();
        if (super.transactionsList().size() <= 5 && transactionsList.equals(transactionListAfterClear)) {
            Reporter.log("\"Clear Search\" button functionality working properly. | ");
        }
    }

    @Override
    public void verifyHelpIconLink() {
        // TODO: Currently help is not displayed in Application, Need
        // confirmation
        /*
         * Assert.assertTrue(helpButtonAccountOverview.get(0).isDisplayed,
         * "helpIconLink is not present. | ");
         * Reporter.log("\'help Icon Link\' is present. | ");
         */
    }

    @Override
    public void validateDisclaimerText() {
        // TODO : enter code once functionality is present
    }

    @Override
    public void selectFileFormatToDownload() {
        Assert.assertTrue(super.radioCSV.isDisplayed(), "Option to download file in csv format not displayed. ");
        Reporter.log("CSV format is selected for downloading. | ");
    }

    @Override
    protected void verifyDownloadChoiceWindow() {
        if (driver.getWindowHandles().size() > 1) {
            Reporter.log("Download choice window shown. | ");
        }
    }

    @Override
    public AccountTypes checkAccountType(final AccountDetails accountDetails) {
        String productCode = productCodes.get(accountDetails.getProductCode());
        if (productCode.equalsIgnoreCase("Saving/Checking")) {
            return AccountTypes.CURRENT;
        } else if (productCode.equalsIgnoreCase("CC")) {
            return AccountTypes.CREDIT;
        } else if (productCode.equalsIgnoreCase("TD")) {
            return AccountTypes.TERMDEPOSIT;
        } else if (productCode.equalsIgnoreCase("INV")) {
            return AccountTypes.INVESTMENT;
        } else if (productCode.equalsIgnoreCase("COMER")) {
            return AccountTypes.LOAN;
        } else if (productCode.equalsIgnoreCase("EMPRE")) {
            return AccountTypes.EMPRE;
        } else if (productCode.equalsIgnoreCase("HIPOT")) {
            return AccountTypes.MORTGAGE;
        } else {
            Assert.fail("Account Selected does not match any criteria in product mapping.");
        }
        return null;
    }

    @Override
    public void storeProductCode(AccountDetails accountDetails, WebElement account) {
        String accountNumber = account.getText().split("\\r?\\n")[1];
        String uniqueAccountNumber = account.getAttribute("unique-account-number");
        String productCode = uniqueAccountNumber.split("\\|\\|")[2];
        Assert.assertTrue(!productCode.isEmpty(), "Product Code attribute is not found.");
        accountDetails.setProductCode(productCode);
        accountDetails.setAccountNumber(accountNumber);
    }

    /*
     * *************** Overridden Methods for TransactionHistory and Smart
     * Search ****************
     */

    @Override
    protected String getInputDateFormat() {
        return DateUtil.DATE_FORMAT_DDMMYYYY;
    }

    @Override
    public void validateNewAccount(String newAccountNumber) {
        wait.until(ExpectedConditions.visibilityOf(dashboardPage));
        Reporter.log("Dashboard page shown. | ");
        boolean flag = false;
        for (WebElement accountRow : accountsTypeAtDashboardPage) {
            jsx.executeScript(SCROLL_TO_VIEW, accountRow);
            if (newAccountNumber.equals(accountRow.getText())) {
                Reporter.log("New Account present on Landing page. | ");
                flag = true;
                break;
            }
        }
        if (!flag) {
            Assert.fail("New Account not present on Landing page. | ");
        }
    }

    @Override
    public String getToDate() throws ParseException {
        return DateUtil.getDateToString(getInputDateFormat(),
            DateUtil.getStringToDate(getDisplayDateFormat(), dateColumnAll.get(dateColumnAll.size() - 1).getText()));
    }

    @Override
    public String getFromDate() throws ParseException {
        return DateUtil.getDateToString(getInputDateFormat(),
            DateUtil.getStringToDate(getDisplayDateFormat(), dateColumnAll.get(0).getText()));
    }

    /**
     * This is to check the default order of the date in the list
     * 
     */
    @Override
    public void defaultOrderCheck() {
        for (int eachDate = 0; eachDate < dateColumnAll.size() - 1; eachDate++) {
            String firstDateDisplayed = dateColumnAll.get(eachDate).getText();
            String nextDateDisplayed = dateColumnAll.get(eachDate + 1).getText();
            try {
                Date firstDate = DateUtil.getStringToDate(getDisplayDateFormat(), firstDateDisplayed);
                Date nextDate = DateUtil.getStringToDate(getDisplayDateFormat(), nextDateDisplayed);
                if (firstDate.before(nextDate) || firstDate.equals(nextDate)) {
                    Reporter.log("Transactions History Displayed in correct Order. | ");
                } else {
                    Assert.fail("Transactions History Displayed is not in correct Order. ");
                }
            } catch (ParseException e) {
                LandingPage.logger.error("Date Format Conversion Error: ", e);
                Assert.fail("Date Format Conversion Error.", e);
            }
        }
    }

    @Override
    public void selectAccountOnDashboardByNameAndNumber(final AccountDetails accountDetail) {
        wait.until(ExpectedConditions.visibilityOf(leftHandMenuMyAccount));
        String xpathAccountNumber = "//span[@class='itemName tiny' and text()=" + accountDetail.getAccountNumber() + "]";
        List<WebElement> lists = driver.findElements(By.xpath(xpathAccountNumber));
        for (WebElement list : lists) {
            jsx.executeScript("arguments[0].scrollIntoView(true);", list);
            if (list.getText().contains(accountDetail.getAccountNumber())) {
                list.click();
                break;
            }
        }
    }


}
