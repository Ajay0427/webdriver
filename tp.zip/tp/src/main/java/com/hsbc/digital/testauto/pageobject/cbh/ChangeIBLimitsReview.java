/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.cbh;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.pageobject.ChangeIBLimitsReviewModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for CBH
 * (Srilanka) entity. </b>
 * </p>
 */

public class ChangeIBLimitsReview extends ChangeIBLimitsReviewModel {

    @FindBy(xpath = "//div[contains(@id,'VerifyBankingLimits')]//span[@data-dojo-attach-point='limitNode']")
    private List<WebElement> updatedDailyLimits;

    @FindBy(xpath = "//input[@data-dojo-attach-point='submitBtn']")
    private WebElement confirmButton;

    @FindBy(xpath = "//input[@name='reauthSecurityCode']")
    private WebElement reauthCodeText;

    @FindBy(xpath = "//input[@data-dojo-attach-point='cancelBtn']")
    private WebElement cancelButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='editLimit']")
    private List<WebElement> reviewPageEditLinks;

    @FindBy(xpath = "//h2[@data-dojo-attach-point='dapPageTitle']")
    private WebElement reviewPageTitle;

    private static final String REVIEW_PAGE_TITLE = "Verify";

    public ChangeIBLimitsReview(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }


    public void validateAndConfirm(final List<Double> newDailyLimits) {
        List<Double> updatedLimits = new ArrayList<>();
        for (int i = 0; i < updatedDailyLimits.size(); i++) {
            String updatedLimitValue = updatedDailyLimits.get(i).getText().replace(",", "");
            updatedLimits.add(Double.parseDouble(updatedLimitValue));
        }
        Assert.assertTrue(updatedLimits.containsAll(newDailyLimits), "Values are not equal");
        Reporter.log("Daily limits are updated correctly.");
        wait.until(ExpectedConditions.elementToBeClickable(confirmButton));
        confirmButton.click();
        Reporter.log("Values verified and Confirm button clicked on verify page.");
    }

    public void enterReauthCode(final Map<String, String> profileProperties) throws IOException {
        /*String code = tokenGenerator.generateReauthCode(profileProperties.get("userName"), profileProperties.get("serialNumber"),
            profileProperties.get("otpKey"));
        reauthCodeText.sendKeys(code);*/
    }

    public void clickCancelButton(final boolean value) {
        wait.until(ExpectedConditions.elementToBeClickable(cancelButton));
        cancelButton.click();
        if (value) {
            cancelDialogYes.click();
            if (!reviewPageEditLinks.isEmpty() && reviewPageEditLinks.get(0).isDisplayed()) {
                Reporter.log("Cancel with Yes button clicked and Dashboard page shown.");
            }
        } else {
            cancelDialogNo.click();
            if (reviewPageTitle.isDisplayed() && reviewPageTitle.getText().equals(ChangeIBLimitsReview.REVIEW_PAGE_TITLE)) {
                Reporter.log("Cancel with No button clicked and review page shown.");
            } else {
                Assert.fail("Review page not displayed");
            }
        }
    }
}
