/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hsbc.digital.testauto.ui.library.UICommonUtil;

/**
 * <p>
 * <b> This model class will hold locators and functionality for Verified by
 * Visa story (UK).</b>
 * </p>
 * 
 * @author Neha Rajesh Gupta
 * @version 1.0.0
 */
public abstract class VerifiedByVisaModel {

    protected final WebDriver driver;
    protected final WebDriverWait wait;
    UICommonUtil uicommonUtil;


    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(VerifiedByVisaModel.class);


    public VerifiedByVisaModel(final WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, 30);
        uicommonUtil = new UICommonUtil(driver);
        PageFactory.initElements(driver, this);

    }


}
