/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.cbh;

import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

import com.hsbc.digital.testauto.models.StopChequeDetails;
import com.hsbc.digital.testauto.pageobject.StopChequeCapturePageModel;

/**
 * <p>
 * <b> Stop Cheque Capture page object model to hold generic function and
 * locators for cbh entity of story stop cheque</b>
 * </p>
 * 
 * @version 1.0.0
 * @author Neeraj Kumar
 */
public class StopChequeCapturePage extends StopChequeCapturePageModel {

    @FindBy(xpath = "//input[contains(@id, 'chequeTypeRange') and contains(@type, 'radio')]")
    private WebElement chequeTypeRange;

    @Override
    protected WebElement getChequeTypeRange() {
        return chequeTypeRange;
    }

    @FindBy(xpath = "//table[contains(@id, 'Select')]//input[contains(@id, 'Select') and contains(@class, 'dijitArrowButtonInner')]")
    private WebElement accountDropIcon;

    @Override
    protected WebElement getAccountDropIcon() {
        return accountDropIcon;
    }

    @FindBy(xpath = "//div[contains(@id,'SelectAccount')]//table[contains(@id,'Select')]//span[contains(@class,'title') and not(contains(@class,'noDisplay'))]")
    private WebElement issueChequeAccountName;

    @Override
    protected WebElement getIssueChequeAccountName() {
        return issueChequeAccountName;
    }

    @FindBy(xpath = "//div[contains(@id,'SelectAccount')]//table[contains(@id,'Select')]//span[contains(@class,'accountDetails')]")
    private WebElement issueChequeAccountNumber;

    @Override
    protected WebElement getIssueChequeAccountNumber() {
        return issueChequeAccountNumber;
    }

    @FindBy(xpath = "//div[@class='disclaimer']//p")
    private WebElement disclamierContainerCapture;

    @Override
    protected WebElement getDisclamierContainerCapture() {
        return disclamierContainerCapture;
    }

    @FindBy(xpath = "//div[@class='callUs']//p")
    private WebElement callSupportText;

    @Override
    protected WebElement getCallSupportText() {
        return callSupportText;
    }

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(StopChequeCapturePage.class);

    public StopChequeCapturePage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    protected String enterIssueDate(final StopChequeDetails stopCheque) throws ParseException {
        return StringUtils.EMPTY;
    }

    @Override
    protected String enterPayeeName(final StopChequeDetails stopCheque) {
        return StringUtils.EMPTY;
    }

    @Override
    public void verifyHelpIcon() {
        Reporter.log("Tool Tip is not applicable for Sri Lanka" + new Date());
    }

    @Override
    public void verifyDetailsAfterNegatingCancelOnCapturePage(final StopChequeDetails stopCheque) {
        isIssueChequeAccountNameDisplayed(stopCheque);
        isIssueChequeAccountNumberDisplayed(stopCheque);
        isChequeNumberDisplayed(stopCheque);
        isAmountDisplayed(stopCheque);
        isReasonToStopChequeDisplayed(stopCheque);
    }

    @Override
    public void validateFieldErrorsCapturePage() {
        isErrorOnBlankChequeNumberFieldDisplayed();
        isErrorOnBlankAmountFieldDisplayed();
    }

}
