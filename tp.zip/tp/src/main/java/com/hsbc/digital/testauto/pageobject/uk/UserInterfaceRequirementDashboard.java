/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.uk;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.UserInterfaceRequirementDashboardModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for User
 * Interface Requirement Dashboard for Canada entity. </b>
 * </p>
 */
public class UserInterfaceRequirementDashboard extends UserInterfaceRequirementDashboardModel {

    private final WebDriverWait wait;
    /*
     * Masthead
     */
    @FindBy(xpath = "//span[contains(@id,'LanguageToggle')]")
    private WebElement languageToggleText;

    /*
     * HSBC LOGO
     */
    @FindBy(xpath = "//*[@alt='HSBC Retail']")
    private WebElement hsbcLogoForMass;

    @FindBy(xpath = "//*[@alt='HSBC Advance']")
    private WebElement hsbcLogoForAdvance;

    /*
     * -------- HEADER LINKS --------
     */
    @FindBy(xpath = "//a[contains(@class,'navigation-link')]/span[text()='My banking']")
    private WebElement myBankingLinkHeader;

    @FindBy(xpath = "//a[contains(@class,'navigation-link')]/span[text()='Investments & financial planning']")
    private WebElement investmentsLinkHeader;

    @FindBy(xpath = "//a[contains(@class,'navigation-link')]/span[text()='Products & Services']")
    private WebElement productAndSevicesLinkHeader;

    @FindBy(xpath = "//a[contains(@class,'navigation-link')]/span[text()='Contact HSBC']")
    private WebElement contactLinkHeader;

    /*
     * My Banking FlyerMenu - Column wise Links
     */
    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='My banking']]/descendant::ul[1]/li")
    private List<WebElement> firstColumnLinksMyBankingHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='My banking']]/descendant::ul[preceding-sibling::h3//span[text()='Move Money']]/li")
    private List<WebElement> secondColumnLinksMyBankingHeader;
    
    
    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='My banking']]/descendant::ul[preceding-sibling::h3//span[text()='Card services']]/li")
    private List<WebElement> thirdColumnLinksMyBankingHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='My banking']]/descendant::ul[preceding-sibling::h3//span[text()='Paym']]/li")
    private List<WebElement> fourthColumnLinksMyBankingHeader;

    /*
     * Investments FlyerMenu - Column wise Links
     */
    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Investments & financial planning']]/descendant::ul[preceding-sibling::h3//h3[text()='Investing']]/li")
    private List<WebElement> firstColumnLinksInvestmentsHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Investments & financial planning']]/descendant::ul[preceding-sibling::h3//span[text()='Financial Planning']]/li")
    private List<WebElement> secondColumnLinksInvestmentsHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Investments & financial planning']]/descendant::ul[preceding-sibling::h3//span[text()='Support']]/li")
    private List<WebElement> thirdColumnLinksInvestmentsHeader;

    /*
     * Products And services FlyerMenu - Column wise Links
     */
    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Products & Services']]/descendant::ul[preceding-sibling::h3//h3[text()='Everyday banking']]/li")
    private List<WebElement> firstColumnLinksProductsAndServicesHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Products & Services']]/descendant::ul[preceding-sibling::h3//span[text()='Borrowing']]/li")
    private List<WebElement> secondColumnLinksProductsAndServicesHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Products & Services']]/descendant::ul[preceding-sibling::h3//span[text()='Insurance']]/li")
    private List<WebElement> thirdColumnLinksProductsAndServicesHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Products & Services']]/descendant::ul[preceding-sibling::h3//span[text()='International']]/li")
    private List<WebElement> fourthColumnLinksProductsAndServicesHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Products & services']]/descendant::ul[preceding-sibling::h3/span[text()='HSBC Premier']]//h4/span")
    private List<WebElement> fourthColumnHSBCPremierHeadingLinksProductsAndServicesHeader;

    /*
     * Contact FlyerMenu - Column wise Links
     */
    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Contact HSBC']]/descendant::ul[preceding-sibling::h3//span[text()='General Support']]/li")
    private List<WebElement> firstColumnLinksContactHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Contact HSBC']]/descendant::ul[preceding-sibling::h3//span[text()='Security']]/li")
    private List<WebElement> secondColumnLinksContactHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Contact HSBC']]//div[contains(@class,'singleElement')]/a")
    private List<WebElement> thirdColumnLinksContactHeader;

    @FindBy(xpath = "//*[contains(@id,'accountsummary')]/div")
    private WebElement accountOverviewWidget;
    
    
    /*
     * -------- FOOTER LINKS --------
     *  Above Footer Links
     */
    @FindBy(xpath = "//div[contains(@class,'footerTopLine')]//li")
    private List<WebElement> aboveFooterLinks;

    /*
     * Below Footer Links list
     */
    @FindBy(xpath = "//div[@class='footer clearfix']/ul//li")
    private List<WebElement> belowFooterLinks;

    /*
     * Middle Layer of Footer Links list
     */
    @FindBy(xpath = "//ul[preceding-sibling::h2[text()='Help and support']]/li")
    private List<WebElement> helpAndSupportLinksFooter;
    @FindBy(xpath = "//ul[preceding-sibling::h2[text()='My profile']]/li")
    private List<WebElement> myProfileLinksFooter;
    @FindBy(xpath = "//ul[preceding-sibling::h2[text()='Secure Key']]/li")
    private List<WebElement> secureLinksFooter;

    /*
     * My banking Links list
     */
    private static final List<String> FIRST_COLUMN_LINKS_TEXT_MYBANKING_MASS = Arrays.asList("Back to my accounts",
        "Travel", "Notify us of travel", "Buy travel money", "Security", "Switch my Secure Key",
        "Change personal security details", "Change my password", "Help with my Secure Key");
    private static final List<String> SECOND_COLUMN_LINKS_TEXT_MYBANKING = Arrays.asList("Pay or transfer",
        "Direct Debits", "Standing orders and future payments", "My payees", "Mortgage applications", "Mortgage options");
    private static final List<String> THIRD_COLUMN_LINKS_TEXT_MYBANKING = Arrays.asList("Activate card",
        "Report a lost or stolen card", "Send me my PIN", "Documents","Statement delivery options", "My documents");
    private static final List<String> FOURTH_COLUMN_LINKS_TEXT_MYBANKING = Arrays.asList("Register to receive payments using Paym",
        "Deregister from Paym", "Change Paym settings", "My Profile","Personal details", "Address details", "Telephone numbers", "Communication preferences");

    private static final List<String> FIRST_COLUMN_LINKS_TEXT_MYBANKING_ADV = Arrays.asList("Back to my accounts",
            "Travel", "Notify us of travel", "Buy travel money", "Global View", "Add or remove a country/territory" ,"Security", "Switch my Secure Key",
            "Change personal security details", "Change my password", "Help with my Secure Key");
    
    /*
     * Investments Links list
     */
    private static final List<String> FIRST_COLUMN_LINKS_TEXT_INVESTMENTS = Arrays.asList("Getting started",
        "Stocks & Shares ISA", "Investment funds", "Apply for Global Investment Centre",
        "Apply for Sharedealing");
    private static final List<String> SECOND_COLUMN_LINKS_TEXT_INVESTMENTS = Arrays.asList("HSBC Premier financial advice",
        "Tools to help you plan");
    private static final List<String> THIRD_COLUMN_LINKS_TEXT_INVESTMENTS = Arrays.asList("Selected Investment Funds", "Child Trust Funds");

    /*
     * Products & services Links list
     */
    private static final List<String> FIRST_COLUMN_LINKS_TEXT_PRODUCTANDSERVICES_MASS = Arrays.asList("Everyday banking overview", 
        "Current accounts", "Savings accounts", "Credit cards", "Ways to bank",
        "Mobile banking", "Apple Pay", "Online Banking","Telephone Banking", "Branch banking");
    private static final List<String> SECOND_COLUMN_LINKS_TEXT_PRODUCT_AND_SERVICES_MASS = Arrays.asList("Borrowing overview",
        "Mortgages", "Loans", "Credit cards", "Overdrafts", "Offers & rewards",
        "home&Away credit card privileges");
    private static final List<String> THIRD_COLUMN_LINKS_TEXT_PRODUCTANDSERVICES_MASS = Arrays.asList("Insurance overview",
        "Life insurance", "Car insurance", "Travel insurance","Home insurance","High Value home insurance","Student insurance"
        , "Premium banking", "HSBC Premier Bank Account", "HSBC Advance Bank Account","HSBC Private Bank");
    private static final List<String> FOURTH_COLUMN_LINKS_TEXT_PRODUCT_AND_SERVICES = Arrays.asList("International Services",
        "HSBC Currency Account", "HSBC Expat" , "Overseas account opening");

    private static final List<String> FIRST_COLUMN_LINKS_TEXT_PRODUCTANDSERVICES_ADV = Arrays.asList("Current accounts", 
            "Savings accounts", "Credit cards", "Ways to bank",
            "Mobile banking", "Apple Pay", "Online Banking","Telephone Banking"," Branch banking");
    private static final List<String> THIRD_COLUMN_LINKS_TEXT_PRODUCTANDSERVICES_ADV = Arrays.asList("Insurance overview",
            "Life insurance", "Car insurance", "Travel insurance","Home insurance","High Value home insurance","HSBC Insurance Aspects"
            , "Premium banking", "HSBC Premier Bank Account", "HSBC Advance Bank Account","HSBC Private Bank");
    
    private static final List<String> THIRD_COLUMN_LINKS_TEXT_PRODUCTANDSERVICES_PMR = Arrays.asList("Premier Worldwide Travel Insurance", "Insurance overview",
            "Life insurance", "Car insurance", "Premier home insurance", "High Value home insurance", "Premium banking"
            , "HSBC Premier Bank Account", "HSBC Advance Bank Account","HSBC Private Bank");
    private static final List<String> SECOND_COLUMN_LINKS_TEXT_PRODUCT_AND_SERVICES_PMR = Arrays.asList("Borrowing overview",
            "Mortgages", "Loans", "Credit cards", "Overdrafts", "Offers & rewards", "Premier privileges", "HSBC Premier Credit Card rewards" ,
            "home&Away credit card privileges");
    /*
     * Contact Links list
     */
    private static final List<String> FIRST_COLUMN_LINKS_TEXT_CONTACT_MASS = Arrays.asList("Contact and support",
        "Find a branch or ATM");
    private static final List<String> SECOND_COLUMN_LINKS_TEXT_CONTACT = Arrays.asList("Send a message",
        "Security Centre", "Free McAfee� Security download");
    private static final List<String> THIRD_COLUMN_LINKS_TEXT_CONTACT = Arrays.asList("Help with my Secure Key");
    
    private static final List<String> FIRST_COLUMN_LINKS_TEXT_CONTACT_ADV = Arrays.asList("Contact and support",
            "Find a branch or ATM" ,"Book or manage an appointment");

    private static final List<String> ABOVE_FOOTER_LINKS_TEXT = Arrays.asList("Contact HSBC", "Find a branch or ATM");
    private static final List<String> BELOW_FOOTER_LINKS_TEXT = Arrays.asList("Legal", "Cookie policy",
        "Accessibility", "Careers", "Security information", "HSBC Group","�HSBC Bank plc 2016");
    
    /* Middle layer footer */
    private static final List<String> HELPANDSUPPORT_LINKS_FOOTER_TEXT = Arrays.asList("Contact and support", "Security centre",
        "Report a lost or stolen card");
    private static final List<String> MY_PROFILE_LINKS_FOOTER_TEXT = Arrays.asList("Personal details",
            "Address details", "Telephone numbers", "Communication preferences");
    private static final List<String> SECURE_KEY_LINKS_FOOTER_TEXT = Arrays.asList("Switch my Secure Key", "Change personal security details", "Change my password",
        "Help with my Secure Key");

    public UserInterfaceRequirementDashboard(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30);
    }

    /**
     * This is to verify the Country Toggle in the Masthead on the dashboard
     */
    @Override
    public void languageToggle() {
        assertAndReportElementIsDisplayed(languageToggleText, "Country/language toggle text on Masthead is displayed",
            "Country/language toggle text on Masthead is not displayed");
    }

    /**
     * This is to verify the All the Header links for the Premier on the
     * dashboard
     */
    @Override
    public void verifyAllHeaderLinksForPremier(FlyerMenuNavigationModel navigationModel) {
        verifyMyBankingLinksHeader(navigationModel , PREMIER);
        verifyInvestmentsLinksHeader(navigationModel);
        verifyProductAndServicesLinksHeader(navigationModel, PREMIER);
        verifyContactLinksHeader(navigationModel, PREMIER);
    }

    /**
     * This is to select expected Header links depending on customer type
     */
    private List<String> getFirstColumnLinksTextOfMyBankingHeaderList(String customerSegment) {
        List<String> firstColumnLinktext;
        if (MASS.equals(customerSegment)) {
        	firstColumnLinktext = FIRST_COLUMN_LINKS_TEXT_MYBANKING_MASS;
        } else {
        	firstColumnLinktext = FIRST_COLUMN_LINKS_TEXT_MYBANKING_ADV;
        }
        return firstColumnLinktext;
    }
    
    /**
     * This is to select expected Header links depending on customer type
     */
    private List<String> getFirstColumnLinksTextOfProductAndServicesHeaderList(String customerSegment) {
        List<String> firstColumnLinktext;
        if (MASS.equals(customerSegment)) {
        	firstColumnLinktext = FIRST_COLUMN_LINKS_TEXT_PRODUCTANDSERVICES_MASS;
        } else {
        	firstColumnLinktext = FIRST_COLUMN_LINKS_TEXT_PRODUCTANDSERVICES_ADV;
        }
        return firstColumnLinktext;
    }
    
    /**
     * This is to select expected Header links depending on customer type
     */
    private List<String> getSecondColumnLinksTextOfProductAndServicesHeaderList(String customerSegment) {
        List<String> secondColumnLinktext;
        if (MASS.equals(customerSegment) || ADVANCE.equals(customerSegment)) {
        	secondColumnLinktext = SECOND_COLUMN_LINKS_TEXT_PRODUCT_AND_SERVICES_MASS;
        } else {
        	secondColumnLinktext = SECOND_COLUMN_LINKS_TEXT_PRODUCT_AND_SERVICES_PMR;
        }
        return secondColumnLinktext;
    }
    
    /**
     * This is to select expected Header links depending on customer type
     */
    private List<String> getThirdColumnLinksTextOfProductAndServicesHeaderList(String customerSegment) {
        List<String> thirdColumnLinktext;
        if (MASS.equals(customerSegment)) {
        	thirdColumnLinktext = THIRD_COLUMN_LINKS_TEXT_PRODUCTANDSERVICES_MASS;
        } else if (ADVANCE.equals(customerSegment)) {
        	thirdColumnLinktext = THIRD_COLUMN_LINKS_TEXT_PRODUCTANDSERVICES_ADV;
        }
        else {
        	thirdColumnLinktext = THIRD_COLUMN_LINKS_TEXT_PRODUCTANDSERVICES_PMR;
        }
        return thirdColumnLinktext;
    }
    
    /**
     * This is to select expected Header links depending on customer type
     */
    private List<String> getFirstColumnLinksTextOfContactsHeaderList(String customerSegment) {
        List<String> firstColumnLinktext;
        if (MASS.equals(customerSegment) || PREMIER.equals(customerSegment) ) {
        	firstColumnLinktext = FIRST_COLUMN_LINKS_TEXT_CONTACT_MASS;
        } else {
        	firstColumnLinktext = FIRST_COLUMN_LINKS_TEXT_CONTACT_ADV;
        }
        return firstColumnLinktext;
    }
    
    
    /**
     * This is to verify the All the Header links for the Advance on the
     * dashboard
     */
    @Override
    public void verifyAllHeaderLinksForAdvance(FlyerMenuNavigationModel navigationModel) {
        verifyMyBankingLinksHeader(navigationModel, ADVANCE);
        verifyInvestmentsLinksHeader(navigationModel);
        verifyProductAndServicesLinksHeader(navigationModel, ADVANCE);
        verifyContactLinksHeader(navigationModel, ADVANCE);
    }

    /**
     * This is to verify the All the Header links for the Mass on the dashboard
     */
    public void verifyAllHeaderLinksForMass(FlyerMenuNavigationModel navigationModel) {
        verifyMyBankingLinksHeader(navigationModel, MASS);
        verifyInvestmentsLinksHeader(navigationModel);
        verifyProductAndServicesLinksHeader(navigationModel, MASS);
        verifyContactLinksHeader(navigationModel, MASS);
    }

    /**
     * This is to verify All My Banking Links in Header for Premier on the
     * dashboard
     */
    @Override
    public void verifyMyBankingLinksHeader(FlyerMenuNavigationModel navigationModel, String customerSegment) {
        navigationModel.mouseOverOnMyBanking();
         validateAndCompareElement(firstColumnLinksMyBankingHeader, getFirstColumnLinksTextOfMyBankingHeaderList(customerSegment),
            "My Banking Header first column");
         validateAndCompareElement(secondColumnLinksMyBankingHeader, SECOND_COLUMN_LINKS_TEXT_MYBANKING,
            "My Banking Header second column");
         validateAndCompareElement(thirdColumnLinksMyBankingHeader, THIRD_COLUMN_LINKS_TEXT_MYBANKING,
            "My Banking Header third column");
         validateAndCompareElement(fourthColumnLinksMyBankingHeader, FOURTH_COLUMN_LINKS_TEXT_MYBANKING,
            "My Banking Header fourth column");
    }

    /**
     * This is to verify All Investments Links on the dashboard
     */
    private void verifyInvestmentsLinksHeader(FlyerMenuNavigationModel navigationModel) {
        navigationModel.mouseOverOnHeader(investmentsLinkHeader);
        super.validateAndCompareElement(firstColumnLinksInvestmentsHeader, FIRST_COLUMN_LINKS_TEXT_INVESTMENTS,
            "Investments Header first column");
        super.validateAndCompareElement(secondColumnLinksInvestmentsHeader, SECOND_COLUMN_LINKS_TEXT_INVESTMENTS,
            "Investments Header second column");
        super.validateAndCompareElement(thirdColumnLinksInvestmentsHeader, THIRD_COLUMN_LINKS_TEXT_INVESTMENTS,
            "Investments Header third column");
    }

    /**
     * This is to verify All Product And Services Links on the dashboard
     */
    private void verifyProductAndServicesLinksHeader(FlyerMenuNavigationModel navigationModel, String customerSegment) {
        navigationModel.mouseOverOnHeader(productAndSevicesLinkHeader);
        super.validateAndCompareElement(firstColumnLinksProductsAndServicesHeader, getFirstColumnLinksTextOfProductAndServicesHeaderList(customerSegment),
            "Product And Services Header first column");
        super.validateAndCompareElement(secondColumnLinksProductsAndServicesHeader,getSecondColumnLinksTextOfProductAndServicesHeaderList(customerSegment),
            "Product And Services Header second column");
        super.validateAndCompareElement(thirdColumnLinksProductsAndServicesHeader, getThirdColumnLinksTextOfProductAndServicesHeaderList(customerSegment),
            "Product And Services Header third column");
        super.validateAndCompareElement(fourthColumnLinksProductsAndServicesHeader, FOURTH_COLUMN_LINKS_TEXT_PRODUCT_AND_SERVICES,
            "Product And Services Header fourth column");
    }

   
    /**
     * This is to verify All Contact Links on the dashboard
     */
    private void verifyContactLinksHeader(FlyerMenuNavigationModel navigationModel, String customerSegment) {
        navigationModel.mouseOverOnHeader(contactLinkHeader);
        super.validateAndCompareElement(firstColumnLinksContactHeader, getFirstColumnLinksTextOfContactsHeaderList(customerSegment),
            "Contact Header first column");
        super.validateAndCompareElement(secondColumnLinksContactHeader, SECOND_COLUMN_LINKS_TEXT_CONTACT,
            "Contact Header second column");
        super.validateAndCompareElement(thirdColumnLinksContactHeader, THIRD_COLUMN_LINKS_TEXT_CONTACT,
            "Contact Header third column");
    }

    /* Footer Methods */
    /**
     * This is to verify the Middle layer in the Footer on the dashboard
     */
    @Override
    public void footerLink() {
        validateAndCompareElement(helpAndSupportLinksFooter, HELPANDSUPPORT_LINKS_FOOTER_TEXT, "Help and Support links footer");
        validateAndCompareElement(myProfileLinksFooter, MY_PROFILE_LINKS_FOOTER_TEXT, "My Profile links footer");
        validateAndCompareElement(secureLinksFooter, SECURE_KEY_LINKS_FOOTER_TEXT,
            "Secure Key links footer");
    }

    /*
     * Above footer Methods
     */
    public List<WebElement> aboveFooterLinksList() {
        return aboveFooterLinks;
    }

    public List<String> aboveFooterLinkText() {
        return ABOVE_FOOTER_LINKS_TEXT;
    }

    /*
     * Below footer Methods
     */
    @Override
    public List<WebElement> belowFooterLinksList() {
        return belowFooterLinks;
    }

    @Override
    public List<String> belowFooterLinkText() {
        return BELOW_FOOTER_LINKS_TEXT;
    }

    
    /**
     * This is to verify the Account Overview Widget on the dashboard and its
     * button
     */
    @Override
    public void verifyAccountOverviewWidget() {
        assertAndReportElementIsDisplayed(accountOverviewWidget, "Account Overview Widget is displayed",
            "Account Overview Widget is not displayed");
    }
    
    /**
     * This is to verify the Exchange Rate Calculator Widget on the dashboard
     */
    @Override
    public void verifyExchangeRateCalculatorWidget() {
    }

}
