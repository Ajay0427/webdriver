/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

/**
 * <p>
 * <b> This model class will hold locators and functionality for Change
 * Internet Banking Limits Confirm page. </b>
 * </p>
 * 
 * @version 1.0.0
 * @author SatyaPrakash S Vyas
 * 
 */
public abstract class ChangeIBLimitsConfirmModel {

    protected final WebDriverWait wait;

    @FindBy(xpath = "//div[@class='alertPanel confirmation']/div")
    private WebElement successMessageBox;

    @FindBy(xpath = "//div[@class='alertPanel error']/div")
    private List<WebElement> errorMessageBox;

    @FindBy(xpath = "//button[@data-dojo-attach-point='backToAcc']")
    private WebElement myAccountsButton;

    /**
     * Print button section
     */
    @FindBy(xpath = "//button[@data-dojo-attach-point='printBtn']")
    private WebElement printButton;

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_PrintFriendlyFormatDialog_') and not (contains(@style,'display: none'))]")
    private WebElement printDialog;

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_PrintFriendlyFormatDialog_') and not (contains(@style,'display: none'))]//button[@data-dojo-attach-point='closeButton']")
    private WebElement printDialogCancelButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='makeFurthChanges']")
    private WebElement makeFurtherChangesButton;

    @FindBy(xpath = "//*[contains(@id,'group_gpib_services_bijit_change_limits_ChangeLimits')]//h2[contains(text(),'Daily payment and transfer limits')]")
    private WebElement capturePageHeading;

    @FindBy(xpath = "//*[@id='_dashboardHeading']/h1/span[text()='My accounts']")
    private WebElement dashboardPage;

    private static final String CONFIRM_MESSAGE = "Your transfer limits have been updated ";

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(ChangeIBLimitsConfirmModel.class);

    public ChangeIBLimitsConfirmModel(final WebDriver driver) {
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30000);
    }

    public void validateSuccessMessage() {
        Reporter.log("confirmation message shown is: " + successMessageBox.getText());
        Assert.assertTrue(ChangeIBLimitsConfirmModel.CONFIRM_MESSAGE.equalsIgnoreCase(successMessageBox.getText()),
            "Success Message does not match.");
    }

    public void clickMyAccountsButton() {
        wait.until(ExpectedConditions.elementToBeClickable(myAccountsButton));
        myAccountsButton.click();
        wait.until(ExpectedConditions.visibilityOf(dashboardPage));
        Reporter.log("My Accounts button clicked and dashboard page shown.");
    }

    public void clickMakeFurtherChangesButton() {
        wait.until(ExpectedConditions.elementToBeClickable(makeFurtherChangesButton));
        makeFurtherChangesButton.click();
        if (capturePageHeading.isDisplayed()) {
            Reporter.log("Make Further Changes button is clicked on confirm Page.");
        } else {
            Assert.fail("Make further changes button is not working as expected");
        }

    }

    public void clickPrintButton() {
        wait.until(ExpectedConditions.elementToBeClickable(printButton));
        printButton.click();
        printDialog.isDisplayed();
        printDialogCancelButton.click();
        Reporter.log("Print button is clicked on confirm Page.");
    }
}
