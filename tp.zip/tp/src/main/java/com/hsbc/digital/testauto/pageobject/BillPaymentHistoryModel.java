/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * 
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.library.RandomUtil;


/***
 * <p>
 * <b> This model class will hold locators and functionality to View Bill
 * Payment History page. </b>
 * </p>
 * 
 * @author Midde Rajesh Kumar
 * @version 1.0.0
 */
public abstract class BillPaymentHistoryModel {

    protected final WebDriver driver;

    @FindBy(xpath = "//table[contains(@id,'SelectAccount')]//td[contains(@class,'dijitArrowButton')]")
    protected WebElement accountDropdownIcon;

    @FindBy(xpath = "//div[contains(@id,'SelectAccount')]//tr[starts-with(@id,'dijit_MenuItem')]")
    protected List<WebElement> accountDropDownList;

    @FindBy(xpath = "//span[@title='Search']")
    private WebElement searchButton;

    @FindBy(xpath = "//input[contains(@id,'fromAmount_CurrencyTextBox')]")
    private WebElement fromAmountInput;

    @FindBy(xpath = "//input[contains(@id,'toAmount_CurrencyTextBox')]")
    private WebElement toAmountInput;

    @FindBy(xpath = "//div[contains(@class,'dijitInputField')]//input[contains(@id, 'dateFrom')]")
    private WebElement fromDateInput;

    @FindBy(xpath = "//div[contains(@class,'dijitInputField')]//input[contains(@id, 'dateTo')]")
    private WebElement toDateInput;

    @FindBy(xpath = "//input[contains(@id,'nameSearch')]")
    private WebElement searchByNameInput;

    @FindBy(xpath = "//button[text()='View results']")
    private WebElement viewResultsButton;

    @FindBy(xpath = "//button[text()='Clear results']")
    private WebElement clearResultsButton;

    @FindBy(xpath = "//th[contains(@id,'colDate')]")
    private WebElement dateSortArrowButton;

    @FindBy(xpath = "//th[contains(@id,'colAmount')]")
    private WebElement amountSortArrowButton;

    @FindBy(xpath = "//th[contains(@id,'colPayees')]")
    private WebElement descriptionSortButton;

    @FindBy(xpath = "//div[@class='gridxBody gridxBodyRowHoverEffect']//table[@class='gridxRowTable']//td[@colid='colDate']")
    protected List<WebElement> dateList;

    @FindBy(xpath = "//div[starts-with(@id,'gridx_Grid_')]//td[contains(@class,'payee')]/span[@class='payeeItem0']")
    protected List<WebElement> descriptionList;

    @FindBy(xpath = "//div[@class='gridxBody gridxBodyRowHoverEffect']//table[@class='gridxRowTable']//td[@colid='colAmount']")
    protected List<WebElement> amountList;

    @FindBy(xpath = "//a[@id='dapViewMorePrintBtn']")
    private WebElement printButton;

    @FindBy(xpath = "//div[contains(@id,'PrintFriendlyFormatDialog') and not (contains(@style,'display: none'))]//button[@class='btnSecondary']")
    private WebElement printPopUpButton;

    @FindBy(xpath = "//span[@class='noTransactions']")
    private WebElement errorMessageLabel;

    @FindBy(xpath = "//div[@class='alertPanel error']")
    private WebElement noTransactionMessage;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_reviewSearchAgain']")
    private WebElement searchAgainButton;

    @FindBy(xpath = "//div[contains(@id, 'gridx_Grid')]//div[contains(@class, 'gridxMain')]//div[contains(@class, 'gridxRow') and @role='row']")
    protected List<WebElement> transactionDetailDisplayElements;

    @FindBy(xpath = "//span[contains(@class,'icon') and @title='Move money']")
    private WebElement moveMoneyButton;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(BillPaymentHistoryModel.class);

    public BillPaymentHistoryModel(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    /**
     * This is to get the input format for the respective entity
     * 
     * @return
     */
    public String getInputFormat() {
        return DateUtil.DATE_FORMAT_MMDDYYYY;
    }

    /**
     * This is to get the input format for the respective entity
     * 
     * @return
     */
    public String getOutputFormat() {
        return DateUtil.DATE_FORMAT_DDMMMYYYY;
    }

    /**
     * This method is for selection the Account from the drop down list
     * 
     */
    public void selectAccount() {
        int counter = 0;
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        accountDropdownIcon.click();
        if (!accountDropDownList.isEmpty()) {
            for (WebElement accountSelection : accountDropDownList) {
            	if(!(counter==0))
            	accountDropdownIcon.click();
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", accountSelection);
                accountSelection.click();
                counter++;
                if (!transactionDetailDisplayElements.isEmpty()) {
                    Reporter.log("Account is selected with some transaction");
                    break;
                }
            }

            if (counter > accountDropDownList.size()) {
                Reporter.log("No account found with Bill Payment History , Please chnage profile to execute this scenario");
                Assert.fail("No Suitable Account founf for this scenario");
            }
        }
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    /**
     * This method is for Selection of Account other than Select All Accounts
     * from drop down list
     */
    public void selectSelectAllAccounts() {
        selectAccount();
    }

    /**
     * 
     * This method is to click on search button
     * 
     */
    public void clickSearchButton() {
        searchButton.click();
    }

    /**
     * This method is to click on View results button
     * 
     */
    public void clickViewResultButton() {
        Assert.assertTrue(viewResultsButton.isDisplayed(), "View results button is not displayed");
        viewResultsButton.click();
        Reporter.log("View results button is clicked.");
    }

    /**
     * This method is to generate from date
     * 
     */
    public String getFromDate() {
        try {
            return DateUtil.getDateToString(getInputFormat(),
                DateUtil.getStringToDate(getOutputFormat(), dateList.get(dateList.size() - 1).getText()));
        } catch (ParseException e) {
            BillPaymentHistoryModel.logger.error("Date Format Conversion Error: ", e);
            Assert.fail("Date Format Conversion Error");
        }
        return null;
    }

    /**
     * This method is to generate to date
     * 
     */
    public String getToDate() {
        try {
            return DateUtil.getDateToString(getInputFormat(),
                DateUtil.getStringToDate(getOutputFormat(), dateList.get(0).getText()));
        } catch (ParseException e) {
            BillPaymentHistoryModel.logger.error("Date Format Conversion Error: ", e);
            Assert.fail("Date Format Conversion Error");
        }
        return null;
    }

    /**
     * This method is to enter from date in the text box
     * 
     */
    public void enterFromDate(final String date) {
        Assert.assertTrue(fromDateInput.isDisplayed(), "FromDate Text field is not displayed");
        Reporter.log("From date text field is displayed");
        fromDateInput.sendKeys(date);
        Reporter.log("Date: " + date + " is entered in From Date");
    }

    /**
     * This method is to enter to date in the text box
     * 
     */
    public void enterToDate(final String date) {
        Assert.assertTrue(toDateInput.isDisplayed(), "To Date Text field is not displayed");
        Reporter.log("To date text field is displayed");
        toDateInput.sendKeys(date);
        Reporter.log("Date: " + date + " is entered in To Date");
    }

    /**
     * 
     * This method is to get from amount value
     * 
     * @return
     */
    public Double getFromAmount() {
        return Double.parseDouble(RandomUtil.generateDoubleNumber(1, 3, 2));
    }

    /**
     * This method is to get to amount value
     * 
     * @return
     */
    public Double getToAmount() {
        return Double.parseDouble(RandomUtil.generateDoubleNumber(9999, 100000, 2));
    }

    /**
     * This method is to enter from amount in the text box
     * 
     */
    public void enterFromAmount(final Double amount) {
        fromAmountInput.sendKeys(String.format("%.2f", amount));
        Reporter.log("Amount entered: " + amount + " in From Amount.");
    }

    /**
     * This method is to enter to amount in the text box
     * 
     */
    public void enterToAmount(final Double amount) {
        toAmountInput.sendKeys(String.format("%.2f", amount));
        Reporter.log("Amount entered: " + amount + " in To Amount.");
    }

    /**
     * This method is to get the list of Beneficiary names
     * 
     */
    public String getDescriptionName() {
        return descriptionList.get(RandomUtil.generateIntNumber(0, descriptionList.size())).getText();
    }

    /**
     * This method is to search by beneficiary names
     * 
     */
    public void searchByBenificiaryName(final String name) {
        searchByNameInput.sendKeys(name);
    }

    /**
     * This method is to sort the transactions by amount
     * 
     */
    public void sortByAmount() {
        if (!amountList.isEmpty()) {
            List<Double> beforeSort = new ArrayList<>();
            for (WebElement element : amountList) {
                beforeSort.add(Double.parseDouble(element.getText().replace(",", "")));
            }
            Collections.sort(beforeSort);
            amountSortArrowButton.click();
            Reporter.log("Click on Amount column for sort");
            List<Double> afterSort = new ArrayList<>();
            for (WebElement element : amountList) {
                afterSort.add(Double.parseDouble(element.getText().replace(",", "")));
            }
            Iterator<Double> targetIt = beforeSort.iterator();
            for (Double uiSortedDate : afterSort) {
                if (!uiSortedDate.equals(targetIt.next())) {
                    BillPaymentHistoryModel.logger.error("Bill Payment History Displayed is not in correct Order");
                    Assert.fail("Bill Payment History Displayed is not in correct Order");
                }
            }
            Reporter.log("Bill Payment history Displayed in correct Order");
        } else {
            BillPaymentHistoryModel.logger.error("Bill Payment history has no Transaction: Message is :"
                + noTransactionMessage.getText());
            Assert.fail("Bill Payment history has no Transaction");
        }
    }

    /**
     * This method is to sort the transactions by date
     * 
     */
    public void sortByDate() {
        if (!dateList.isEmpty()) {
            List<Date> beforeSort = new ArrayList<>();
            for (WebElement element : dateList) {
                try {
                    beforeSort.add(DateUtil.getStringToDate(getOutputFormat(), element.getText()));
                } catch (ParseException e) {
                    BillPaymentHistoryModel.logger.error("Date Format Conversion Error: ", e);
                    Assert.fail("Date Format Conversion Error");
                }
            }
            Collections.sort(beforeSort);
            dateSortArrowButton.click();
            Reporter.log("Click on Date column for sort");
            List<Date> afterSort = new ArrayList<>();
            for (WebElement element : dateList) {
                try {
                    afterSort.add(DateUtil.getStringToDate(getOutputFormat(), element.getText()));
                } catch (ParseException e) {
                    BillPaymentHistoryModel.logger.error("Date Format Conversion Error: ", e);
                    Assert.fail("Date Format Conversion Error");
                }

            }

            Iterator<Date> targetIt = beforeSort.iterator();
            for (Date uiSortedDate : afterSort) {
                if (!uiSortedDate.equals(targetIt.next())) {
                    BillPaymentHistoryModel.logger.error("Bill Payment History Displayed is not in correct Order");
                    Assert.fail("Bill Payment History Displayed is not in correct Order");
                }
            }
            Reporter.log("Statement History Displayed in correct Order");
        } else {
            BillPaymentHistoryModel.logger.error("Bill Payment history has no Transaction: Message is :"
                + noTransactionMessage.getText());
            Assert.fail("Bill Payment history has no Transaction");
        }
    }

    /**
     * This is to check the default order of the date in the list
     * 
     */
    public void defaultOrderCheck() {
        for (int eachDate = 0; eachDate < dateList.size() - 1; eachDate++) {
            String firstDateDisplayed = dateList.get(eachDate).getText();
            String nextDateDisplayed = dateList.get(eachDate + 1).getText();
            try {
                Date firstDate = DateUtil.getStringToDate(getOutputFormat(), firstDateDisplayed);
                Date nextDate = DateUtil.getStringToDate(getOutputFormat(), nextDateDisplayed);
                if (!(firstDate.after(nextDate) || firstDate.equals(nextDate))) {
                    BillPaymentHistoryModel.logger.error("Bill Payment History Displayed is not in correct Order");
                    Assert.fail("Bill Payment History Displayed is not in correct Order");
                }
            } catch (ParseException e) {
                BillPaymentHistoryModel.logger.error("Date Format Conversion Error: ", e);
                Assert.fail("Date Format Conversion Error");
            }
        }
        Reporter.log("Bill Payment History Displayed in correct Order");
    }

    /**
     * This method is to get the list of sorted transactions
     * 
     */
    public void sortDescription() {
        List<String> expecteddescription = new ArrayList<>();
        for (WebElement element : descriptionList) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
            expecteddescription.add(element.getText());
        }
        Collections.sort(expecteddescription);
        Iterator<String> iteratorExpected = expecteddescription.iterator();
        descriptionSortButton.click();
        Reporter.log("Click on Description column for sort");

        for (WebElement element : descriptionList) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
            Assert.assertTrue(iteratorExpected.next().equals(element.getText()), "Description in the List is not sorted.");
        }
        Reporter.log("Description in the List is sorted.");
    }

    /**
     * This method is to click and verify the clear Results button
     * functionality
     * 
     */
    public void verifyClearResultsButton() {
        String beforeValue = searchByNameInput.getAttribute("value");
        Assert.assertTrue(clearResultsButton.isDisplayed(), "Clear Results button is not present");
        clearResultsButton.click();
        Reporter.log("Clear Results button is clicked");
        String afterValue = searchByNameInput.getAttribute("value");
        Assert.assertTrue(!beforeValue.equals(afterValue), "Clear Results button functionality is not working properly.");
        Reporter.log("Clear Results button functionality is working properly.");
    }

    /**
     * This method is to click on print button
     * 
     */

    public void clickPrintButton() {
        Assert.assertTrue(printButton.isDisplayed(), "Print button is not displayed on Transaction History section");
        printButton.click();
        Reporter.log("Print button is clicked on Transaction History section");
    }

    /**
     * This method is to verify the print popup dialog
     * 
     */
    public void verifyPrintPopupDialogDisplayed() {
        Assert.assertTrue(printPopUpButton.isDisplayed(), "Print popup dialog is not displayed.");
        Reporter.log("Print popup dialog is displayed.");
    }

    public void verifyHelpIcon() {}

    /**
     * This method is to verify error message
     * 
     */
    public void verifyErrorMessage() {
        Assert.assertTrue(errorMessageLabel.isDisplayed(), "No error message is displayed");
        Reporter.log("Error message is displayed as: " + errorMessageLabel.getText());
    }


    /**
     * This is to verify the Bill payment history list for Date
     * 
     * @param fromDate
     * @param toDate
     */
    public void verifyBillPaymentHistoryByDate(final String fromDate, final String toDate) {
        try {
            String tempFromDate = DateUtil.getDateToString(getOutputFormat(), DateUtil.getStringToDate(getInputFormat(), fromDate));
            String tempToDate = DateUtil.getDateToString(getOutputFormat(), DateUtil.getStringToDate(getInputFormat(), toDate));
            checkDateBetweenRange(getOutputFormat(), tempFromDate, tempToDate);
        } catch (ParseException e) {
            BillPaymentHistoryModel.logger.error("Date Format Conversion Error: ", e);
            Assert.fail("Date Format Conversion Error: ");
        }
    }

    /**
     * This is to check the date is between the Form and To Date
     * 
     * @param dateFormat
     * @param fromDate
     * @param toDate
     */
    public void checkDateBetweenRange(final String dateFormat, final String fromDate, final String toDate) {
        boolean dateFlag = false;
        try {
            Date tempFromDate = DateUtil.getStringToDate(dateFormat, fromDate);
            Date tempToDate = DateUtil.getStringToDate(dateFormat, toDate);

            for (int eachDate = 0; eachDate < dateList.size(); eachDate++) {
                Date tempDate = DateUtil.getStringToDate(dateFormat, dateList.get(eachDate).getText());
                if (!((tempDate.after(tempFromDate) && tempDate.before(tempToDate)) || tempDate.equals(tempFromDate) || tempDate
                    .equals(tempToDate))) {
                    dateFlag = true;
                }
            }
        } catch (ParseException e) {
            BillPaymentHistoryModel.logger.error("Date Format Conversion Error: ", e);
            Assert.fail("Date Format Conversion Error: ", e);
        }

        if (dateFlag) {
            BillPaymentHistoryModel.logger.error("All the dates displayed in the list is not between the range: " + fromDate
                + " - " + toDate);
            Assert.fail("All the dates displayed in the list is not between the range: " + fromDate + " - " + toDate);
        } else {
            Reporter.log("All the dates displayed in the list is between the range: " + fromDate + " - " + toDate);
        }
    }

    /**
     * This is to compare the Result by Description name
     * 
     * @param expname
     */
    public void compareResultByName(final String expname) {
        for (WebElement tempname : descriptionList) {
            Assert.assertTrue(tempname.getText().contains(expname), "Expected name: " + expname
                + " is not present in description list.");
        }
        Reporter.log("Expected name: " + expname + " is present in description list.");
    }

    /**
     * This is to compare the Result is between the From and To Amount
     * 
     * @param fromAmt
     * @param toAmt
     */
    public void compareResultByAmount(final Double fromAmt, final Double toAmt) {
        for (WebElement tempAmount : amountList) {
            Double actualAmount = Double.valueOf(tempAmount.getText().replace(",", ""));
            Assert.assertTrue(actualAmount >= fromAmt && actualAmount <= toAmt, "Amount is displaying as " + actualAmount
                + " which dosen't lie between + " + fromAmt + " and " + toAmt);
        }
        Reporter.log("Amounts in the List is  between: " + fromAmt + " and " + toAmt);
    }

    /**
     * This is to check if the Bill payment history is available or not
     * 
     */
    public void checkBillPaymentHistoryAvailability() {
        if (dateList.isEmpty()) {
            BillPaymentHistoryModel.logger.error("Bill Payment history has no Transaction: Message is: "
                + noTransactionMessage.getText());
            Assert.fail("Bill Payment history has no Transaction");
        } else {
            BillPaymentHistoryModel.logger.info("Bill Payment history has Transactions.");
        }
    }

    /**
     * 
     */
    public void verifyVisibilityOfViewMoreButton() {}

    /**
     * 
     */
    public void validateDisclaimerText() {}

    /**
     * Verifies Search again button functionality
     * 
     * @param descriptionName
     *            : String
     */

    public void verifySearchAgainButton(String descriptionName) {
        List<String> transactionListBeforeSearchAgain = transactionsList();
        Assert.assertTrue(searchAgainButton.isDisplayed(), "Search Again button is not present. | ");
        searchAgainButton.click();
        Reporter.log("Search Again button clicked. | ");
        String afterValue = searchByNameInput.getAttribute("value");
        Assert.assertTrue(descriptionName.equals(afterValue), "Search Again button functionality not working properly. ");
        Reporter.log("Values displayed before and after clicking on Search Again button are " + descriptionName + " :: "
            + afterValue + ". | ");
        List<String> transactionListAfterSearchAgain = transactionsList();
        if (transactionsList().size() <= 5 && transactionListBeforeSearchAgain.equals(transactionListAfterSearchAgain)) {
            Reporter.log("\"Search Again\" button functionality working properly. | ");
        }
    }

    /**
     * Returns first line of description from each transaction in transactions
     * list
     */
    public List<String> transactionsList() {
        List<String> transactionDataList = new ArrayList<>();
        for (WebElement eachTransaction : descriptionList) {
            transactionDataList.add(eachTransaction.getText());
        }
        return transactionDataList;
    }

    public void verifyClearSearchButton(List<String> transactionsList) {}

    public void clickMoveMoneyButton() {
        Assert.assertTrue(moveMoneyButton.isDisplayed(), "MoveMoney button is not displayed. ");
        Reporter.log("Move Money button is displayed. | ");
        moveMoneyButton.click();
        Reporter.log("Move Money button clicked. | ");
    }
}
