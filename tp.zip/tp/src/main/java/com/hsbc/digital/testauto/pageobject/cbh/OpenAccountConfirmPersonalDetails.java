/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.cbh;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.pageobject.OpenAccountConfirmPersonalDetailsModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Canada
 * entity. </b>
 * </p>
 */
public class OpenAccountConfirmPersonalDetails extends OpenAccountConfirmPersonalDetailsModel {

    @FindBy(xpath = "//input[contains(@id,'confirm')]")
    private WebElement confirmDetailsCheckBox;

    @FindBy(xpath = "//input[contains(@id,'TermsAndConditions')]")
    private WebElement termsAndConditionCheckBox;

    @FindBy(xpath = "//span[text()='Continue']")
    private WebElement continueButton;

    @FindBy(xpath = " //button[contains(text(),'Cancel')]")
    private WebElement cancelButton;

    @FindBy(xpath = " //div[text()='Savings accounts']")
    private WebElement savingAccount;

    @FindBy(xpath = "//span[contains(text(),'Edit')]")
    private WebElement editDetailsButtonConfirmPage;

    @FindBy(xpath = "//a[contains(text(),'Yes')]")
    private WebElement yesButtonOnPopUp;

    private static final String TITLE_TD = "Guaranteed Investment Certificate (GIC) and Term Deposit";

    public OpenAccountConfirmPersonalDetails(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    /**
     * Click on first radio for random selection for confirmation
     */
    @Override
    public void confirmPersonalDetails() {
        Assert.assertTrue(confirmDetailsCheckBox.isDisplayed(), "Check box to confirm Details is not displayed");
        confirmDetailsCheckBox.click();
        Reporter.log("Select Confirm Details check box");

        Assert.assertTrue(termsAndConditionCheckBox.isDisplayed(), "Check box of terms and condition is not displayed");
        termsAndConditionCheckBox.click();
        Reporter.log("Select Terms and Condition check box");
        clickContinueButton();
    }

    @Override
    public void verifyTitle() {
        Assert.assertEquals(opennewTDTitleHeading.getText(), OpenAccountConfirmPersonalDetails.TITLE_TD);
    }

    @Override
    public void clickContinueButton() {
        wait.until(ExpectedConditions.elementToBeClickable(continueButton));
        continueButton.click();
        wait.until(ExpectedConditions.visibilityOf(openAccountOptionsPage));
        Reporter.log("Continue button clicked and Options page shown.");
    }

    /**
     * Click cancel button
     */
    @Override
    public void clickCancelButton(final boolean isCancel) {
        wait.until(ExpectedConditions.elementToBeClickable(cancelButton));
        cancelButton.click();
        if (isCancel) {
            cancelDialogYes.click();
            Assert.assertTrue(savingAccount.isDisplayed(),
                "User is not navigated to product details page after clicking Cancel - Yes");
            Reporter.log("User navigated to product details page after clicking Cancel - Yes");
        } else {
            cancelDialogNo.click();
            personalDetailsForm.isDisplayed();
            Reporter.log("Cancel button - No clicked and personal details page shown.");
        }
    }

    @Override
    public void verifyeditDetailsFunctionality() {
        Assert.assertTrue(editDetailsButtonConfirmPage.isDisplayed(), "Edit details button is not displayed");
        editDetailsButtonConfirmPage.click();
        Reporter.log("Edit details button clicked");

        Assert.assertTrue(yesButtonOnPopUp.isDisplayed(), "Yes button is not displayed on pop up");
        yesButtonOnPopUp.click();
        Reporter.log("Yes button on pop up clicked");

    }
}
