/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.library.TokenGenerator;

/**
 * <p>
 * <b> This model class will hold locators and functionality for Request
 * Replacement Pin Capture page that can be used around all entities. </b>
 * </p>
 * 
 * @version 1.0.0
 * @author SatyaPrakash S Vyas
 */
public abstract class IssueReplacementPinCaptureModel {

    protected WebDriverWait wait;

    private TokenGenerator tokenGenerator;

    @FindBy(xpath = "//input[@type='radio' and @name='pinType']")
    private List<WebElement> radioButtons;

    @FindBy(xpath = "//input[@name='reauthSecurityCode']")
    private WebElement reauthEditField;

    @FindBy(xpath = "//span[text()='Continue']")
    private WebElement continueButton;

    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
    protected WebElement cancelButton;

    @FindBy(xpath = "//div[@class='row submitButtonsPanel ']/button[@title='Yes']")
    private WebElement cancelDialogYes;

    @FindBy(xpath = "//div[@class='row submitButtonsPanel ']/button[@title='No']")
    private WebElement cancelDialogNo;

    @FindBy(xpath = "//*[@id='_dashboardHeading']/h1/span[text()='My accounts']")
    protected WebElement dashboardPage;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(IssueReplacementPinCaptureModel.class);

    public IssueReplacementPinCaptureModel(final WebDriver driver) {
        PageFactory.initElements(driver, this);
        this.wait = new WebDriverWait(driver, 30000);
        tokenGenerator = new TokenGenerator();
    }

    public void selectNewPinFor() {
        if (radioButtons.isEmpty()) {
            int randomNumber = RandomUtil.generateIntNumber(0, radioButtons.size());
            radioButtons.get(randomNumber).click();
            Reporter.log("Radio button selected randomly.");
        } else {
            Reporter.log("Default selection as 'New Pin For' available.");
        }
    }

    public void enterReauthCode(final Map<String, String> profileProperties) throws IOException {
        String userName = profileProperties.get("userName");
        String serialNumber = profileProperties.get("serialNumber");
        String otpkey = profileProperties.get("otpKey");
        String reauthCode = tokenGenerator.generateReauthCode(userName, serialNumber, otpkey);
        Assert.assertTrue(reauthEditField.isEnabled(), "Reauth Code field is not enabled");
        reauthEditField.clear();
        reauthEditField.sendKeys(reauthCode);
        Reporter.log("Reauth code entered in text field.");
    }

    public void clickContinueButton() {
        wait.until(ExpectedConditions.elementToBeClickable(continueButton));
        continueButton.click();
        Reporter.log("Continue button clicked and Confirmation page shown.");
    }

    public void clickCancelButton(final boolean isCancel) {
        wait.until(ExpectedConditions.elementToBeClickable(cancelButton));
        cancelButton.click();
        if (isCancel) {
            cancelDialogYes.click();
            dashboardPage.isDisplayed();
            Reporter.log("Cancel button - Yes clicked and Dashboard page shown.");
        } else {
            cancelDialogNo.click();
            Reporter.log("Cancel button - No clicked and user is on same page.");
        }
    }

    /**
     * 
     * <p>
     * <b> This method will select account from list for Card. Applicable for
     * CBH </b>
     * </p>
     * 
     * @return
     */
    public String selectAccount() {
        return StringUtils.EMPTY;
    }
}
