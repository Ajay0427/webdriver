package com.hsbc.digital.testauto.pageobject.uk;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

import com.hsbc.digital.testauto.models.CommunicationPreferencess;
import com.hsbc.digital.testauto.pageobject.CommunicationPreferencesConfirmPageModel;


/**
 * Contains locators and functions of Communication Preferences story for UK -
 * Confirm Page
 * 
 * @author Neha Rajesh Gupta
 * 
 * **/

public class CommunicationPreferencesConfirmPage extends CommunicationPreferencesConfirmPageModel {

    @FindBy(xpath = "//p[contains(text(),'Confirm')]")
    private WebElement confirmMessage;

    @FindBy(xpath = "//a[contains(@title,'print')]")
    private WebElement printButton;

    @FindBy(xpath = "//div[contains(@class,'hsbcButtonCenter')]//a[contains(text(),'My accounts')]")
    private WebElement myAccountsButton;

    @FindBy(xpath = "//strong[contains(text(),'Email')]//following::td[1]/label")
    private WebElement emailField;

    @FindBy(xpath = "//strong[contains(text(),'messages')]//following::td[1]/label")
    private WebElement messagesNDocumentsField;

    @FindBy(xpath = "//strong[contains(text(),'Telephone')]//following::td[1]/label")
    private WebElement telephoneField;

    @FindBy(xpath = "//strong[contains(text(),'Mobile')]//following::td[1]/label")
    private WebElement mobileField;

    @FindBy(xpath = "//strong[contains(text(),'Post')]//following::td[1]/label")
    private WebElement postField;

    public CommunicationPreferencesConfirmPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    public void confirmMessageDisplayed() {
        confirmMessage.isDisplayed();
        Reporter.log("Confirm Message displayed on confirm page");
    }

    @Override
    public void printButtonDisplayed() {
        printButton.isDisplayed();
        Reporter.log("Print button is displayed on the confirm page.");
    }

    @Override
    public void myAccountsButtonDisplayed() {
        myAccountsButton.isDisplayed();
        Reporter.log("My accounts button is displayed on the confirm page.");
    }

    @Override
    public boolean validateEmailField(CommunicationPreferencess communicationPreferences) {
        return validateField(emailField, communicationPreferences.getEmail());
    }

    @Override
    public boolean validatePostField(CommunicationPreferencess communicationPreferences) {
        return validateField(postField, communicationPreferences.getPost());
    }

    @Override
    public boolean validateMobileField(CommunicationPreferencess communicationPreferences) {
        return validateField(mobileField, communicationPreferences.getMobileMessaging());
    }

    @Override
    public boolean validateTelephoneField(CommunicationPreferencess communicationPreferences) {
        return validateField(telephoneField, communicationPreferences.getTelephone());
    }

    @Override
    public boolean validatemessagesNDocumentsField(CommunicationPreferencess communicationPreferences) {
        return validateField(messagesNDocumentsField, communicationPreferences.getMessagesNDocments());
    }

    @Override
    public boolean validateField(WebElement field, boolean reviewPageValueSet) {
        return (reviewPageValueSet && field.getText().equals("Yes") || !reviewPageValueSet && field.getText().equals("No")) ? true
            : false;
    }
}
