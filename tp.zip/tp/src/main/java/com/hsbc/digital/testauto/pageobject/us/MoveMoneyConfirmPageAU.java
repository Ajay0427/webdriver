package com.hsbc.digital.testauto.pageobject.us;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.hsbc.digital.testauto.pageobject.MoveMoneyConfirmPageModelNew;

public class MoveMoneyConfirmPageAU extends MoveMoneyConfirmPageModelNew {

    public MoveMoneyConfirmPageAU(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }


}
