package com.hsbc.digital.testauto.pageobject.us;

import java.text.ParseException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyVerifyPageModel;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

public class MoveMoneyVerifyPage extends MoveMoneyVerifyPageModel {

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(MoveMoneyVerifyPage.class);
    private final WebDriverWait wait;
    protected final UICommonUtil uiCommonUtil;
    private final WebDriver driver;
    JavascriptExecutor jsx;

    @FindBy(xpath = "//div[contains(@class, 'move-money confirmationPage')]//button[@data-dojo-attach-point= '_cancel']")
    private WebElement cancelButton;

    @FindBy(xpath = "//div[contains(@id,'ConfirmDialog_') and not (contains(@style,'display: none'))]//button[(@data-dojo-attach-point='_btnCancel')]")
    protected WebElement cancelDialogYes;

    @FindBy(xpath = "//div[contains(@id,'ConfirmDialog_') and not (contains(@style,'display: none'))]//button[(@data-dojo-attach-point='_btnOk')]")
    protected WebElement cancelDialogNo;

    private static final String SCROLL_TO_VIEW = "arguments[0].scrollIntoView(true);";
    private static final String LABEL_PAYEE_NAME = "Payee name";
    private static final String LABEL_PAYEE_REFERENCE = "Payee reference";
    protected static final String LABEL_PAYMENT_DATE = "Transfer date";
    protected static final String LABEL_DEBIT_AMOUNT = "Amount";
    private static final String LABEL_NUMBER_OF_PAYMENT = "Number of transfers";
    protected static final String LABEL_PURPOSE_OF_PAYMENT = "Purpose of payment";
    protected static final String LABEL_PURPOSE_OF_PAYMENT_DEST_COUNTRY = "Purpose of payment destination country";

    public MoveMoneyVerifyPage(final WebDriver driver) {
        super(driver);
        this.driver = driver;
        jsx = (JavascriptExecutor) driver;
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30000);
        uiCommonUtil = new UICommonUtil(driver);
    }

    @Override
    public void verifyLCY2LCYRecurringTransactionDetailsOnVerifyPage(final Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Verify Page.");
        MoveMoneyVerifyPage.logger.info("LCY2LCYRecurring Transaction Details verified on Verify Page.");
    }

    @Override
    protected void validateRecurringFlow(final Transaction transactionDetail) {
        wait.until(ExpectedConditions.visibilityOf(verifyPageTitle));
        isFromAccountNameDisplayed(transactionDetail.getFromAccount());
        isFromAccountNumberDisplayed(transactionDetail.getFromAccount());
        if (!transactionDetail.getToAccount().getAccountName().isEmpty()) {
            isToAccountNameDisplayed(transactionDetail.getToAccount());
        }
        isToAccountNumberDisplayed(transactionDetail.getToAccount());
        isStartDateDisplayed(transactionDetail);
    }

    @Override
    public void verifyLCY2LCYNowTransactionDetailsOnVerifyPage(final Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        MoveMoneyVerifyPage.logger.info("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    @Override
    protected void validateNowFlow(final Transaction transactionDetail) {
        wait.until(ExpectedConditions.visibilityOf(verifyPageTitle));
        isFromAccountNameDisplayed(transactionDetail.getFromAccount());
        isFromAccountNumberDisplayed(transactionDetail.getFromAccount());
        isToAccountNameDisplayed(transactionDetail.getToAccount());
        isToAccountNumberDisplayed(transactionDetail.getToAccount());
        try {
            isPaymentDateDisplayed(DateUtil.getDateToString(DateUtil.DATE_FORMAT_MMMDYYYY, DateUtil.getSystemDate()));
        } catch (ParseException e) {
            logger.error("Date Conversion error: ", e);
            Assert.fail("Date Conversion error: ", e);
        }
        isYourReferenceTextDisplayed(transactionDetail.getYourReference());
        validatePurposeOfPayment(transactionDetail.getReasonForTransaction());
        validatePurposeForPaymentDestCountry(transactionDetail.getReasonForPaymentDestCountry());
    }

    @Override
    protected void isFromAccountNameDisplayed(final AccountDetails accountDetail) {
        Assert
            .assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyVerifyPageModel.LABEL_FROM, accountDetail.getAccountName(),
                UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
                "Given From Account Name not found.");
        MoveMoneyVerifyPage.logger.info("From Account Name displayed is :" + accountDetail.getAccountName());
        Reporter.log("From Account Name displayed is :" + accountDetail.getAccountName());
    }

    @Override
    protected void isFromAccountNumberDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyVerifyPageModel.LABEL_FROM,
            accountDetail.getAccountNumber(), UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given From Account Number not found.");
        MoveMoneyVerifyPage.logger.info("From Account Number displayed is :" + accountDetail.getAccountNumber());
        Reporter.log("From Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    @Override
    protected void isToAccountNameDisplayed(final AccountDetails accountDetail) {
        String labelToAccount = isLabelDisplayed(MoveMoneyVerifyPageModel.LABEL_TO, UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName) ? MoveMoneyVerifyPageModel.LABEL_TO : MoveMoneyVerifyPage.LABEL_PAYEE_NAME;
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(labelToAccount, accountDetail.getAccountName(),
            UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Name not found.");
        MoveMoneyVerifyPage.logger.info("To Account Name displayed is :" + accountDetail.getAccountName());
        Reporter.log("To Account Name displayed is :" + accountDetail.getAccountName());
    }

    @Override
    protected void isToAccountNumberDisplayed(final AccountDetails accountDetail) {
        String labelToAccount = isLabelDisplayed(MoveMoneyVerifyPageModel.LABEL_TO, UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName) ? MoveMoneyVerifyPageModel.LABEL_TO : MoveMoneyVerifyPage.LABEL_PAYEE_REFERENCE;
        Assert
            .assertTrue(uiCommonUtil.textByParentAndSibling(labelToAccount, accountDetail.getAccountNumber(),
                UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
                "Given To Account Number not found.");
        MoveMoneyVerifyPage.logger.info("To Account Number displayed is :" + accountDetail.getAccountNumber());
        Reporter.log("To Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    @Override
    protected void isPaymentDateDisplayed(final String paymentDate) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyVerifyPage.LABEL_PAYMENT_DATE, paymentDate,
            UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Payment Date not found.");
        logger.info("Payment Date displayed is: " + paymentDate);
        Reporter.log("Payment Date displayed is: " + paymentDate + ".| ");
    }

    @Override
    protected void isYourReferenceTextDisplayed(final String yourReference) {
        if (yourReference != null) {
            Assert.assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyVerifyPageModel.LABEL_YOUR_REFERENCE, yourReference,
                UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
                "Given Your Reference Text not found.");
            MoveMoneyVerifyPage.logger.info("Your Reference Text displayed is :" + yourReference);
            Reporter.log("Your Reference Text displayed is :" + yourReference);
        } else {
            logger.info("Your Reference Text is not Entered");
        }
    }

    private void validatePurposeOfPayment(String reasonForTransaction) {
        if (reasonForTransaction != null) {
            Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PURPOSE_OF_PAYMENT, reasonForTransaction,
                UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
                "Given Purpose of Payment Text not found.");
            logger.info("Purpose of Payment Text displayed is: " + reasonForTransaction);
            Reporter.log("Purpose of Payment Text displayed is: " + reasonForTransaction);
        } else {
            MoveMoneyVerifyPage.logger.info("Reason for transaction Text is not Entered");
        }
    }

    private void validatePurposeForPaymentDestCountry(String reasonForPaymentDestCountry) {
        if (reasonForPaymentDestCountry != null) {
            Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PURPOSE_OF_PAYMENT_DEST_COUNTRY,
                reasonForPaymentDestCountry, UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
                "Given Purpose of Payment Destination Country Text not found.");
            logger.info("Purpose of Payment Destination Country Text displayed is: " + reasonForPaymentDestCountry);
            Reporter.log("Purpose of Payment Destination Country Text displayed is: " + reasonForPaymentDestCountry);
        } else {
            MoveMoneyVerifyPage.logger.info("Reason For Payment Dest Country Text is not entered:");
        }
    }

    @Override
    protected void isAmountDisplayed(final String amount) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyVerifyPageModel.LABEL_AMOUNT, amount,
            UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Transfer Amount not found.");
        MoveMoneyVerifyPage.logger.info("Amount displayed is :" + amount);
        Reporter.log("Amount displayed is :" + amount);
    }

    @Override
    protected void isStartDateDisplayed(final Transaction transaction) {
        try {
            String startDate = DateUtil.getDateToString(MoveMoneyVerifyPageModel.DATE_FORMAT,
                transaction.getFirstDateOfTransaction());
            Assert.assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyVerifyPageModel.LABEL_START_DATE, startDate,
                UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Start Date not found.");
            MoveMoneyVerifyPage.logger.info("Start Date displayed is :" + startDate);
        } catch (ParseException e) {
            MoveMoneyCapturePageModel.logger.error(e);
            Assert.fail("Parsing to Payment Date Fail " + e.getMessage(), e);
        }

    }

    @Override
    protected void isFrequencyDisplayed(final String frequencyValue) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyVerifyPageModel.LABEL_FREQUENCY, frequencyValue,
            UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Frequency Value not found.");
        MoveMoneyVerifyPage.logger.info("Frequency Value displayed is :" + frequencyValue);
    }

    @Override
    protected void isDebitAmountDisplayed(final String amount) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_DEBIT_AMOUNT, amount, UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Transfer Amount not found.");
        MoveMoneyVerifyPage.logger.info("Amount displayed is :" + amount);
    }

    @Override
    protected void isNumberOfPaymentDisplayed(final String valueNOP) {
        Assert
            .assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyVerifyPage.LABEL_NUMBER_OF_PAYMENT, valueNOP,
                UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
                "Given Number Of Payment not found.");
        MoveMoneyVerifyPage.logger.info("Number Of Payment displayed is :" + valueNOP);
    }


    public boolean isLabelDisplayed(final String fieldLabel, final By page, final By pageFieldName) {
        boolean flag = false;
        List<WebElement> fieldLabels = driver.findElement(page).findElements(pageFieldName);
        for (WebElement label : fieldLabels) {
            jsx.executeScript(MoveMoneyVerifyPage.SCROLL_TO_VIEW, label);
            if (label.isDisplayed() && label.getText().contains(fieldLabel)) {
                flag = true;
            }
        }
        return flag;
    }

    @Override
    protected void isPaymentDateAsLaterDateDisplayed(final Transaction transaction) {
        String paymentDate;
        try {
            paymentDate = DateUtil.getDateToString(MoveMoneyVerifyPageModel.DATE_FORMAT, transaction.getLaterDate());
            Assert.assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyVerifyPage.LABEL_PAYMENT_DATE, paymentDate,
                UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Payment Date not found.");
            Reporter.log("Payment Date displayed is :" + paymentDate);
        } catch (ParseException e) {
            MoveMoneyVerifyPageModel.logger.error("Exception:", e);
            Assert.fail("Parsing to Payment Date Fail " + e.getMessage(), e);
        }

    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.MoveMoneyVerifyPageModel#clickCancelButton(boolean)
     */
    @Override
    public void clickCancelButton(final boolean isCancel) {
        wait.until(ExpectedConditions.elementToBeClickable(cancelButton));
        cancelButton.click();
        if (isCancel) {
            clickCancelPopUpCancelButton();
        } else {
            clickContinuePopupContinueButton();
            verifyPageTitle();
        }
    }

    @Override
    public void verifyPageTitle() {
        wait.until(ExpectedConditions.visibilityOf(verifyPageTitle));
        Assert.assertTrue(verifyPageTitle.isDisplayed(), "Verify Page is not displayed.");
        Reporter.log("Verify Page is displayed. | ");
    }

    @Override
    public void verifyM2NMInternationalLCY2LCYNowTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }
}
