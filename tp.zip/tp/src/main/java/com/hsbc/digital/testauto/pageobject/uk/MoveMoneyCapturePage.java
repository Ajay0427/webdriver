/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.uk;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;

/**
 * <p>
 * <b> This class will hold locators and functionality related methods for Move
 * MOney capture page specific to UK Entity </b>
 * </p>
 * 
 * @author Deepti Patil
 * 
 */
public class MoveMoneyCapturePage extends MoveMoneyCapturePageModel {

    private final By locatorSelectedPayeeAccountNumber = By.xpath("//div[contains(@id, 'myPayee')]//span[2]");

    public MoveMoneyCapturePage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    public void isPayeeNumberDisplayed(final AccountDetails accountDetail) {
        WebElement payeeAccountNumber = driver.findElements(locatorPayeeAccountNumber).isEmpty() ? driver
            .findElement(locatorSelectedPayeeAccountNumber) : driver.findElement(locatorPayeeAccountNumber);
        Assert.assertTrue(payeeAccountNumber.getText().trim().equalsIgnoreCase(accountDetail.getAccountNumber().trim()),
            "Payee Account Number does not match expected value.");
        Reporter.log("Payee Number matches : " + accountDetail.getAccountName());
    }

    @Override
    public By getLocatorSelectedPayeeAccountNumber() {
        return locatorSelectedPayeeAccountNumber;
    }
}
