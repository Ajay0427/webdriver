/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.cbh;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.UpdateMaturiryInstructionsDetails;
import com.hsbc.digital.testauto.pageobject.UpdateMaturityInstructionModel;

/**
 * <p>
 * <b> UpdateMaturityInstruction pom for cbh entity. </b>
 * </p>
 */
public class UpdateMaturityInstruction extends UpdateMaturityInstructionModel {

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(UpdateMaturityInstruction.class);
    // Dashboard Page Locators
    @FindBy(xpath = "//a[contains(text(),'Maturity instructions')]")
    private List<WebElement> updateMaturityLinkManageMenuList;

    @FindBy(xpath = "//a[contains(text(),'Maturity instructions')]")
    private WebElement updateMaturityLinkManageMenu;

    // Update Maturity Instruction Capture Page Locators
    @FindBy(xpath = "//div[@class='accountSummaryHeadContainer']//th[text()='Maturity  date']//following-sibling::td")
    private WebElement selectedAccountStartDate;

    @FindBy(xpath = "//table[contains(@id,'onMaturity')]//span[1]")
    private WebElement onMaturitySelectedItem;

    @FindBy(xpath = "//table[contains(@id,'onMaturity')]//input[contains(@id,'arrowid')]")
    private WebElement onMaturityListArrow;

    @FindBy(xpath = "//div[contains(@class,'onMaturity')]//table//tr")
    protected List<WebElement> onMaturityList;

    @FindBy(xpath = "//input[contains(@id,'includeInterest')]")
    private WebElement includeIntrestRadioButton;

    @FindBy(xpath = "//input[contains(@id,'withdrawIntrest')]")
    private WebElement withdrawIntrestRadioButton;

    @FindBy(xpath = " //table[contains(@id,'newFixedTerm')]//input[contains(@id,'arrowid')]")
    private WebElement newFixedTermArrow;

    @FindBy(xpath = "//div[contains(@id,'newFixedTerm')]//table//tr")
    private List<WebElement> newFixedTermList;

    @FindBy(xpath = "//table[contains(@id,'newFixedTerm')]//span[contains(text(),'Fixed') ]")
    private WebElement newFixedTermFixed;

    @FindBy(xpath = "//input[contains(@id,'arrowid') and contains (@id,'addFundsFromAccount')]")
    private WebElement addMoneyFromAccountArrow;

    @FindBy(xpath = "//div[contains(@class,'interestRates')]//span[@data-dojo-attach-point='selectedInterestRate']")
    private WebElement intrestRate;

    @FindBy(xpath = "//label[text()='New fixed term']")
    private WebElement newFixedTermLabel;

    // Locators on Update Maturity Review page
    @FindBy(xpath = "//div[contains(@id,'ReviewMaturityInstructions')]//dt[text()='Add money to']/following::span[1]")
    private WebElement AddFundsToAccountReview;

    @FindBy(xpath = "//div[contains(@id,'ReviewMaturityInstructions')]//dt[text()='Add money from']/following::span[1]")
    private WebElement AddFundsFromAccountReview;

    @FindBy(xpath = "//input[contains(@id,'TermsAndConditions')]")
    private WebElement termAndConditionCheckBox;

    @FindBy(xpath = "//div[contains(@id,'ReviewMaturityInstructions')]//dt[text()='On maturity']/following::dd[1]")
    protected WebElement onMaturityReview;

    @FindBy(xpath = " //dt[text()='New fixed term']/following-sibling::dd[1]")
    protected WebElement newFixedTermReview;

    @FindBy(xpath = "//div[contains(@id,'ReviewMaturityInstructions')]//dt[text()='Interest rate']/following::dd[1]")
    protected WebElement intrestRateReview;

    @FindBy(xpath = "//div[contains(@id,'ReviewMaturityInstructions')]//dt[text()='Account']/following::dd[1]//div//span[1]")
    protected WebElement accountFieldReview;

    @FindBy(xpath = "//div[contains(@id,'ReviewMaturityInstructions')]//dt[text()='Maturity date']/following::dd[1]")
    protected WebElement maturityDateReview;

    @FindBy(xpath = "//div[contains(@id,'ReviewMaturityInstructions')]//dt[text()='Maturity amount']/following::dd[1]")
    protected WebElement maturityAmountReview;

    @FindBy(xpath = "//div[contains(@id,'ReviewMaturityInstructions')]//dt[text()='Total amount']/following::dd[1]")
    protected WebElement totalAmountReview;

    @FindBy(xpath = "//div[contains(@id,'ReviewMaturityInstructions')]//dt[text()='Add money to']/following::dd[1]//div//span[1]")
    protected WebElement addMoneyToReview;

    @FindBy(xpath = "//div[contains(@id,'ReviewMaturityInstructions')]//dt[text()='Add money from']/following::dd[1]//div//span[1]")
    protected WebElement addMoneyFromReview;

    @FindBy(xpath = "//div[contains(@id,'ReviewMaturityInstructions')]//dt[text()='Amount to add']/following::dd[1]")
    protected WebElement amountToAddReview;

    @FindBy(xpath = "//div[contains(@id,'ReviewMaturityInstructions')]//dt[text()='New balance']/following::dd[1]")
    protected WebElement newBalanceReview;

    @FindBy(xpath = "//div[contains(@id,'ReviewMaturityInstructions')]//dt[text()='Renew amount']/following::dd[1]")
    protected WebElement renewAmountReview;

    // Locators on Update Maturity confirmation page

    @FindBy(xpath = "//p[text()='Update successful']")
    protected WebElement updateSuccessfulHeading;

    @FindBy(xpath = "//p[@data-dojo-attach-point='_confMsg']")
    protected WebElement confirmationMessage;

    protected static final String maturityOptionRenewTotalBalanceForCBH = "Renew for a new term";

    public UpdateMaturityInstruction(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    protected boolean isUpdateMaturityLinkDisplayed() {
        return !updateMaturityLinkManageMenuList.isEmpty() && updateMaturityLinkManageMenu.isDisplayed();
    }

    protected void clickUpdateMaturityLink() {
        updateMaturityLinkManageMenuList.get(0).click();
    }

    public void verifyCurrentMaturityInstruction() {

        Assert.assertTrue(selectedAccountBalance.isDisplayed(),
            "Account Balance field is not displayed under Current maturity instructions section");
        Reporter.log("Account Balance field is displayed as " + selectedAccountBalance.getText()
            + " under Current maturity instructions section");

        Assert.assertTrue(selectedAccountTerm.isDisplayed(),
            "Account term field is not displayed under Current maturity instructions section");
        Reporter.log("Account term field is displayed as" + selectedAccountTerm.getText()
            + "  under Current maturity instructions section");

        Assert.assertTrue(selectedAccountMaturityDate.isDisplayed(),
            "Account maturity date field is not displayed under Current maturity instructions section");
        Reporter.log("Account maturity date field is displayed as" + selectedAccountMaturityDate.getText()
            + "   under Current maturity instructions section");

        Assert.assertTrue(selectedAccountInterestrate.isDisplayed(),
            "Account Interest rate field is not displayed under Current maturity instructions section");
        Reporter.log("Account Interest rate field is displayed as" + selectedAccountInterestrate.getText()
            + "   under Current maturity instructions section");

        Assert.assertTrue(selectedAccountInterestMaturity.isDisplayed(),
            "Account Interest maturity field is not displayed under Current maturity instructions section");
        Reporter.log("Account Interest maturity field is displayed as" + selectedAccountInterestMaturity.getText()
            + "   under Current maturity instructions section");

    }

    public String selectOnMaturity() {
        onMaturityListArrow.click();
        int randomIndex = RandomUtil.generateIntNumber(1, onMaturityList.size());
        WebElement row = onMaturityList.get(randomIndex);
        row.click();
        return onMaturitySelectedItem.getText();
    }


    public String selectAddFundsFromAccount() {
        addMoneyFromAccountArrow.click();
        int randomIndex = RandomUtil.generateIntNumber(1, addMoneyFromAccountList.size());
        WebElement row = addMoneyFromAccountList.get(randomIndex);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", row);
        row.click();
        return selectedAccountNumberAddFundsTo.getText();
    }


    public String selectNewFixedTerm() {

        if (newFixedTermArrow.isDisplayed()) {

            newFixedTermArrow.click();
            int randomIndex = RandomUtil.generateIntNumber(1, newFixedTermList.size());
            WebElement row = newFixedTermList.get(randomIndex);
            row.click();
            return newFixedTermFixed.getText();
        }

        if (newFixedTermFixed.isDisplayed()) {
            Reporter.log("Term is fixed and displayed as " + newFixedTermFixed.getText());
            return newFixedTermFixed.getText();
        }

        return newFixedTermFixed.getText();
    }

    public UpdateMaturiryInstructionsDetails captureUpdateMaturityDetails() {
        UpdateMaturiryInstructionsDetails objUpdateMaturiryInstructionsDetails = new UpdateMaturiryInstructionsDetails();
        String maturityType = selectOnMaturity();


        if (maturityType.contains(UpdateMaturityInstructionModel.maturityOptionRenewTotalBalance)) {
            objUpdateMaturiryInstructionsDetails.setnewFixedTerm(selectNewFixedTerm());
            int randomIndex = RandomUtil.generateIntNumber(1, 2);
            if (randomIndex == 1) {
                includeIntrestRadioButton.click();
            } else {
                withdrawIntrestRadioButton.click();
                objUpdateMaturiryInstructionsDetails.setSelectAddFundAccount(selectAddFundsToAccount());

            }
            objUpdateMaturiryInstructionsDetails.setIntrestRate(intrestRate.getText());
        }
        if (maturityType.contains(UpdateMaturityInstructionModel.maturityOptionDoNotRenew)) {
            objUpdateMaturiryInstructionsDetails.setSelectAddFundAccount(selectAddFundsToAccount());
        }

        if (maturityType.contains(UpdateMaturityInstructionModel.maturityOptionAddFunds)) {
            objUpdateMaturiryInstructionsDetails.setSelectAddFundAccount(selectAddFundsFromAccount());
            objUpdateMaturiryInstructionsDetails.setnewFixedTerm(selectNewFixedTerm());
            objUpdateMaturiryInstructionsDetails.setAmountToAdd(enterAmountToAdd());
            newFixedTermLabel.click();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            objUpdateMaturiryInstructionsDetails.setIntrestRate(intrestRate.getText());

        }

        if (maturityType.contains(UpdateMaturityInstructionModel.maturityOptionAWithdrawFunds)) {
            objUpdateMaturiryInstructionsDetails.setSelectAddFundAccount(selectAddFundsToAccount());
            objUpdateMaturiryInstructionsDetails.setnewFixedTerm(selectNewFixedTerm());
            objUpdateMaturiryInstructionsDetails.setAmountWithDraw(enterAmountToWithdraw());
            newFixedTermLabel.click();
        }
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        return objUpdateMaturiryInstructionsDetails;

    }

    public void verifyUpdateMaturityReviewPage(final UpdateMaturiryInstructionsDetails objUpdateMaturiryInstructionsDetails) {

        Assert.assertTrue(headingVerify.isDisplayed(), "Verify Update Maturity page is not displayed");
        Reporter.log("Verify Maturity page is displayed");

        String onMaturityReviewPage = onMaturityReview.getText();

        if (onMaturityReviewPage.contains(UpdateMaturityInstructionModel.maturityOptionRenewTotalBalance)) {

            Assert.assertTrue(newFixedTermReview.getText().contains(objUpdateMaturiryInstructionsDetails.getnewFixedTerm()),
                "Fixed term did not match");
            Assert.assertTrue(intrestRateReview.getText().contains(objUpdateMaturiryInstructionsDetails.getoIntrestRate()),
                "Intrest Rate does not match");
            verifyOtherDetailsReviewPageforRenewForNewTerm();
        }

        if (onMaturityReviewPage.contains(UpdateMaturityInstructionModel.maturityOptionDoNotRenew)) {

            Assert.assertTrue(
                AddFundsToAccountReview.getText().contains(objUpdateMaturiryInstructionsDetails.getSelectAddFundAccount()),
                "Add Funds To Account did not match");
            verifyOtherDetailsReviewPageforDoNotRenew();
        }

        if (onMaturityReviewPage.contains(UpdateMaturityInstructionModel.maturityOptionAddFunds)) {
            String amountToAdd = amountToAddReview.getText();
            Assert.assertTrue(newFixedTermReview.getText().contains(objUpdateMaturiryInstructionsDetails.getnewFixedTerm()),
                "Fixed term did not match");
            Assert.assertTrue(
                AddFundsFromAccountReview.getText().contains(objUpdateMaturiryInstructionsDetails.getSelectAddFundAccount()),
                "Add Funds To Account did not match");
            if (amountToAdd.contains(",")) {
                amountToAdd = amountToAdd.replace(",", "");
            }
            Assert.assertTrue(amountToAdd.contains(objUpdateMaturiryInstructionsDetails.getAmountToAdd()),
                "Add Funds amount did not match");
            verifyOtherDetailsReviewPageforAddFunds();
        }

        if (onMaturityReviewPage.contains(UpdateMaturityInstructionModel.maturityOptionAWithdraw)) {
            Assert.assertTrue(newFixedTermReview.getText().contains(objUpdateMaturiryInstructionsDetails.getnewFixedTerm()),
                "Fixed term did not match");
            Assert.assertTrue(
                AddFundsToAccountReview.getText().contains(objUpdateMaturiryInstructionsDetails.getSelectAddFundAccount()),
                "Add Funds To Account did not match");
            Assert.assertTrue(amountToWithdraw.getText().contains(objUpdateMaturiryInstructionsDetails.getAmountWithdraw()),
                "Add Funds amount did not match");
            verifyOtherDetailsReviewPageforWithrawFunds();
        }
    }

    public void selectTnCReviewPage() {

        Assert.assertTrue(termAndConditionCheckBox.isDisplayed(), "Term and Condition check box is not displayed");
        termAndConditionCheckBox.click();
        Reporter.log("Term and condition cjeck box is selected");

    }

    public void verifyOtherDetailsReviewPageforRenewForNewTerm() {
        Assert.assertTrue(accountFieldReview.isDisplayed(), "Account field is not displayed");
        Reporter.log("Account field is displayed as " + accountFieldReview.getText());

        Assert.assertTrue(maturityDateReview.isDisplayed(), "Maturity Date is not displayed");
        Reporter.log("Maturity Date is displayed as " + maturityDateReview.getText());

        Assert.assertTrue(maturityAmountReview.isDisplayed(), "Maturity Amount is not displayed");
        Reporter.log("Maturity Amount is displayed as " + maturityAmountReview.getText());

    }

    public void verifyOtherDetailsReviewPageforDoNotRenew() {
        Assert.assertTrue(accountFieldReview.isDisplayed(), "Account field is not displayed");
        Reporter.log("Account field is displayed as " + accountFieldReview.getText());

        Assert.assertTrue(maturityDateReview.isDisplayed(), "Maturity Date is not displayed");
        Reporter.log("Maturity Date is displayed as " + maturityDateReview.getText());

        Assert.assertTrue(maturityAmountReview.isDisplayed(), "Maturity Amount is not displayed");
        Reporter.log("Maturity Amount is displayed as " + maturityAmountReview.getText());

        Assert.assertTrue(addMoneyToReview.isDisplayed(), "Add money to is not displayed");
        Reporter.log("Add money to is displayed as " + addMoneyToReview.getText());

    }

    public void verifyOtherDetailsReviewPageforAddFunds() {
        Assert.assertTrue(accountFieldReview.isDisplayed(), "Account field is not displayed");
        Reporter.log("Account field is displayed as " + accountFieldReview.getText());

        Assert.assertTrue(maturityDateReview.isDisplayed(), "Maturity Date is not displayed");
        Reporter.log("Maturity Date is displayed as " + maturityDateReview.getText());

        Assert.assertTrue(maturityAmountReview.isDisplayed(), "Maturity Amount is not displayed");
        Reporter.log("Maturity Amount is displayed as " + maturityAmountReview.getText());

        Assert.assertTrue(addMoneyFromReview.isDisplayed(), "Add money from is not displayed");
        Reporter.log("Add money from is displayed as " + addMoneyFromReview.getText());

        Assert.assertTrue(amountToAddReview.isDisplayed(), "Amount to Add is not displayed");
        Reporter.log("Amount to add is displayed as " + amountToAddReview.getText());

        Assert.assertTrue(newBalanceReview.isDisplayed(), "New Balance is not displayed");
        Reporter.log("New Balance is displayed as " + newBalanceReview.getText());

    }

    public void verifyOtherDetailsReviewPageforWithrawFunds() {
        Assert.assertTrue(accountFieldReview.isDisplayed(), "Account field is not displayed");
        Reporter.log("Account field is displayed as " + accountFieldReview.getText());

        Assert.assertTrue(maturityDateReview.isDisplayed(), "Maturity Date is not displayed");
        Reporter.log("Maturity Date is displayed as " + maturityDateReview.getText());

        Assert.assertTrue(maturityAmountReview.isDisplayed(), "Maturity Amount is not displayed");
        Reporter.log("Maturity Amount is displayed as " + maturityAmountReview.getText());

        Assert.assertTrue(addMoneyToReview.isDisplayed(), "Add money from is not displayed");
        Reporter.log("Add money to is displayed as " + addMoneyToReview.getText());

        Assert.assertTrue(renewAmountReview.isDisplayed(), "Renew Amount is not displayed");
        Reporter.log("renew Amount is displayed as " + renewAmountReview.getText());

    }

    public void verifyUpdateMaturityConfirmationPage() {

        Assert
            .assertTrue(updateSuccessfulHeading.isDisplayed(), "Upadet suuccessful heading is not displayed on Confirmation page");
        Reporter.log("Upadet suuccessful heading is displayed as" + updateSuccessfulHeading.getText());

        Assert.assertTrue(confirmationMessage.isDisplayed(), "Confirmation message is not displayed on confirmation page");
        Reporter.log("Confirmation message is displayed as " + confirmationMessage.getText());
    }

    public void clicksConfirmButton() {
        Assert.assertTrue(termAndConditionCheckBox.isDisplayed(), "Term and Condition check box i snot displayed is not displayed");
        termAndConditionCheckBox.click();
        Reporter.log("Term and Condition is selected");
        Assert.assertTrue(confirmButton.isDisplayed(), "Confirm button is not displayed");
        Reporter.log("Confirm button is displayed");
        confirmButton.click();
        Reporter.log("Clicks on Confirm button");
    }

}
