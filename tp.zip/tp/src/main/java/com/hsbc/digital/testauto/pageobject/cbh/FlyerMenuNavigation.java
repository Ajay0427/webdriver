/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.cbh;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Flyover
 * Menu for Canada entity. </b>
 * </p>
 */
public class FlyerMenuNavigation extends FlyerMenuNavigationModel {

    /*
     * -------- HEADER LINKS --------
     */
    @FindBy(xpath = "//a[contains(@class,'navigation-link')]//span[contains(text(),'Products & services')]")
    protected WebElement productAndServicesLinkHeader;

    @FindBy(xpath = "//a[contains(@class,'navigation-link')]//span[contains(text(),'Investments & financial planning')]")
    protected WebElement myInvestmentsAndFinancialLinkHeader;

    /*
     * FOR MASS
     */
    /*
     * My Banking Header Links
     */
    @FindBy(xpath = "//span[text()='My Accounts']")
    public WebElement myAccountLinkMyBankingHeader;

    /*
     * My Banking - My investment accounts Links
     */
    @FindBy(linkText = "Launch HSBC InvestDirect")
    private WebElement launchHSBCInvestLinkMyInvestmentMyBankingHeader;

    @FindBy(linkText = "Logon to HSBC Private Investment Management")
    private WebElement logonToHSBCPrivateLinkMyInvestmentMyBankingHeader;

    /*
     * My Banking - Report a lost or stolen card Links
     */
    @FindBy(linkText = "Report a lost or stolen card")
    private WebElement reportALostCardLinkReportLostCardMyBankingHeader;

    @FindBy(linkText = "Request Replacement PIN")
    private WebElement requestReplacementPin;

    /*
     * My Banking - My profile Links
     */
    @FindBy(linkText = "Update Personal details")
    private WebElement updatePersonalDetailsLinkMyProfileMyBankingHeader;

    @FindBy(xpath = "//a[text()='Notification settings']")
    private WebElement notificationSettingLinkMyProfileMyBankingHeader;

    @FindBy(xpath = "Alert settings")
    private WebElement alertSettingsLinkMyProfileMyBankingHeader;

    /*
     * My Banking - Move Money Header Links
     */
    @FindBy(linkText = "Pay or transfer")
    private WebElement payOrTransferLinkMoveMoneyMyBankingHeader;

    @FindBy(linkText = "Future payments or transfers")
    private WebElement futurePaymentsOrTransfersLinkMoveMoneyMyBankingHeader;

    @FindBy(linkText = "Pending INTERAC e-Transfer")
    private WebElement pendingINTERACLinkMoveMoneyMyBankingHeader;

    @FindBy(xpath = "//a[text()='Bill Payment history']")
    private WebElement billPaymentHistoryLinkMoveMoneyMyBankingHeader;

    /*
     * My Banking - Global view Links
     */
    @FindBy(linkText = "Add or remove a country")
    private WebElement addOrRemoveACountryLinkGlobalViewMyBankingHeader;

    @FindBy(linkText = "Online transfer and payment limits")
    private WebElement manageInternetBankingLimitsLink;

    /*
     * My Banking - Security Links
     */
    @FindBy(linkText = "Switch my Security Device")
    private WebElement switchMySecurityLinkSecurityMyBankingHeader;

    @FindBy(linkText = "Change personal security details")
    private WebElement changePersonalSecurityLinkSecurityMyBankingHeader;

    @FindBy(linkText = "Change my password")
    private WebElement changeMyPasswordLinkSecurityMyBankingHeader;

    @FindBy(linkText = "Help with my Security Device")
    private WebElement helpWithMySecurityLinkSecurityMyBankingHeader;

    @FindBy(linkText = "Security centre")
    private WebElement securityCenterLinkSecurityMyBankingHeader;

    /*
     * My Banking - Cheques Links
     */

    @FindBy(linkText = "Order cheques")
    private WebElement orderChequesLinkChequesMyBankingHeader;

    @FindBy(linkText = "Stop a cheque")
    private WebElement stopAChequeLinkChequesMyBankingHeader;

    @Override
    protected WebElement getStopAChequeLinkChequesMyBankingHeader() {
        return stopAChequeLinkChequesMyBankingHeader;
    }

    /*
     * My Banking - Travel Links
     */
    @FindBy(linkText = "Notify us of travel")
    private WebElement notifyUsOfTravelLinkTravelMyBankingHeader;

    /*
     * My Banking - Account services Links
     */
    @FindBy(linkText = "Rename accounts")
    private WebElement renameAccountsLinkAccountServicesMyBankingHeader;

    @FindBy(linkText = "View foreign exchange rates")
    private WebElement viewForeignExchangeLinkAccountServicesMyBankingHeader;

    @FindBy(linkText = "Order a chequebook")
    private WebElement orderChequeBook;

    /*
     * My Banking - Documents Links
     */
    @FindBy(linkText = "View and print statements")
    private WebElement viewAndPrintStatementsLinkDocumentsMyBankingHeader;

    @FindBy(linkText = "View terms and conditions")
    private WebElement viewTermsAndConditionsLinkDocumentsMyBankingHeader;

    @FindBy(linkText = "Statements")
    private WebElement statements;

    /*
     * Products & Services - Account Opening Links
     */
    @FindBy(linkText = "Everyday Banking")
    private WebElement everydayBankingLinkAccountOpeningProductAndServicesHeader;

    @FindBy(xpath = "//a[text()='GICs and Term Deposits']")
    private WebElement gicAndTermDepositsLinkAccountOpeningProductAndServicesHeader;

    @FindBy(xpath = "//a[text()='Time deposits']")
    private WebElement termDepositsLinkEverydayBankingProductAndServicesHeader;

    @FindBy(xpath = "//a[text()='Current accounts']")
    private WebElement currentAccountProductAndServicesHeader;

    @FindBy(xpath = "//a[text()='Savings accounts']")
    private WebElement savingAccountLinkEverydayBankingProductAndServicesHeader;

    @FindBy(xpath = "//a[text()='Tax-Free Savings Accounts (TFSA)']")
    private WebElement taxFreeSavingsLinkAccountOpeningProductAndServicesHeader;

    /*
     * Products & Services - Advice And Tools Links
     */
    @FindBy(linkText = "Saving for your goals")
    private WebElement savingForGoalsLinkAdviceAndToolsProductAndServicesHeader;

    @FindBy(linkText = "Get a travel insurance quote")
    private WebElement getATravelLinkAdviceAndToolsProductAndServicesHeader;

    @FindBy(linkText = "Travel insurance FAQs")
    private WebElement travelInsuranceLinkAdviceAndToolsProductAndServicesHeader;

    @FindBy(linkText = "Chequing account interest rates")
    private WebElement chequingAccountLinkAdviceAndToolsProductAndServicesHeader;

    @FindBy(linkText = "Savings account interest rates")
    private WebElement savingAccountInterestLinkAdviceAndToolsProductAndServicesHeader;

    @FindBy(linkText = "Foreign currency interest rates")
    private WebElement foreignCurrencyInterestLinkAdviceAndToolsProductAndServicesHeader;

    @FindBy(linkText = "Foreign currency converter and exchange rates")
    private WebElement foreignCurrencyConverterLinkAdviceAndToolsProductAndServicesHeader;

    @FindBy(linkText = "Life stage calculators")
    private WebElement lifeStageCalculatorsLinkAdviceAndToolsProductAndServicesHeader;

    @FindBy(linkText = "Personal service charges statement of disclosure")
    private WebElement personalServiceChargesLinkAdviceAndToolsProductAndServicesHeader;

    @FindBy(xpath = "//a[contains(text(),'Powers of attorney and joint deposit accounts info')]")
    private WebElement powersOfAttorneyLinkAdviceAndToolsProductAndServicesHeader;

    /*
     * Products & Services - Banking Links
     */
    @FindBy(linkText = "Products overview")
    private WebElement productsOverviewLinkBankingProductAndServicesHeader;

    /*
     * Products & Services - Knowledge Center Links
     */
    @FindBy(linkText = "Mortgage calculators")
    private WebElement mortgageCalculatorsLinkKnowledgeCentreProductAndServicesHeader;

    @FindBy(linkText = "Mortgage FAQs")
    private WebElement mortgageFQAsLinkKnowledgeCentreProductAndServicesHeader;

    @FindBy(linkText = "RRSP calculators")
    private WebElement rrspCalculatorLinkKnowledgeCentreProductAndServicesHeader;

    @FindBy(linkText = "Mortgage rates")
    private WebElement mortgageRatesLinkKnowledgeCentreProductAndServicesHeader;

    /*
     * Products & Services - Borrowing Links
     */
    @FindBy(linkText = "Borrowing overview")
    private WebElement borrowingOverviewLinkBorrowingProductAndServicesHeader;

    @FindBy(linkText = "Mortgages")
    private WebElement mortgagesLinkBorrowingProductAndServicesHeader;

    @FindBy(linkText = "Loans")
    private WebElement loansLinkBorrowingProductAndServicesHeader;

    @FindBy(linkText = "Credit Cards")
    private WebElement creditCardsLinkBorrowingProductAndServicesHeader;

    /*
     * Products & Services - Ways to bank Links
     */
    @FindBy(linkText = "Online Banking")
    private WebElement onlineBankingLinkWaysToBankProductAndServicesHeader;

    @FindBy(linkText = "ATM")
    private WebElement atmLinkWaysToBankProductAndServicesHeader;

    @FindBy(linkText = "Mobile banking")
    private WebElement mobileBankingLinkWaysToBankProductAndServicesHeader;

    @FindBy(linkText = "Telephone Banking")
    private WebElement telephoneBankingLinkWaysToBankProductAndServicesHeader;

    @FindBy(linkText = "Branch")
    private WebElement branchLinkWaysToBankProductAndServicesHeader;

    @FindBy(linkText = "INTERAC e-Transfer")
    private WebElement interacETransferLinkWaysToBankProductAndServicesHeader;

    /*
     * Products & Services - Insurance Links
     */
    @FindBy(linkText = "HSBC Travel Insurance")
    private WebElement hsbcTravelInsuranceLinkInsuranceProductAndServicesHeader;

    /*
     * Products & Services - HSBC Premier Links
     */
    @FindBy(linkText = "HSBC Premier overview")
    private WebElement hsbcPremierOverviewLinkHSBCPremierProductAndServicesHeader;

    /*
     * Products & Services - HSBC Advance Links
     */
    @FindBy(linkText = "HSBC Advance overview")
    private WebElement hsbcAdvanceOverviewLinkHSBCAdvanceProductAndServicesHeader;

    /*
     * Investments and Financial planning - Advice and insights Links
     */
    @FindBy(linkText = "Investment insights centre")
    private WebElement investmentInsightLinkAdviceInsightInvestmentsHeader;

    @FindBy(linkText = "Stock Market GIC Market Tracker")
    private WebElement stockMarketGICLinkAdviceInsightInvestmentsHeader;

    @FindBy(linkText = "HSBC Mutual Fund Information & resources")
    private WebElement hsbcMutualFundLinkAdviceInsightInvestmentsHeader;

    @FindBy(linkText = "Self-directed online investment tools & resources")
    private WebElement selfDirectedOnlineInvestmentLinkAdviceInsightInvestmentsHeader;

    @FindBy(linkText = "Self-directed online investing FAQs")
    private WebElement selfDirectedOnlineInvestingLinkAdviceInsightInvestmentsHeader;

    @FindBy(linkText = "Wealth Planning")
    private WebElement wealthPlanningLinkAdviceInsightInvestmentsHeader;

    /*
     * Investments and Financial planning - Investment solutions Links
     */
    @FindBy(linkText = "Term Deposits")
    private WebElement termDepositsLinkInvestmentsolutionsInvestmentsHeader;

    @FindBy(linkText = "Guranteed Investment Certificates (GIC)")
    private WebElement guranteedInvestmentCertificatesLinkInvestmentsolutionsInvestmentsHeader;

    @FindBy(linkText = "Mutual Funds")
    private WebElement mutualFundsLinkInvestmentsolutionsInvestmentsHeader;

    @FindBy(linkText = "Managed Solutions")
    private WebElement managesSolutionsLinkInvestmentsolutionsInvestmentsHeader;

    @FindBy(linkText = "Registered Products")
    private WebElement registeredProductsLinkInvestmentsolutionsInvestmentsHeader;

    @FindBy(linkText = "Tax-Free Savings Accounts (TFSA)")
    private WebElement taxFreeSavingsLinkInvestmentsolutionsInvestmentsHeader;

    @FindBy(linkText = "Self-directed online investing")
    private WebElement selfDirectedOnlineInvestingLinkInvestmentsolutionsInvestmentsHeader;

    @FindBy(linkText = "Private Investment Management")
    private WebElement privateInvestmentManagementLinkInvestmentsolutionsInvestmentsHeader;

    /*
     * Investments and Financial planning - Retiring and Education Links
     */
    @FindBy(linkText = "Plan for a comfortable retirement")
    private WebElement planForAComfortableLinkRetiringAndEducationInvestmentsHeader;

    @FindBy(linkText = "Receive an income in retirement")
    private WebElement receiveAnIncomeLinkRetiringAndEducationInvestmentsHeader;

    @FindBy(linkText = "Saving for education")
    private WebElement savingForEducationLinkRetiringAndEducationInvestmentsHeader;

    @FindBy(linkText = "Grow your wealth")
    private WebElement growYourWealthLinkRetiringAndEducationInvestmentsHeader;

    @FindBy(linkText = "Plan your children's future")
    private WebElement planYourChildrenLinkRetiringAndEducationInvestmentsHeader;

    @FindBy(linkText = "Plan your retirement")
    private WebElement planYourRetirementLinkRetiringAndEducationInvestmentsHeader;

    @FindBy(linkText = "Live your retirement")
    private WebElement liveYourRetirementLinkRetiringAndEducationInvestmentsHeader;

    /*
     * Investments and Financial planning - HSBC Premier Link
     */
    @FindBy(linkText = "HSBC Premier overview")
    private WebElement hsbcPremierOverviewLinkHSBCPremierInvestmentsHeader;

    /*
     * Investments and Financial planning - HSBC Advance Link
     */
    @FindBy(linkText = "HSBC Advance overview")
    private WebElement hsbcAdvanceOverviewLinkHSBCAdvanceInvestmentsHeader;

    /*
     * CONTACT HSBC
     */
    @FindBy(linkText = "Contact and support")
    private WebElement contactAndSupportLinkContactHSBCHeader;

    @FindBy(linkText = "Send a message")
    private WebElement sendAMessageLinkContactHSBCHeader;

    @FindBy(linkText = "Find a branch or ATM")
    private WebElement findABranchOrATMLinkContactHSBCHeader;

    @FindBy(linkText = "Have a specialist contact me")
    private WebElement haveASpecialistLinkContactHSBCHeader;

    @FindBy(linkText = "Book an appointment")
    private WebElement bookAnAppointmentLinkContactHSBCHeader;

    @FindBy(linkText = "HSBC on social media")
    private WebElement hsbcOnSocialMediaLinkContactHSBCHeader;

    /*
     * Existing Locators
     */
    @FindBy(linkText = "Remove country from Global View")
    public WebElement addRemoveCountryLink;

    // @FindBy(linkText = "Rename accounts")
    // public WebElement renameAccountsLink;

    @FindBy(xpath = "//a[text()='Rename accounts']")
    public WebElement renameAccountsLink;

    @FindBy(xpath = "//*[@data-uid= 'lostStolenCard']")
    public WebElement reportLostStolenCard;

    @FindBy(linkText = "Future payments")
    public WebElement futurePayment;

    @FindBy(xpath = "//a[text()='GICs and Term Deposits']")
    public WebElement GICsAndTDLink;

    @FindBy(xpath = ".//a[@data-uid='payeemanagement']")
    private WebElement linkMyPayees;

    public FlyerMenuNavigation(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    /*
     * Story 38 - User Dashboard Interface
     */
    /*
     * Header Methods for Mass
     */
    /**
     * This is to verify all the Header Links for Mass on the dashboard
     */
    @Override
    public void verifyAllHeaderLinksForMass() {
        verifyMyBankingLinksHeaderForMass();
        verifyProductAndServicesLinksHeaderForMass();
        verifyMyInvestmentsAndFinancialLinksHeaderForMass();
        verifyContactHSBCLinksHeaderForMass();
    }

    /**
     * This is to verify My Banking Links for Mass in Header on the dashboard
     */
    private void verifyMyBankingLinksHeaderForMass() {
        mouseOverOnHeader(myBankingLinkHeader);
        myBankingGeneralLinks();
        myBankingMyInvestmentAccountsLinks();
        myBankingReportLostStolenCardLinks();
        myBankingMyProfileLinks();
        myBankingMoveMoneyLinks();
        myBankingGlobalViewLinks();
        myBankingSecurityLinks();
        myBankingChequesLinks();
        myBankingTravelLinks();
        myBankingAccountServicesLink();
        myBankingDocumentsLinks();
    }

    /**
     * This is to verify My Banking General Links in Header on the dashboard
     */
    public void myBankingGeneralLinks() {
        assertAndReportElementIsDisplayed(myAccountLinkMyBankingHeader, "My Account Link in My Banking is displayed",
            "My Account Link in My Banking is not displayed");
    }

    /**
     * This is to verify My Banking Investment Account Links in Header on the
     * dashboard
     */
    public void myBankingMyInvestmentAccountsLinks() {
        assertAndReportElementIsDisplayed(launchHSBCInvestLinkMyInvestmentMyBankingHeader,
            "Launch HSBC InvestDirect Link in My Banking is displayed",
            "Launch HSBC InvestDirect Link in My Banking is not displayed");
        assertAndReportElementIsDisplayed(logonToHSBCPrivateLinkMyInvestmentMyBankingHeader,
            "Logon to HSBC Private Investment Management Link in My Banking is displayed",
            "Logon to HSBC Private Investment Management Link in My Banking is not displayed");
    }

    /**
     * This is to verify My Banking Report A Lost Or Stolen Card Links in
     * Header on the dashboard
     */
    public void myBankingReportLostStolenCardLinks() {
        assertAndReportElementIsDisplayed(reportALostCardLinkReportLostCardMyBankingHeader,
            "Report a lost or stolen card Link in My Banking is displayed",
            "Report a lost or stolen card Link in My Banking is not displayed");
    }

    /**
     * This is to verify My Banking My Profile Links in Header on the dashboard
     */
    public void myBankingMyProfileLinks() {
        assertAndReportElementIsDisplayed(updatePersonalDetailsLinkMyProfileMyBankingHeader,
            "Update Personal details Link in My Banking is displayed",
            "Update Personal details Link in My Banking is not displayed");
        assertAndReportElementIsDisplayed(notificationSettingLinkMyProfileMyBankingHeader,
            "Statement/notification options Link in My Banking is displayed",
            "Statement/notification options Link in My Banking is not displayed");
        assertAndReportElementIsDisplayed(alertSettingsLinkMyProfileMyBankingHeader,
            "Alert settings Link in My Banking is displayed", "Alert settings Link in My Banking is not displayed");
    }

    /**
     * This is to verify My Banking Move Money Links in Header on the dashboard
     */
    public void myBankingMoveMoneyLinks() {
        assertAndReportElementIsDisplayed(payOrTransferLinkMoveMoneyMyBankingHeader,
            "Pay or transfer Link in My Banking is displayed", "Pay or transfer Link in My Banking is not displayed");
        assertAndReportElementIsDisplayed(futurePaymentsOrTransfersLinkMoveMoneyMyBankingHeader,
            "Future payments or transfers Link in My Banking is displayed",
            "Future payments or transfers Link in My Banking is not displayed");
        assertAndReportElementIsDisplayed(myPayeesLinkMoveMoneyMyBankingHeader, "My payees Link in My Banking is displayed",
            "My payees Link in My Banking is not displayed");
        assertAndReportElementIsDisplayed(pendingINTERACLinkMoveMoneyMyBankingHeader,
            "Pending INTERAC e-Transfer Link in My Banking is displayed",
            "Pending INTERAC e-Transfer Link in My Banking is not displayed");
        assertAndReportElementIsDisplayed(billPaymentHistoryLinkMoveMoneyMyBankingHeader,
            "Bill payment history Link in My Banking is displayed", "Bill payment history Link in My Banking is not displayed");
    }

    /**
     * This is to verify My Banking Global View Links in Header on the
     * dashboard
     */
    public void myBankingGlobalViewLinks() {
        assertAndReportElementIsDisplayed(addOrRemoveACountryLinkGlobalViewMyBankingHeader,
            "Add or remove a country Link in My Banking is displayed",
            "Add or remove a country Link in My Banking is not displayed");
    }

    /**
     * This is to verify My Banking Security Links in Header on the dashboard
     */
    public void myBankingSecurityLinks() {
        assertAndReportElementIsDisplayed(switchMySecurityLinkSecurityMyBankingHeader,
            "Switch my Security Device Link in My Banking is displayed",
            "Switch my Security Device Link in My Banking is not displayed");
        assertAndReportElementIsDisplayed(changePersonalSecurityLinkSecurityMyBankingHeader,
            "Change personal security details Link in My Banking is displayed",
            "Change personal security details Link in My Banking is not displayed");
        assertAndReportElementIsDisplayed(changeMyPasswordLinkSecurityMyBankingHeader,
            "Change my password Link in My Banking is displayed", "Change my password Link in My Banking is not displayed");
        assertAndReportElementIsDisplayed(helpWithMySecurityLinkSecurityMyBankingHeader,
            "Help with my Security Device Link in My Banking is displayed",
            "Help with my Security Device in My Banking is not displayed");
        assertAndReportElementIsDisplayed(securityCenterLinkSecurityMyBankingHeader,
            "Security centre Link in My Banking is displayed", "Security centre Link in My Banking is not displayed");
    }

    /**
     * This is to verify My Banking Cheques Links in Header on the dashboard
     */
    public void myBankingChequesLinks() {
        assertAndReportElementIsDisplayed(orderChequesLinkChequesMyBankingHeader, "Order cheques Link in My Banking is displayed",
            "Order cheques Link in My Banking is not displayed");
        assertAndReportElementIsDisplayed(stopAChequeLinkChequesMyBankingHeader, "Stop a cheque Link in My Banking is displayed",
            "Stop a cheque Link in My Banking is not displayed");
    }

    /**
     * This is to verify My Banking Travel Links in Header on the dashboard
     */
    public void myBankingTravelLinks() {
        assertAndReportElementIsDisplayed(notifyUsOfTravelLinkTravelMyBankingHeader,
            "Notify us of travel Link in My Banking is displayed", "Notify us of travel Link in My Banking is not displayed");
    }

    /**
     * This is to verify My Banking Account Services Links in Header on the
     * dashboard
     */
    public void myBankingAccountServicesLink() {
        assertAndReportElementIsDisplayed(renameAccountsLinkAccountServicesMyBankingHeader,
            "Rename accounts Link in My Banking is displayed", "Rename accounts in My Banking is not displayed");
        assertAndReportElementIsDisplayed(viewForeignExchangeLinkAccountServicesMyBankingHeader,
            "View foreign exchange rates Link in My Banking is displayed",
            "View foreign exchange rates Link in My Banking is not displayed");
    }

    /**
     * This is to verify My Banking Documents Links in Header on the dashboard
     */
    public void myBankingDocumentsLinks() {
        assertAndReportElementIsDisplayed(viewAndPrintStatementsLinkDocumentsMyBankingHeader,
            "View and print statements Link in My Banking is displayed",
            "View and print statements Link in My Banking is not displayed");
        assertAndReportElementIsDisplayed(viewTermsAndConditionsLinkDocumentsMyBankingHeader,
            "View terms and conditions Link in My Banking is displayed",
            "View terms and conditions Link in My Banking is not displayed");
    }

    /**
     * This is to verify All the Product And Services Links in Header for MASS
     * on the dashboard
     */
    private void verifyProductAndServicesLinksHeaderForMass() {
        mouseOverOnHeader(productAndServicesLinkHeader);
        productAndServicesAccountOpeningLinks();
        productAndServicesAdviceAndToolsLinks();
        productAndServicesBankingLinks();
        productAndServicesKnowledgeCenterLinks();
        productAndServicesBorrowingLinks();
        productAndServicesWaysToBankLinks();
        productAndServicesInsuranceLinks();
        productAndServicesHSBCPremierLinks();
        productAndServicesHSBCAdvanceLinks();
    }

    /**
     * This is to verify Product And Services Account Opening Links in Header
     * on the dashboard
     */
    public void productAndServicesAccountOpeningLinks() {
        assertAndReportElementIsDisplayed(everydayBankingLinkAccountOpeningProductAndServicesHeader,
            "Everyday Banking Link in Product And Services is displayed",
            "Everyday Banking Link in Product And Services is not displayed");
        assertAndReportElementIsDisplayed(gicAndTermDepositsLinkAccountOpeningProductAndServicesHeader,
            "GICs and Term Deposits Link in Product And Services is displayed",
            "GICs and Term Deposits Link in Product And Services is not displayed");
        assertAndReportElementIsDisplayed(taxFreeSavingsLinkAccountOpeningProductAndServicesHeader,
            "Tax-Free Savings Accounts (TFSA) Link in Product And Services is displayed",
            "Tax-Free Savings Accounts (TFSA) Link in Product And Services is not displayed");
    }

    /**
     * This is to verify Product And Services Advice And Tools Links in Header
     * on the dashboard
     */
    public void productAndServicesAdviceAndToolsLinks() {
        assertAndReportElementIsDisplayed(savingForGoalsLinkAdviceAndToolsProductAndServicesHeader,
            "Saving for your goals Link in Product And Services is displayed",
            "Saving for your goals Link in Product And Services is not displayed");
        assertAndReportElementIsDisplayed(getATravelLinkAdviceAndToolsProductAndServicesHeader,
            "Get a travel insurance quote Link in Product And Services is displayed",
            "Get a travel insurance quote Link in Product And Services is not displayed");
        assertAndReportElementIsDisplayed(travelInsuranceLinkAdviceAndToolsProductAndServicesHeader,
            "Travel insurance FAQs Link in Product And Services is displayed",
            "Travel insurance FAQs Link in Product And Services is not displayed");
        assertAndReportElementIsDisplayed(chequingAccountLinkAdviceAndToolsProductAndServicesHeader,
            "Chequing account interest rates Link in Product And Services is displayed",
            "Chequing account interest rates Link in Product And Services is not displayed");
        assertAndReportElementIsDisplayed(savingAccountInterestLinkAdviceAndToolsProductAndServicesHeader,
            "Savings account interest rates Link in Product And Services is displayed",
            "Savings account interest rates Link in Product And Services is not displayed");
        assertAndReportElementIsDisplayed(foreignCurrencyInterestLinkAdviceAndToolsProductAndServicesHeader,
            "Foreign currency interest rates Link in Product And Services is displayed",
            "Foreign currency interest rates Link in Product And Services is not displayed");
        assertAndReportElementIsDisplayed(foreignCurrencyConverterLinkAdviceAndToolsProductAndServicesHeader,
            "Foreign currency converter and exchange rates Link in Product And Services is displayed",
            "Foreign currency converter and exchange rates Link in Product And Services is not displayed");
        assertAndReportElementIsDisplayed(lifeStageCalculatorsLinkAdviceAndToolsProductAndServicesHeader,
            "Life stage calculators Link in Product And Services is displayed",
            "Life stage calculators Link in Product And Services is not displayed");
        assertAndReportElementIsDisplayed(personalServiceChargesLinkAdviceAndToolsProductAndServicesHeader,
            "Personal service charges statement of disclosure Link in Product And Services is displayed",
            "Personal service charges statement of disclosure Link in Product And Services is not displayed");
        assertAndReportElementIsDisplayed(powersOfAttorneyLinkAdviceAndToolsProductAndServicesHeader,
            "Powers of attorney and joint deposit accounts information Link in Product And Services is displayed",
            "Powers of attorney and joint deposit accounts information Link in Product And Services is not displayed");

    }

    /**
     * This is to verify Product And Services Services Banking Links in Header
     * on the dashboard
     */
    public void productAndServicesBankingLinks() {
        assertAndReportElementIsDisplayed(productsOverviewLinkBankingProductAndServicesHeader,
            "Products overview Link in Product And Services is displayed",
            "Products overview Link in Product And Services is not displayed");
    }

    /**
     * This is to verify Product And Services Knowledge Center Links in Header
     * on the dashboard
     */
    public void productAndServicesKnowledgeCenterLinks() {
        assertAndReportElementIsDisplayed(mortgageCalculatorsLinkKnowledgeCentreProductAndServicesHeader,
            "Mortgage calculators Link in Product And Services is displayed",
            "Mortgage calculators Link in Product And Services is not displayed");
        assertAndReportElementIsDisplayed(mortgageFQAsLinkKnowledgeCentreProductAndServicesHeader,
            "Mortgage FAQs Link in Product And Services is displayed",
            "Mortgage FAQs Link in Product And Services is not displayed");
        assertAndReportElementIsDisplayed(rrspCalculatorLinkKnowledgeCentreProductAndServicesHeader,
            "RRSP calculators Link in Product And Services is displayed",
            "RRSP calculators Link in Product And Services is not displayed");
        assertAndReportElementIsDisplayed(mortgageRatesLinkKnowledgeCentreProductAndServicesHeader,
            "Mortgage rates Link in Product And Services is displayed",
            "Mortgage rates Link in Product And Services is not displayed");

    }

    /**
     * This is to verify Product And Services Borrowing Links in Header on the
     * dashboard
     */
    public void productAndServicesBorrowingLinks() {
        assertAndReportElementIsDisplayed(borrowingOverviewLinkBorrowingProductAndServicesHeader,
            "Borrowing overview Link in Product And Services is displayed",
            "Borrowing overview Link in Product And Services is not displayed");
        assertAndReportElementIsDisplayed(mortgagesLinkBorrowingProductAndServicesHeader,
            "Mortgages Link in Product And Services is displayed", "Mortgages Link in Product And Services is not displayed");
        assertAndReportElementIsDisplayed(loansLinkBorrowingProductAndServicesHeader,
            "Loans Link in Product And Services is displayed", "Loans Link in Product And Services is not displayed");
        assertAndReportElementIsDisplayed(creditCardsLinkBorrowingProductAndServicesHeader,
            "Credit Cards Link in Product And Services is displayed", "Credit Cards Link in Product And Services is not displayed");
    }

    /**
     * This is to verify Product And Services Ways To Bank Links in Header on
     * the dashboard
     */
    public void productAndServicesWaysToBankLinks() {
        assertAndReportElementIsDisplayed(onlineBankingLinkWaysToBankProductAndServicesHeader,
            "Online Banking Link in Product And Services is displayed",
            "Online Banking Link in Product And Services is not displayed");
        assertAndReportElementIsDisplayed(atmLinkWaysToBankProductAndServicesHeader,
            "ATM Link in Product And Services is displayed", "ATM Link in Product And Services is not displayed");
        assertAndReportElementIsDisplayed(mobileBankingLinkWaysToBankProductAndServicesHeader,
            "Mobile banking Link in Product And Services is displayed",
            "Mobile banking Link in Product And Services is not displayed");
        assertAndReportElementIsDisplayed(telephoneBankingLinkWaysToBankProductAndServicesHeader,
            "Telephone Banking Link in Product And Services is displayed",
            "Telephone Banking Link in Product And Services is not displayed");
        assertAndReportElementIsDisplayed(branchLinkWaysToBankProductAndServicesHeader,
            "Branch Link in Product And Services is displayed", "Branch Link in Product And Services is not displayed");
        assertAndReportElementIsDisplayed(interacETransferLinkWaysToBankProductAndServicesHeader,
            "INTERAC e-Transfer Link in Product And Services is displayed",
            "INTERAC e-Transfer Link in Product And Services is not displayed");
    }

    /**
     * This is to verify Product And Services Insurance Links in Header on the
     * dashboard
     */
    public void productAndServicesInsuranceLinks() {
        assertAndReportElementIsDisplayed(hsbcTravelInsuranceLinkInsuranceProductAndServicesHeader,
            "HSBC Travel Insurance Link in Product And Services is displayed",
            "HSBC Travel Insurance Link in Product And Services is not displayed");
    }

    /**
     * This is to verify Product And Services HSBC Premier Links in Header on
     * the dashboard
     */
    public void productAndServicesHSBCPremierLinks() {
        assertAndReportElementIsDisplayed(hsbcPremierOverviewLinkHSBCPremierProductAndServicesHeader,
            "HSBC Premier overview Link in Product And Services is displayed",
            "HSBC Premier overview Link in Product And Services is not displayed");
    }

    /**
     * This is to verify Product And Services HSBC Advance Links in Header on
     * the dashboard
     */
    public void productAndServicesHSBCAdvanceLinks() {
        assertAndReportElementIsDisplayed(hsbcAdvanceOverviewLinkHSBCAdvanceProductAndServicesHeader,
            "HSBC Advance overview Link in Product And Services is displayed",
            "HSBC Advance overview Link in Product And Services is not displayed");
    }

    /**
     * This is to verify All My Investment And Financial Links in Header for
     * Mass on the dashboard
     */
    private void verifyMyInvestmentsAndFinancialLinksHeaderForMass() {
        mouseOverOnHeader(myInvestmentsAndFinancialLinkHeader);
        investmentAndFinancialAdivceAndInsightsLinks();
        investmentAndFinancialInvestmentSolutionsLinks();
        investmentAndFinancialRetiringAndEducationLinks();
        investmentAndFinancialHSBCPremierLinks();
        investmentAndFinancialHSBCAdvanceLinks();
    }

    /**
     * This is to verify My Investment And Financial Advice And Insights Links
     * in Header on the dashboard
     */
    public void investmentAndFinancialAdivceAndInsightsLinks() {
        assertAndReportElementIsDisplayed(investmentInsightLinkAdviceInsightInvestmentsHeader,
            "Investment insights centre Link in Investments and Financial planning is displayed",
            "Investment insights centre Link in Investments and Financial planning is not displayed");
        assertAndReportElementIsDisplayed(stockMarketGICLinkAdviceInsightInvestmentsHeader,
            "Stock Market GIC Market Tracker Link in Investments and Financial planning is displayed",
            "Stock Market GIC Market Tracker Link in Investments and Financial planning is not displayed");
        assertAndReportElementIsDisplayed(hsbcMutualFundLinkAdviceInsightInvestmentsHeader,
            "HSBC Mutual Fund Information & resources Link in Investments and Financial planning is displayed",
            "HSBC Mutual Fund Information & resources Link in Investments and Financial planning is not displayed");
        assertAndReportElementIsDisplayed(selfDirectedOnlineInvestmentLinkAdviceInsightInvestmentsHeader,
            "Self-directed online investment tools & resources Link in Investments and Financial planning is displayed",
            "Self-directed online investment tools & resources Link in Investments and Financial planning is not displayed");
        assertAndReportElementIsDisplayed(selfDirectedOnlineInvestingLinkAdviceInsightInvestmentsHeader,
            "Self-directed online investing FAQs Link in Investments and Financial planning is displayed",
            "Self-directed online investing FAQs Link in Investments and Financial planning is not displayed");
        assertAndReportElementIsDisplayed(wealthPlanningLinkAdviceInsightInvestmentsHeader,
            "Wealth Planning Link in Investments and Financial planning is displayed",
            "Wealth Planning Link in Investments and Financial planning is not displayed");
    }

    /**
     * This is to verify My Investment And Financial Investment Solutions Links
     * in Header on the dashboard
     */
    public void investmentAndFinancialInvestmentSolutionsLinks() {
        assertAndReportElementIsDisplayed(termDepositsLinkInvestmentsolutionsInvestmentsHeader,
            "Term Deposits Link in Investments and Financial planning is displayed",
            "Term Deposits Link in Investments and Financial planning is not displayed");
        assertAndReportElementIsDisplayed(guranteedInvestmentCertificatesLinkInvestmentsolutionsInvestmentsHeader,
            "Guranteed Investment Certificates (GIC) Link in Investments and Financial planning is displayed",
            "Guranteed Investment Certificates (GIC) Link in Investments and Financial planning is not displayed");
        assertAndReportElementIsDisplayed(mutualFundsLinkInvestmentsolutionsInvestmentsHeader,
            "Mutual Funds Link in Investments and Financial planning is displayed",
            "Mutual Funds Link in Investments and Financial planning is not displayed");
        assertAndReportElementIsDisplayed(managesSolutionsLinkInvestmentsolutionsInvestmentsHeader,
            "Managed Solutions Link in Investments and Financial planning is displayed",
            "Managed Solutions Link in Investments and Financial planning is not displayed");
        assertAndReportElementIsDisplayed(registeredProductsLinkInvestmentsolutionsInvestmentsHeader,
            "Registered Products Link in Investments and Financial planning is displayed",
            "Registered Products Link in Investments and Financial planning is not displayed");
        assertAndReportElementIsDisplayed(taxFreeSavingsLinkInvestmentsolutionsInvestmentsHeader,
            "Tax-Free Savings Accounts (TFSA) Link in Investments and Financial planning is displayed",
            "Tax-Free Savings Accounts (TFSA) Link in Investments and Financial planning is not displayed");
        assertAndReportElementIsDisplayed(selfDirectedOnlineInvestingLinkInvestmentsolutionsInvestmentsHeader,
            "Self-directed online investing Link in Investments and Financial planning is displayed",
            "Self-directed online investing Link in Investments and Financial planning is not displayed");
        assertAndReportElementIsDisplayed(privateInvestmentManagementLinkInvestmentsolutionsInvestmentsHeader,
            "Private Investment Management Link in Investments and Financial planning is displayed",
            "Private Investment Management Link in Investments and Financial planning is not displayed");
    }

    /**
     * This is to verify My Investment And Financial Retiring And Education
     * Links in Header on the dashboard
     */
    public void investmentAndFinancialRetiringAndEducationLinks() {
        assertAndReportElementIsDisplayed(planForAComfortableLinkRetiringAndEducationInvestmentsHeader,
            "Plan for a comfortable retirement Link in Investments and Financial planning is displayed",
            "Plan for a comfortable retirement Link in Investments and Financial planning is not displayed");
        assertAndReportElementIsDisplayed(receiveAnIncomeLinkRetiringAndEducationInvestmentsHeader,
            "Receive an income in retirement Link in Investments and Financial planning is displayed",
            "Receive an income in retirement Link in Investments and Financial planning is not displayed");
        assertAndReportElementIsDisplayed(savingForEducationLinkRetiringAndEducationInvestmentsHeader,
            "Saving for education Link in Investments and Financial planning is displayed",
            "Saving for education Link in Investments and Financial planning is not displayed");
        assertAndReportElementIsDisplayed(growYourWealthLinkRetiringAndEducationInvestmentsHeader,
            "Grow your wealth Link in Investments and Financial planning is displayed",
            "Grow your wealth Link in Investments and Financial planning is not displayed");
        assertAndReportElementIsDisplayed(planYourChildrenLinkRetiringAndEducationInvestmentsHeader,
            "Plan your children's future Link in Investments and Financial planning is displayed",
            "Plan your children's future Link in Investments and Financial planning is not displayed");
        assertAndReportElementIsDisplayed(planYourRetirementLinkRetiringAndEducationInvestmentsHeader,
            "Plan your retirement Link in Investments and Financial planning is displayed",
            "Plan your retirement Link in Investments and Financial planning is not displayed");
        assertAndReportElementIsDisplayed(liveYourRetirementLinkRetiringAndEducationInvestmentsHeader,
            "Live your retirement Link in Investments and Financial planning is displayed",
            "Live your retirement Link in Investments and Financial planning is not displayed");
    }

    /**
     * This is to verify My Investment And Financial HSBC Premier Links in
     * Header on the dashboard
     */
    public void investmentAndFinancialHSBCPremierLinks() {
        assertAndReportElementIsDisplayed(hsbcPremierOverviewLinkHSBCPremierInvestmentsHeader,
            "HSBC Premier overview Link in Investments and Financial planning is displayed",
            "HSBC Premier overview Link in Investments and Financial planning is not displayed");
    }

    /**
     * This is to verify My Investment And Financial HSBC Advance Links in
     * Header on the dashboard
     */
    public void investmentAndFinancialHSBCAdvanceLinks() {
        assertAndReportElementIsDisplayed(hsbcAdvanceOverviewLinkHSBCAdvanceInvestmentsHeader,
            "HSBC Advance overview Link in Investments and Financial planning is displayed",
            "HSBC Advance overview Link in Investments and Financial planning is not displayed");
    }

    /**
     * This is to verify All Contact HSBC Links in Header for Mass on the
     * dashboard
     */
    private void verifyContactHSBCLinksHeaderForMass() {
        mouseOverOnHeader(contactHSBCLinkHeader);
        contactHSBCGeneralLinks();
    }

    /**
     * This is to verify Contact HSBC General Links in Header on the dashboard
     */
    public void contactHSBCGeneralLinks() {
        assertAndReportElementIsDisplayed(contactAndSupportLinkContactHSBCHeader,
            "Contact and support Link in Contact HSBC is displayed", "Contact and support Link in Contact HSBC is not displayed");
        assertAndReportElementIsDisplayed(sendAMessageLinkContactHSBCHeader, "Send a message Link in Contact HSBC is displayed",
            "Send a message Link in Contact HSBC is not displayed");
        assertAndReportElementIsDisplayed(findABranchOrATMLinkContactHSBCHeader,
            "Find a branch or ATM Link in Contact HSBC is displayed", "Find a branch or ATM Link in Contact HSBC is not displayed");
        assertAndReportElementIsDisplayed(haveASpecialistLinkContactHSBCHeader,
            "Have a specialist contact me Link in Contact HSBC is displayed",
            "Have a specialist contact me Link in Contact HSBC is not displayed");
        assertAndReportElementIsDisplayed(bookAnAppointmentLinkContactHSBCHeader,
            "Book an appointment Link in Contact HSBC is displayed", "Book an appointment Link in Contact HSBC is not displayed");
        assertAndReportElementIsDisplayed(hsbcOnSocialMediaLinkContactHSBCHeader,
            "HSBC on social media Link in Contact HSBC is displayed", "HSBC on social media Link in Contact HSBC is not displayed");
    }

    /*
     * Header Methods for Advance
     */
    /**
     * This is to verify All Header Links in Header for Advance on the
     * dashboard
     */
    @Override
    public void verifyAllHeaderLinksForAdvance() {
        verifyMyBankingLinksHeaderForAdvance();
        verifyProductAndServicesLinksHeaderForAdvance();
        verifyMyInvestmentsAndFinancialLinksHeaderForAdvance();
        verifyContactHSBCLinksHeaderForAdvance();
    }

    /**
     * This is to verify All My Banking Links in Header for Advance on the
     * dashboard
     */
    private void verifyMyBankingLinksHeaderForAdvance() {
        mouseOverOnHeader(myBankingLinkHeader);
        myBankingGeneralLinks();
        myBankingMyInvestmentAccountsLinks();
        myBankingReportLostStolenCardLinks();
        myBankingMyProfileLinks();
        myBankingMoveMoneyLinks();
        myBankingGlobalViewLinks();
        myBankingSecurityLinks();
        myBankingChequesLinks();
        myBankingTravelLinks();
        myBankingAccountServicesLink();
        myBankingDocumentsLinks();
    }

    /**
     * This is to verify All Product And Services Links in Header for Advance
     * on the dashboard
     */
    private void verifyProductAndServicesLinksHeaderForAdvance() {
        mouseOverOnHeader(productAndServicesLinkHeader);
        productAndServicesAccountOpeningLinks();
        productAndServicesAdviceAndToolsLinks();
        productAndServicesBankingLinks();
        productAndServicesKnowledgeCenterLinks();
        productAndServicesBorrowingLinks();
        productAndServicesWaysToBankLinks();
        productAndServicesInsuranceLinks();
        productAndServicesHSBCPremierLinks();
        productAndServicesHSBCAdvanceLinks();
    }

    /**
     * This is to verify All My Investments And Financial Links in Header for
     * Advance on the dashboard
     */
    private void verifyMyInvestmentsAndFinancialLinksHeaderForAdvance() {
        mouseOverOnHeader(myInvestmentsAndFinancialLinkHeader);
        investmentAndFinancialAdivceAndInsightsLinks();
        investmentAndFinancialInvestmentSolutionsLinks();
        investmentAndFinancialRetiringAndEducationLinks();
        investmentAndFinancialHSBCPremierLinks();
        investmentAndFinancialHSBCAdvanceLinks();
    }

    /**
     * This is to verify All Conatct HSBC Links in Header for Advance on the
     * dashboard
     */
    private void verifyContactHSBCLinksHeaderForAdvance() {
        mouseOverOnHeader(contactHSBCLinkHeader);
        contactHSBCGeneralLinks();
    }

    /*
     * Header Methods for Premier
     */
    /**
     * This is to verify All Header Links in Header for Premier on the
     * dashboard
     */
    @Override
    public void verifyAllHeaderLinksForPremier() {
        verifyMyBankingLinksHeaderForPremier();
        verifyProductAndServicesLinksHeaderForPremier();
        verifyMyInvestmentsAndFinancialLinksHeaderForPremier();
        verifyContactHSBCLinksHeaderForPremier();
    }

    /**
     * This is to verify All My Banking Links in Header for Premier on the
     * dashboard
     */
    private void verifyMyBankingLinksHeaderForPremier() {
        mouseOverOnHeader(myBankingLinkHeader);
        myBankingGeneralLinks();
        myBankingMyInvestmentAccountsLinks();
        myBankingReportLostStolenCardLinks();
        myBankingMyProfileLinks();
        myBankingMoveMoneyLinks();
        myBankingGlobalViewLinks();
        myBankingSecurityLinks();
        myBankingChequesLinks();
        myBankingTravelLinks();
        myBankingAccountServicesLink();
        myBankingDocumentsLinks();
    }

    /**
     * This is to verify All Product And Services Links in Header for Premier
     * on the dashboard
     */
    private void verifyProductAndServicesLinksHeaderForPremier() {
        mouseOverOnHeader(productAndServicesLinkHeader);
        productAndServicesAccountOpeningLinks();
        productAndServicesAdviceAndToolsLinks();
        productAndServicesBankingLinks();
        productAndServicesKnowledgeCenterLinks();
        productAndServicesBorrowingLinks();
        productAndServicesWaysToBankLinks();
        productAndServicesInsuranceLinks();
        productAndServicesHSBCPremierLinks();
        productAndServicesHSBCAdvanceLinks();
    }

    /**
     * This is to verify All My Investment And Financial Links in Header for
     * Premier on the dashboard
     */
    private void verifyMyInvestmentsAndFinancialLinksHeaderForPremier() {
        mouseOverOnHeader(myInvestmentsAndFinancialLinkHeader);
        investmentAndFinancialAdivceAndInsightsLinks();
        investmentAndFinancialInvestmentSolutionsLinks();
        investmentAndFinancialRetiringAndEducationLinks();
        investmentAndFinancialHSBCPremierLinks();
        investmentAndFinancialHSBCAdvanceLinks();
    }

    /**
     * This is to verify All Contact HSBC Links in Header for Premier on the
     * dashboard
     */
    private void verifyContactHSBCLinksHeaderForPremier() {
        mouseOverOnHeader(contactHSBCLinkHeader);
        contactHSBCGeneralLinks();
    }

    /*
     * Change
     */
    // /*
    // * --------------------------- NAVIGATION FLOWS
    // ---------------------------
    // */
    // public void myBankingOverlay(final WebElement elementLink) {
    // mouseOverOnHeader(myBankingLinkHeader);
    // elementLink.click();
    // }
    //
    // public void myMenuProductNServices(final WebElement elementLink) {
    // mouseOverOnHeader(productAndServicesLinkHeader);
    // elementLink.click();
    // }
    //
    // /*
    // * My Banking
    // */
    //
    // @Override
    // public void navigateToGlobalViewPage() {
    // myBankingOverlay(addOrRemoveACountryLinkGlobalViewMyBankingHeader);
    // }
    //
    // @Override
    // public void navigateToRenameAccountsPage() {
    // myBankingOverlay(renameAccountsLinkAccountServicesMyBankingHeader);
    // }
    //
    // @Override
    // public void navigateToFutureDatedTransaction() {
    // myBankingOverlay(futurePaymentsOrTransfersLinkMoveMoneyMyBankingHeader);
    // }
    //
    // @Override
    // public void navigateToMypayeesPage() {
    // myBankingOverlay(myPayeesLinkMoveMoneyMyBankingHeader);
    // }
    //
    // /*
    // * Product And Services
    // */
    //
    // @Override
    // public void navigateToApplyOpenNewTimeDeposit() {
    // myMenuProductNServices(gicAndTermDepositsLinkAccountOpeningProductAndServicesHeader);
    // }

    /*
     * --------------------------- NAVIGATION FLOWS ---------------------------
     */
    @Override
    public void navigateToGlobalViewPage() {
        super.myMenu(addRemoveCountryLink);
    }

    @Override
    public void navigateToRenameAccountsPage() {
        super.myMenu(renameAccountsLink);
    }

    @Override
    public void navigateToReportLostOrStolenCardPage() {
        super.myMenu(reportLostStolenCard);
    }

    @Override
    public void navigateToFutureDatedTransaction() {
        super.myMenu(futurePayment);
    }

    @Override
    public void navigateToApplyOpenNewSaving() {
        super.myMenuProductAndServices(savingAccountLinkEverydayBankingProductAndServicesHeader);
    }

    @Override
    public void navigateToApplyTermDepositAccount() {
        super.myMenuProductAndServices(termDepositsLinkEverydayBankingProductAndServicesHeader);
    }

    @Override
    public void navigateToApplyCurentAccount() {
        super.myMenuProductAndServices(currentAccountProductAndServicesHeader);
    }

    @Override
    public void navigateToApplySavingsAccount() {
        super.myMenuProductAndServices(termDepositsLinkEverydayBankingProductAndServicesHeader);
    }

    @Override
    public void navigateToTFSA() {
        super.myMenuProductAndServices(taxFreeSavingsLinkAccountOpeningProductAndServicesHeader);
    }

    @Override
    public void navigateToMypayeesPage() {
        super.myMenu(linkMyPayees);
    }

    @Override
    public void navigateToStatementsAndAdvices() {
        super.myMenu(statements);

    }

    @Override
    public void navigateToBillPaymentHistory() {
        super.myMenu(billPaymentHistoryLinkMoveMoneyMyBankingHeader);
    }

    @Override
    public void navigateToUpdateContactDetails() {

        super.myMenu(updatePersonalDetailsLinkMyProfileMyBankingHeader);
    }

    @Override
    public void navigateToRequestReplacementPin() {
        super.myMenu(requestReplacementPin);
    }

    @Override
    public void navigateToManageInternetBankingLimits() {
        super.myMenu(manageInternetBankingLimitsLink);
    }

    /**
     * 
     * <p>
     * This is to scroll the WebElement into view and check whether it is
     * displayed on the application or not and report to the log
     * </p>
     * 
     * @param element
     *            - to check whether WebElement is displayed or not
     * @param passMessage
     *            - pass message
     * @param errorMessage
     *            - error message
     */
    public void assertAndReportElementIsDisplayed(final WebElement element, final String passMessage, final String errorMessage) {
        wait.until(ExpectedConditions.visibilityOf(element));
        Assert.assertTrue(element.isDisplayed(), errorMessage);
        Reporter.log(passMessage);
    }

    @Override
    public void navigateToStatementOrNotificationOptions() {
        super.myMenu(notificationSettingLinkMyProfileMyBankingHeader);
    }

    @Override
    public void navigateToAlertSettings() {
        super.myMenu(notificationSettingLinkMyProfileMyBankingHeader);
    }

    @Override
    public void navigateToOrderChequeBookPage() {
        myMenu(orderChequeBook);
    }

    /*
     * Parameter : driver Purpose : To navigate Tariff and Charges page
     */
    @Override
    public boolean navigateTnCPage() {
        return false;

    }
}
