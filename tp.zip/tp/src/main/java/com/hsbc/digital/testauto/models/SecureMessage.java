package com.hsbc.digital.testauto.models;

import java.util.Date;

/*
 * This is POJO class for Story15-SecureMessaging Author- Aniket Chinake
 */
public class SecureMessage {
    private String accountNumber;
    private String accountName;
    private String problemReason;
    private String paymentAmount;
    private String payeeName;
    private String additionalComments;
    private String typeOfTransaction;
    private String problemWithTransaction;
    private Date apprPostingDate;
    private Date txnDate;
    private String paymentFrequency;
    private String reasonForRequest;
    private String checkNumber;
    private String otherDetails;
    private Date datePostedToAccount;

    public void setAccountNumber(final String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountName(final String accountName) {
        this.accountName = accountName;
    }

    public String getAccountName() {
        return this.accountName;
    }

    public void setProblemReason(final String problemReason) {
        this.problemReason = problemReason;
    }

    public String getProblemReason() {
        return this.problemReason;
    }

    public void setPaymentAmount(final String paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

    public String getPaymentAmount() {
        return this.paymentAmount;
    }

    public void setPayeeName(final String payeeName) {
        this.payeeName = payeeName;
    }

    public String getPayeeName() {
        return this.payeeName;
    }

    public void setAdditionalComments(final String additionalComments) {
        this.additionalComments = additionalComments;
    }

    public String getAdditionalComments() {
        return this.additionalComments;
    }

    public void setTypeOfTxn(final String typeOfTransaction) {
        this.typeOfTransaction = typeOfTransaction;
    }

    public String getTypeOfTxn() {
        return typeOfTransaction;
    }

    public void setProblemWithTxn(final String problemWithTransaction) {
        this.problemWithTransaction = problemWithTransaction;
    }

    public String getProblemWithTxn() {
        return problemWithTransaction;
    }

    public void setApprPostingDate(final Date apprPostingDate) {
        this.apprPostingDate = apprPostingDate;
    }

    public Date getApprPostingDate() {
        return apprPostingDate;
    }

    public void setPaymentFreq(final String paymentFrequency) {
        this.paymentFrequency = paymentFrequency;
    }

    public String getPaymentFreq() {
        return paymentFrequency;
    }

    public void setTransactionDate(final Date txnDate) {
        this.txnDate = txnDate;
    }

    public Date getTransactionDate() {
        return txnDate;
    }

    public void setDatePostedToAccount(final Date datePostedToAccount) {
        this.datePostedToAccount = datePostedToAccount;
    }

    public Date getDatePostedToAccount() {
        return datePostedToAccount;
    }

    public void setCheckNumber(final String checkNumber) {
        this.checkNumber = checkNumber;
    }

    public String getCheckNumber() {
        return checkNumber;
    }


    public void setReasonForRequest(final String reasonForRequest) {
        this.reasonForRequest = reasonForRequest;
    }

    public String getReasonForRequest() {
        return reasonForRequest;
    }

    public void setOtherDetails(final String otherDetails) {
        this.otherDetails = otherDetails;
    }

    public String getOtherDetails() {
        return otherDetails;
    }
}
