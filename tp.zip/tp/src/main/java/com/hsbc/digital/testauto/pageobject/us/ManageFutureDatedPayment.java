/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.us;


import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.ManageFutureDatedDetails;
import com.hsbc.digital.testauto.pageobject.ManageFutureDatedPaymentModel;

/**
 * <p>
 * <b>This class will have locators and specific behaviours for US entity for
 * Manage Future Dated Payment. </b>
 * </p>
 */
public class ManageFutureDatedPayment extends ManageFutureDatedPaymentModel {

    /*
     * Verification of elements on show details
     */

    @FindBy(xpath = "//div[@data-dojo-attach-point='listDataNode']/*[contains(@id,'group_gpib_mvmny_bijit_us_')]//span[@class='dijitTitlePaneTextNode']")
    private List<WebElement> allShowDetailsLinkInList;

    @FindBy(xpath = "//div[contains(@class,'dijitTitlePaneTitleOpen')]//following-sibling::div/descendant::dt[contains(text(),'due')]/following::dd")
    private WebElement transferDateValueInShowDetails;

    @FindBy(xpath = "//div[@data-dojo-attach-point='listDataNode']/*[contains(@id,'group_gpib_mvmny_bijit_us_')]//span[@class='amountText']")
    protected List<WebElement> allAmountOnShowDetails;

    @FindBy(xpath = "//div[contains(@class, 'dijitDialogFixed dijitDialog')]//div[contains(@class, 'unsavedChangesAlertPanel')]//button[@class='btnSecondary']")
    private WebElement cancelEditDetailsYesButton;

    @FindBy(xpath = "//div[contains(@class, 'dijitDialogFixed dijitDialog')]//div[contains(@class, 'unsavedChangesAlertPanel')]//button[@class='btnTertiary']")
    private WebElement cancelEditDetailsNoButton;

    @FindBy(xpath = "//div[@data-dojo-attach-point='listDataNode']/*[contains(@id,'group_gpib_mvmny_bijit_us')]//span[@class='date'] | //div[@data-dojo-attach-point='listDataNode']/*[contains(@id,'WidgetsInTemplateMixin_')]//div[@data-dojo-attach-point='_paymentDateData']")
    private List<WebElement> allDateOnShowDetails;

    public ManageFutureDatedPayment(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    /**
     * This is to select a particular transaction from the list of transaction
     * displayed.
     */
    @Override
    public ManageFutureDatedDetails selectTransactionFromList() {
        ManageFutureDatedDetails manageFDT = new ManageFutureDatedDetails();
        int randomValue = allShowDetailsLinkInList.size();
        randomValue = RandomUtil.generateIntNumber(0, randomValue);
        allShowDetailsLinkInList.get(randomValue).click();
        assertAndReportElementisDisplayed(editDetailsButton, "Show Details pane is displayed", "Show Detials pane is not displayed");
        manageFDT.setFromAccountSelected(fromAccountValueInShowDetails.getText());
        manageFDT.setToAccountSelected(toAccountValueInShowDetails.getText());
        manageFDT.setAmountSelected(amountValueInShowDetails.getText());
        manageFDT.setTransferDate(transferDateValueInShowDetails.getText());
        return manageFDT;
    }

    @Override
    public void verifyAmountOnShowDetailsChanged(final String expectedAmount) {
        boolean amountFlag = false;
        wait.until(ExpectedConditions.visibilityOfAllElements(allAmountOnShowDetails));
        for (int eachAmount = 0; eachAmount < allAmountOnShowDetails.size(); eachAmount++) {
            if (allAmountOnShowDetails.get(eachAmount).getText().trim().equalsIgnoreCase(expectedAmount)) {
                amountFlag = true;
            }
        }
        if (amountFlag) {
            Reporter.log("Amount is changed with the new amount: " + expectedAmount);
        } else {
            ManageFutureDatedPaymentModel.logger.error("Amount is not changed with the new amount: " + expectedAmount);
            Assert.fail("Amount is not changed with the new amount: " + expectedAmount);
        }
    }

    /**
     * This is to edit the transaction from the list and click yes button on
     * cancel popup
     */
    @Override
    public void clickYesCancelEditTransaction() {
        clickButtonOnCancelEditTransaction(cancelEditDetailsYesButton, editDetailsButton);
    }

    /**
     * This is to edit the transaction from the list and click no button on
     * cancel popup
     */
    @Override
    public void clickNoCancelEditTransaction() {
        clickButtonOnCancelEditTransaction(cancelEditDetailsNoButton, cancelEditDetails);
    }

}