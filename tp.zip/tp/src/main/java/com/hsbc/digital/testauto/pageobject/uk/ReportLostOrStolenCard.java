/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.uk;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.pageobject.ReportLostOrStolenCardModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Report
 * Lost Or Stolen Card for Mexico entity. </b>
 * </p>
 */
public class ReportLostOrStolenCard extends ReportLostOrStolenCardModel {
	
	private static final List<String> actualLable = Arrays.asList("From within the UK","From outside the UK","Textphone from within the UK","From outside the UK");

    // Locator for report Lost Stolen Card Link on Footer
    @FindBy(xpath = "//div[contains(@class,'footer')]//a[contains(text(),'lost or stolen card')]")
    private WebElement reportLostStolenCardLinkOnFooter;

    // Locator for report Lost Or Stolen Card Title on dialog box
    @FindBy(xpath = "//div[contains(@class,'heading')]//h2")
    private WebElement reportLostOrStolenCardTitle;
    
    // Locator for report Lost Or Stolen disclaimer
    @FindBy(xpath = "//div[contains(@class,'lostNStolenCard')]/p")
    private WebElement disclaimer;
    
    // Locator for report Lost Or Stolen Contact numbers
    @FindBy(xpath = "//li/h4[contains(text(),'within') or contains(text(),'outside')]")
    private List <WebElement> contactDetails;
    
    
    // Locator for close button on report Lost Or Stolen Card Dialog box
    @FindBy(xpath = "//div[contains(@class,'row')]//input[contains(@class,'btnSecondary')]")
    private WebElement closeButton;
    
    // Locator for Manage button on overview section
    @FindBy(xpath = "//button[contains(@class,'manage') and @aria-selected='false']")
    private List<WebElement> manageButtonList;
    
    
    /**
     * @param driver
     */
    public ReportLostOrStolenCard(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);

    }

    /**
     * Method to click Report Lost Or Stolen Card Footer Link.
     * 
     */
    public void clickReportLostOrStolenCardFooterLink() {
        scrollToWebElement(reportLostStolenCardLinkOnFooter);
        reportLostStolenCardLinkOnFooter.click();
        Reporter.log("Report lost Or stolen card link on Footer clicked. ");
    }

    /**
     * Method to verify report Lost Card Footer Menu Flow.
     * 
     */
    @Override
    public void reportLostCardFooterMenuFlow() {
        clickReportLostOrStolenCardFooterLink();
        clickCloseButton();
    }

    
    /**
     * Method to check if Report Lost Or Stolen Card Dialog box is Displayed.
     * 
     */
    @Override
    public void isReportLostOrStolenCardDialogDisplayed() {
        Assert.assertTrue(reportLostOrStolenCardTitle.isDisplayed(), "Report Lost Or Stolen Card Dialog not displayed. ");
        Reporter.log("Report Lost Or Stolen Card Dialog is displayed. ");
    }
    
    /**
     * Method to check if Disclaimer message is Displayed.
     * 
     */
    @Override
    public void isDisclaimerDisplayed() {
        Assert.assertTrue(disclaimer.isDisplayed(), "Disclaimer message not displayed. ");
        Reporter.log("Disclaimer message is displayed. ");
    }
   
    /**
     * Method to check if Contact details is Displayed.
     * Not applicable for UK
     */
    @Override
    public void isContactDetailsDisplayed() {
    	verifyFields(actualLable,contactDetails);
    }
    
    /**
     * Method to verify if all Contact details list.
     */
    public void verifyFields(final List<String> expectedLabels, final List<WebElement> actualLabelList) {
    	List<String> actualLabels = new ArrayList<>();
        for (WebElement actualLabel : actualLabelList) {
            if (!actualLabel.getText().trim().isEmpty()) {
                actualLabels.add(actualLabel.getText());
            }
        }
        if (expectedLabels.size() == actualLabels.size() && expectedLabels.containsAll(actualLabels)) {
            Reporter.log("Field labels are displayed as expected: " + expectedLabels);
    }
        else {
            Reporter.log("Mismatch in Expected and Actual contact labels list");
            Reporter.log("Expected labels: " + expectedLabels);
            Reporter.log("Actual labels: " + actualLabels);
            Assert.fail("Mismatch in Labels");
        }
    }
    
    
    /**
     * Method to click on close button on report Lost Card dialog box.
     * 
     */
    @Override
    public void clickCloseButton() {
        scrollToWebElement(closeButton);
        closeButton.click();
        Reporter.log("Clicked on Close button. ");
    }
    
    
    /**
     * Method to get manage button
     * 
     */
    @Override
    public List<WebElement> getManageButtonList() {
        return manageButtonList;
    }
    
}
