/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.cbh;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

import com.hsbc.digital.testauto.pageobject.TargetedMarketingModel;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Targeted
 * Marketing for CBH entity. </b>
 * </p>
 */
public class TargetedMarketing extends TargetedMarketingModel {

    private final By bottonSlotGlobalViewPage = By.xpath("//div[@id='_campaignDetails' and @widgetid='_campaignDetails']");

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(TargetedMarketing.class);
    private final UICommonUtil util;

    public TargetedMarketing(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        util = new UICommonUtil(driver);
    }

    @Override
    public void verifyGlobalViewPageTopContentSlot() {
        logger.info("Not applicable for cbh");
    }

    @Override
    public void verifyGlobalViewPageLeftContentSlot() {
        logger.info("Not applicable for cbh");
    }

    @Override
    public void verifyGlobalViewPageBottomContentSlot() {
        Reporter.log("Verifying the Bottom Content Slot of the Global View Page");
        scrollWebElementIntoView(util.activeElement(bottonSlotGlobalViewPage));
        verifyBottomContentSlot(util.activeElement(bottonSlotGlobalViewPage));
    };
}
