/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

/***
 * <p>
 * <b> This model class will hold locators and functionality for Open Account
 * Confirm details page. </b>
 * </p>
 * 
 * @author SatyaPrakash S Vyas
 * @version 1.0.0
 */
public abstract class OpenAccountConfirmPersonalDetailsModel {

    protected final WebDriverWait wait;

    @FindBy(xpath = "//*[@id='productsContainer']/div/div[1]/h2")
    protected WebElement opennewTDTitleHeading;

    @FindBy(xpath = "//form[contains(@id,'hdx_dijits_form_Form')]")
    protected WebElement personalDetailsForm;

    @FindBy(xpath = "//*[@class='acceptTermsRow']//input[contains(@id,'group_gpib_actopening_common_bijits_CustomerDetails')]")
    protected List<WebElement> confirmCheckBox;

    @FindBy(xpath = "//dl[@class='custEditSectionNode clearfix editDetailsFooter']/dd//span[text()='Edit these details']")
    private WebElement editButton;

    @FindBy(xpath = "//div[@class='submitButtonsPanel spacingSubmitBtnPanel']//span[contains(@id,'dijit_form_Button')]")
    protected WebElement continueButton;

    @FindBy(xpath = "//div[@class='submitButtonsPanel spacingSubmitBtnPanel']//button[@class='btnTertiary js-step1Cancel spacinCancelBtn']")
    private WebElement cancelButton;

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_Dialog_') and not (contains(@style,'display: none'))]//button[(@data-dojo-attach-point='_captureCancelYes')]")
    protected WebElement cancelDialogYes;

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_Dialog_') and not (contains(@style,'display: none'))]//button[(@data-dojo-attach-point='_captureCancelNo')]")
    protected WebElement cancelDialogNo;

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_Dialog_') and not (contains(@style,'display: none'))]//button[(@data-dojo-attach-point='continuePopUpEdit')]")
    private WebElement editDialogYes;

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_Dialog_') and not (contains(@style,'display: none'))]//span[text()='No' or text()='Cancel']")
    private WebElement editDialogNo;

    @FindBy(xpath = "//a[@id='contactinformation']")
    private WebElement custMaintenanceheading;

    @FindBy(xpath = "//div[contains(@id,'group_gpib_cust_bijit_ContactInformation_')]")
    private WebElement custDetailsForm;

    @FindBy(xpath = "//h2[@data-dojo-attach-point='stepTitle' and text()='Options']")
    protected WebElement openAccountOptionsPage;

    private static final String TITLE_TD = "Time Deposit";
    private static final String TITLE_UPDATE_PERSONAL_INFO = "Update Personal Information and Contact Information";

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger
        .getLogger(OpenAccountConfirmPersonalDetailsModel.class);

    public OpenAccountConfirmPersonalDetailsModel(final WebDriver driver) {
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30);
    }

    /**
     * Click on CheckBox for Confirmation
     */
    public void clickConfirmCheckBox() {
        wait.until(ExpectedConditions.visibilityOf(confirmCheckBox.get(0)));
        confirmCheckBox.get(0).click();
        Reporter.log("Confirm checkbox clicked.");
    }

    /**
     * Click continue button once enabled after clicking check box
     */
    public void clickContinueButton() {
        wait.until(ExpectedConditions.elementToBeClickable(continueButton));
        continueButton.click();
        wait.until(ExpectedConditions.visibilityOf(openAccountOptionsPage));
        Reporter.log("Continue button clicked and Options page shown.");
    }

    /**
     * Click cancel button
     */
    public void clickCancelButton(final boolean isCancel) {
        wait.until(ExpectedConditions.elementToBeClickable(cancelButton));
        cancelButton.click();
        if (isCancel) {
            cancelDialogYes.click();
            wait.until(ExpectedConditions.visibilityOf(opennewTDTitleHeading));
            verifyTitle();
            Reporter.log("User navigated to product details page after clicking Cancel - Yes");
        } else {
            cancelDialogNo.click();
            personalDetailsForm.isDisplayed();
            Reporter.log("Cancel button - No clicked and personal details page shown.");
        }
    }

    public void verifyTitle() {
        Assert.assertEquals(opennewTDTitleHeading.getText(), OpenAccountConfirmPersonalDetailsModel.TITLE_TD);
    }

    public void clickEditDetailsButton(final boolean value) {
        wait.until(ExpectedConditions.elementToBeClickable(editButton));
        editButton.click();
        if (value) {
            wait.until(ExpectedConditions.elementToBeClickable(editDialogYes));
            editDialogYes.click();
            wait.until(ExpectedConditions.visibilityOf(custDetailsForm));
            Assert.assertTrue(OpenAccountConfirmPersonalDetailsModel.TITLE_UPDATE_PERSONAL_INFO
                .equalsIgnoreCase(custMaintenanceheading.getText()), "Update personal details page not shown.");

            Reporter.log("Edit personal details button - Yes/Continue clicked and Update personal details page shown.");
        } else {
            editDialogNo.click();
            personalDetailsForm.isDisplayed();
            Reporter.log("Edit personal details button - No/Cancel clicked and Confirm personal details page shown.");
        }
    }

    public void submitDetails() {
        clickConfirmCheckBox();
        clickContinueButton();
    }

    /**
     * <p><b>
     * TODO : Insert description of the method's responsibility/role.
     * </b></p>
     *
     */
    public void confirmPersonalDetails() {
        // TODO Auto-generated method stub

    }

    /**
     * <p><b>
     * TODO : Insert description of the method's responsibility/role.
     * </b></p>
     *
     */
    public void verifyeditDetailsFunctionality() {
        // TODO Auto-generated method stub

    }

}
