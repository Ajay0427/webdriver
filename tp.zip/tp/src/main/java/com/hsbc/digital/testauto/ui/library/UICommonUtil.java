package com.hsbc.digital.testauto.ui.library;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;

public class UICommonUtil {
    private final WebDriverWait wait;
    private final WebDriver driver;
    private final Actions action;
    private final JavascriptExecutor jsx;
    private static final int YEAR_LIST_SIZE = 2;
    protected static final String SCROLL_TO_VIEW = "arguments[0].scrollIntoView(true);";
    public static final By verifyPage = By.xpath("//div[contains(@id, 'Verify') or contains(@id, 'Verfiy')]");
    public static final By confirmPage = By.xpath("//div[contains(@id, 'Confirm')]");

    /************** Calender Elemements *******/
    private final By locatorMonthLink = By.xpath("//*[contains(@id, '_popup_mddb_label')]");

    private final By locatorMonthDiv = By.xpath("//div[contains(@id, '_popup_mddb_mdd')]");

    private final By locatorMonthDisplayed = By.xpath("div[@class='dijitCalendarMonthLabel']");

    private final By locatorYearLink = By.xpath("//*[contains(@id, '_popup_yddb_label')]");

    private final By locatorYearDiv = By.xpath("//div[contains(@id, '_popup_yddb_ydd')]");

    private final By locatorDateDisplayed = By
        .xpath("//table[contains(@id, '_popup')]//td[contains(@class, 'dijitCalendarCurrentMonth')]");

    /******** Page Elements *******/
    public static final By pageFieldValue = By.xpath("//following-sibling::div[contains(@class, 'itemValue')]");
    public static final By pageFieldLabels = By.xpath("//div[contains(@class, 'itemLabel')]");

    public static final By pageFieldName = By
        .xpath("//div[contains(@class, 'itemLabel') or contains(@class,'VerticalBarNoMargin') or contains(@class,'divRedVerticalBar')]");


    public UICommonUtil(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30000);
        action = new Actions(driver);
        jsx = (JavascriptExecutor) driver;
    }


    /**
     * Method to return Active Element i.e. element that is displayed.
     */
    public WebElement activeElement(final By locator) {
        WebElement elem = null;
        List<WebElement> allElements = driver.findElements(locator);
        for (WebElement elem1 : allElements) {
            if (elem1.isDisplayed()) {
                elem = elem1;
                break;
            }
        }
        return elem;
    }


    /**
     * Method to return Active Element by its Parent Element.
     */
    public WebElement activeElementByParent(final WebElement parentElem, final By locator) {
        WebElement elem = null;
        List<WebElement> allElements = parentElem.findElements(locator);
        for (WebElement elem1 : allElements) {
            if (elem1.isDisplayed()) {
                elem = elem1;
                break;
            }
        }
        return elem;
    }

    /**
     * Method inside datePicker Method to bring desired year up for selection
     */
    private void checkAndPickYear(final WebElement yearLink, final int year, final int startRange, final int endRange) {
        int sRange = startRange;
        int eRange = endRange;
        if (year < sRange) {
            do {
                pickYear(yearLink, sRange);
                sRange = sRange - UICommonUtil.YEAR_LIST_SIZE;
            } while (year < sRange);
        } else if (year > eRange) {
            do {
                pickYear(yearLink, eRange);
                eRange = eRange + UICommonUtil.YEAR_LIST_SIZE;
            } while (year > eRange);
        } else {
            pickYear(yearLink, year);
        }

    }

    /**
     * Method inside datePicker Method to select Year from Calendar Year
     * dropdown
     */
    private void pickYear(final WebElement yearLink, final int range) {
        String neededYear = Integer.toString(range);
        yearLink.click();
        WebElement yearDiv = activeElement(locatorYearDiv);
        List<WebElement> yearsDisplayed = yearDiv.findElements(locatorMonthDisplayed);
        try {
            for (WebElement years : yearsDisplayed) {
                if (years.getText().equalsIgnoreCase(neededYear)) {
                    years.click();
                    break;
                }
            }
        } catch (StaleElementReferenceException e) {
            MoveMoneyCapturePageModel.logger.error("Stale Exception " + e);
        }
    }

    /**
     * Method inside datePicker Method to select Month from Calendar Month
     * dropdown
     */
    private void pickMonth(final WebElement monthLink, final String correctMonth) {
        monthLink.click();
        WebElement monthDiv = activeElement(locatorMonthDiv);
        List<WebElement> monthsDisplayed = monthDiv.findElements(locatorMonthDisplayed);
        for (WebElement months : monthsDisplayed) {
            if (months.getText().equalsIgnoreCase(correctMonth)) {
                months.click();
                break;
            }
        }
    }

    /**
     * Method inside datePicker Method to click on Date cell
     */
    private void clickDateCell(final String dateToSelect) {
        List<WebElement> datesDisplayed = driver.findElements(locatorDateDisplayed);
        for (WebElement cellDate : datesDisplayed) {
            if (cellDate.getText().equalsIgnoreCase(dateToSelect)) {
                wait.until(ExpectedConditions.elementToBeClickable(cellDate));
                cellDate.click();
            }
        }
    }

    /**
     * Select Date using Calendar Date Picker
     */
    public Date selectDate(final WebElement dateSelectArrow, final WebElement dateTable, final Date inputDate) {
        Reporter.log("Date Picker function started.");
        String correctMonth;
        Calendar cal = Calendar.getInstance();
        cal.setTime(inputDate);
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);
        cal.setTime(new Date());
        int curYear = cal.get(Calendar.YEAR);
        int startRange = curYear - YEAR_LIST_SIZE;
        int endRange = curYear + YEAR_LIST_SIZE;
        String dateToSelect = Integer.toString(day);
        String[] monthNames = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
            "November", "December"};
        correctMonth = monthNames[month];
        try {
            dateSelectArrow.click();
            wait.until(ExpectedConditions.visibilityOf(dateTable));
            action.moveToElement(dateTable).build().perform();
            WebElement monthLink = activeElementByParent(dateTable, locatorMonthLink);
            wait.until(ExpectedConditions.elementToBeClickable(monthLink));
            pickMonth(monthLink, correctMonth);
            WebElement yearLink = activeElementByParent(dateTable, locatorYearLink);
            wait.until(ExpectedConditions.elementToBeClickable(yearLink));
            checkAndPickYear(yearLink, year, startRange, endRange);
            wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(locatorDateDisplayed));
            clickDateCell(dateToSelect);
            Reporter.log("Date clicked on :" + inputDate);
            return inputDate;
        } catch (Exception e) {
            Assert.fail("Exception thrown on failing to click on Date " + inputDate + " :" + e.getMessage());
            MoveMoneyCapturePageModel.logger.error(e);
            return null;
        }

    }


    /**
     * Method to return true if text and its corresponding field match the
     * criteria user specifies else return false
     */
    public boolean textByParentAndSibling(final String fieldLabel, final String fieldValue, final By page, final By pageFieldName,
        final By pageFieldValue) {
        boolean flag = false;
        List<WebElement> fieldLabels = driver.findElement(page).findElements(pageFieldName);
        for (WebElement label : fieldLabels) {
            jsx.executeScript(UICommonUtil.SCROLL_TO_VIEW, label);
            if (label.isDisplayed() && label.getText().contains(fieldLabel)) {
                List<WebElement> valueElements = label.findElements(pageFieldValue);
                if (isValuePresent(valueElements, fieldValue)) {
                    flag = true;
                    break;
                }
            }
        }
        return flag;
    }

    /**
     * Method to return true if field value matches the expected field value
     */
    private boolean isValuePresent(final List<WebElement> valueElements, final String fieldValue) {
        boolean flag = false;
        for (WebElement valueElement : valueElements) {
            if (valueElement.isDisplayed() && valueElement.getText().contains(fieldValue)
                || fieldValue.contains(valueElement.getText().replaceAll("\\n.*", ""))) {
                flag = true;
                break;
            }
        }
        return flag;
    }

    public void mouseMoveToElement(WebElement element) {
        Actions actions = new Actions(driver);
        actions.moveToElement(element);
        actions.click().build().perform();
    }

}
