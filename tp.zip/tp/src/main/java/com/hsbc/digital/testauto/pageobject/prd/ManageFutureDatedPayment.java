/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.prd;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.ManageFutureDatedDetails;
import com.hsbc.digital.testauto.pageobject.ManageFutureDatedPaymentModel;

/**
 * <p>
 * <b>This class will have locators and specific behaviours for PRD(China)
 * entity for Manage Future Dated Payment. </b>
 * </p>
 */
public class ManageFutureDatedPayment extends ManageFutureDatedPaymentModel {

    private static final String VERIFY_INTERNATIONAL_VALUE = "International";

    private static final String INPUT_FORMAT = "dd/MM/yyyy";
    private static final String DISPLAY_LIST_FORMAT = "MMM dd, yyyy";

    @FindBy(xpath = "//div[@class='alertPanel info']")
    private List<WebElement> noTransactionMessage;

    /*
     * Delete Functionality
     */
    @FindBy(xpath = "//div[contains(@id,'Dialog') and contains(@class,'dijitDialogFixed')]//button[contains(text(),'Yes')]")
    private WebElement deleteButtonDialogYes;

    @FindBy(xpath = "//div[contains(@id,'Dialog') and contains(@class,'dijitDialogFixed')]//button[contains(text(),'No')]")
    private WebElement deleteButtonDialogNo;

    /*
     * Edit Functionality
     */
    @FindBy(xpath = "//div[@class='dijitDialogFixed dijitDialog']//button[@class='btnTertiary']")
    private WebElement cancelEditDetailsNoButton;

    @FindBy(xpath = "//div[contains(@class,'dijitTitlePaneTitleOpen')]//following-sibling::div/descendant::div[@class='alertPanel confirmation']")
    private WebElement saveDetailsConfirmationMessage;

    public ManageFutureDatedPayment(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    /**
     * This is to get the Date Format of the specific entity for input
     * 
     * @return String - Format of the input field
     */
    @Override
    public String getDefaultInputFormatDate() {
        return ManageFutureDatedPayment.INPUT_FORMAT;
    }

    /**
     * This is to get the Date Format of the specific entity for list that is
     * displayed
     * 
     * @return String - Format of the date that is displayed in the list
     */
    @Override
    public String getDefaultDisplayListFormatDate() {
        return ManageFutureDatedPayment.DISPLAY_LIST_FORMAT;
    }

    @Override
    public List<WebElement> getNoTransactionWebElement() {
        return noTransactionMessage;
    }

    /*
     * Functionality not Applicable for PRD Entity
     */
    @Override
    public void enterFromAmount(final String amount) {
        ManageFutureDatedPaymentModel.logger.info("Functionality is not applicable for PRD.");
        Assert.fail("Functionality is not applicable for PRD.");
    }

    @Override
    public void enterToAmount(final String amount) {
        ManageFutureDatedPaymentModel.logger.info("Functionality is not applicable for PRD.");
        Assert.fail("Functionality is not applicable for PRD.");
    }

    @Override
    public void getAmountConditionValues(final ManageFutureDatedDetails manageFDT) {
        ManageFutureDatedPaymentModel.logger.info("Functionality is not applicable for PRD.");
    }

    @Override
    public void clearFromAmount() {
        ManageFutureDatedPaymentModel.logger.info("Functionality is not applicable for PRD.");
        Assert.fail("Functionality is not applicable for PRD.");
    }

    @Override
    public void clearToAmount() {
        ManageFutureDatedPaymentModel.logger.info("Functionality is not applicable for PRD.");
        Assert.fail("Functionality is not applicable for PRD.");
    }

    @Override
    public void checkAmountDataDisplayedInList(final ManageFutureDatedDetails manageFDT) {
        ManageFutureDatedPaymentModel.logger.info("Functionality is not applicable for PRD.");
    }

    @Override
    public void confirmEditTransactionCheckCrossTick() {
        ManageFutureDatedPaymentModel.logger.info("Functionality is not applicable for PRD.");
        Assert.fail("Functionality is not applicable for PRD.");
    }

    @Override
    public void checkCrossTickOnOverlayReviewPageEditTransaction() {
        ManageFutureDatedPaymentModel.logger.info("Functionality is not applicable for PRD.");
        Assert.fail("Functionality is not applicable for PRD.");
    }

    @Override
    public void cancelConfirmEditTransaction() {
        ManageFutureDatedPaymentModel.logger.info("Functionality is not applicable for PRD.");
        Assert.fail("Functionality is not applicable for PRD.");
    }

    @Override
    public void verifyCancelConfirmEditTransaction() {
        ManageFutureDatedPaymentModel.logger.info("Functionality is not applicable for PRD.");
        Assert.fail("Functionality is not applicable for PRD.");
    }

    /**
     * This is to verify the data that is displayed for the Transfer Type
     * 
     * @param manageFDT
     * @param eachSection
     */
    @Override
    public void verifyTranferType(final ManageFutureDatedDetails manageFDT, final int eachSection) {
        switch (manageFDT.getTransferTypeFromDropdown()) {
        case "To other Local Banks in China":
            Assert.assertEquals(allPayeeTypeOnShowDetails.get(eachSection).getText(),
                ManageFutureDatedPaymentModel.VERIFY_DOMESTIC_VALUE);
            break;
        case "Within HSBC in Mainland China":
            Assert.assertEquals(allPayeeTypeOnShowDetails.get(eachSection).getText(),
                ManageFutureDatedPaymentModel.VERIFY_DOMESTIC_VALUE);
            break;
        case "Global Transfer":
            Assert.assertEquals(allPayeeTypeOnShowDetails.get(eachSection).getText(),
                ManageFutureDatedPayment.VERIFY_INTERNATIONAL_VALUE);
            break;
        default:
            String tempValue = allPayeeTypeOnShowDetails.get(eachSection).getText();
            if (!(tempValue.equalsIgnoreCase(ManageFutureDatedPaymentModel.VERIFY_DOMESTIC_VALUE) || tempValue
                .equalsIgnoreCase(ManageFutureDatedPayment.VERIFY_INTERNATIONAL_VALUE))) {
                Assert.fail("The transfer/ payment type is incorrect.");
            }
        }
    }

    /**
     * This is to verify the data that is displayed fo the Transfer Frequency
     * 
     * @param manageFDT
     * @param eachSection
     */
    @Override
    public void verifyTransferFrequency(final ManageFutureDatedDetails manageFDT, final int eachSection) {
        switch (manageFDT.getTransferFrequencyFromDropdown()) {
        case "One time transfers":
            Assert.assertFalse(
                allRecurringOnShowDetails.get(eachSection).getText().trim()
                    .equalsIgnoreCase(ManageFutureDatedPaymentModel.VERIFY_RECURRING_VALUE),
                "Recurring Payment is displayed for One Time Transfers");
            break;
        case "Recurring transfer":
            Assert.assertEquals(allRecurringOnShowDetails.get(eachSection).getText().trim(),
                ManageFutureDatedPaymentModel.VERIFY_RECURRING_VALUE);
            break;
        default:
            String tempValue = allRecurringOnShowDetails.get(eachSection).getText();
            if (!(tempValue.equalsIgnoreCase(ManageFutureDatedPaymentModel.VERIFY_RECURRING_VALUE) || tempValue.isEmpty())) {
                Assert.fail("The transfer/ payment frequency is incorrect.");
            }
        }
    }

    /**
     * This is to edit a particular transaction from the list and confirm the
     * editing.
     */
    @Override
    public void confirmEditTransaction() {
        assertAndReportElementisDisplayed(saveDetailsConfirmationMessage,
            "Successfully Saved the Edit changes and Confirmation Message is displayed",
            "Successfully Saved the Edit changes and Confirmation Message is not displayed");
    }

    /**
     * This is to verify the Edit Transaction functionality from the list and
     * the value that was edited
     */
    @Override
    public void verifyConfirmEditTransaction(final ManageFutureDatedDetails manageFDTRandomAmount) {
        wait.until(ExpectedConditions.invisibilityOfElementLocated(processingOverlayDialog));
        Reporter.log("Amount in the Show Details Pane: ");
        getTextAssertEqualsAndReportLog(amountValueInShowDetails, manageFDTRandomAmount.getRandomAmount());
        Reporter.log("Amount on the Show Details Pane: ");
        getTextAssertEqualsAndReportLog(amountValueOnShowDetails, manageFDTRandomAmount.getRandomAmount());
        Reporter.log("Amount is changed with the new amount : " + manageFDTRandomAmount.getRandomAmount());
    }

    /**
     * This is to delete the transaction from the list and click on Yes
     */
    @Override
    public void confirmDeleteTransaction() {
        clickAndReportButtonOnDeleteTransaction(deleteButtonDialogYes);
    }

    /**
     * This is to delete the transaction from the list and click on No
     */
    @Override
    public void cancelDeleteTransaction() {
        clickAndReportButtonOnDeleteTransaction(deleteButtonDialogNo);
    }

    /**
     * This is to edit the transaction from the list and click no button on
     * cancel popup
     */
    @Override
    public void clickNoCancelEditTransaction() {
        clickButtonOnCancelEditTransaction(cancelEditDetailsNoButton, cancelEditDetails);
    }

    /*
     * Dropdown Selection
     */
    /**
     * This is to get the text condition for the domestic type
     * 
     * @param conditionValue
     * @return String
     */
    public String getDomesticTypeCondition() {
        String expectedConditionValueText = StringUtils.EMPTY;
        int noOfCondition = 2;
        int randomValue = RandomUtil.generateIntNumber(1, 1 + noOfCondition);
        if (randomValue == 1) {
            expectedConditionValueText = "To other local";
        } else if (randomValue == 2) {
            expectedConditionValueText = "Within HSBC";
        }
        return expectedConditionValueText;
    }
}