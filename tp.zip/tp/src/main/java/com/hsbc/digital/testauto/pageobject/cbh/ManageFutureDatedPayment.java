/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.cbh;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.pageobject.ManageFutureDatedPaymentModel;

/**
 * <p>
 * <b>This class will have locators and specific behaviors for CBH(Sri Lanka)
 * entity for Manage Future Dated Payment. </b> Author - Neha Rajesh Gupta
 * </p>
 */
public class ManageFutureDatedPayment extends ManageFutureDatedPaymentModel {

    @FindBy(xpath = "//span[contains(@id,'dijit_form_Button_4_label')]")
    private WebElement printWholeList;

    @FindBy(xpath = "//button[contains(@class,'btnTertiary') and contains(@data-dojo-attach-point,'closeButton')]")
    private List<WebElement> printPopupCancelButton;

    @FindBy(xpath = "//div[contains(@class,'gridHeaderRow')]")
    private List<WebElement> printPopupPanel;

    @FindBy(xpath = "//div[contains(@class,'dijitTitlePaneTitleOpen')]//following-sibling::div//descendant::dt[contains(text(),'From')]/following::dd[1]")
    private WebElement fromAccountValueInShowDetails;

    @FindBy(xpath = "//div[contains(@class,'dijitTitlePaneTitleOpen')]//following-sibling::div//dt[text()='To']/following-sibling::dd/span[1]")
    private WebElement toAccountValueInShowDetails;

    @FindBy(xpath = "//div[contains(@class,'dijitTitlePaneTitleOpen')]//following-sibling::div/descendant::dt[contains(text(),'due')]/following::dd[1]")
    private WebElement transferDateValueInShowDetails;

    @FindBy(xpath = "//span[contains(@id,'dijit_form_ToggleButton_0_label')]")
    private WebElement filterTransactionsButton;

    @FindBy(xpath = "//div[contains(@class,'submitButtonsPanel borderedConwas successful.tent')]//span[contains(text(),'Print this payment')]")
    private WebElement editDetailsConfirmationPagePrintButton;

    @FindBy(xpath = "//div[contains(@id,'Dialog') and contains(@class,'dijitDialogFixed') and contains(@style,'position: fixed')]//div[@class='dijitDialogTitleBar']//button")
    protected WebElement crossTickButton;

    @FindBy(xpath = "//div[contains(@id, 'FutureTransactions')]//div[contains(@class, 'futureDatedPaymentsHeading')]")
    private WebElement pageTitle;

    @FindBy(xpath = "//div[contains(@id, 'uniqName')]//div[contains(@class, 'futurePaymentItem')]")
    private List<WebElement> futurePaymentRows;

    @FindBy(xpath = "//div[starts-with(@id, 'hdx_dijits_Dialog')]//div[contains(@class, 'deleteButtonWrapper')]//button[contains(@class, 'btnSecondary')]")
    private WebElement deleteButtonOnConfirmationDialog;

    public ManageFutureDatedPayment(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    public WebElement getCrossTickButton() {
        return crossTickButton;
    }

    @Override
    public WebElement getEditDetailsConfirmationPagePrintButton() {
        return editDetailsConfirmationPagePrintButton;
    }

    @Override
    public WebElement getFilterTransactionsButton() {
        return filterTransactionsButton;
    }

    @Override
    public WebElement getTransferDateValueInShowDetails() {
        return transferDateValueInShowDetails;
    }

    @Override
    public WebElement getPrintWholeList() {
        return printWholeList;
    }

    @Override
    public List<WebElement> getPrintPopupCancelButton() {
        return printPopupCancelButton;
    }

    @Override
    public WebElement getFromAccountValueInShowDetails() {
        return fromAccountValueInShowDetails;
    }

    @Override
    public WebElement getToAccountValueInShowDetails() {
        return toAccountValueInShowDetails;
    }

    @Override
    public void verifyPrintFromShowDetails() {
        logger.info("not applicable for cbh");
    }

    @Override
    public List<WebElement> getPrintPopupPanel() {
        return printPopupPanel;
    }

    @Override
    protected void verifyAmountOnShowDetailsChanged(final String expectedAmount) {
        boolean amountFlag = false;
        for (int eachAmount = 0; eachAmount < allAmountOnShowDetails.size(); eachAmount++) {
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            if (allAmountOnShowDetails.get(eachAmount).getText().trim().equalsIgnoreCase(expectedAmount)) {
                amountFlag = true;
                break;
            }
        }
        if (amountFlag) {
            Reporter.log("Amount is changed with the new amount: " + expectedAmount);
        } else {
            ManageFutureDatedPaymentModel.logger.error("Amount is not changed with the new amount: " + expectedAmount);
            Assert.fail("Amount is not changed with the new amount: " + expectedAmount);
        }
    }

    @Override
    public void checkCrossTickOnOverlay() {
        crossTickButton = uiCommonUtil
            .activeElement(By
                .xpath("//div[contains(@id,'Dialog') and contains(@class,'dijitDialogFixed') and contains(@style,'position: fixed')]//div[@class='dijitDialogTitleBar']//button"));
        assertAndReportElementisDisplayed(getCrossTickButton(), "Cross Tick Button is displayed on overlay",
            "Cross Tick Button is not displayed on overlay");

        executor.executeScript("arguments[0].click();", getCrossTickButton());

        Reporter.log("Cross Tick button is clicked on the Overlay");
    }

    @Override
    public void confirmEditTransactionCheckCrossTick() {
        assertAndReportElementisDisplayed(paymentSummaryLabelOnEditDetailsReviewPage, "Review page of Edit Details is displayed",
            "Review page of Edit Details is not displayed");
        confirmEditDetailsContinueButton.click();
        assertAndReportElementisDisplayed(confirmMessageOnEditDetailsConfirmationPage,
            "Confirmation page of Edit Details is displayed", "Confirmation page of Edit Details is not displayed");
        editDetailsConfirmationPageCrossTickButton = uiCommonUtil
            .activeElement(By
                .xpath("//div[contains(@id,'FutureTransactionEditConfirm') and not (contains(@style,'display: none'))]//button[contains(@title,'Close')]"));
        editDetailsConfirmationPageCrossTickButton.click();
    }


}
