/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.us;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.pageobject.OrderChequeBookCapturePageModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Order
 * Cheque Book Capture Page for US entity. </b>
 * </p>
 */
public class OrderChequeBookCapturePage extends OrderChequeBookCapturePageModel {

    // Locator for selected number of chequebook
    @FindBy(xpath = "//table[contains(@id,'numberOfBook')]//div[contains(@class,'InputField')]")
    private WebElement selectedNumberOfChequeBooks;

    private static final String EXPECTED_CAPTUREPAGE_TITLE = "Order checks";

    private static final String ACCOUNT_TYPE_CODE = "PPSP";

    public OrderChequeBookCapturePage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    /**
     * Method to verify capture page is displayed.
     * 
     */
    @Override
    public void isOrderChequeCapturePageDisplayed() {
        Assert.assertTrue(
            orderChequeBookCapturePage.isDisplayed()
                && orderChequeBookCapturePage.getText().equalsIgnoreCase(EXPECTED_CAPTUREPAGE_TITLE),
            "Order Cheque Book Capture Page is not displayed or displayed title does not match with expected title. ");
        Reporter.log("Order Cheque Book Capture Page is displayed and displayed title matchs with expected title. ");
    }

    /**
     * Method to select number of cheque books on capture page
     * 
     */
    @Override
    public void selectNumberOfChequeBooks() {
        clickNumberOfChequesDropDownButton();
        verifyMaximumNumberOfChequeBooks();
        selectValues(numberOfChequeBookList);
        Reporter.log("Number of cheque books selected. ");
    }

    /**
     * Method to set Account details selected
     * 
     * @return accountDetails
     * 
     */
    @Override
    public AccountDetails setAccountDetails() {
        AccountDetails accountDetails = new AccountDetails();
        String[] details = selectedAccount.getText().split("\\r?\\n");
        accountDetails.setAccountName(details[0]);
        accountDetails.setAccountNumber(details[1]);
        accountDetails.setNumberOfChequeBooks(selectedNumberOfChequeBooks.getText());
        return accountDetails;
    }

    /**
     * Method to verify invalid accounts for ordering a cheque book.
     * 
     */
    @Override
    public void verifyInvalidAccounts() {
        for (WebElement account : accountsLists) {
            if (account.getAttribute("unique-account-number").contains(ACCOUNT_TYPE_CODE)) {
                account.click();
                if (manageButtonList.isEmpty()) {
                    Reporter.log("Manage button not displayed for the account. ");
                } else {
                    clickManageButton();
                    Assert.assertTrue(orderChequesLink.isEmpty(),
                        "Order Cheque Book link is displayed for the account. Hence Failed. ");
                    Reporter.log("Order Cheque Book link is not displayed for the account. ");
                }
            }
        }
    }
}
