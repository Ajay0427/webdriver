package com.hsbc.digital.testauto.pageobject.ca;

import java.text.ParseException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyVerifyPageModel;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

public class MoveMoneyVerifyPage extends MoveMoneyVerifyPageModel {


    // Query Raised to Confirm Label Values for other MM Functions

    protected static final String LABEL_FROM = "From";
    protected static final String LABEL_TO = "To";
    protected static final String LABEL_NOTIFY = "To";
    protected static final String LABEL_LANG = "Language";
    protected static final String LABEL_SQUES = "Security question";
    protected static final String LABEL_SANS = "Security answer";
    protected static final String LABEL_EMAILADDRESS = "Email address";
    protected static final String LABEL_FEE = "Fee";
    protected static final String LABEL_DATE = "Date";
    protected static final String LABEL_START_DATE = "Date of first payment";


    @FindBy(xpath = ".//div[contains(@class,'submitButtonsPanel')]//input[contains(@class,'btnPrimary') and contains(@data-dojo-attach-point,'_confirmTxn')]")
    private WebElement confirmButton;

    @FindBy(xpath = ".//div[contains(@class,'itemButton')]//button[contains(@ data-dojo-attach-point,'_edit')]")
    private WebElement editDetailsButton;

    @FindBy(xpath = ".//span[contains(@class,'InteracLogo')]")
    private WebElement verfiylogocapturepage;

    @FindBy(xpath = "//div[contains(text(),'Payment fee is charged to the account you are transferring funds from, whether the INTERAC e-Transfer is cancelled, declined, expires or the recipient fails to answer security question correctly')]")
    private WebElement verfiyfeeBodyippage;

    @FindBy(xpath = "//div[contains(text(),'Payment fee is charged to the account you are transferring funds from, whether the INTERAC e-Transfer is cancelled, declined, expires or the recipient fails to answer security question correctly')]")
    private List<WebElement> verfiyfeeBody1ippage;

    @FindBy(xpath = ".//p[contains(@class,'M2MfieldSubtext') and contains(text(),'Transfers sent or received after 18:00 PT will reflect the next business date')]")
    private WebElement copytextippage;

    @FindBy(xpath = ".//p[contains(@class,'M2MfieldSubtext') and contains(text(),'Transfers sent or received after 18:00 PT will reflect the next business date')]")
    private List<WebElement> copytextippageList;

    @FindBy(xpath = "//div[contains(@id,'TxnHandler')]//span[contains(@class,'InteracTrademarkwp') or contains(text(),'Trademark of Interac Inc. Used under license.')]")
    private WebElement tradeMark;

    @FindBy(xpath = "//div[contains(@id,'VerifyInteracPayeeTransfer')]//span[contains(@class,'InteracTrademarkwp') or contains(text(),'Trademark of Interac Inc. Used under license.')]")
    private WebElement verifyTradeMark;


    @FindBy(xpath = ".//span[contains(@class,'InteracLogo')]")
    private WebElement verfiylogoconfirmation;

    @FindBy(xpath = ".//div[contains(@class,'verificationPage ')]//div[contains(text(),'Payment fee is charged to the account you are transferring funds from, whether the INTERAC e-Transfer is cancelled, declined, expires or the recipient fails to answer security question correctly')]")
    private WebElement verfiyfeeBodyverifypage;

    @FindBy(xpath = ".//div[contains(@class,'verificationPage ')]//div[contains(text(),'Payment fee is charged to the account you are transferring funds from, whether the INTERAC e-Transfer is cancelled, declined, expires or the recipient fails to answer security question correctly')]")
    private List<WebElement> verfiyfeeBody1verifypage;


    @FindBy(xpath = ".//div[contains(@class,'rightLblAlign')]//span[contains(text(),'Transfers sent or received after 18:00 PT will reflect the next business date')]")
    private WebElement copytextvppage;

    @FindBy(xpath = ".//div[contains(@class,'rightLblAlign')]//span[contains(text(),'Transfers sent or received after 18:00 PT will reflect the next business date')]")
    private List<WebElement> copytextvppageList;

    @FindBy(xpath = ".//div[contains(@class,'confirmTransferValue ')]//span[contains(text(),'Transfers sent or received after 18:00 PT will reflect the next business date')]")
    private WebElement copytextconfirpage;

    @FindBy(xpath = ".//div[contains(@class,'confirmTransferValue ')]//span[contains(text(),'Transfers sent or received after 18:00 PT will reflect the next business date')]")
    private List<WebElement> copytextconfirpageList;

    @FindBy(xpath = ".//span[contains(@class,'InteracLogo verifyInteracLogo')]")
    private WebElement verfiylogo;


    @FindBy(xpath = ".//div[contains(@class,'msgAvailableBalanceConfirm') and contains(text(),'CAD 1.25 is charged to the account you are transferring funds from, whether the INTERAC e-Transfer is cancelled, declined, expires, or the recipient fails to answer the security question correctly')]")
    private WebElement verfiyfeeBodyConfimpage;

    @FindBy(xpath = ".//div[contains(@class,'msgAvailableBalanceConfirm') and contains(text(),'CAD 1.25 is charged to the account you are transferring funds from, whether the INTERAC e-Transfer is cancelled, declined, expires, or the recipient fails to answer the security question correctly')]")
    private List<WebElement> verfiyfeeBodyListConfimpage;


    @FindBy(xpath = ".//input[contains(@class,'btnTertiary') and contains(@value,'My accounts')]")
    private WebElement myAccountButton;


    @FindBy(xpath = ".//span[contains(text(),'My accounts') and contains(@class,'title')]")
    protected WebElement verifyMyAccountTitle;


    public static final By pageFieldValueIe = By.xpath("//following-sibling::div[contains(@class, 'rightLblAlign')]");

    public static final By pageFieldNameIe = By
        .xpath(".//div[contains(@class,'itemList')]//div[contains(@data-dojo-attach-point,'dapVerifyDetailsDL')]//div[contains(@class,'itemLbl')or contains (@class,'divRedVerticalBar')]");


    public MoveMoneyVerifyPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    protected void isFromAccountNameDisplayed(final AccountDetails accountDetail) {
        Assert
            .assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyVerifyPage.LABEL_FROM, accountDetail.getAccountName(),
                UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
                "Given From Account Name not found.");
        Reporter.log("From Account Name displayed is :" + accountDetail.getAccountName());
    }

    @Override
    protected void isFromAccountNumberDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyVerifyPage.LABEL_FROM, accountDetail.getAccountNumber(),
            UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given From Account Number not found.");
        Reporter.log("From Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    @Override
    protected void isToAccountNameDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyVerifyPage.LABEL_TO, accountDetail.getAccountName(),
            UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Name not found.");
        Reporter.log("To Account Name displayed is :" + accountDetail.getAccountName());
    }

    @Override
    protected void isToAccountNumberDisplayed(final AccountDetails accountDetail) {
        Assert
            .assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyVerifyPage.LABEL_TO, accountDetail.getAccountNumber(),
                UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
                "Given To Account Number not found.");
        Reporter.log("To Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    @Override
    public void clickConfirmButton() {
        wait.until(ExpectedConditions.elementToBeClickable(confirmButton));
        confirmButton.click();
        Reporter.log("Confirm button is clicked.");
    }

    @Override
    public void clickEditDetailsButton() {
        wait.until(ExpectedConditions.elementToBeClickable(editDetailsButton));
        editDetailsButton.click();
        Reporter.log("Edit Details button is clicked.");
    }

    @Override
    public void verfiyInteractLogoCapturepage() {
        wait.until(ExpectedConditions.elementToBeClickable(verfiylogocapturepage));
        verfiylogocapturepage.isDisplayed();
        Reporter.log("Verify on the Capture /input page , interact e transfer logo is present below payee ");
    }


    @Override
    public void verfiyFeeBodyInputpage() {
        wait.until(ExpectedConditions.elementToBeClickable(verfiyfeeBodyippage));
        if (verfiyfeeBodyippage.isDisplayed() && !verfiyfeeBody1ippage.isEmpty()) {
            Reporter.log("Verify on the Capture /input page ,Verify the Fee field and body copy displayed below Fee field");
        } else {
            Reporter.log("Verify on the Capture /input page ,Verify the Fee field and body copy Not displayed below Fee field");

        }
    }

    @Override
    public void copytextInputpage() {
        wait.until(ExpectedConditions.elementToBeClickable(copytextippage));
        if (copytextippage.isDisplayed() && !copytextippageList.isEmpty()) {
            Reporter
                .log("Verify on the Capture /input page ,Transfers sent or received after 18:00 PT will reflect the next business date");
        } else {
            Reporter
                .log("Not Verify on the Capture /input page ,Transfers sent or received after 18:00 PT will reflect the next business date");

        }
    }

    @Override
    public void verfiyCapctureBrandingTradeMark() {

        wait.until(ExpectedConditions.elementToBeClickable(tradeMark));
        if (tradeMark.isDisplayed()) {
            Reporter.log("Verify on the Capture /input page , @Trademark of Interac Inc. Used under license. ");
        } else {
            Reporter.log("Verify on the Capture /input page ,not displayed @Trademark of Interac Inc. Used under license. ");
        }
    }

    @Override
    public void verfiypageBrandingTradeMark() {

        wait.until(ExpectedConditions.elementToBeClickable(verifyTradeMark));
        if (verifyTradeMark.isDisplayed()) {
            Reporter.log("Verify on the Verify page , @Trademark of Interac Inc. Used under license. ");
        } else {
            Reporter.log("Verify on the Verify page ,not displayed @Trademark of Interac Inc. Used under license. ");
        }
    }


    @Override
    public void verfiyInteractLogoConfirmation() {
        if (verfiylogoconfirmation.isDisplayed()) {
            Reporter.log("interact e transfer logo is present on the Confirmation page");
        } else {
            Reporter.log("interact e transfer logo is Notpresent on the Confirmation page");
        }
    }

    @Override
    public void verfiyFeeBodyVerifypage() {
        wait.until(ExpectedConditions.elementToBeClickable(verfiyfeeBodyverifypage));
        if (verfiyfeeBodyverifypage.isDisplayed() && !verfiyfeeBody1verifypage.isEmpty()) {
            Reporter.log("Verify on the Verify page ,Verify the Fee field and body copy displayed below Fee field");
        } else {
            Reporter.log("Verify on the Verify page ,Verify the Fee field and body copy Not displayed below Fee field");

        }
    }

    @Override
    public void copytextVerifypage() {
        wait.until(ExpectedConditions.elementToBeClickable(copytextvppage));
        if (copytextvppage.isDisplayed() && !copytextvppageList.isEmpty()) {
            Reporter
                .log("Verify on the Verify  page ,Transfers sent or received after 18:00 PT will reflect the next business date");
        } else {
            Reporter
                .log("Not Verify on the Verify page ,Transfers sent or received after 18:00 PT will reflect the next business date");

        }
    }

    @Override
    public void copytextConfimationypage() {
        wait.until(ExpectedConditions.elementToBeClickable(copytextconfirpage));
        if (copytextconfirpage.isDisplayed() && !copytextconfirpageList.isEmpty()) {
            Reporter
                .log("Verify on the Confirmation  page ,Transfers sent or received after 18:00 PT will reflect the next business date");
        } else {
            Reporter
                .log("Not Verify on the Confirmation page ,Transfers sent or received after 18:00 PT will reflect the next business date");

        }
    }

    @Override
    public void verfiyInteractLogoVerfiypage() {
        wait.until(ExpectedConditions.elementToBeClickable(verfiylogo));
        verfiylogo.isDisplayed();
        Reporter.log("Verify on the Verfiy /input page , interact e transfer logo is present below payee ");
    }

    @Override
    public void verfiyFeeBodyConfirmationpage() {
        wait.until(ExpectedConditions.elementToBeClickable(verfiyfeeBodyConfimpage));
        if (verfiyfeeBodyConfimpage.isDisplayed() && !verfiyfeeBodyListConfimpage.isEmpty()) {
            Reporter.log("Verify on the Confirmation page ,Verify the Fee field and body copy displayed below Fee field");
        } else {
            Reporter.log("Verify on the Confirmation page ,Verify the Fee field and body copy Not displayed below Fee field");

        }
    }

    @Override
    public void clickMyAccountButton() {
        wait.until(ExpectedConditions.elementToBeClickable(myAccountButton));
        myAccountButton.click();
        Reporter.log("My Account  button is clicked.");
    }

    @Override
    public void verifyMyAccountpage() {
        wait.until(ExpectedConditions.visibilityOf(verifyMyAccountTitle));
        if (verifyMyAccountTitle.isDisplayed()) {
            Reporter.log("Account Summay page is displayed after click on the My Account button.");
        } else {
            Reporter.log("Account Summay page is Not displayed after click on the My Account button.");
        }
    }


    @Override
    protected void isPayeeReferenceTextDisplayed(String payeeReference) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PAYEE_REFERENCE, payeeReference, UICommonUtil.verifyPage,
            pageFieldNameIe, pageFieldValueIe), "Given Your Payee Reference Text not found.");
        Reporter.log("Your Payee Reference Text displayed is :" + payeeReference);
    }

    @Override
    public void verifyLCY2LCYNowIETransactionDetailsOnVerifyPage(final Transaction transactionDetail) {
        validateNowFlowIETransfer(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        isPayeeReferenceTextDisplayed(transactionDetail.getPayeeReference());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    @Override
    protected void validateNowFlowIETransfer(final Transaction transactionDetail) {

        isPayeeName(transactionDetail.getToAccount().getPayeeName());
        isNotifyMeBy(transactionDetail.getToAccount().getEmailName());
        isEmailAddressSender(transactionDetail.getToAccount().getEmailAddress());
        isLanguage(transactionDetail.getToAccount().getLang());
        isSecurityQue(transactionDetail.getToAccount().getSecurityQue());
        isSecurityAns(transactionDetail.getToAccount().getSecurityAns());
        isNotifyMeBy(transactionDetail.getToAccount().getNotifyMeBy());
        isEmailAddressSender(transactionDetail.getToAccount().getEmailAddress());
        isFee(transactionDetail.getToAccount().getFee());
        isDate(transactionDetail.getToAccount().getDate());

    }

    @Override
    protected void isPayeeName(final String payeeName) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PAYEENAME, payeeName, UICommonUtil.verifyPage, pageFieldNameIe,
            pageFieldValueIe), "Given payee name is not found.");
        Reporter.log("payee name is  :" + payeeName);
    }

    @Override
    protected void isNotifyMeBy(final String email) {
        Assert.assertTrue(
            uiCommonUtil.textByParentAndSibling(LABEL_NOTIFY, email, UICommonUtil.verifyPage, pageFieldNameIe, pageFieldValueIe),
            "Given  Notify Me By name is not found.");
        Reporter.log("Is Notify Me By name correct" + email);
    }

    @Override
    protected void isLanguage(final String lang) {
        Assert.assertTrue(
            uiCommonUtil.textByParentAndSibling(LABEL_LANG, lang, UICommonUtil.verifyPage, pageFieldNameIe, pageFieldValueIe),
            "Given  lang is not found.");
        Reporter.log("lang  name is  :" + lang);

    }

    @Override
    protected void isSecurityQue(final String securityQuestion) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_SQUES, securityQuestion, UICommonUtil.verifyPage,
            pageFieldNameIe, pageFieldValueIe), "Given  Security question is not found.");
        Reporter.log("Security question  name is  :" + securityQuestion);
    }

    @Override
    protected void isSecurityAns(final String securityAnswer) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_SANS, securityAnswer, UICommonUtil.verifyPage, pageFieldNameIe,
            pageFieldValueIe), "Given  Security answer is not found.");
        Reporter.log("Security answer  name is  :" + securityAnswer);
    }

    @Override
    protected void isEmailAddressSender(final String emailAddressSender) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_EMAILADDRESS, emailAddressSender, UICommonUtil.verifyPage,
            pageFieldNameIe, pageFieldValueIe), "Given email Address is not found.");
        Reporter.log("email  name is  :" + emailAddressSender);
    }

    @Override
    protected void isFee(final String fee) {
        Assert.assertTrue(
            uiCommonUtil.textByParentAndSibling(LABEL_FEE, fee, UICommonUtil.verifyPage, pageFieldNameIe, pageFieldValueIe),
            "Given Fee is not found.");
        Reporter.log("Fee  name is  :" + fee);
    }

    @Override
    protected void isDate(final String date) {
        Assert.assertTrue(
            uiCommonUtil.textByParentAndSibling(LABEL_DATE, date, UICommonUtil.verifyPage, pageFieldNameIe, pageFieldValueIe),
            "Given Date is not found.");
        Reporter.log("Date  name is  :" + date);
    }

    @Override
    protected void isStartDateDisplayed(Transaction transaction) {
        try {
            String startDate = DateUtil.getDateToString(DATE_FORMAT, transaction.getFirstDateOfTransaction());
            Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_START_DATE, startDate, UICommonUtil.verifyPage,
                UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Start Date not found.");
            Reporter.log("Start Date displayed is :" + startDate);
        } catch (ParseException e) {
            MoveMoneyCapturePageModel.logger.error(e);
            Assert.fail("Parsing to Payment Date Fail " + e.getMessage(), e);
        }

    }


    /**************** Recurring Flow Verification ****************/
    /* RD - Transaction End date is removed from below methods */
    @Override
    public void verifyM2MLCY2LCYRecurringTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Verify Page.");
    }

    @Override
    public void verifyM2MLCY2FCYRecurringTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2FCYRecurring Transaction Details Verified on Verify Page");
    }

    @Override
    public void verifyM2MFCY2LCYRecurringTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("FCY2LCYRecurring Transaction Details Verified on Verify Page");
    }

    @Override
    public void verifyM2MFCY2FCYRecurringTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("FCY2LFYRecurring Transaction Details Verified on Verify Page");
    }


}
