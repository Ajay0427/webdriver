/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.digital.testauto.pageobject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.AccountTypes;
import com.hsbc.digital.testauto.models.OpenAccountDetails;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

/**
 * <p>
 * <b> This Model class will hold locators and functionality related methods
 * for LP Stories Account Summary, Account Overview , Transaction History &
 * Search, Download Transaction History that can be used around all entities
 * </b>
 * </p>
 * 
 * @version 1.0.0
 * @author Deepti Patil
 * 
 */

public abstract class LandingPageModel {

    protected WebDriver driver;
    protected final WebDriverWait wait;
    private final JavascriptExecutor jsx;
    protected final UICommonUtil uiCommonUtil;

    // Locator for Account Summary title
    @FindBy(xpath = "//div[contains(@id,'_titleBarNode')]//span[text()='My accounts']")
    protected WebElement accountSummaryTitle;

    // Locator for list of Accounts in Account Summary Section
    @FindBy(xpath = "//div[contains(@id,'TitlePane')]/span[@isgspentity='yes']")
    protected List<WebElement> accountsLists;

    @FindBy(xpath = "//div[contains(@id,'TitlePane')]/span[@isgspentity='yes' or @isgspentity='no']")
    protected List<WebElement> allAccountsLists;

    @FindBy(xpath = "//div[contains(@id,'TitlePane')]/span[@isgspentity='yes']//span[@class='itemTitle']")
    protected List<WebElement> accountsNameLists;

    @FindBy(xpath = "//div[contains(@id,'TitlePane')]/span[@isgspentity='yes']//span[contains(@class,'itemName')]")
    protected List<WebElement> accountsNumberLists;

    @FindBy(xpath = "//div[contains(@id,'TitlePane')]/span[@isgspentity='no']")
    protected List<WebElement> otherEntityAccountLists;

    @FindBy(xpath = "//span[@class='countryAccount']")
    protected List<WebElement> linkedEntities;

    @FindBy(xpath = "//span[contains(@class,'accountAccordionArrow')]//span[@class='arrowIcon']")
    protected List<WebElement> arrowButton;

    @FindBy(xpath = "//div[@class='dashboardTransations']/h2")
    protected WebElement otherEntityLoginButton;

    // Locator for image on Account Summary Section
    @FindBy(xpath = "//div[contains(@id,'TitlePane')]//span[contains(@class,'flag')]")
    private WebElement accountSummaryFlag;

    // Locators for account information on Account Overview Section
    @FindBy(xpath = "//div[@class='dashboardTransations']/h2")
    protected WebElement accountDescription;

    @FindBy(css = "div.dashboardTransations > p")
    protected WebElement overviewAccountNumber;

    @FindBy(css = "#currencyField > span.currencyType")
    protected WebElement accountCurrency;

    @FindBy(css = "#balanceField > span.label")
    private WebElement availableBalance;

    // Locator for account name of selected account in Account Summary Section
    @FindBy(xpath = "//span[contains(@class,'selected') or contains(@class,'bundleAccountSelected')]//span[@class='itemTitle']")
    private WebElement summaryAccountName;

    // Locator for account Balance of selected account in Account Summary
    // Section
    @FindBy(xpath = "//span[contains(@class,'selected') or contains(@class,'bundleAccountSelected')]//span[contains(@class,'itemValue privacy')]")
    private WebElement summaryAccountBalance;

    // Locator for account Currency of selected account in Account Summary
    // Section
    @FindBy(xpath = "//span[contains(@class,'selected') or contains(@class,'bundleAccountSelected')]//span[contains(@class,'itemValue privacy')]/following-sibling::span")
    private WebElement summaryAccountCurrency;

    // Locator for account Number of selected account in Account Summary
    // Section
    @FindBy(xpath = "//span[contains(@class,'selected') or contains(@class,'bundleAccountSelected')]//span[@class='itemDetails']/following-sibling::span[contains(@class,'itemName')]")
    private WebElement summaryAccountNumber;

    // Locator for print button on Account Summary Section
    @FindBy(xpath = "//div[@id='printButtonAcctSumm']/a")
    protected WebElement accountSummaryPrintButton;

    // Locators for Account Summary Print Preview Section

    @FindBy(xpath = "//div[contains(@class,'printFriendlyBox') ]//table//tbody//tr")
    private List<WebElement> printPreviewAccountList;

    @FindBy(xpath = "//div[contains(@id,'PrintFriendlyFormatDialog') and not(contains(@style,'display: none'))]//table[@summary='PrintTable']//tr")
    private List<WebElement> accountSummaryPrintPreviewAllTransDate;

    @FindBy(xpath = "//div[contains(@id,'PrintFriendlyFormatDialog') and not(contains(@style,'display: none'))]//div[contains(@id,'__WidgetsInTemplateMixin_')]//button[text()='Cancel']")
    protected WebElement accountSummaryPrintPreviewCancelButton;

    @FindBy(xpath = "//div[contains(@id,'PrintFriendlyFormatDialog') and not(contains(@style,'display: none'))]//button[@class='btnSecondary' and text()='Print']")
    protected WebElement accountSummaryPreviewPrintButton;

    @FindBy(xpath = "//div[contains(@id,'PrintFriendly') and not(contains(@style,'display: none'))]//span[contains(@class,'flag')]")
    private WebElement accountSummaryPrintPreviewFlag;

    @FindBy(xpath = "//div[contains(@id,'PrintFriendly') and not(contains(@style,'display: none'))]//span[@class='countryText']")
    private WebElement accountSummaryPrintPreviewEntityName;

    @FindBy(xpath = "//div[contains(@id,'PrintFriendly') and not(contains(@style,'display: none'))]//span[contains(@class,'PrintFriendlyHeading')]/following-sibling::span")
    private WebElement accountSummaryPrintPreviewDate;

    @FindBy(xpath = ".//div[contains(@id,'CcAccountSnapshot')]//span[text()='Balance as at']")
    private WebElement balanceAtDate;

    @FindBy(xpath = "//div[@class='gridxBody gridxBodyRowHoverEffect']//table[@class='gridxRowTable']//td[@colid='colDate']")
    private List<WebElement> transDateColumnAll;


    // Locators for Buttons on Account Overview Section
    @FindBy(xpath = "//span[contains(@id,'dijit_form_Button')]/span[text()='Details']")
    protected WebElement detailsButton;

    @FindBy(xpath = "//span[contains(@id,'dijit_form_Button')]/span[text()='Details']")
    protected List<WebElement> detailsButtons;

    @FindBy(xpath = "//div[@id='accountsummary']//*[contains(text(),'Move money')]")
    protected List<WebElement> moveMoneyButtons;

    @FindBy(xpath = "//a[@id='dapViewMorePrintBtn']")
    private WebElement accountOverviewPrintButton;

    @FindBy(xpath = "//button[contains(@class,'manage')]")
    protected WebElement manageButton;

    @FindBy(xpath = "//div[@class='manageContainer']//a[text()='Stop cheque']")
    public List<WebElement> stopChequeLinkManageMenuList;

    @FindBy(xpath = "//div[@id='dapManageAccContainer']//a[contains(@data-uid, 'accountInfoAndTnC')]")
    private List<WebElement> accInfoAndTnCLinkManageMenuList;

    @FindBy(xpath = "//span[text()='Search']")
    protected WebElement searchButton;

    // Locators for Print Preview Section of Account Overview section
    @FindBy(xpath = "//div[contains(@id,'PrintFriendlyFormatDialog') and not(contains(@style,'display: none'))]//div[@class='dashboardTransations']/p[1]")
    protected WebElement accountOverviewPrintPreviewAccountNumber;

    @FindBy(xpath = "//div[contains(@id,'PrintFriendlyFormatDialog') and not(contains(@style,'display: none'))]//div[@class='dashboardTransations']/h2")
    protected WebElement accountOverviewPrintPreviewAccountName;

    @FindBy(xpath = "//div[contains(@id,'PrintFriendlyFormatDialog') and not(contains(@style,'display: none'))]//table[@summary='PrintTable']//tr")
    private List<WebElement> accountOverviewPrintPreviewAllTransDate;

    @FindBy(xpath = "//div[contains(@id,'PrintFriendlyFormatDialog') and not(contains(@style,'display: none'))]//div[contains(@id,'__WidgetsInTemplateMixin_')]//button[text()='Cancel']")
    protected WebElement accountOverviewPrintPreviewCancelButton;

    @FindBy(xpath = "//div[contains(@id,'PrintFriendlyFormatDialog') and not(contains(@style,'display: none'))]//button[@class='btnSecondary' and text()='Print']")
    protected WebElement accountOverviewPreviewPrintButton;

    /*  @FindBy(xpath = "//div[contains(@id,'WidgetsInTemplateMixin')]//div/ul//span[3]")
      protected WebElement accountOverviewPreviewErrorMessage;
      */


    // Locators for Buttons on New Transaction Page of Move Money
    @FindBy(xpath = "//div[not(contains(@style,'display: none'))]//button[@data-dojo-attach-point='_btnCancel']")
    protected WebElement secondaryTransactionCancelButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_cancelButton']")
    protected WebElement primaryTransactionCancelButton;

    // Locators for labels and values on Details Section
    @FindBy(xpath = "//div[contains(@id,'accountDetails_')]//dt[contains(@class,'clearLeft')]")
    protected List<WebElement> detailsLabels;

    @FindBy(xpath = "//div[contains(@id,'accountDetailsFields')]//dd")
    private List<WebElement> detailsValues;

    // Locators for transaction table headers
    @FindBy(xpath = "//div[contains(@id,'TransactionGrid')]//th//div[@class='gridxSortNode']")
    protected List<WebElement> transactionTableHeaders;

    // Locators for transaction table widget
    @FindBy(xpath = "//div[contains(@id,'TransactionGridStructure')]//div[contains(@id,'gridx_Grid')]")
    protected List<WebElement> transactionGrid;

    // Locators for total transactions on transaction history table widget
    @FindBy(xpath = "//div[@class='gridxBody gridxBodyRowHoverEffect']//table[@class='gridxRowTable']//td[@colid='colDate']")
    protected List<WebElement> dateColumnAll;

    // View More button on Transaction History Widget
    @FindBy(xpath = "//button[text()='View more' and @aria-hidden='false']")
    private WebElement viewMoreButton;

    @FindBy(xpath = "//button[text()='View more' and @aria-hidden='false']")
    protected List<WebElement> viewMoreButtonList;

    // --------------Story Transaction History & Search----------------------

    // From Date text in Search Section
    @FindBy(xpath = "//input[starts-with(@id,'hdx_dijits_form_DateRange_') and contains(@id,'_dateFrom')]")
    protected WebElement fromDateTextField;

    // To Date text in Search Section
    @FindBy(xpath = "//input[starts-with(@id,'hdx_dijits_form_DateRange_') and contains(@id,'_dateTo')]")
    protected WebElement toDateTextField;

    // From Date icon in Search Section
    @FindBy(xpath = ".//table[starts-with(@id,'hdx_dijits_form_DateRange_') and contains(@id,'_dateFrom_popup')]")
    private WebElement fromDateInputField;

    // No Transaction error message
    @FindBy(xpath = "//div[@id='_dapTransactionGridError']//div/ul//span[3]")
    private WebElement errorMessage;

    @FindBy(xpath = "//div[@class='alertPanel error']//span[contains(text(),'no transactions')]")
    private List<WebElement> errorMessageList;

    // Error for Invalid Account name
    @FindBy(xpath = "  //span[contains(text(),'No transactions')]")
    private WebElement errorInvalidAccountName;

    // To Amount text field in Search Section
    @FindBy(xpath = "//input[contains(@id,'toAmount_CurrencyTextBox')]")
    private WebElement toAmountTextField;

    // From Amount text field in Search Section
    @FindBy(xpath = "//input[contains(@id,'fromAmount_CurrencyTextBox')]")
    private WebElement fromAmountTextField;

    // View Result button in Search Section
    @FindBy(xpath = "//button[text()='View results']")
    private WebElement viewResultButton;

    // error message for Future Date in Search Section
    @FindBy(xpath = "//span[starts-with(@id,'hdx_dijits_form_DateRange_') and contains(@id,'_dateFrom_validationMessage')]")
    private WebElement dateErrorMessage;

    // displaying elements/transaction on History
    @FindBy(xpath = "//div[contains(@id, 'gridx_Grid')]//div[contains(@class, 'gridxMain')]//div[contains(@class, 'gridxRow') and @role='row']")
    protected List<WebElement> transactionDetailDisplayElements;

    // x path to get list of description name
    @FindBy(xpath = "//div[starts-with(@id,'gridx_Grid_')]//span[contains(@class,'payeeItem')]")
    protected List<WebElement> transactionDetailsDescription;

    // x path to get search by name test field
    @FindBy(xpath = "//input[contains(@id,'nameSearch')]")
    protected List<WebElement> searchByName;

    // x path to get list of transaction details (Amount column)
    @FindBy(xpath = "//div[starts-with(@id,'gridx_Grid_')]//td[@colid='colAmount']")
    protected List<WebElement> transactionDetailsListAmountCol;

    // x-path for Clear Results button
    @FindBy(xpath = "//button[@title='Clear results']")
    private WebElement clearResultsButton;

    @FindBy(xpath = "//span[@title='Move money']")
    private WebElement moveMoneyButton;

    // To locate Move Money button
    @FindBy(xpath = "//h2[contains(@data-dojo-attach-point,'transactionTitle')]")
    private WebElement moveMoneyTransactionPage;

    @FindBy(xpath = "//div[starts-with(@id,'gridx_Grid_')]//td[contains(@class,'payee')]/span[1]")
    protected List<WebElement> descriptionColumnAll;

    @FindBy(xpath = "//div[@class='gridxBody gridxBodyRowHoverEffect']//td[@colid='colAmount']")
    protected List<WebElement> amountColAll;

    @FindBy(xpath = "//div[@class='gridxBody gridxBodyRowHoverEffect']//td[@colid='colBalance']")
    private List<WebElement> balanceColAll;

    @FindBy(xpath = "//div[@class='gridHeaderColContainer']//div[text()='Description']")
    protected WebElement descriptionSort;

    @FindBy(xpath = "//div[@class='gridHeaderColContainer']//div[contains(text(),'Amount')]")
    protected WebElement amountSort;

    @FindBy(xpath = "//div[@class='gridHeaderColContainer']//div[text()='Date']")
    private WebElement dateSort;

    @FindBy(xpath = "//div[@class='gridxSortNode' and contains(text(),'Balance')]")
    private WebElement balanceSort;

    @FindBy(xpath = "//th[contains(@id,'colDate')]")
    protected WebElement dateSortArrowButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_reviewClearSearch']")
    protected WebElement clearSearchButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_reviewtransnotlisted']")
    protected WebElement transactionNotListedButton;

    @FindBy(xpath = "//div[contains(@id,'ReportTransactionDialog') and contains(@style,'position: fixed')]//button[contains(@class,'dijitDialogCloseIcon')]")
    protected WebElement reportingAProblemDialogueCloseIcon;

    @FindBy(xpath = "//div[@class='gridxBodyEmpty']/span")
    private List<WebElement> noTransactionsMessage;


    // ------------------DowloandTransaction History---------------------------

    @FindBy(css = "span.countryAccount")
    protected WebElement leftHandMenuMyAccount;

    // Download button on overview section
    @FindBy(xpath = "//a[@id='dapViewMoreDownload']")
    protected WebElement downloadButton;

    // Radio button to choose format as csv
    @FindBy(xpath = "//div[starts-with(@id,'hdx_dijits_Dialog_') and contains(@class,'dijitDialogFixed dijitDialog')]//label[contains(text(),'CSV')]")
    protected WebElement radioCSV;

    // Radio button to choose format as qfx
    @FindBy(xpath = "//div[starts-with(@id,'hdx_dijits_Dialog_') and contains(@class,'dijitDialogFixed dijitDialog')]//label[contains(text(),'QFX')]")
    private WebElement radioQFX;

    // Radio button to choose format
    @FindBy(xpath = "//div[starts-with(@id,'hdx_dijits_Dialog_') and contains(@class,'dijitDialogFixed dijitDialog')]//label")
    protected List<WebElement> radioButtonList;

    // Cancel button on Download popup
    @FindBy(xpath = "//div[contains(@class,'dijitDialogFixed') and not(contains(@style,'display: none'))]//button[text()='Cancel']")
    private WebElement cancelButton;

    // Download button on Download popup
    @FindBy(xpath = "//div[contains(@class,'dijitDialogFixed') and not(contains(@style,'display: none'))]//button[text()='Download']")
    private WebElement downloadButtonOnPopup;

    @FindBy(xpath = "//div[contains(@class,'smallInputList')]")
    private List<WebElement> formatOption;

    // Transaction History review buttons
    @FindBy(xpath = "//button[@data-dojo-attach-point='_reviewSearchAgain']")
    private WebElement searchAgainButton;

    private final By locatorReferenceNumber = By.xpath(".//div[contains(@class, 'noDisplay')]//*[contains(@class, 'payeeItem')]");

    private final By locatorAmount = By.cssSelector("td.gridxSortCell.amount");

    private final By locatorBalance = By.cssSelector("td.gridxSortCell.balance");

    private final By locatorAccountName = By.xpath(".//span[contains(@class, 'itemTitle')]");

    private final By locatorAccountNumber = By.xpath(".//span[contains(@class, 'itemName')]");

    private final By accountOverviewPreviewErrorMessage = By
        .xpath("//div[contains(@id,'WidgetsInTemplateMixin')]//following-sibling::div[contains(@class,'printborderContent')]//ul//span[3]");

    private static final String[] expectedTransactionHeaders = {"Date", "Description", "Amount", "Balance", ""};

    public static final String ERROR_MESSAGE = "VerifyErrorMessage";
    public static final String VIEW_MORE_BUTTON_TEXT = "ViewMoreButton";
    public static final String VIEW_TRANSACTION_TEXT = "VerifyTransaction";

    private static final String GET_HIDDEN_TEXT = "return arguments[0].innerHTML";
    protected static final int DEFAULT_DECIMAL_PLACES = 2;

    private static final String INVALID_FROM_DATE = "02/14/2016";
    private static final String INVALID_TO_DATE = "02/15/2016";
    private static final String INVALID_SEARCH_NAME = "ssss";
    private final By locatorTransactionGridLoader = By
        .xpath("//span[(@id='_transactionGridLoader') and (not (@style='display: none;'))]");

    private final Transaction transaction;
    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(LandingPageModel.class);
    protected static final String PRODUCT_MAPPING_FILE = "/ProductMapping.properties";
    protected static final String MAPPING_FILE_PATH = "src/main/resources/projecttestdata/";
    public Map<String, String> productCodes = new HashMap<String, String>();

    public LandingPageModel(final WebDriver driver) {
        this.driver = driver;
        jsx = (JavascriptExecutor) driver;
        wait = new WebDriverWait(driver, 30);
        PageFactory.initElements(driver, this);
        uiCommonUtil = new UICommonUtil(driver);
        transaction = new Transaction();
    }

    public void verifyMortgageAccountOverviewInfo(final AccountDetails accountDetails) {}

    public void verifyBrokerageAccountInfo(final AccountDetails accountDetails) {}

    public void verifyRetirementAccountOverviewInfo(final AccountDetails accountDetails) {}

    public void verifyLoanAccountOverviewInfo(final AccountDetails accountDetails) {}

    public void verifyAccountOverviewInfo(final AccountDetails accountDetails) {}

    public void verifyCreditCardAccountOverviewInfo(final AccountDetails accountDetails) {}

    public void verifyTDAccountOverviewInfo(final AccountDetails accountDetails) {}

    public void verifyCurrentAccountDetails() {}

    public void verifySavingsAccountDetails() {}

    public void verifyLoanAccountDetails() {}

    public void verifyCurrentManageLinks() {}

    public void verifySavingsManageLinks() {}

    public void verifyTDManageLinks() {}

    public void verifyMortgageManageLinks() {}

    public void verifyInvestmentManageLinks() {}

    public void verifyCreditCardManageLinks() {}

    public void verifyLoanManageLinks() {}

    public void verifyTDAccountDetails() {}

    public void verifyRetirementAccountDetails() {}

    public void verifyCreditCardDetails() {}

    public void verifyDisclaimerDisplayedInDetailsSection() {}

    public void verifySelectCreditDetails() {}

    public void verifyMortgageAccountDetails() {}

    public void verifyMoveMoneyNavigation(final AccountDetails accDetail) {}

    public void verifyMultipleEntityAccounts() {}

    public void verifyAccountSummarySection() {}

    public void verifyRetirementAccountPrint(final AccountDetails accountDetails) {}

    public void verifyRealTimeUpdate(final AccountDetails accDetail) {}

    public void verifyAccountOverviewHelp(final AccountDetails accDetail) {}

    public void verifyOrderOfAccounts() {}

    public void verifyBundledAccountSummary() {}

    public void verifyBundledAccountOverviewSection() {}

    public void storeProductCode(final AccountDetails accountDetails, final WebElement account) {}

    public void verifyTitle() {
        Assert.assertTrue(accountSummaryTitle.isDisplayed(), "Dashboard Page not shown.");
    }

    /**
     * Method to verify summary section and also overview details.
     * 
     */
    public void verifyAccountSummaryDetails() {
        for (WebElement account : accountsLists) {
            String accountText = account.getText();
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", account);
            account.click();
            verifyAccountSummaryInfo();
            AccountDetails accDetail = setAccountInfo(accountText);
            storeProductCode(accDetail, account);
            verifyAccountOverview(accDetail);
            verifyRealTimeUpdate(accDetail);
        }
        verifyBundledAccountSummary();
    }

    /**
     * Method to verify account summary section of selected account.
     * 
     */
    public void verifyAccountSummaryInfo() {
        isElementDisplayed(summaryAccountName);
        Reporter.log("Summary Account Name displayed. ");
        isElementDisplayed(summaryAccountNumber);
        Reporter.log("Summary Account Number displayed. ");
        isElementDisplayed(summaryAccountBalance);
        Reporter.log("Summary Account Balance displayed. ");
        isElementDisplayed(summaryAccountCurrency);
        Reporter.log("Summary Account Currency displayed. ");
    }

    /**
     * Method to set account details of selected account.
     * 
     * @param account
     *            details
     * 
     */
    public AccountDetails setAccountInfo(final String accountText) {
        AccountDetails accountDetails = new AccountDetails();
        String[] details = accountText.split("\\r?\\n");
        accountDetails.setAccountName(details[0]);
        accountDetails.setAccountNumber(details[1]);
        accountDetails.setAccountBalance(details[2]);
        accountDetails.setCurrency(details[3]);
        return accountDetails;
    }

    /**
     * Method to verify account overview section of selected account.
     * 
     */
    public void verifyAccountOverviewSection() {
        verifySingleEntityOverviewSection(accountsLists);
        verifyBundledAccountOverviewSection();
    }

    /**
     * Method to verify account overview section of local entity.
     * 
     * @param accounts
     *            list
     */
    public void verifySingleEntityOverviewSection(final List<WebElement> listOfAccounts) {
        int totalAccounts = listOfAccounts.size();
        int i = 0;
        while (true) {
            WebElement account = listOfAccounts.get(i);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", account);
            String accountText = account.getText();
            account.click();
            AccountDetails accountDetail = setAccountInfo(accountText);
            storeProductCode(accountDetail, account);
            verifyAccountOverview(accountDetail);
            verifyAccountDetails(accountDetail);
            verifyRealTimeUpdate(accountDetail);
            verifyAccountOverviewHelp(accountDetail);
            verifyAccountOverviewPrint(accountDetail);
            verifyMoveMoneyNavigation(accountDetail);
            i++;
            if (i == totalAccounts) {
                break;
            }

        }
    }

    /**
     * Method to verify account overview section of multiple entity.
     * 
     */
    public void verifyMultipleEntityOverviewSection() {
        verifyMultipleEntityAccounts();
    }

    /**
     * Method to select an account from account summary list.
     * 
     * @param element
     * @return account details
     * 
     */
    public String selectAccount(final AccountDetails accountDetails, final List<WebElement> list) {
        int randomIndex = RandomUtil.generateIntNumber(1, list.size());
        String accountText = StringUtils.EMPTY;
        for (int index = 0; index < list.size(); index++) {
            WebElement element = list.get(index);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
            if ((accountDetails != null && element.getText().contains(accountDetails.getAccountNumber()))
                || (accountDetails == null && index == randomIndex)) {
                accountText = element.getText();
                element.click();
                break;
            }
        }
        return accountText;
    }

    /**
     * Method to click any particular element.
     * 
     * @param element
     * 
     */
    public void clickElement(final WebElement element) {
        try {
            Assert.assertTrue(element.isDisplayed(), "Element not displayed");
            Assert.assertTrue(element.isEnabled(), "Element not enabled");
            element.click();
            Reporter.log("Element clicked. ");
        } catch (Exception e) {
            LandingPageModel.logger.error("Exception:", e);
        }
    }

    /**
     * To get total accounts size
     * 
     * @return
     */
    public int getAccountListSize() {
        Reporter.log("Total accounts present on landing Page are: " + accountsLists.size() + ".| ");
        return accountsLists.size();
    }

    /**
     * Method to verify Print button on Account Summary section.
     * 
     */
    public void verifyAccountSummaryPrint() {
        int size = allAccountsLists.size();
        accountSummaryPrintButton.click();
        Reporter.log("Print Button is clicked");
        verifyAccountSummaryPrintPreviewDetails(size);
        verifyAccountSummaryPrintPreviewPage();
    }

    /**
     * Method to verify details on Account Summary Print Preview Page.
     * 
     * @param size
     */
    public void verifyAccountSummaryPrintPreviewDetails(final int size) {
        Assert.assertTrue(size == printPreviewAccountList.size(), "Account List size: " + printPreviewAccountList.size()
            + " : on print preview page is not correct.");
        Reporter.log("Details on preview page verified. ");
    }

    /**
     * Method to verify Account Summary Print Preview section.
     * 
     */
    public void verifyAccountSummaryPrintPreviewPage() {
        isElementDisplayed(accountSummaryPrintPreviewDate);
        Reporter.log("Date on Summary Preview Page displayed. ");
        isElementDisplayed(accountSummaryPrintPreviewFlag);
        Reporter.log("Flag on Summary Preview Page displayed. ");
        isElementDisplayed(accountSummaryPrintPreviewEntityName);
        Reporter.log("Entity name on Summary Preview Page displayed. ");
        isElementDisplayed(accountSummaryPreviewPrintButton);
        Reporter.log("Print Button on Summary Preview Page displayed. ");
        isElementDisplayed(accountSummaryPrintPreviewCancelButton);
        Reporter.log("Cancel button on Summary Preview Page displayed. ");
        accountSummaryPrintPreviewCancelButton.click();
        Reporter.log("Cancel Button is clicked. ");
    }

    /**
     * Method to verify account information on account overview section.
     * 
     * @param object
     *            of AccountDetails class
     */
    public void verifyAccountOverview(final AccountDetails accountDetails) {
        AccountTypes accountTypes = checkAccountType(accountDetails);
        Reporter.log("Account Selected is: " + accountTypes);
        switch (accountTypes) {
        case SAVINGS:
        case TFSASAVINGS:
            verifyAccountOverviewInfo(accountDetails);
            verifySavingsManageLinks();
            break;
        case CURRENT:
            verifyAccountOverviewInfo(accountDetails);
            verifyCurrentManageLinks();
            break;
        case TERMDEPOSIT:
        case TFSATERMDEPOSIT:
            verifyTDAccountOverviewInfo(accountDetails);
            verifyTDManageLinks();
            break;
        case MORTGAGE:
            verifyMortgageAccountOverviewInfo(accountDetails);
            verifyMortgageManageLinks();
            break;
        case LOAN:
            verifyLoanAccountOverviewInfo(accountDetails);
            verifyLoanManageLinks();
            break;
        case INVESTMENT:
            verifyInvestmentAccountOverviewInfo(accountDetails);
            verifyInvestmentManageLinks();
            break;
        case RETIREMENT:
            verifyRetirementAccountOverviewInfo(accountDetails);
            break;
        case BROKERAGE:
            verifyBrokerageAccountInfo(accountDetails);
            break;
        case SELECTCREDIT:
        case CREDIT:
            verifyCreditCardAccountOverviewInfo(accountDetails);
            verifyCreditCardManageLinks();
            break;
        case INSURANCE:
            verifyInsuranceAccountOverviewInfo(accountDetails);
            break;
        case HCA:
            verifyAccountOverviewInfo(accountDetails);
            break;
        case PENSION:
            verifyInsuranceAccountOverviewInfo(accountDetails);
            break;
        case HIDC:

            break;
        case RRSP:

            break;
        case EMPRE:

            break;
        default:
            verifyAccountInfo(accountDetails);
        }
    }

    public AccountTypes checkAccountType(final AccountDetails accountDetails) {
        if (accountDetails
            .getAccountName()
            .toLowerCase()
            .matches(
                "(.*)chequing(.*)|(.*)checking(.*)|(.*)chkg(.*)|performance statement|(.*)current(.*)|hsbc premier|hsbc advance(.*)|extravantage(.*)|commercial asset mgmt")
            && !accountDetails.getAccountName().toLowerCase().matches("(.*)savings(.*)")) {
            return AccountTypes.CURRENT;
        } else if (!accountDetails.getAccountName().toLowerCase().matches("(.*)remittance(.*)|(.*)retirement(.*)|(.*)tfsa(.*)")
            && accountDetails.getAccountName().toLowerCase().matches("(.*)savings(.*)")) {
            return AccountTypes.SAVINGS;
        } else if (accountDetails.getAccountName().toLowerCase().matches("(.*)mortgage(.*)")) {
            return AccountTypes.MORTGAGE;
        } else if (accountDetails.getAccountName().toLowerCase().matches("(.*)retirement(.*)")) {
            return AccountTypes.RETIREMENT;
        } else if (accountDetails.getAccountName().toLowerCase().matches("(.*)loan(.*)")) {
            return AccountTypes.LOAN;
        } else if (accountDetails.getAccountName().toLowerCase()
            .matches("(.*)time(.*)|(.*)term(.*)|(.*)gic(.*)|(.*)tfsa high(.*)|(.*)month(.*)|(.*)year(.*)")) {
            return AccountTypes.TERMDEPOSIT;
        } else if (accountDetails.getAccountName().toLowerCase()
            .matches("(.*)investment(.*)|(.*)hsbc advance(.*)|(.*)mmx4(.*)|(.*)money market value(.*)")
            && !accountDetails.getAccountName().toLowerCase().matches("(.*)savings(.*)")) {
            return AccountTypes.INVESTMENT;
        } else if (accountDetails.getAccountName().toLowerCase().matches("(.*)remittance(.*)")) {
            return AccountTypes.REMITTANCE;
        } else if (accountDetails.getAccountName().toLowerCase().matches("brokerage(.*)")) {
            return AccountTypes.BROKERAGE;
        } else if (accountDetails.getAccountName().toLowerCase().matches("select credit")) {
            return AccountTypes.SELECTCREDIT;
        } else if (accountDetails.getAccountName().toLowerCase().matches("(.*)credit(.*)")) {
            return AccountTypes.CREDIT;
        } else if (accountDetails.isBundledAccount() == true) {
            return AccountTypes.BUNDLED;
        } else {
            Reporter.log("Account Selected does not match any criteria.");
        }
        return null;
    }

    /**
     * Method to verify account information on account overview section.
     * 
     * @param object
     *            of AccountDetails class
     */
    public void verifyAccountInfo(final AccountDetails accountDetails) {
        verifyAccountDescription(accountDetails);
        verifyAccountNumber(accountDetails);
        verifyAccountCurrency(accountDetails);
        isBalanceDisplayed(accountDetails);
        Reporter.log("Balance on overview Page displayed. ");
        if (!transactionGrid.isEmpty()) {
            verifyTransactionHistoryWidget();
        } else {
            Reporter.log("There are no transactions performed for this account. ");
        }
    }

    public void verifyTransactionHistoryWidget() {
        if (!transactionTableHeaders.isEmpty()) {
            verifyFields(Arrays.asList(LandingPageModel.expectedTransactionHeaders), transactionTableHeaders);
        }

        if (dateColumnAll.size() > 5) {
            verifyViewMoreFunctionality(dateColumnAll.size());
        } else if (dateColumnAll.size() < 5) {
            Assert.assertTrue(viewMoreButtonList.isEmpty(), "View More Button Displayed");
            Reporter.log("Transactions in history are less then 5. Hence, View More button not displayed. ");
        }
    }

    public void verifyViewMoreFunctionality(final int size) {
        isElementDisplayed(viewMoreButtonList.get(0));
        Reporter.log("View more button displayed. ");
        viewMoreButtonList.get(0).click();
        if (dateColumnAll.size() > size) {
            Reporter.log("More Transactions are displayed. ");
        }
    }


    /**
     * Method to verify account description/type/name on account overview
     * section.
     * 
     * @param object
     *            of AccountDetails class
     */
    public void verifyAccountDescription(final AccountDetails accountDetails) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", accountDescription);
        Assert.assertTrue(
            accountDescription.isDisplayed() && accountDetails.getAccountName().equalsIgnoreCase(accountDescription.getText()),
            "Account description not displayed and incorrect");
        Reporter.log("Account Name " + accountDescription.getText() + " displayed and verified. ");
    }

    /**
     * Method to verify account number on account overview section.
     * 
     * @param object
     *            of AccountDetails class
     */
    public void verifyAccountNumber(final AccountDetails accountDetails) {
        Assert.assertTrue(
            overviewAccountNumber.isDisplayed()
                && accountDetails.getAccountNumber().equalsIgnoreCase(overviewAccountNumber.getText()),
            "Account Number not displayed and incorrect");
        Reporter.log("Account Number: " + overviewAccountNumber.getText() + " displayed and verified. ");
    }

    /**
     * Method to verify account Currency on account overview section.
     * 
     * @param object
     *            of AccountDetails class
     */
    public void verifyAccountCurrency(final AccountDetails accountDetails) {
        Assert.assertTrue(
            accountCurrency.isDisplayed() && accountDetails.getCurrency().equalsIgnoreCase(accountCurrency.getText()),
            "Account Currency not displayed");
        Reporter.log("Account Currency displayed and verified. ");
    }

    /**
     * Method to verify Available Balance on account overview section.
     * 
     */
    public void isBalanceDisplayed(final AccountDetails accountDetails) {
        Assert.assertTrue(availableBalance.isDisplayed(), "Account Balance not displayed");
        Reporter.log("Account Balance displayed and verified. ");
    }

    /**
     * Method to verify Account Details Section after clicking on details
     * button on account overview section.
     * 
     */
    public void verifyAccountDetails(final AccountDetails accountDetails) {
        AccountTypes accountTypes = checkAccountType(accountDetails);
        if (!(accountTypes.equals(AccountTypes.BROKERAGE) || accountTypes.equals(AccountTypes.INVESTMENT))) {
            Assert.assertTrue(detailsButton.isDisplayed(), "Details Button is displayed and verified");
            Reporter.log("Details Button is displayed and verified. ");
            clickElement(detailsButton);
            Reporter.log("Details Button is clicked to expand the details section. ");
            switch (accountTypes) {
            case SAVINGS:
            case TFSASAVINGS:
                verifySavingsAccountDetails();
                break;
            case CURRENT:
                verifyCurrentAccountDetails();
                break;
            case TERMDEPOSIT:
            case TFSATERMDEPOSIT:
                verifyTDAccountDetails();
                break;
            case MORTGAGE:
                verifyMortgageAccountDetails();
                break;
            case LOAN:
                verifyLoanAccountDetails();
                break;
            case INVESTMENT:
                verifyAccountInfo(accountDetails);
                break;
            case RETIREMENT:
                verifyRetirementAccountDetails();
                break;
            case CREDIT:
                verifyCreditCardDetails();
                break;
            case SELECTCREDIT:
                verifySelectCreditDetails();
                break;
            case HIDC:

                break;
            case RRSP:

                break;
            default:
                break;
            }
            verifyDisclaimerDisplayedInDetailsSection();
            clickElement(detailsButton);
            Reporter.log("Details Button is clicked to close the details section. ");
        } else {
            Reporter.log("Selected Account does not support Details Section.");
        }
    }

    /**
     * Method to verify Print button on account overview section.
     * 
     * @param object
     *            of AccountDetails class
     */
    public void verifyAccountOverviewPrint(final AccountDetails accountDetails) {
        AccountTypes accountTypes = checkAccountType(accountDetails);
        if (!accountTypes.equals(AccountTypes.RETIREMENT)) {
            verifyAccountOverviewPrintPreviewPage(accountDetails);
        } else {
            verifyRetirementAccountPrint(accountDetails);
        }
    }

    /**
     * Method to verify Print Preview section.
     * 
     * @param accountNumber
     *            , size
     * 
     */
    public void verifyAccountOverviewPrintPreviewPage(final AccountDetails accountDetails) {
        verifyAccountOverviewPrintPreviewDetails(accountDetails);
        isAccountOverviewPrintPreviewButtonsDisplayed();
    }

    /**
     * Method to verify Print Preview Buttons.
     * 
     */
    public void isAccountOverviewPrintPreviewButtonsDisplayed() {
        isElementDisplayed(accountOverviewPreviewPrintButton);
        Reporter.log("Print Button on preview page verified. ");
        isElementDisplayed(accountOverviewPrintPreviewCancelButton);
        Reporter.log("Cancel Button on preview page verified. ");
        clickElement(accountOverviewPrintPreviewCancelButton);
        Reporter.log("Cancel Button is clicked. ");
    }

    /**
     * Method to verify details on Print Preview Page.
     * 
     */
    public void verifyAccountOverviewPrintPreviewDetails(final AccountDetails accountDetails) {

        if (!transactionGrid.isEmpty()) {
            int size = transDateColumnAll.size();
            accountOverviewPrintButton.click();
            Reporter.log("Print Button is clicked. ");
            Assert.assertTrue(accountDetails.getAccountNumber()
                .equalsIgnoreCase(accountOverviewPrintPreviewAccountNumber.getText())
                && size == accountOverviewPrintPreviewAllTransDate.size() - 1, "Account Number: "
                + accountOverviewPrintPreviewAccountNumber.getText() + " : or the size of transaction: "
                + (accountOverviewPrintPreviewAllTransDate.size() - 1) + " :on print preview page is not correct.");
        } else if (!getNoTransactionErrorMessageElementList().isEmpty()) {
            accountOverviewPrintButton.click();
            Reporter.log("Print Button is clicked. ");
            Assert.assertTrue(
                accountDetails.getAccountNumber().equalsIgnoreCase(accountOverviewPrintPreviewAccountNumber.getText())
                    && uiCommonUtil.activeElement(accountOverviewPreviewErrorMessage).isDisplayed(), "Account Number: "
                    + accountOverviewPrintPreviewAccountNumber.getText()
                    + " :is not correct or error message is not displayed on print preview page.");
        } else {
            accountOverviewPrintButton.click();
            Reporter.log("Print Button is clicked. ");
            Assert.assertTrue(accountDetails.getAccountNumber()
                .equalsIgnoreCase(accountOverviewPrintPreviewAccountNumber.getText())
                && accountDetails.getAccountName().equalsIgnoreCase(accountOverviewPrintPreviewAccountName.getText()),
                "Account Number: " + accountOverviewPrintPreviewAccountNumber.getText() + " : or Name: "
                    + accountOverviewPrintPreviewAccountName.getText() + " : on print preview page is not correct.");
        }
        Reporter.log("Details on preview page verified. ");
    }

    /**
     * Method to check if the element is displayed.
     * 
     * @param WebElement
     * 
     */
    public void isElementDisplayed(final WebElement element) {
        Assert.assertTrue(element.isDisplayed(), "Element not Displayed. ");
    }

    /**
     * Method to verify fields in details section.
     * 
     * @param expectedLabels
     */
    public void verifyFields(final List<String> expectedLabels, final List<WebElement> actualLabelList) {
        List<String> actualLabels = new ArrayList<>();
        for (WebElement actualLabel : actualLabelList) {
            actualLabels.add(actualLabel.getText());
        }
        Assert.assertTrue(expectedLabels.containsAll(actualLabels), "All feilds not present.");
        Reporter.log("All fields verified. ");
    }

    /**
     * Method to verify Investment account summary section
     * 
     * @param accountDetails
     */
    public void verifyInvestmentAccountOverviewInfo(final AccountDetails accountDetails) {
        verifyAccountInfo(accountDetails);
    }

    // -------------Transaction History & Search----------------------------

    public void verifyTransactionHistorySection(final String option) {
        int counter = 1;
        for (WebElement acc : accountsLists) {
            jsx.executeScript("arguments[0].scrollIntoView(true);", acc);
            acc.click();
            wait.until(ExpectedConditions.invisibilityOfElementLocated(locatorTransactionGridLoader));
            counter++;
            if (option.equals(LandingPageModel.ERROR_MESSAGE) && !getNoTransactionErrorMessageElementList().isEmpty()) {
                Reporter.log("Account is selected to verify error message. | ");
                break;
            } else if (option.equals(LandingPageModel.VIEW_MORE_BUTTON_TEXT) && !viewMoreButtonList.isEmpty()) {
                Reporter.log("Account is selected to verify View More button. | ");
                break;
            } else if (option.equals(LandingPageModel.VIEW_TRANSACTION_TEXT) && !transactionDetailDisplayElements.isEmpty()) {
                Reporter.log("Account is selected with some transaction history. | ");
                break;
            }
        }
        if (counter > accountsLists.size()) {
            Reporter.log("No account found for required condition , Please change profile to execute this scenario");
            Assert.fail("No Suitable Account found for this scenario");
        }
    }

    public void clickSearchButton() {
        Assert.assertTrue(searchButton.isDisplayed(), "Search button is not displayed. | ");
        searchButton.click();
        Reporter.log("Search button clicked. | ");
    }

    public int enterToAmount() {
        Integer endRange = RandomUtil.generateIntNumber(999999, 100000000);
        toAmountTextField.sendKeys(endRange.toString());
        Reporter.log(endRange + " entered in \"To Amount\" text field. ");
        return endRange;
    }

    public void clickViewResultButton() {
        Assert.assertTrue(viewResultButton.isDisplayed(), "View results button is not displayed. ");
        viewResultButton.click();
        Reporter.log("View Results button clicked. | ");
    }

    public void verifyTransactionHistoryInDateRage(final String fromDate, final String toDate) {}

    public String getFutureDate(final Date todayDate, final int numOfYear) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(todayDate);
        calendar.add(Calendar.YEAR, numOfYear);
        DateFormat dateFormat = new SimpleDateFormat(DateUtil.DATE_FORMAT_MMDDYYYY);
        String today = dateFormat.format(calendar.getTime());
        return today;
    }

    public String getFromDate() throws ParseException {
        return DateUtil.getDateToString(getInputDateFormat(),
            DateUtil.getStringToDate(getDisplayDateFormat(), dateColumnAll.get(dateColumnAll.size() - 1).getText()));
    }

    protected String getDisplayDateFormat() {
        return DateUtil.DATE_FORMAT_DDMMMYYYY;
    }

    protected String getInputDateFormat() {
        return DateUtil.DATE_FORMAT_MMDDYYYY;
    }

    public String getToDate() throws ParseException {
        return DateUtil.getDateToString(getInputDateFormat(),
            DateUtil.getStringToDate(getDisplayDateFormat(), dateColumnAll.get(0).getText()));
    }

    public void enterInvalidFromDate() {
        Assert.assertTrue(fromDateTextField.isDisplayed(), "FromDate Text field is not displayed. ");
        Reporter.log("\"From date\" text field is displayed. ");
        fromDateTextField.sendKeys(getInvalidFromDate());
        Reporter.log("Date i.e. : " + getInvalidFromDate() + " is entered in \"From Date\" field. ");
    }

    public String getInvalidFromDate() {
        return INVALID_FROM_DATE;
    }

    /**
     * Method to get INVALID_FROM_DATE as String.
     */
    public void enterInvalidToDate() {
        Assert.assertTrue(toDateTextField.isDisplayed(), "To Date Text field is not displayed. ");
        Reporter.log("\"To date\" text field is displayed. ");
        toDateTextField.sendKeys(getInvalidToDate());
        Reporter.log("Date i.e. : " + getInvalidToDate() + " is entered in \"To Date\". ");
    }

    /**
     * Method to get INVALID_TO_DATE as String.
     */
    public String getInvalidToDate() {
        return INVALID_TO_DATE;
    }

    public int enterFromAmount() {
        Integer endRange = RandomUtil.generateIntNumber(1, 3);
        fromAmountTextField.sendKeys(endRange.toString());
        Reporter.log(endRange + " entered in \"From Amount\" text field.");
        return endRange;
    }

    public void enterFromDate(final String Date) {
        Assert.assertTrue(fromDateTextField.isDisplayed(), "FromDate Text field is not displayed");
        Reporter.log("From date text field is displayed");
        fromDateTextField.sendKeys(Date);
        Reporter.log("Date i.e. : " + Date + " is entered in From Date");
    }

    public void enterToDate(final String date) {
        Assert.assertTrue(toDateTextField.isDisplayed(), "To Date Text field is not displayed");
        Reporter.log("To date text field is displayed");
        toDateTextField.sendKeys(date);
        Reporter.log("Date i.e. : " + date + " is entered in To Date");
    }

    public void verifyErrorMessageForInvalidDate() {
        Assert.assertTrue(dateErrorMessage.isDisplayed(), "Error message is not displayed for invalid date. ");
        Reporter.log("Error message is displayed as : " + dateErrorMessage.getText());
    }

    public void verifyErrorMessageForInvalidDetails() {
        Reporter.log("\"No Transaction Error message\" is displayed. Error message is: " + errorMessage.getText());
    }

    public int getDisplayTransactionCount() {
        return transactionDetailDisplayElements.size();
    }

    // verify count of displaying element before and after clicking on View
    // More button
    public void verifyViewMoreButtonFunctionality() {
        int beforeCount = getDisplayTransactionCount();
        viewMoreButtonList.get(0).click();
        Reporter.log("Click on View More button");
        int afterCount = getDisplayTransactionCount();
        Assert.assertTrue(afterCount > beforeCount, "View more functionality is not working properly");
        Reporter.log("Value of displaying details before clicking ov ViewMore : " + beforeCount
            + " Count after clcing of Viewmore : " + afterCount);
    }

    // functions for story transaction search
    public String getDescriptionName() {
        return transactionDetailsDescription.get(0).getText();
    }

    public void enterSearchName(final String name) {
        Assert.assertTrue(checkAndVerifyExistence(searchByName), "Search by name test is not visible");
        searchByName.get(0).sendKeys(name);
        Reporter.log("Account name entered in \"Search by name\" field is " + name + " . | ");
    }

    protected boolean checkAndVerifyExistence(final List<WebElement> element) {
        if (!element.isEmpty() && element.get(0).isDisplayed()) {
            return true;
        } else {
            return false;
        }
    }

    public void enterInvalidSearchName() {
        Assert.assertTrue(checkAndVerifyExistence(searchByName), "\"Search by name\" text field is not visible.");
        Reporter.log("\"Search by name\" text field is visible. | ");
        searchByName.get(0).sendKeys(LandingPageModel.INVALID_SEARCH_NAME);
        Reporter.log("Name entered in \"Search by name\" text field is " + LandingPageModel.INVALID_SEARCH_NAME + ". | ");
    }

    public void compareResultByName(final String expname) {
        String DescriptionName = transactionDetailsDescription.get(0).getText();
        Assert.assertTrue(DescriptionName.contains(expname), "Expected name i.e. +" + expname + " is not present in description. ");
    }

    public void compareResultAmount(final int fromAmt, final int toAmt) {
        String amountValueString = transactionDetailsListAmountCol.get(0).getText();

        if (amountValueString.contains("-") || amountValueString.contains(",")) {
            amountValueString = amountValueString.replace("-", "").replace(",", "");
        }
        Double actualAmount = Double.valueOf(amountValueString);
        Assert.assertTrue(actualAmount >= fromAmt && actualAmount <= toAmt, "Amount is displaying as " + actualAmount
            + " which dosen't lie between + " + fromAmt + " and " + toAmt);
    }

    public void clickPrintButton() {
        Assert
            .assertTrue(accountOverviewPrintButton.isDisplayed(), "Print button is not displayed on Transaction History section.");
        accountOverviewPrintButton.click();
        Reporter.log("Print button is clicked on Transaction History section. ");
    }

    public void verifyPrintButtonOnPopup() {
        Assert.assertTrue(accountOverviewPreviewPrintButton.isDisplayed(), "Print button is not displayed on popup");
        Reporter.log("Print button is displayed on Popup");
    }

    public void verifyErrorForInvalidAccountName() {
        Assert.assertTrue(transactionGrid.isEmpty(), "Transactions displayed for invalid account. ");
        String errMessage = errorInvalidAccountName.getText();
        Reporter.log("Error is displayed as :" + errMessage);
    }

    public void verifyClearSearchButton(final List<String> transactionsList) {}

    public void verifyClearResultsButton() {
        String beforeValue = searchByName.get(0).getAttribute("value");
        Assert.assertTrue(getClearResultsButton().isDisplayed(), "Clear Results button is not present");
        getClearResultsButton().click();
        Reporter.log("Clear Results button clicked");
        String afterValue = searchByName.get(0).getAttribute("value");
        Assert.assertTrue(!beforeValue.equals(afterValue), "Clear Results button functionality not working properly. ");
        Reporter.log("Value displayed before and after clicking on Clear Results button is " + beforeValue + " and " + afterValue
            + ". | ");
    }

    public WebElement getClearResultsButton() {
        return clearResultsButton;
    }

    public void clickMoveMoneyButton() {
        Assert.assertTrue(getMoveMoneyButton().isDisplayed(), "MoveMoney button is not displayed. ");
        Reporter.log("Move Money button is displayed. | ");
        getMoveMoneyButton().click();
        Reporter.log("Move Money button clicked. | ");
    }

    protected WebElement getMoveMoneyButton() {
        return moveMoneyButton;
    }

    public void clickDetailsButton() {
        Assert.assertTrue(detailsButton.isDisplayed(), "Details button is not displayed on Transaction History section");
        Reporter.log("Details button is displayed on Transaction History section");
        detailsButton.click();
    }

    public void verifyVisibilityOfViewMoreButton() {
        if (accountsLists.size() < 5) {
            Assert.assertTrue(viewMoreButtonList.isEmpty(), "View More button is visible for less transaction");
            Reporter.log("View More button is not visible");
        }
    }

    // to verify if date is sorted successfully
    public void verifyDateSorting() throws ParseException {
        Assert.assertTrue(dateSorting(), "Transaction History is not sorted by date.");
        Reporter.log("Transaction History successfully sorted by date.");
    }

    // To sort the date
    public boolean dateSorting() throws ParseException {
        boolean flag = false;
        DateFormat format = new SimpleDateFormat(DateUtil.DATE_FORMAT_DDMMMYYYY);
        List<Date> beforeSort = new ArrayList<Date>();
        for (WebElement element : dateColumnAll) {
            Date date = format.parse(element.getText());
            beforeSort.add(date);
        }
        Collections.sort(beforeSort);
        getDateSort().click();
        Reporter.log("Click on Date column for sort");
        List<Date> afterSort = new ArrayList<Date>();
        for (WebElement element : dateColumnAll) {
            Date date = format.parse(element.getText());
            afterSort.add(date);
        }

        Iterator<Date> targetIt = beforeSort.iterator();
        for (Date uiSortedDate : afterSort) {
            if (uiSortedDate.equals(targetIt.next())) {
                flag = true;
            } else {
                Reporter.log("Not sorted correctly");
                flag = false;
                break;
            }
        }
        return flag;
    }

    // This will check whether sorting functionality is working fine for
    // Description
    public void verifyAmountSorting() {
        Assert.assertTrue(sortAmount(), "Transaction are not sort by amount");
        Reporter.log("Transactions are sorted by amount");
    }

    public WebElement getBalanceSort() {
        return balanceSort;
    }

    public boolean sortAmount() {
        boolean flag = false;
        Double[] beforeSort = getAmountsFromUI();
        getBalanceSort().click();
        Double[] afterSort = getAmountsFromUI();
        for (int j = 0; j < beforeSort.length; j++) {
            if (Double.compare(beforeSort[j], afterSort[j]) == 0) {
                flag = true;
            } else {
                flag = false;
            }
        }
        return flag;
    }

    // this will return all the element of amount
    public Double[] getAmountsFromUI() {
        int i = 0;
        Double[] amounts = new Double[amountColAll.size()];
        if (!amountColAll.isEmpty()) {
            for (WebElement list : amountColAll) {
                if (!list.getText().trim().isEmpty()) {
                    String amt = list.getText();
                    if (list.getText().contains(",")) {
                        amt = amt.replace(",", "");
                    }
                    amounts[i] = Double.parseDouble(amt);
                    i++;
                }
            }
        }
        return amounts;
    }


    // This will check whether sorting functionality is working fine for
    // Description
    public void verifyDescriptionSorting() {
        Assert.assertTrue(sortDescriptions(), "Transaction are not sort by description");
        Reporter.log("Transactions are sorted by Description");
    }

    public boolean sortDescriptions() {
        boolean flag = false;
        String[] beforeSort = getDescriptionsFromUI();
        getDescriptionSort().click();
        String[] afterSort = getDescriptionsFromUI();
        for (int j = 0; j < beforeSort.length - (j + 1); j++) {
            if (beforeSort[j].equals(afterSort[beforeSort.length - (j + 1)])) {
                flag = true;
            } else {
                flag = false;
            }
        }
        return flag;
    }

    // this will return all the element of Description
    public String[] getDescriptionsFromUI() {
        int i = 0;
        String[] descriptions = new String[descriptionColumnAll.size()];
        if (!descriptionColumnAll.isEmpty()) {
            for (WebElement list : descriptionColumnAll) {
                if (!list.getText().trim().isEmpty()) {
                    descriptions[i] = list.getText();
                    i++;
                }
            }
        }
        return descriptions;
    }

    // -------------------Download Transaction History------------------

    public void downloadTransactionHistory(final boolean IsDownload) {
        clickDownloadButton();
        if (IsDownload) {
            selectFileFormatToDownload();
            clickDownloadButtonOnPopup();
            verifyDownloadChoiceWindow();
        } else {
            clickCancelButtonOnPopup();
        }
    }

    protected void clickDownloadButton() {
        Assert.assertTrue(downloadButton.isDisplayed(), "Download button is not displayed");
        Reporter.log("Download button is displayed. | ");
        downloadButton.click();
        Reporter.log("Download button clicked. | ");
    }

    // select a format to download
    public void selectFileFormatToDownload() {
        Assert.assertTrue(radioCSV.isDisplayed(), "Option to download file in csv format not displayed. ");
        int num = RandomUtil.generateIntNumber(1, formatOption.size());
        if (num == 1) {
            radioCSV.click();
            Reporter.log("Selected csv format to download");
        }
        if (num == 2) {
            radioQFX.click();
            Reporter.log("Selected csv format to download");
        }
    }

    // To click on download button on pop-up
    public void clickDownloadButtonOnPopup() {
        Assert.assertTrue(downloadButtonOnPopup.isDisplayed(), "Download button on pop up is not displayed. ");
        Reporter.log("Download button is displayed on pop up. | ");
        downloadButtonOnPopup.click();
        Reporter.log("Download button is clicked on pop up. | ");
    }

    public void clickCancelButtonOnPopup() {
        Assert.assertTrue(cancelButton.isDisplayed(), "Cancel button on pop up is not displayed");
        Reporter.log("Download button is displayed on pop up. | ");
        cancelButton.click();
        Reporter.log("Cancel button is clicked on pop up. | ");
    }

    protected void verifyDownloadChoiceWindow() {}

    public void isLeftHandMenuForAccountsOnDashboardDisplayed() {
        Assert.assertTrue(leftHandMenuMyAccount.isDisplayed(), "Left Hand Menu For Accounts On Dashboard is not displayed.");
        Reporter.log("Left Hand Menu For Accounts On Dashboard is displayed.");
    }

    public void selectAccountOnDashboardByNameAndNumber(final AccountDetails accountDetail) {
        wait.until(ExpectedConditions.visibilityOf(leftHandMenuMyAccount));
        String xpathAccountNumber = "//span[contains(@unique-account-number,'" + accountDetail.getAccountNumber() + "')]";
        List<WebElement> lists = driver.findElements(By.xpath(xpathAccountNumber));
        for (WebElement list : lists) {
            jsx.executeScript("arguments[0].scrollIntoView(true);", list);
            if (list.getText().contains(accountDetail.getAccountName())) {
                list.click();
                break;
            }
        }
    }

    public AccountDetails selectAccountToAccessStopChequeLinkFromManage(final AccountDetails accountDetail) {
        if (accountDetail.getAccountNumber() != null) {
            selectAccountOnDashboardByNameAndNumber(accountDetail);
            Assert.assertTrue(manageButton.isDisplayed(), "Manage button is not displayed on Dashboard page");
            manageButton.click();
            Reporter.log("Manage button clicked");
            clickStopChequeLink();
            return accountDetail;
        } else {
            AccountDetails accountInformation = null;
            for (WebElement accountRow : accountsLists) {
                accountRow.click();
                Assert.assertTrue(manageButton.isDisplayed(), "Manage button is not displayed on Dashboard page");
                manageButton.click();
                Reporter.log("Manage button clicked");
                if (isStopChequeLinkPresent()) {
                    String accountNumber = accountRow.findElement(locatorAccountNumber).getText();
                    String accountName = accountRow.findElement(locatorAccountName).getText();
                    accountInformation = new AccountDetails();
                    accountInformation.setAccountName(accountName);
                    accountInformation.setAccountNumber(accountNumber);
                    Reporter.log("Stop cheque link is displayed for selected account i.e. " + accountRow.getText());
                    clickStopChequeLink();
                    Reporter.log("Stop Cheque link click");
                    break;
                }
            }
            return accountInformation;
        }
    }


    public void selectAccountToAccessViewPrintFeeTnCLinkFromManage() {
        for (WebElement accountRow : accountsLists) {
            accountRow.click();
            Assert.assertTrue(manageButton.isDisplayed(), "Manage button is not displayed on Dashboard page");
            manageButton.click();
            Reporter.log("Manage button clicked");
            if (isViewPrintFeeTnCLinkPresent()) {
                Reporter.log("link is displayed for selected account i.e. " + accountRow.getText());
                clickViewPrintFeeTnCLink();
                Reporter.log("ViewPrintFeeTnC link click");
                break;
            }
        }
    }

    protected boolean isViewPrintFeeTnCLinkPresent() {
        return false;
    }

    protected boolean isStopChequeLinkPresent() {
        return !stopChequeLinkManageMenuList.isEmpty();
    }

    protected void clickStopChequeLink() {
        stopChequeLinkManageMenuList.get(0).click();
    }

    protected void clickViewPrintFeeTnCLink() {
        accInfoAndTnCLinkManageMenuList.get(0).click();
    }

    public void isImmediateTransactionPosted(final Transaction transaction) {
        if (!transactionDetailDisplayElements.isEmpty()) {
            String referenceNumberValue = getLatestTransactionHistoryReferenceValue();
            String amountValue = getLatestTransactionHistoryAmount();
            String balanceValue = getLatestTransactionHistoryBalance();
            Double updatedBalance = Double.parseDouble(balanceValue.replace(",", ""));
            String transactionAmount = RandomUtil.formatDouble(transaction.getFromAccount().getDoubleAccountBalance()
                - updatedBalance, RandomUtil.getDecimalFormat(LandingPageModel.DEFAULT_DECIMAL_PLACES));
            if (amountValue.equals("-" + transactionAmount) && referenceNumberValue.contains(transaction.getReferenceNumber())) {
                Reporter.log("The Transaction entry with reference number : " + transaction.getReferenceNumber()
                    + " is found on Dashboard.");
            }
        }
    }

    protected String getLatestTransactionHistoryAmount() {
        return transactionDetailDisplayElements.get(0).findElement(locatorAmount).getText();
    }

    protected String getLatestTransactionHistoryBalance() {
        return transactionDetailDisplayElements.get(0).findElement(locatorBalance).getText();
    }

    protected String getLatestTransactionHistoryReferenceValue() {
        return (String) jsx.executeScript(LandingPageModel.GET_HIDDEN_TEXT,
            transactionDetailDisplayElements.get(0).findElement(locatorReferenceNumber));
    }

    /**
     * Returns first line of description from each transaction in transactions
     * list
     */
    public List<String> transactionsList() {
        List<String> transactionDataList = new ArrayList<>();
        for (WebElement eachTransaction : transactionDetailsDescription) {
            transactionDataList.add(eachTransaction.getText());
        }
        return transactionDataList;
    }

    /**
     * Verifies Search again button functionality
     * 
     * @param descriptionName
     *            : String
     */
    public void verifySearchAgainButton(final String descriptionName) {
        transaction.setTransactionsList(transactionsList());
        Assert.assertTrue(searchAgainButton.isDisplayed(), "Search Again button is not present. | ");
        searchAgainButton.click();
        Reporter.log("Search Again button clicked. | ");
        String afterValue = searchByNameFieldValue();
        Assert.assertTrue(descriptionName.equals(afterValue), "Search Again button functionality not working properly. ");
        Reporter.log("Values displayed before and after clicking on Search Again button are " + descriptionName + " :: "
            + afterValue + ". | ");
        List<String> transactionListAfterSearchAgain = transactionsList();
        if (transactionsList().size() <= 5 && transaction.getTransactionsList().equals(transactionListAfterSearchAgain)) {
            Reporter.log("\"Search Again\" button functionality working properly. | ");
        }
    }

    private String searchByNameFieldValue() {
        return searchByName.get(0).getAttribute("value");
    }

    /**
     * 
     */
    public void verifyTransactionNotListedButton() {}

    /**
     * Verify Help Icon Link
     */
    public void verifyHelpIconLink() {}

    /**
     * 
     */
    public void validateDisclaimerText() {}

    /**
     * This is to check the default order of the date in the list
     * 
     */
    public void defaultOrderCheck() {
        for (int eachDate = 0; eachDate < dateColumnAll.size() - 1; eachDate++) {
            String firstDateDisplayed = dateColumnAll.get(eachDate).getText();
            String nextDateDisplayed = dateColumnAll.get(eachDate + 1).getText();
            try {
                Date firstDate = DateUtil.getStringToDate(getDisplayDateFormat(), firstDateDisplayed);
                Date nextDate = DateUtil.getStringToDate(getDisplayDateFormat(), nextDateDisplayed);
                if (firstDate.after(nextDate) || firstDate.equals(nextDate)) {
                    Reporter.log("Transactions History Displayed in correct Order. | ");
                } else {
                    Assert.fail("Transactions History Displayed is not in correct Order. ");
                }
            } catch (ParseException e) {
                LandingPageModel.logger.error("Date Format Conversion Error: ", e);
                Assert.fail("Date Format Conversion Error.", e);
            }
        }
    }

    public void readProductTypeMapping(final String entity) {
        productCodes = FileUtil.readProperties(MAPPING_FILE_PATH + entity + PRODUCT_MAPPING_FILE);
    }

    public boolean equalMaps(final Map<String, String> actualMap, final Map<String, String> expectedMap) {
        return true;
    }

    public boolean isSorted(final List<Integer> list) {
        return true;
    }

    public void validateNewAccount(final String newAccountNumber) {}

    public List<WebElement> getNoTransactionErrorMessageElementList() {
        return getErrorMessageList();
    }

    /**
     * This is to check the date is between the Form and To Date
     * 
     * @param dateFormat
     * @param fromDate
     * @param toDate
     */
    public void checkDateBetweenRange(final String dateFormat, final Date fromDate, final Date toDate) {
        boolean dateFlag = true;
        Date tempDate;
        int fromDateTransactionCount = 0;
        int toDateTransactionCount = 0;
        try {
            for (int count = 0; count < dateColumnAll.size(); count++) {
                tempDate = DateUtil.getStringToDate(dateFormat, dateColumnAll.get(count).getText());
                fromDateTransactionCount = tempDate.toString().equals(fromDate.toString()) ? fromDateTransactionCount + 1
                    : fromDateTransactionCount;
                toDateTransactionCount = tempDate.toString().equals(toDate.toString()) ? toDateTransactionCount + 1
                    : toDateTransactionCount;
                if (!((tempDate.after(fromDate) && tempDate.before(toDate)) || tempDate.equals(fromDate) || tempDate.equals(toDate))) {
                    dateFlag = false;
                }
            }
        } catch (ParseException e) {
            LandingPageModel.logger.error("Date Format Conversion Error: ", e);
            Assert.fail("Date Format Conversion Error: ");
        }
        if (dateFlag && fromDateTransactionCount > 0 && toDateTransactionCount > 0) {
            Reporter.log("All the dates displayed in the list are in range : " + fromDate + " - " + toDate);
        } else {
            LandingPageModel.logger.error("Transaction history displayed is not in date range: " + fromDate + " - " + toDate);
            Assert.fail("Transaction history displayed is not in date range: " + fromDate + " - " + toDate);
        }
    }

    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     * @param objOpenAccountDetails
     */
    public void verifyCreatedAccontOnDashboard(final OpenAccountDetails objOpenAccountDetails) {
        // TODO Auto-generated method stub

    }

    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     * @param listOfAccounts
     */
    public void verifyOtherEntityOverviewSection(final List<WebElement> listOfAccounts) {}

    /**
     * This is to check that the transaction is available or not
     * 
     */
    public void checkTransactionAvailability() {
        if (dateColumnAll.isEmpty()) {
            Assert.fail("Error Message: " + noTransactionsMessage.get(0).getText());
        } else {
            Reporter.log("Transaction are available for provided search criteria.");
        }
    }

    public WebElement getAccountSummaryTitle() {
        return accountSummaryTitle;
    }

    public List<WebElement> getErrorMessageList() {
        return errorMessageList;
    }

    public WebElement getDateSort() {
        return dateSort;
    }

    public WebElement getDescriptionSort() {
        return descriptionSort;
    }

    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     * @param accountDetails
     */
    public void verifyInsuranceAccountOverviewInfo(final AccountDetails accountDetails) {}


    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     * @param accountDetails
     */
    public void verifyAccountInfoForInvestmentPension(final AccountDetails accountDetails) {

    }

    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     * @param listOfAccounts
     */
    public void verifyDifferentEntityOverviewSection(final List<WebElement> listOfAccounts) {}
}
