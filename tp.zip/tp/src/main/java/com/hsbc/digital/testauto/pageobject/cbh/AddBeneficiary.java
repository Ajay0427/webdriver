package com.hsbc.digital.testauto.pageobject.cbh;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.AddBeneficiaryDetails;
import com.hsbc.digital.testauto.models.BankDetails;
import com.hsbc.digital.testauto.pageobject.AddBeneficiaryModel;

public class AddBeneficiary extends com.hsbc.digital.testauto.pageobject.AddBeneficiaryModel {
    private final WebDriverWait wait;
    private final JavascriptExecutor jsx;

    /**
     * Web Elements for story-40-Add beneficiary- CANADA---------Starts
     */

    /**
     * Field Label on Verify page
     */
    private static final String SCROLL_TO_VIEW = "arguments[0].scrollIntoView(true);";
    private static final String LABEL_PAYEE_NAME = "Name";
    private static final String LABEL_PAYEENAME = "Payee name";
    private static final String LABEL_BANK_COUNTRY = "Bank country";
    private static final String LABEL_ACCOUNT_TYPE = "Account type";
    private static final String LABEL_ACC_NUMBER = "Account number";
    private static final String Label_International_ACC_NUMBER = "IBAN / Account number";
    private static final String LABEL_ACC_CURRENCY = "Account currency";
    private static final String LABEL_BANK_NAME = "Bank Name";
    private static final String LABEL_PAYEE_ADDRESS = "Payee Address";
    private static final String LABEL_BANK_CITY = "Bank City";
    private static final String LABEL_BANK_CODE = "Bank Code";
    private static final String LABEL_BANK_ADDRESS = "Bank Address";
    private static final String SUCESS_MSG = "Payee successfully saved.";
    private static final String BANK_COUNTRY = "Sri Lanka";
    private static final String PAYEE_TYPE_HSBC = "HSBC Bank Account in Sri Lanka";
    private static final String PAYEE_TYPE_NONHSBC = "Other Local bank";
    private static final String LCY_CURRENCY_SYMBOL = "LKR";
    private static final String OPTION_BANK_ADDRESS = "Manually Input Bank Address";
    private static final String VALUE_MODE_OF_TRANSFER = "SLIPS";
    private static final String ENTITY_BANK_COUNTRY = "Sri Lanka";

    @FindBy(xpath = ".//input[starts-with(@id,'accountNumberInput_group_gpib_mvmny_bijit_Add') and @data-dojo-attach-point='textbox,focusNode']")
    protected WebElement domAccountNumberField;

    @FindBy(xpath = ".//*[starts-with(@id,'dijit_form_Button')and text()='Next to personal details']")
    private WebElement addPayeeDetailsBtn;

    @Override
    protected WebElement getAddPayeeDetailsBtn() {
        return addPayeeDetailsBtn;
    }

    @FindBy(xpath = "//input[starts-with(@id, 'payeeNameInput') and contains(@data-dojo-attach-point, 'textbox,focusNode')]")
    private WebElement payeeNameText;

    @FindBy(xpath = "//input[contains(@id, 'CaptureBankAddressStandAlone') and contains(@id, '_addrLine1')]")
    private List<WebElement> payeeAddress1;

    @FindBy(xpath = "//input[contains(@id, 'CaptureBankAddressStandAlone') and contains(@id, '_addrLine2')]")
    private WebElement payeeAddress2;

    @FindBy(xpath = "//input[contains(@id, 'CaptureBankAddressStandAlone') and contains(@id, '_addrLine3')]")
    private WebElement payeeAddress3;

    private final By locatorPayeeName = By.xpath(".//td[contains(@class, 'payeeName')]//strong");

    private final By locatorPayeeAccountNumber = By.xpath(".//td[contains(@class, 'payeeName')]//span");

    @FindBy(xpath = "//table[contains(@id, '_modeOfTransfer')]//span[contains(@role, 'option')]")
    private List<WebElement> modeOfTransferTexts;

    @FindBy(xpath = ".//div[starts-with(@id,'hdx_bijits_mvmny_bijit_AddPayeeVerifyDialog') and @role='dialog']")
    private WebElement reviewDialog;

    @FindBy(xpath = "//div[contains(@id, 'Verify')]")
    private WebElement verifyPage;

    @FindBy(xpath = "//div[contains(@id, 'AddPayeeConfirmDialog')]//div[@class='alertPanel confirmation']//p")
    private List<WebElement> confirmPayeeMsgs;

    @FindBy(xpath = ".//button[@data-dojo-attach-point='continueButton' and  @type='button']")
    private List<WebElement> confirmButtons;

    @FindBy(xpath = ".//button[@data-dojo-attach-point='closeButton' and  @type='button']")
    private List<WebElement> closeBtns;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='companyLabel']")
    protected WebElement addNewCompanyPayeeBtn;

    @FindBy(xpath = "//div[contains(@id, 'sucessMsgAddEditDelete') and contains(@class, 'alertPanel confirmation')]")
    private List<WebElement> successfulPayeeAdditionElements;

    @FindBy(xpath = "//table[contains(@id, '_bank_accountCCY')]//input[contains(@id, '_bank_accountCCY') and contains(@class, 'dijitArrowButtonInner')]")
    private WebElement accountDetailsDropIcon;

    @FindBy(xpath = "//input[contains(@id, 'otrDropdown') and contains(@class, 'dijitArrowButtonInner')]")
    private WebElement clearanceCodeDropIcon;

    @FindBy(xpath = "//div[contains(@class,'dijitComboBoxMenu')  and contains(@role, 'listbox')]")
    private WebElement listMenuItems;

    @FindBy(xpath = "//div[contains(@class,'dijitMenuActive')]")
    protected WebElement listDropdown;

    @FindBy(xpath = ".//div[contains(@class, 'deletePayeeDialog')]//p[contains(@data-dojo-attach-point, '_payeeNameNode')]")
    private WebElement payeeNameOnDialog;

    private final By pageLoader = By.xpath("//div[contains(@id,'_loader')]/p");

    @Override
    protected WebElement getPayeeNameOnDialog() {
        return payeeNameOnDialog;
    }

    /**
     * Locators for Field label and Field value on Review dialog
     */
    private final By locatorVerifyPageFieldValue = By.xpath("//following-sibling::div[contains(@class, 'itemValue')]");

    private final By locatorVerifyPageFieldName = By.xpath("//div[contains(@id, 'Verify')]//div[contains(@class, 'itemLabel')]");

    private final By localCurrencyLocator = By.xpath(".//div[contains(text(),'Sri Lankan Rupee')]");

    private final By locatorBankNameAndBranch = By.xpath(".//div[contains(@data-dojo-attach-point, '_bankNameNode')]");

    private final By locatorModeOfTransfer = By.xpath(".//div[contains(@data-dojo-attach-point, '_modeoftransfer')]");

    private final By menuText = By.cssSelector("[id$='_text']");

    protected final By menuPopup = By.cssSelector("div.dijitReset.dijitMenuItem[id*='_popup']");

    // Locators
    private final By payeeName = By.xpath(".//td[contains(@class,'payeeName')]/strong");
    private final By accNumber = By.xpath(".//td[contains(@class,'payeeName')]/span");
    private final By viewButton = By.xpath(".//td[contains(@class,'payeeButtons')]//button[contains(@class,'viewPayee')]");
    private final By addressFieldLabel = By.xpath(".//div[@data-dojo-attach-point='_payeeAddrLine1Node']/dt");
    private final By addressFieldValue = By.xpath(".//div[@data-dojo-attach-point='_payeeAddrLine1Node']/dd");
    private final By bankCodeField = By.xpath(".//div[@data-dojo-attach-point='_bankCodeNode']/dt");
    private final By bankCodeValue = By.xpath(".//div[@data-dojo-attach-point='_bankCodeNode']/dt");
    private final By accountNumberField = By.xpath(".//div[@data-dojo-attach-point='_accountNumberNode']/dt");
    private final By accountNumbervalue = By.xpath(".//div[@data-dojo-attach-point='_accountNumberNode']/dd");
    private final By accountCCYField = By.xpath(".//div[@data-dojo-attach-point='_bankAccountCcyNode']/dt");
    private final By accountCCYValue = By.xpath(".//div[@data-dojo-attach-point='_bankAccountCcyNode']/dd");
    private final By bankNameField = By.xpath(".//div[@data-dojo-attach-point='_bankNameNode']/dt");
    private final By bankNameValue = By.xpath(".//div[@data-dojo-attach-point='_bankNameNode']/dd");
    private final By bankAddField = By.xpath(".//div[@data-dojo-attach-point='_bankAddressNode']/dt");
    private final By bankAddvalue = By.xpath(".//div[@data-dojo-attach-point='_bankAddressNode']/dd");
    private final By closeButton = By.xpath(".//button[@data-dojo-attach-point='_editCancelNode']");

    public AddBeneficiary(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30000);
        jsx = (JavascriptExecutor) driver;
    }

    @Override
    public String enterHSBCPayeeName() {
        return StringUtils.EMPTY;
    }

   
    @Override
    public String enterPayeeName() {
        addPayeeDetailsBtn.click();
        String payeeName = RandomUtil.generateAlphaNumericText(10);
        enterPayeeName(payeeName);
        Reporter.log("Payee name entered is " + payeeName);
        return payeeName;
    }

    /**
     * This method enters the HSBC payee Bank details like account number and
     * account currency
     */
    @Override
    public BankDetails enterHSBCBankDetails(final String accountNumber) {
        BankDetails bankDetails = new BankDetails();
        bankDetails.setBankCntry(AddBeneficiary.BANK_COUNTRY);
        bankDetails.setAccountCCY(selectCurrency(true));
        enterDomesticAccountNumber(accountNumber);
        bankDetails.setAccountNumber(accountNumber);
        return bankDetails;
    }

    public String selectCurrency(final String currency) {
        String selectedCurrency = StringUtils.EMPTY;
        currencyListDropDownIcon.click();
        wait.until(ExpectedConditions.visibilityOf(currencyList));
        List<WebElement> currencyLists = driver.findElements(currencyLocator);
        int randomIndex = RandomUtil.generateIntNumber(0, currencyLists.size());
        for (int index = 0; index < currencyLists.size(); index++) {
            WebElement currencyRow = currencyLists.get(index);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", currencyRow);
            if ((currency == null && index == randomIndex) || (currency != null && currencyRow.getText().contains(currency))) {
                currencyRow.click();
                selectedCurrency = currencyRow.getText();
                Reporter.log("Currency is Selected:" + currencyRow.getText());
                break;
            }
        }
        return selectedCurrency;
    }

    /**
     * This method validates if Newly added payee is successfully added to All
     * payees list And All payees count is incremented by '1'
     * 
     * @param name
     *            : Name of newly added payee
     * @param accNum
     *            : Account number of newly added payee
     * @param payeeCnt
     *            : Count before new payee is added
     */
    @Override
    public void searchNewlyAddedPayee(final String name, final String accNum, final int payeeCnt) {
        wait.until(ExpectedConditions.visibilityOf(myPayeesPageTitle));
        List<WebElement> payeeListRows = driver.findElements(By.xpath("//*[contains(text(),'" + accNum + "')]")).isEmpty() ? driver
            .findElements(By.xpath("//*[contains(text(),'" + name + "')]")) : driver.findElements(By.xpath("//*[contains(text(),'"
            + accNum + "')]"));
        if (!payeeListRows.isEmpty()) {
            Reporter.log("Newly added payee name is present in All payees list");
            Assert.assertTrue(getAllpayeesCount() == payeeCnt + 1, "All Payees count is NOT updated");
            Reporter.log("All Payees count is incremented");
        } else {
            Assert.fail("Newly added Payee not found in list.");
        }
    }

    /**
     * This method randomly select the Account currency
     * 
     * @param element
     *            : Currency List
     */
    @Override
    public String selectCurrency(final boolean isLocalCurrency) {
        String selectedCurrency;
        currencyListDropDownIcon.click();
        wait.until(ExpectedConditions.visibilityOf(currencyList));
        List<WebElement> currencyRows = driver.findElements(currencyLocator);
        if (!isLocalCurrency) {
            int randomValue = RandomUtil.generateIntNumber(0, currencyRows.size());
            WebElement currencyRow = currencyRows.get(randomValue);
            jsx.executeScript("arguments[0].scrollIntoView(true);", currencyRow);
            selectedCurrency = currencyRow.getText();
            currencyRow.click();

        } else {
            WebElement localCCY = currencyList.findElement(localCurrencyLocator);
            jsx.executeScript("arguments[0].scrollIntoView(true);", localCCY);
            selectedCurrency = localCCY.getText();
            localCCY.click();
        }
        Reporter.log("Currency selected is " + selectedCurrency);
        if (selectedCurrency.contains(LCY_CURRENCY_SYMBOL)) {
            String regex = "\\s*\\b" + LCY_CURRENCY_SYMBOL + "\\b\\s*";
            selectedCurrency = selectedCurrency.replaceAll(regex, "");
        }
        return selectedCurrency;
    }

    /**
     * Method to Select Value from Dropdown
     */
    protected void selectValue(final WebElement arrowDrop, final WebElement menuDrop, final String valueToSelect) {
        arrowDrop.click();
        wait.until(ExpectedConditions.visibilityOf(menuDrop));
        List<WebElement> valueElements = menuDrop.findElements(menuText).isEmpty() ? menuDrop.findElements(menuPopup) : menuDrop
            .findElements(menuText);
        for (WebElement valueElement : valueElements) {
            jsx.executeScript(SCROLL_TO_VIEW, valueElement);
            if (valueElement.getText().contains(valueToSelect)) {
                wait.until(ExpectedConditions.elementToBeClickable(valueElement));
                valueElement.click();
                Reporter.log(valueToSelect + " is selected in dropdown.");
                break;
            }
        }
    }

    /**
     * This method populates Other Local bank Payee details like account number
     * Randomly generates valid account number for NON HSBC bank payee. And
     * populates in Account number field
     * 
     * @return : Account number
     */
    @Override
    public BankDetails enterNonHSBCBankDetails(final String searchText) {
        BankDetails objBankDetails = new BankDetails();
        objBankDetails.setBankName(selectOtherLocalBank(searchText, localBankNameList));
        if (modeOfTransferTexts.get(0).getText().contains(VALUE_MODE_OF_TRANSFER)) {
            selectValue(accountDetailsDropIcon, listDropdown, OPTION_BANK_ADDRESS);
        }
        String accountNum = RandomUtil.generateIntNumber(12);
        enterDomesticAccountNumber(accountNum);
        objBankDetails.setAccountNumber(accountNum);
        objBankDetails.setBankCntry(AddBeneficiary.BANK_COUNTRY);
        Reporter.log("Account number entered is :" + accountNum);
        return objBankDetails;
    }

    /**
     * This method enters the domestic HSBC or NON HSBC Bank (Other Local bank)
     * account number
     * 
     * @param accountNumber
     *            : Account number to be populated
     */
    @Override
    public void enterDomesticAccountNumber(final String accountNumber) {
        domAccountNumberField.click();
        domAccountNumberField.clear();
        domAccountNumberField.sendKeys(accountNumber);
        Reporter.log("Account Number Entered for new payee :" + accountNumber);

    }

    /**
     * This method randomly select the Local Bank name from Bank Drop down list
     * 
     * @param element
     *            : Bank/Bank Branch List
     */
    @Override
    public String selectOtherLocalBank(final String text, final WebElement element) {
        // serach character is not required for Canada
        localBankNameListDropdownIcon.click();
        wait.until(ExpectedConditions.visibilityOf(element));
        List<WebElement> listings = element.findElements(otherLocalBankLocator);
        int randomValue = RandomUtil.generateIntNumber(0, listings.size());
        WebElement bankSelected = listings.get(randomValue);// Clicking on the
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", bankSelected);
        bankSelected.click();
        return bankSelected.getText();

    }

    /**
     * This method enters the Payee Address details
     * 
     * @param obj
     *            : AddBeneficiary JAVA object populate payee address fields
     */
    @Override
    public String enterPayeeAddressDetails() {
        String addLine1 = StringUtils.EMPTY;
        String addLine2 = StringUtils.EMPTY;
        String addLine3 = StringUtils.EMPTY;
        if (!modeOfTransferTexts.isEmpty() && modeOfTransferTexts.get(0).getText().contains(VALUE_MODE_OF_TRANSFER)
            || !payeeAddress1.isEmpty() && payeeAddress1.get(0).isDisplayed()) {
            addLine1 = RandomUtil.generateAlphaNumericText(10);
            addLine2 = RandomUtil.generateAlphaNumericText(10);
            addLine3 = RandomUtil.generateAlphaNumericText(10);
            payeeAddress1.get(0).clear();
            payeeAddress1.get(0).click();
            payeeAddress1.get(0).sendKeys(addLine1);
            payeeAddress1.get(0).sendKeys(Keys.RETURN);
            payeeAddress2.clear();
            payeeAddress2.click();
            payeeAddress2.sendKeys(addLine2);
            payeeAddress2.sendKeys(Keys.RETURN);
            payeeAddress3.clear();
            payeeAddress3.click();
            payeeAddress3.sendKeys(addLine3);
            payeeAddress3.sendKeys(Keys.RETURN);
        }
        if (StringUtils.isNotEmpty(addLine1) && StringUtils.isNotEmpty(addLine2)) {
            return addLine1 + "::" + addLine2 + "::" + addLine3;
        } else {
            return StringUtils.EMPTY;
        }
    }

    @Override
    public void verifyPayeeReviewPage(final AddBeneficiaryDetails addBeneficiaryDetails) {
        if (!successfulPayeeAdditionElements.isEmpty() && successfulPayeeAdditionElements.get(0).isDisplayed()) {
            Assert.assertTrue(successfulPayeeAdditionElements.get(0).getText().contains(addBeneficiaryDetails.getPayeeName()),
                "Payee is not added.");
            Reporter.log("Company Payee added is :" + addBeneficiaryDetails.getPayeeName());
        } else {
            if (addBeneficiaryDetails.getAccountType().equalsIgnoreCase(AddBeneficiary.PAYEE_TYPE_HSBC)
                && addBeneficiaryDetails.getBankDetails().getBankCntry().equalsIgnoreCase(AddBeneficiary.BANK_COUNTRY)) {
                verifyHSBCBankPayeeReviewPage(addBeneficiaryDetails);
            } else if (addBeneficiaryDetails.getAccountType().equalsIgnoreCase(AddBeneficiary.PAYEE_TYPE_NONHSBC)
                && (addBeneficiaryDetails.getBankDetails().getBankCntry().equalsIgnoreCase(AddBeneficiary.BANK_COUNTRY))) {
                verifyOtherLocalbankPayeeReviewPage(addBeneficiaryDetails);
            }

            else if (!(addBeneficiaryDetails.getBankDetails().getBankCntry().equalsIgnoreCase(AddBeneficiary.BANK_COUNTRY))
                && (addBeneficiaryDetails.getBankDetails().getBankCode() == null)) {
                verifyInternationalPayeeReviewPage(addBeneficiaryDetails);
            } else {
                verifyOtherCityInternationalPayeeReviewPage(addBeneficiaryDetails);
            }
        }
    }

    /**
     * This method verifies the field label and Field Values correctly
     * displayed on Review page for HSBC bank payee
     */
    public void verifyHSBCBankPayeeReviewPage(final AddBeneficiaryDetails addBeneficiaryDetails) {
        wait.until(ExpectedConditions.visibilityOf(reviewDialog));
        reviewDialog.isDisplayed();
        isBankCountryDisplayed(AddBeneficiary.LABEL_BANK_COUNTRY, addBeneficiaryDetails.getBankDetails().getBankCntry());
        isAccountTypeDisplayed(AddBeneficiary.LABEL_ACCOUNT_TYPE, addBeneficiaryDetails.getAccountType());
        isAccountNumberDisplayed(AddBeneficiary.LABEL_ACC_NUMBER, addBeneficiaryDetails.getBankDetails().getAccountNumber());
        isAccountCCYDispalyed(AddBeneficiary.LABEL_ACC_CURRENCY, addBeneficiaryDetails.getBankDetails().getAccountCCY());
        Reporter.log("HSBC  bank payee details  Details verified on Verify Page.");
    }

    /**
     * This method verifies the field label and Field Values correctly
     * displayed on Review page for NON HSBC BANK payee
     */
    public void verifyOtherLocalbankPayeeReviewPage(final AddBeneficiaryDetails addBeneficiaryDetails) {
        wait.until(ExpectedConditions.visibilityOf(reviewDialog));
        reviewDialog.isDisplayed();
        isPayeeNameDisplayed(AddBeneficiary.LABEL_PAYEENAME, addBeneficiaryDetails.getPayeeName());
        isBankCountryDisplayed(AddBeneficiary.LABEL_BANK_COUNTRY, addBeneficiaryDetails.getBankDetails().getBankCntry());
        isAccountTypeDisplayed(AddBeneficiary.LABEL_ACCOUNT_TYPE, addBeneficiaryDetails.getAccountType());
        isBankNameDisplayed(AddBeneficiary.LABEL_BANK_NAME, addBeneficiaryDetails.getBankDetails().getBankName());
        isAccountNumberDisplayed(AddBeneficiary.LABEL_ACC_NUMBER, addBeneficiaryDetails.getBankDetails().getAccountNumber());
        Reporter.log("Other Local  bank payee details  Details verified on Verify Page.");
    }

    /**
     * This method verifies the field label and Field Values correctly
     * displayed on Review page for International Payee
     */
    public void verifyInternationalPayeeReviewPage(final AddBeneficiaryDetails addBeneficiaryDetails) {
        wait.until(ExpectedConditions.visibilityOf(reviewDialog));
        reviewDialog.isDisplayed();
        isPayeeNameDisplayed(AddBeneficiary.LABEL_PAYEENAME, addBeneficiaryDetails.getPayeeName());
        isBankCountryDisplayed(AddBeneficiary.LABEL_BANK_COUNTRY, addBeneficiaryDetails.getBankDetails().getBankCntry());
        isBankCityDisplayed(AddBeneficiary.LABEL_BANK_CITY, addBeneficiaryDetails.getBankDetails().getBankCity());
        isBankNameDisplayed(AddBeneficiary.LABEL_BANK_NAME, addBeneficiaryDetails.getBankDetails().getBankName());
        isAccountNumberDisplayed(AddBeneficiary.Label_International_ACC_NUMBER, addBeneficiaryDetails.getBankDetails()
            .getAccountNumber());
        if (StringUtils.isNotEmpty(addBeneficiaryDetails.getPayeeAddress1())) {
            isPayeeAddressDisplayed(AddBeneficiary.LABEL_PAYEE_ADDRESS, addBeneficiaryDetails.getPayeeAddress1());
        }
        Reporter.log("International   bank payee details  Details verified on Verify Page.");
    }

    /**
     * This method verifies the field label and Field Values correctly
     * displayed on Review page for Other Bank/City International Payee
     */
    public void verifyOtherCityInternationalPayeeReviewPage(final AddBeneficiaryDetails addBeneficiaryDetails) {
        wait.until(ExpectedConditions.visibilityOf(reviewDialog));
        reviewDialog.isDisplayed();
        isPayeeNameDisplayed(AddBeneficiary.LABEL_PAYEENAME, addBeneficiaryDetails.getPayeeName());
        isBankCountryDisplayed(AddBeneficiary.LABEL_BANK_COUNTRY, addBeneficiaryDetails.getBankDetails().getBankCntry());
        isAccountNumberDisplayed(AddBeneficiary.Label_International_ACC_NUMBER, addBeneficiaryDetails.getBankDetails()
            .getAccountNumber());
        isBankNameDisplayed(AddBeneficiary.LABEL_BANK_NAME, addBeneficiaryDetails.getBankDetails().getBankName());
        isBankAddDisplayed(AddBeneficiary.LABEL_BANK_ADDRESS, addBeneficiaryDetails.getBankDetails().getBankAddress1());
        isBankCodeDisplayed(AddBeneficiary.LABEL_BANK_CODE, addBeneficiaryDetails.getBankDetails().getBankCode());
        if (StringUtils.isNotEmpty(addBeneficiaryDetails.getPayeeAddress1())) {
            isPayeeAddressDisplayed(AddBeneficiary.LABEL_PAYEE_ADDRESS, addBeneficiaryDetails.getPayeeAddress1());
        }
        Reporter.log("Other country/City international  bank payee details  Details verified on Verify Page.");
    }

    /**
     * This method validates if payee Name Label and value on review page is
     * correct
     * 
     * @param fieldName
     *            : Payee Name
     * @param fieldValue
     *            : payee Name value
     */
    public void isPayeeNameDisplayed(final String fieldName, final String fieldValue) {
        Assert.assertTrue(textByParentAndSibling(fieldName, fieldValue), "Given Payee Name not found.");
        Reporter.log("From Payee Name displayed is :" + fieldValue);
    }

    /**
     * This method validates if Bank Country Label and value on review page is
     * correct
     * 
     * @param fieldName
     *            : Bank Country
     * @param fieldValue
     *            :Bank Country value
     */
    public void isBankCountryDisplayed(final String fieldName, final String fieldValue) {
        Assert.assertTrue(textByParentAndSibling(fieldName, fieldValue), "Given Bank Country  not found.");
        Reporter.log("From Bank Country displayed is :" + fieldValue);
    }

    /**
     * This method validates if Payee Type Label and value on review page is
     * correct
     * 
     * @param fieldName
     *            : Payee Type
     * @param fieldValue
     *            :Payee Type value
     */
    public void isAccountTypeDisplayed(final String fieldName, final String fieldValue) {
        Assert.assertTrue(textByParentAndSibling(fieldName, fieldValue), "Given Payee Type not found.");
        Reporter.log("From Payee Type displayed is :" + fieldValue);
    }

    /**
     * This method validates if Account number Label and value on review page
     * is correct
     * 
     * @param fieldName
     *            : Account number
     * @param fieldValue
     *            :Account number value
     */
    public void isAccountNumberDisplayed(final String fieldName, final String fieldValue) {
        Assert.assertTrue(textByParentAndSibling(fieldName, fieldValue), "Given Account Number not found.");
        Reporter.log("From Account Number displayed is :" + fieldValue);
    }

    /**
     * This method validates if Account Currency Label and value on review page
     * is correct
     * 
     * @param fieldName
     *            : Account Currency
     * @param fieldValue
     *            :Account Currency value
     */
    public void isAccountCCYDispalyed(final String fieldName, final String fieldValue) {
        Assert.assertTrue(textByParentAndSibling(fieldName, fieldValue), "Given Account Currency not found.");
        Reporter.log("From Account Currency displayed is :" + fieldValue);
    }

    /**
     * This method validates if BANK Name Label and value on review page is
     * correct
     * 
     * @param fieldName
     *            : BANK Name
     * @param fieldValue
     *            :BANK Name value
     */
    public void isBankNameDisplayed(final String fieldName, final String fieldValue) {
        Assert.assertTrue(textByParentAndSibling(fieldName, fieldValue), "Given BANK Name not found.");
        Reporter.log("From BANK Name displayed is :" + fieldValue);
    }

    /**
     * This method validates if payee address Label and value on review page is
     * correct
     * 
     * @param fieldName
     *            : payee address
     * @param fieldValue
     *            :payee address value
     */
    public void isPayeeAddressDisplayed(final String fieldName, final String fieldValue) {
        Assert.assertTrue(textByParentAndSibling(fieldName, fieldValue), "Given Payee Address  not found.");
        Reporter.log("From payee address displayed is :" + fieldValue);
    }

    /**
     * This method validates if BANK City Label and value on review page is
     * correct
     * 
     * @param fieldName
     *            : BANK City
     * @param fieldValue
     *            :BANK City value
     */
    public void isBankCityDisplayed(final String fieldName, final String fieldValue) {
        Assert.assertTrue(textByParentAndSibling(fieldName, fieldValue), "Given  Bank city  not found.");
        Reporter.log("From BANK City displayed is :" + fieldValue);
    }

    /**
     * This method validates if BANK code Label and value on review page is
     * correct
     * 
     * @param fieldName
     *            : BANK code
     * @param fieldValue
     *            :BANK code value
     */
    public void isBankCodeDisplayed(final String fieldName, final String fieldValue) {
        Assert.assertTrue(textByParentAndSibling(fieldName, fieldValue), "Given Bank code  not found.");
        Reporter.log("From BANK code displayed is :" + fieldValue);
    }

    /**
     * This method validates if BANK address Label and value on review page is
     * correct
     * 
     * @param fieldName
     *            : BANK address
     * @param fieldValue
     *            :BANK address value
     */
    public void isBankAddDisplayed(final String fieldName, final String fieldValue) {
        Assert.assertTrue(textByParentAndSibling(fieldName, fieldValue), "Given Bank Address  not found.");
        Reporter.log("From BANK address displayed is :" + fieldValue);
    }

    /**
     * Method to return true if text and its corresponding field match the
     * criteria user specifies else return false
     */
    public boolean textByParentAndSibling(final String fieldLabel, final String fieldValue) {
        boolean flag = false;
        List<WebElement> fieldLabels = verifyPage.findElements(locatorVerifyPageFieldName);
        for (WebElement elem : fieldLabels) {
            jsx.executeScript(AddBeneficiary.SCROLL_TO_VIEW, elem);
            if (elem.isDisplayed() && elem.getText().contains(fieldLabel)) {
                List<WebElement> valueElements = elem.findElements(locatorVerifyPageFieldValue);
                if (isValuePresent(valueElements, fieldValue)) {
                    flag = true;
                    break;
                }

            }
        }
        return flag;
    }

    /**
     * Method to return true if field value matches the expected field value
     */
    private boolean isValuePresent(final List<WebElement> valueElements, final String fieldValue) {
        boolean flag = false;
        for (WebElement elem : valueElements) {
            if (elem.isDisplayed() && elem.getText().contains(fieldValue) || fieldValue.contains(elem.getText())) {
                flag = true;
                break;
            }
        }
        return flag;
    }

    /**
     * This method verify success/fail message displayed on My Payees page on
     * completing the add New payee flow
     * 
     * @param payeeName
     *            : Newly added payee name
     */
    @Override
    public void verifySucessMessage(final AddBeneficiaryDetails obj) {
        if (!confirmPayeeMsgs.isEmpty() && confirmPayeeMsgs.get(0).isDisplayed()) {
            Assert.assertTrue((AddBeneficiary.SUCESS_MSG.contains(confirmPayeeMsgs.get(0).getText())),
                "Payee is not sucessfully added");
            Reporter.log("Payee " + obj.getPayeeName() + " is  sucessfully added");
        }
    }

    @Override
    public void clickConfirmOnReviewPage() {
        if (!confirmButtons.isEmpty() && confirmButtons.get(0).isDisplayed()) {
            confirmButtons.get(0).click();
            Reporter.log("Confirm Dbutton ids clicked");
        }
    }

    /**
     * This method close the Add Payee confirm Dialog box
     */
    @Override
    public void closeConfirmDialog() {
        if (!closeBtns.isEmpty() && closeBtns.get(0).isDisplayed()) {
            closeBtns.get(0).click();
            Reporter.log("Confirm Dialog box is closed");
        }
    }

    @Override
    public int addCompanyPayee() {
        wait.until(ExpectedConditions.invisibilityOfElementLocated(pageLoader));
        newPayeeTab.click();
        wait.until(ExpectedConditions.elementToBeClickable(addNewCompanyPayeeBtn));
        addNewCompanyPayeeBtn.click();
        Reporter.log("Company  payee button selected");
        return getAllpayeesCount();
    }

    /**
     * This method verify Company Payee details displayed when View button is
     * clicked
     * 
     * @param payeeName
     */
    @Override
    public void verifyCompanyPayeeDetails(final WebElement element) {
        String displayName = element.findElement(payeeName).getText();
        String displayAccNumber = element.findElement(accNumber).getText();
        WebElement button = element.findElement(viewButton);
        button.isEnabled();
        button.click();
        wait.until(ExpectedConditions.visibilityOf(companyPayeeDetailsView));
        String name = verifyPayeeNameField(companyPayeeDetailsView, LABEL_PAYEE_NAME);
        Assert.assertTrue(displayName.equals(name), "Company  payee name is NOT  matched in Details pane");
        Reporter.log("Company payee name " + name + " is  displayed and matched");
        Assert.assertTrue(displayAccNumber.equals(accNumber), "Company payee account number is NOT matched in Details pane");
        Reporter.log("Company payee account number  " + accNumber + " is  displayed");
        Assert.assertTrue(companyPayeeDetailsView.findElement(closeButton).isEnabled(), "Close button is NOT enabled");
        companyPayeeDetailsView.findElement(closeButton).click();
    }

    @Override
    public void verifyHSBCPersoPayeeDetails(final WebElement element) {
        String displayName = element.findElement(payeeName).getText();
        WebElement viewButtonElement = element.findElement(viewButton);
        viewButtonElement.isEnabled();
        viewButtonElement.click();
        wait.until(ExpectedConditions.visibilityOf(personPayeeDetailsView));
        String name = verifyPayeeNameField(personPayeeDetailsView, LABEL_PAYEE_NAME);
        Assert.assertTrue(displayName.equals(name), "Person payee name is NOT  matched in Details pane");
        verifyField(personPayeeDetailsView, accountNumberField, accountNumbervalue);
        verifyField(personPayeeDetailsView, accountCCYField, accountCCYValue);
        personPayeeDetailsView.findElement(closeButton).click();
    }

    /**
     * This method verify HSBC bank Payee details displayed when View button is
     * clicked
     * 
     * @param payeeName
     */
    @Override
    public void verifyPersonPayeeDetails(final WebElement element) {
        String displayName = element.findElement(payeeName).getText();
        WebElement button = element.findElement(viewButton);
        button.isEnabled();
        button.click();
        wait.until(ExpectedConditions.visibilityOf(personPayeeDetailsView));
        String name = verifyPayeeNameField(personPayeeDetailsView, LABEL_PAYEE_NAME);
        Assert.assertTrue(displayName.equals(name), "Person payee name is NOT  matched in Details pane");
        verifyField(personPayeeDetailsView, addressFieldLabel, addressFieldValue);
        verifyField(personPayeeDetailsView, bankCodeField, bankCodeValue);
        verifyField(personPayeeDetailsView, accountNumberField, accountNumbervalue);
        verifyField(personPayeeDetailsView, accountCCYField, accountCCYValue);
        verifyField(personPayeeDetailsView, bankNameField, bankNameValue);
        verifyField(personPayeeDetailsView, bankAddField, bankAddvalue);
        personPayeeDetailsView.findElement(closeButton).click();
    }

    @Override
    public AccountDetails selectPersonPayeeFromPersonPayeeList(final String entityCurrency, final boolean domesticHSBCPayee,
        final boolean domesticAccount, final boolean domesticCurrency) {
        List<AccountDetails> payeeList = validPersonPayeeDetails(entityCurrency, domesticHSBCPayee, domesticAccount,
            domesticCurrency);
        List<AccountDetails> validPayeeList = new ArrayList<>();
        for (AccountDetails payee : payeeList) {
            if (!(payee.getAccountNumber().length() == 16)) {
                validPayeeList.add(payee);
            }
        }
        int index = RandomUtil.generateIntNumber(DEFAULT_LIST_STARTING_INDEX, validPayeeList.size());
        Assert.assertTrue(index >= DEFAULT_LIST_STARTING_INDEX, "No Payees found.");
        return validPayeeList.get(index);
    }

    private boolean isFieldsNotDisplayed(WebElement bankNameAndBranchLabel, WebElement modeOfTransfer) {
        return !bankNameAndBranchLabel.isDisplayed() && !modeOfTransfer.isDisplayed();
    }

    private boolean isHSBCBankPayee(boolean domesticHSBCPayee, String entity, String accountLocation,
        WebElement bankNameAndBranchLabel, WebElement modeOfTransfer) {
        return domesticHSBCPayee && isFieldsNotDisplayed(bankNameAndBranchLabel, modeOfTransfer)
            && entity.equalsIgnoreCase(accountLocation);
    }

    private boolean isOtherBankPayee(boolean domesticHSBCPayee, String entity, String accountLocation,
        WebElement bankNameAndBranchLabel, WebElement modeOfTransfer) {
        return !domesticHSBCPayee && (bankNameAndBranchLabel.isDisplayed() || modeOfTransfer.isDisplayed())
            && entity.equalsIgnoreCase(accountLocation);
    }

    private boolean isValidDomesticAccount(boolean domesticHSBCPayee, String entity, String accountLocation,
        WebElement bankNameAndBranchLabel, WebElement modeOfTransfer) {
        return isHSBCBankPayee(domesticHSBCPayee, entity, accountLocation, bankNameAndBranchLabel, modeOfTransfer)
            || isOtherBankPayee(domesticHSBCPayee, entity, accountLocation, bankNameAndBranchLabel, modeOfTransfer);
    }

    @Override
    protected List<AccountDetails> validPersonPayeeDetails(final String entityCurrency, final boolean domesticHSBCPayee,
        final boolean domesticAccount, final boolean domesticCurrency) {
        List<AccountDetails> storeAccountValue = new ArrayList<>();
        String entity = getEntityBankCountry();
        List<WebElement> payeeList = driver.findElements(locatorAllPayeesRow);
        for (WebElement payee : payeeList) {
            jsx.executeScript(AddBeneficiaryModel.SCROLL_TO_VIEW, payee);
            if (payee.findElement(locatorPayeeType).getAttribute("alt").equalsIgnoreCase(AddBeneficiaryModel.PERSON_PAYEE)) {
                String personPayeeName = payee.findElement(locatorPayeeName).getText();
                String payeeAccountLocation = payee.findElement(locatorPayeeCountry).getText();
                WebElement btnView = payee.findElement(locatorViewPayee);
                wait.until(ExpectedConditions.elementToBeClickable(btnView));
                btnView.click();
                wait.until(ExpectedConditions.visibilityOf(payee.findElement(locatorManagePerson)));
                WebElement elemManagePerson = payee.findElement(locatorManagePerson);
                String personPayeeNumber = elemManagePerson.findElement(locatorPayeeAccountNumber).getText();
                WebElement bankNameAndBranchLabel = elemManagePerson.findElement(locatorBankNameAndBranch);
                WebElement modeOfTransfer = elemManagePerson.findElement(locatorModeOfTransfer);
                String personPayeeBankCountry = isValidDomesticAccount(domesticHSBCPayee, entity, payeeAccountLocation,
                    bankNameAndBranchLabel, modeOfTransfer) ? payeeAccountLocation : (String) jsx.executeScript(
                    AddBeneficiaryModel.GET_HIDDEN_TEXT, elemManagePerson.findElement(locatorPayeeBankCountry));
                String personPayeeCurrency = elemManagePerson.findElement(locatorPayeeCurrency).getText();
                if (isValidPayee(domesticAccount, domesticCurrency, entity, entityCurrency, personPayeeBankCountry,
                    personPayeeCurrency) && !personPayeeBankCountry.trim().isEmpty()) {
                    AccountDetails accountDetails = addPayeeAccountInformation(personPayeeName, personPayeeNumber,
                        personPayeeBankCountry, personPayeeCurrency);
                    storeAccountValue.add(accountDetails);
                }
            }
        }
        return storeAccountValue;
    }

    @Override
    protected String getEntityBankCountry() {
        return ENTITY_BANK_COUNTRY;
    }

    @Override
    public int addPersonPayee() {
        wait.until(ExpectedConditions.invisibilityOfElementLocated(pageLoader));
        newPayeeTab.click();
        wait.until(ExpectedConditions.elementToBeClickable(enterDetailsBtn));
        enterDetailsBtn.click();
        Reporter.log("Add new person payee button selected");
        return getAllpayeesCount();
    }

}
