/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.text.ParseException;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.models.TransactionFrequency;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

/**
 * <p>
 * <b> Abstract Class is used to define all the common function required for
 * Verify page of Move Money stories With Primary story being Story 39 </b>
 * 
 * @version 1.0.0
 * @author Neeraj Kumar & Pramesh
 * 
 *         </p>
 */
public abstract class MoveMoneyVerifyPageModel {

    protected final WebDriverWait wait;
    protected final UICommonUtil uiCommonUtil;

    /**
     * Field Label on Verify page
     */
    protected static final String LABEL_FROM = "From";
    protected static final String LABEL_TO = "To";
    protected static final String LABEL_AMOUNT = "Amount";
    protected static final String LABEL_DEBIT_AMOUNT = "Debit amount";
    protected static final String LABEL_PAYMENT_DATE = "Payment date";
    protected static final String LABEL_YOUR_REFERENCE = "Your reference";
    protected static final String LABEL_PAYEE_REFERENCE = "Payee's reference";
    protected static final String LABEL_START_DATE = "Start date";
    protected static final String LABEL_TRANSACTION_END_DATE = "Transaction end date";
    protected static final String LABEL_FREQUENCY = "Frequency";
    protected static final String LABEL_NUMBER_OF_PAYMENT = "Number of payments";
    protected static final String DEFAULT_PAYMENT_DATE_VALUE = "Now";
    protected static final String LABEL_REASON_FOR_TRANSACTION = "Reason for transaction";
    protected static final String LABEL_PAYEE_ADDRESS = "Payee address";
    protected static final String DATE_FORMAT = "dd MMM yyyy";
    protected static final String PAYMENT_RECURRING_VALUE = "Recurring ";
    protected static final String LABEL_PAYEENAME = StringUtils.EMPTY;
    protected static final String LABEL_PAYEEACCOUNTNUMBER = StringUtils.EMPTY;

    @FindBy(xpath = "//div[contains(@id, 'Verify') or contains(@id, 'Verfiy')]//div[contains(@class, 'steptracker-heading')]")
    protected WebElement verifyPageTitle;

    @FindBy(xpath = "//div[contains(@class, 'move-money confirmationPage')]//*[contains(text(),'Cancel') or contains(@data-dojo-attach-point, '_cancel')]")
    private WebElement cancelButton;

    @FindBy(xpath = "//div[contains(@class, 'move-money confirmationPage')]//*[contains(@data-dojo-attach-point, '_confirmTxn')]")
    private WebElement confirmButton;

    @FindBy(xpath = "//div[contains(@class, 'move-money confirmationPage')]//button[@data-dojo-attach-point='_edit']")
    private WebElement editDetailsButton;

    @FindBy(xpath = "//div[contains(@id,'ConfirmDialog')]//button[@data-dojo-attach-point='_btnCancel']")
    private WebElement cancelPopUpDialogButton;

    @FindBy(xpath = "//div[contains(@id,'ConfirmDialog')]//button[@data-dojo-attach-point='_btnOk']")
    private WebElement continuePopUpDialogButton;

    private final By locatorCancelDialog = By.xpath("//div[contains(@id,'ConfirmDialog')]");

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(MoveMoneyVerifyPageModel.class);

    public MoveMoneyVerifyPageModel(final WebDriver driver) {
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30000);
        uiCommonUtil = new UICommonUtil(driver);

    }

    /**
     * Verification Methods
     * 
     */
    protected void isFromAccountNameDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_FROM, accountDetail.getAccountName(), UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given From Account Name not found.");
        Reporter.log("From Account Name displayed is :" + accountDetail.getAccountName());
    }

    protected void isFromAccountNumberDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_FROM, accountDetail.getAccountNumber(),
            UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given From Account Number not found.");
        Reporter.log("From Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    protected void isToAccountNameDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_TO, accountDetail.getAccountName(), UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Name not found.");
        Reporter.log("To Account Name displayed is :" + accountDetail.getAccountName());
    }

    protected void isToAccountNumberDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_TO, accountDetail.getAccountNumber(), UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Number not found.");
        Reporter.log("To Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    protected void isAmountDisplayed(String amount) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_AMOUNT, amount, UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Transfer Amount not found.");
        Reporter.log("Amount displayed is :" + amount);
    }

    protected void isDebitAmountDisplayed(String amount) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_DEBIT_AMOUNT, amount, UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Transfer Amount not found.");
        Reporter.log("Amount displayed is :" + amount);
    }

    protected void isPaymentDateDisplayed(String paymentDate) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PAYMENT_DATE, "Now", UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Payment Date not found.");
        Reporter.log("Payment Date displayed is :" + paymentDate);
    }

    protected void isPaymentDateAsLaterDateDisplayed(Transaction transaction) {
        String paymentDate;
        try {
            paymentDate = DateUtil.getDateToString(DATE_FORMAT, transaction.getLaterDate());
            Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PAYMENT_DATE, paymentDate, UICommonUtil.verifyPage,
                UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Payment Date not found.");
            Reporter.log("Payment Date displayed is :" + paymentDate);
        } catch (ParseException e) {
            MoveMoneyVerifyPageModel.logger.error("Exception:", e);
            Assert.fail("Parsing to Payment Date Fail " + e.getMessage(), e);
        }

    }

    protected void isYourReferenceTextDisplayed(String yourReference) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_YOUR_REFERENCE, yourReference, UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Your Reference Text not found.");
        Reporter.log("Your Reference Text displayed is :" + yourReference);
    }

    protected void isPayeeReferenceTextDisplayed(String payeeReference) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PAYEE_REFERENCE, payeeReference, UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Your Reference Text not found.");
        Reporter.log("Your Reference Text displayed is :" + payeeReference);
    }

    protected void isStartDateDisplayed(Transaction transaction) {
        try {
            String startDate = DateUtil.getDateToString(DATE_FORMAT, transaction.getFirstDateOfTransaction());
            Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_START_DATE, startDate, UICommonUtil.verifyPage,
                UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Start Date not found.");
            Reporter.log("Start Date displayed is :" + startDate);
        } catch (ParseException e) {
            MoveMoneyCapturePageModel.logger.error(e);
            Assert.fail("Parsing to Payment Date Fail " + e.getMessage(), e);
        }

    }

    protected void isTransactionEndDateDisplayed(TransactionFrequency transactionFrequency) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_TRANSACTION_END_DATE, transactionFrequency.getValue(),
            UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given Transaction End Date dropdown value not found.");
        Reporter.log("Transaction End Date dropdown value displayed is :" + transactionFrequency.getValue());
    }

    protected void isFrequencyDisplayed(String frequencyValue) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_FREQUENCY, frequencyValue, UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Frequency Value not found.");
        Reporter.log("Frequency Value displayed is :" + frequencyValue);
    }

    protected void isRecurringFrequencyDisplayed(String frequencyValue) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_FREQUENCY, PAYMENT_RECURRING_VALUE + frequencyValue,
            UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Frequency Value not found.");
        Reporter.log("Frequency Value displayed is :" + frequencyValue);
    }

    protected void isNumberOfPaymentDisplayed(String valueNOP) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_NUMBER_OF_PAYMENT, valueNOP, UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Number Of Payment not found.");
        Reporter.log("Number Of Payment displayed is :" + valueNOP);
    }

    protected void isReasonForTransaction(String reasonForTransaction) {
        Assert.assertTrue(!uiCommonUtil.textByParentAndSibling(LABEL_REASON_FOR_TRANSACTION, reasonForTransaction,
            UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given Reason For Transaction not found.");
        Reporter.log("Reason For Transaction Field is Not Applicable");
    }

    private void isPayeeAdressDisplayed(String address) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PAYEE_ADDRESS, address, UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Number Of Payment not found.");
        Reporter.log("Number Of Payment displayed is :" + address);
    }

    public void verifyPageTitle() {
        wait.until(ExpectedConditions.visibilityOf(verifyPageTitle));
        Assert.assertTrue(verifyPageTitle.isDisplayed(), "Confirm Page is not displayed.");
        Reporter.log("Confirm Page is displayed after continuing duplicate transaction.");
    }


    public void clickConfirmButton() {
        wait.until(ExpectedConditions.elementToBeClickable(confirmButton));
        confirmButton.click();
        Reporter.log("Confirm button is clicked.");
    }

    public void clickCancelButton() {
        wait.until(ExpectedConditions.elementToBeClickable(cancelButton));
        cancelButton.click();
        Reporter.log("Cancel button is clicked.");
    }

    public void clickEditDetailsButton() {
        wait.until(ExpectedConditions.elementToBeClickable(editDetailsButton));
        editDetailsButton.click();
        Reporter.log("Edit Details button is clicked.");
    }

    public void clickCancelPopUpCancelButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(locatorCancelDialog));
        cancelPopUpDialogButton.click();
        Reporter.log("Cancel Button on Cancel Dialog is clicked.");
    }

    public void clickContinuePopupContinueButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(locatorCancelDialog));
        continuePopUpDialogButton.click();
        Reporter.log("Don't Cancel Button on Cancel Dialog is clicked.");
    }

    /**************** Now Flow Verification *************/
    /**
     * Method to verify Transaction details on verify page for Now flow
     */
    protected void validateNowFlow(Transaction transactionDetail) {
        wait.until(ExpectedConditions.visibilityOf(verifyPageTitle));
        isFromAccountNameDisplayed(transactionDetail.getFromAccount());
        isFromAccountNumberDisplayed(transactionDetail.getFromAccount());
        if (StringUtils.isNotEmpty(transactionDetail.getToAccount().getAccountName())) {
            isToAccountNameDisplayed(transactionDetail.getToAccount());
        }
        isToAccountNumberDisplayed(transactionDetail.getToAccount());
        isPaymentDateDisplayed(DEFAULT_PAYMENT_DATE_VALUE);
        isYourReferenceTextDisplayed(transactionDetail.getYourReference());
    }

    protected void validateM2MNowFlow(Transaction transactionDetail) {
        wait.until(ExpectedConditions.visibilityOf(verifyPageTitle));
        isFromAccountNameDisplayed(transactionDetail.getFromAccount());
        isFromAccountNumberDisplayed(transactionDetail.getFromAccount());
        if (StringUtils.isNotEmpty(transactionDetail.getToAccount().getAccountName())) {
            isToAccountNameDisplayed(transactionDetail.getToAccount());
        }
        isToAccountNumberDisplayed(transactionDetail.getToAccount());
        isPaymentDateDisplayed(DEFAULT_PAYMENT_DATE_VALUE);
        isYourReferenceTextDisplayed(transactionDetail.getYourReference());
    }

    public void verifyLCY2LCYNowTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    public void verifyM2MLCY2LCYNowTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    public void verifyM2CLCY2LCYNowTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        this.verifyLCY2LCYNowTransactionDetailsOnVerifyPage(transactionDetail);

    }

    public void verifyNonHSBCLCY2LCYNowTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        isPayeeReferenceTextDisplayed(transactionDetail.getPayeeReference());
        Reporter.log("LCY2LCYNowNonHSBC Transaction Details verified on Verify Page.");
    }

    public void verifyInlineNonHSBCLCY2LCYNowTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        verifyNonHSBCLCY2LCYNowTransactionDetailsOnVerifyPage(transactionDetail);
        if (!transactionDetail.getAddress1().trim().isEmpty()) {
            isPayeeAdressDisplayed(transactionDetail.getAddress1());
        }
        Reporter.log("InlineLCY2LCYNowNonHSBC Transaction Details verified on Verify Page.");
    }

    /**
     * Method to verify Transaction details on verify page for Now flow
     */
    public void verifyLCY2FCYNowTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2FCYNow Transaction Details verified on Verify Page.");
    }

    /**
     * Method to verify FCY to FCY Transaction details on verify page for Now
     * flow
     */
    public void verifyFCY2FCYNowTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("FCY2FCYNow Transaction Details verified on Verify Page.");
    }

    /**
     * Method to verify FCY to LCY Transaction details on verify page for Now
     * flow
     */
    public void verifyFCY2LCYNowTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isReasonForTransaction(transactionDetail.getReasonForTransaction());
        Reporter.log("FCY2LCYNow Transaction Details verified on Verify Page.");
    }

    public void verifyNonHSBCFCY2LCYNowTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        isPayeeReferenceTextDisplayed(transactionDetail.getPayeeReference());
        Reporter.log("NonHSBCFCY2LCYNow Transaction Details verified on Verify Page.");
    }

    public void verifyInlineNonHSBCFCY2LCYNowTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        verifyNonHSBCFCY2LCYNowTransactionDetailsOnVerifyPage(transactionDetail);
        if (!transactionDetail.getAddress1().trim().isEmpty()) {
            isPayeeAdressDisplayed(transactionDetail.getAddress1());
        }
        Reporter.log("InlineNonHSBCFCY2LCYNow Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMInternationalLCY2LCYNowTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    /**************** Later Flow Verification ****************/
    protected void validateLaterFlow(Transaction transactionDetail) {
        wait.until(ExpectedConditions.visibilityOf(verifyPageTitle));
        isFromAccountNameDisplayed(transactionDetail.getFromAccount());
        isFromAccountNumberDisplayed(transactionDetail.getFromAccount());
        if (StringUtils.isNotEmpty(transactionDetail.getToAccount().getAccountName())) {
            isToAccountNameDisplayed(transactionDetail.getToAccount());
        }
        isToAccountNumberDisplayed(transactionDetail.getToAccount());
        isPaymentDateAsLaterDateDisplayed(transactionDetail);
        isYourReferenceTextDisplayed(transactionDetail.getYourReference());
    }

    /**
     * Method to verify LCY to LCY Transaction details on verify page for Later
     * flow
     */
    public void verifyLCY2LCYLaterTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Verify Page.");
    }


    public void verifyM2CLCY2LCYLaterTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        this.verifyLCY2LCYLaterTransactionDetailsOnVerifyPage(transactionDetail);
    }

    public void verifyM2CFCY2LCYLaterTransactionDetailsOnVerifyPage(Transaction transactionDetail) {

    }

    public void verifyNonHSBCLCY2LCYLaterTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        isPayeeReferenceTextDisplayed(transactionDetail.getPayeeReference());
        Reporter.log("LCY2LCYLaterNonHSBC Transaction Details verified on Verify Page.");
    }

    public void verifyInlineNonHSBCLCY2LCYLaterTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        verifyNonHSBCLCY2LCYLaterTransactionDetailsOnVerifyPage(transactionDetail);
        if (!transactionDetail.getAddress1().trim().isEmpty()) {
            isPayeeAdressDisplayed(transactionDetail.getAddress1());
        }
        Reporter.log("LCY2LCYLaterNonHSBC Transaction Details verified on Verify Page.");
    }

    /**
     * Method to verify LCY to FCY Transaction details on verify page for Later
     * flow
     */
    public void verifyLCY2FCYLaterTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2FCYLater Transaction Details verified on Verify Page.");
    }

    /**
     * Method to verify FCY to LCY Transaction details on verify page for Later
     * flow
     */
    public void verifyFCY2LCYLaterTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("FCY2LCYLater Transaction Details verified on Verify Page.");
    }

    public void verifyNonHSBCFCY2LCYLaterTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        verifyFCY2LCYLaterTransactionDetailsOnVerifyPage(transactionDetail);
        isPayeeReferenceTextDisplayed(transactionDetail.getPayeeReference());
        Reporter.log("NonHSBCFCY2LCYLater Transaction Details verified on Verify Page.");
    }

    public void verifyInlineNonHSBCFCY2LCYLaterTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        verifyNonHSBCFCY2LCYLaterTransactionDetailsOnVerifyPage(transactionDetail);
        if (!transactionDetail.getAddress1().trim().isEmpty()) {
            isPayeeAdressDisplayed(transactionDetail.getAddress1());
        }
        Reporter.log("InlineNonHSBCFCY2LCYLater Transaction Details verified on Verify Page.");
    }

    /**
     * Method to verify FCY to FCY Transaction details on verify page for Later
     * flow
     */
    public void verifyFCY2FCYLaterTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("FCY2FCYLater Transaction Details verified on Verify Page.");
    }

    /**************** Recurring Flow Verification ****************/
    /**
     * Method to verify Transaction details on verify page for Recurring flow
     */
    protected void validateRecurringFlow(Transaction transactionDetail) {
        wait.until(ExpectedConditions.visibilityOf(verifyPageTitle));
        isFromAccountNameDisplayed(transactionDetail.getFromAccount());
        isFromAccountNumberDisplayed(transactionDetail.getFromAccount());
        if (StringUtils.isEmpty(transactionDetail.getToAccount().getAccountName())) {
            isToAccountNameDisplayed(transactionDetail.getToAccount());
        }
        isToAccountNumberDisplayed(transactionDetail.getToAccount());
        isYourReferenceTextDisplayed(transactionDetail.getYourReference());
        isStartDateDisplayed(transactionDetail);
    }


    public void verifyLCY2LCYRecurringTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Verify Page.");
    }

    public void verifyM2CLCY2LCYRecurringTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        this.verifyLCY2LCYRecurringTransactionDetailsOnVerifyPage(transactionDetail);
    }

    public void verifyNonHSBCLCY2LCYRecurringTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        if (StringUtils.isNotEmpty(transactionDetail.getAddress1())) {
            isPayeeAdressDisplayed(transactionDetail.getAddress1());
        }
        Reporter.log("LCY2LCYRecurringNonHSBC Transaction Details verified on Verify Page.");
    }

    public void verifyInlineNonHSBCLCY2LCYRecurringTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        verifyNonHSBCLCY2LCYRecurringTransactionDetailsOnVerifyPage(transactionDetail);
        isPayeeAdressDisplayed(transactionDetail.getAddress1());
        Reporter.log("InlineLCY2LCYRecurringNonHSBC Transaction Details verified on Verify Page.");
    }

    public void verifyM2MLCY2LCYRecurringTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isAmountDisplayed(transactionDetail.getAmount());
        isTransactionEndDateDisplayed(transactionDetail.getTransactionFrequency());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Verify Page.");
    }

    /**
     * Method to verify LCY2FCYRecurring Transaction details on verify page for
     * Recurring flow
     */
    public void verifyLCY2FCYRecurringTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2FCYRecurring Transaction Details Verified on Verify Page");
    }

    public void verifyM2MLCY2FCYRecurringTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isAmountDisplayed(transactionDetail.getAmount());
        isTransactionEndDateDisplayed(transactionDetail.getTransactionFrequency());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2FCYRecurring Transaction Details Verified on Verify Page");
    }

    /**
     * Method to verify FCY2LCYRecurring Transaction details on verify page for
     * Recurring flow
     */
    public void verifyFCY2LCYRecurringTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("FCY2LCYRecurring Transaction Details Verified on Verify Page");
    }

    public void verifyNonHSBCFCY2LCYRecurringTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        verifyFCY2LCYRecurringTransactionDetailsOnVerifyPage(transactionDetail);
        isPayeeReferenceTextDisplayed(transactionDetail.getPayeeReference());
        Reporter.log("NonHSBCFCY2LCYRecurring Transaction Details Verified on Verify Page");
    }

    public void verifyInlineNonHSBCFCY2LCYRecurringTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        verifyNonHSBCFCY2LCYRecurringTransactionDetailsOnVerifyPage(transactionDetail);
        if (!transactionDetail.getAddress1().trim().isEmpty()) {
            isPayeeAdressDisplayed(transactionDetail.getAddress1());
        }
        Reporter.log("InlineNonHSBCFCY2LCYRecurring Transaction Details Verified on Verify Page");
    }

    public void verifyM2MFCY2LCYRecurringTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isAmountDisplayed(transactionDetail.getAmount());
        isTransactionEndDateDisplayed(transactionDetail.getTransactionFrequency());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("FCY2LCYRecurring Transaction Details Verified on Verify Page");
    }

    /**
     * Method to verify FCY2FCYRecurring Transaction details on verify page for
     * Recurring flow
     */
    public void verifyFCY2FCYRecurringTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("FCY2LFYRecurring Transaction Details Verified on Verify Page");
    }

    public void verifyM2MFCY2FCYRecurringTransactionDetailsOnVerifyPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isAmountDisplayed(transactionDetail.getAmount());
        isTransactionEndDateDisplayed(transactionDetail.getTransactionFrequency());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("FCY2LFYRecurring Transaction Details Verified on Verify Page");
    }

    public void verifyLCY2LCYNowIETransactionDetailsOnVerifyPage(final Transaction transactionDetail) {}

    protected void validateNowFlowIETransfer(final Transaction transactionDetail) {}

    protected void isPayeeName(final String payeename) {}

    protected void isNotifyMeBy(final String email) {}

    protected void isLanguage(final String lang) {}

    protected void isSecurityQue(final String securityquestion) {}

    protected void isSecurityAns(final String securityanswer) {}

    protected void isEmailAddressSender(final String emailaddresssender) {}

    protected void isFee(final String fee) {}

    protected void isDate(final String date) {}

    public void verfiyInteractLogoCapturepage() {}

    public void verfiyFeeBodyInputpage() {}

    public void copytextInputpage() {}

    public void verfiyCapctureBrandingTradeMark() {}

    public void verfiypageBrandingTradeMark() {}

    public void verfiyInteractLogoConfirmation() {}

    public void verfiyFeeBodyVerifypage() {}

    public void copytextVerifypage() {}

    public void copytextConfimationypage() {}

    public void verfiyInteractLogoVerfiypage() {}

    public void verfiyFeeBodyConfirmationpage() {}

    public void clickMyAccountButton() {}

    public void verifyMyAccountpage() {}

    public void clickCancelButton(boolean isCancel) {
        logger.info("Cancel functionality performed in entity POM which has boolean value: " + isCancel);
    }
}
