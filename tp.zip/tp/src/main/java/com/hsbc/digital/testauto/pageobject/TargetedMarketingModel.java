/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

/**
 * <p>
 * <b> This model class will hold locators and functionality for Targeted
 * Marketing of the Application </b> <br>
 * </p>
 * 
 * @author Nirmal
 * @version 1.0.0
 */
public abstract class TargetedMarketingModel {

    protected final WebDriver driver;
    protected final WebDriverWait wait;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(TargetedMarketingModel.class);

    /**
     * Content Slots of the dashboard Page
     */
    @FindBy(id = "bannerNode")
    private WebElement topContentSlotDashboardPage;

    @FindBy(id = "_campaignDetails1")
    private WebElement leftContentSlotDashboardPage;

    @FindBy(id = "_campaignDetails2")
    private WebElement bottomContentSlotDashboardPage;


    /**
     * Content Slots of the Move Money Page
     */
    @FindBy(id = "bannerNode")
    private WebElement topContentSlotMoveMoneyPage;

    @FindBy(id = "_campaignDetails2")
    private WebElement leftContentSlotMoveMoneyPage;

    /**
     * Content Slots of the Move Money Confirmation Page
     */
    @FindBy(id = "bannerNode")
    private WebElement topContentSlotMoveMoneyConfirmationPage;

    @FindBy(id = "_campaignDetails2")
    private WebElement leftContentSlotMoveMoneyConfirmationPage;

    @FindBy(id = "_campaignDetails")
    private WebElement bottomContentSlotMoveMoneyConfirmationPage;

    /**
     * Content Slots of the Global View Page
     */
    @FindBy(id = "bannerNode")
    private WebElement topContentSlotGlobalViewPage;

    @FindBy(id = "_campaignDetails2")
    private WebElement leftContentSlotGlobalViewPage;

    @FindBy(id = "_campaignDetails")
    private WebElement bottomContentSlotGlobalViewPage;

    /**
     * Previous, Play, Pause, Next button on the Content Slots Common across
     * pages
     */
    protected final By previousButtonOnSlot = By.cssSelector("button.prev");
    protected final By playButtonOnSlot = By.cssSelector("button.play");
    protected final By pauseButtonOnSlot = By.cssSelector("button.pause");
    protected final By nextButtonOnSlot = By.cssSelector("button.next");

    /**
     * Constructor to instantiate locators with driver.Will be invoked from
     * Children only.
     * 
     * @param driver
     */
    public TargetedMarketingModel(final WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, 30);
        PageFactory.initElements(driver, this);
    }


    /**
     * CATEGORY - Top, Left, Bottom Content Slots for Dashboard Page
     */
    /**
     * This is to check the Content Slot at the Top location of the Dashboard
     * Page.
     */
    public void verifyDashboardTopContentSlot() {
        Reporter.log("Verifying the Top Content Slot of the Dashboard Page");
        verifyTopContentSlot(topContentSlotDashboardPage);
    }

    /**
     * This is to check the Content Slot at the Left location of the Dashboard
     * Page.
     */
    public void verifyDashboardLeftContentSlot() {
        Reporter.log("Verifying the Left Content Slot of the Dashboard Page");
        verifyLeftContentSlot(getLeftContentSlotDashboardPage());
    }

    /**
     * This is to check the Content Slot at the Bottom location of the
     * Dashboard Page.
     */
    public void verifyDashboardBottomContentSlot() {
        Reporter.log("Verifying the Bottom Content Slot of the Dashboard Page");
        verifyBottomContentSlot(bottomContentSlotDashboardPage);
    }


    /**
     * CATEGORY - Top, Left Content Slots for Move Money Page
     */
    /**
     * This is to check the Content Slot at the Top location of the Move Money
     * Page.
     */
    public void verifyMoveMoneyPageTopContentSlot() {
        Reporter.log("Verifying the Top Content Slot of the Move Money Page");
        verifyTopContentSlot(topContentSlotMoveMoneyPage);
    }

    /**
     * This is to check the Content Slot at the Left location of the Move Money
     * Page.
     */
    public void verifyMoveMoneyPageLeftContentSlot() {
        Reporter.log("Verifying the Left Content Slot of the Move Money Page");
        verifyLeftContentSlot(leftContentSlotMoveMoneyPage);
    }


    /**
     * CATEGORY - Top, Left Content Slots for Move Money Review Page
     */
    /**
     * This is to check the Content Slot at the Top location of the Move Money
     * Review Page.
     */
    public void verifyMoveMoneyReviewPageTopContentSlot() {
        TargetedMarketingModel.logger.error("The Top Content Slot is not available in the Move Money Review page");
    }

    /**
     * This is to check the Content Slot at the Left location of the Move Money
     * Review Page.
     */
    public void verifyMoveMoneyReviewPageLeftContentSlot() {
        TargetedMarketingModel.logger.error("The Left Content Slot is not available in the Move Money Review page");
    }


    /**
     * CATEGORY - Top, Left, Bottom Content Slots for Move Money Confirmation
     * Page
     */
    /**
     * This is to check the Content Slot at the Top location of the Move Money
     * Confirmation Page.
     */
    public void verifyMoveMoneyConfirmationPageTopContentSlot() {
        Reporter.log("Verifying the Top Content Slot of the Move Money Confirmation Page");
        verifyTopContentSlot(topContentSlotMoveMoneyConfirmationPage);
    }

    /**
     * This is to check the Content Slot at the Left location of the Move Money
     * Confirmation Page.
     */
    public void verifyMoveMoneyConfirmationPageLeftContentSlot() {
        Reporter.log("Verifying the Left Content Slot of the Move Money Confirmation Page");
        verifyLeftContentSlot(leftContentSlotMoveMoneyConfirmationPage);
    }

    /**
     * This is to check the Content Slot at the Bottom location of the Move
     * Money Confirmation Page.
     */
    public void verifyMoveMoneyConfirmationPageBottomContentSlot() {
        Reporter.log("Verifying the Bottom Content Slot of the Move Money Confirmation Page");
        verifyBottomContentSlot(bottomContentSlotMoveMoneyConfirmationPage);
    }


    /**
     * CATEGORY - Top, Left, Bottom Content Slots for Account Opening Page
     */
    /**
     * This is to check the Content Slot at the Top location of the Account
     * Opening Page.
     */
    public void verifyAccountOpeningPageTopContentSlot() {
        TargetedMarketingModel.logger.error("The Top Content Slot is not applicable in the Account Opening page");
    };

    /**
     * This is to check the Content Slot at the Left location of the Account
     * Opening Page.
     */
    public void verifyAccountOpeningPageLeftContentSlot() {
        TargetedMarketingModel.logger.error("The Left Content Slot is not applicable in the Account Opening page");
    };


    /**
     * CATEGORY - Top, Left, Bottom Content Slots for Global View Page
     */
    /**
     * This is to check the Content Slot at the Top location of the Global View
     * Page.
     */
    public void verifyGlobalViewPageTopContentSlot() {
        Reporter.log("Verifying the Top Content Slot of the Global View Page");
        verifyTopContentSlot(topContentSlotGlobalViewPage);
    };

    /**
     * This is to check the Content Slot at the Left location of the Global
     * View Page.
     */
    public void verifyGlobalViewPageLeftContentSlot() {
        Reporter.log("Verifying the Left Content Slot of the Global View Page");
        verifyLeftContentSlot(leftContentSlotGlobalViewPage);
    };

    /**
     * This is to check the Content Slot at the Bottom location of the Global
     * View Page.
     */
    public void verifyGlobalViewPageBottomContentSlot() {
        Reporter.log("Verifying the Bottom Content Slot of the Global View Page");
        verifyBottomContentSlot(bottomContentSlotGlobalViewPage);
    };


    /**
     * CATEGORY - Top, Left, Bottom Content Slots verification common across
     * page
     */
    /**
     * This is to check the Content Slot at the Top location in the Page.
     */
    public void verifyTopContentSlot(final WebElement topContentSlot) {
        scrollWebElementIntoView(topContentSlot);
        Assert.assertTrue(topContentSlot.isDisplayed(), "Top Content Slot is not displayed on the Page");
        Reporter.log("Top Content Slot is displayed on the Page");
    }

    /**
     * This is to check the Content Slot at the Left location in the Page.
     */
    public void verifyLeftContentSlot(final WebElement leftContentSlot) {
        scrollWebElementIntoView(leftContentSlot);
        Assert.assertTrue(leftContentSlot.isDisplayed(), "Left Content Slot is not displayed on the page");
        Reporter.log("Left Content Slot is displayed on the page");
        isPreviousButtonDisplayed(leftContentSlot);
        isPlayAndPauseButtonDisplayed(leftContentSlot);
        isNextButtonDisplayed(leftContentSlot);
    }

    /**
     * This is to check the Content Slot at the Bottom location in the Page.
     */
    public void verifyBottomContentSlot(final WebElement bottomContentSlot) {
        scrollWebElementIntoView(bottomContentSlot);
        Assert.assertTrue(bottomContentSlot.isDisplayed(), "Bottom Content Slot is not displayed on the page");
        Reporter.log("Bottom Content Slot is displayed on the page");
        isPreviousButtonDisplayed(bottomContentSlot);
        isPlayAndPauseButtonDisplayed(bottomContentSlot);
        isNextButtonDisplayed(bottomContentSlot);
    }

    /**
     * CATEGORY - Previos, Play, Pause and Next Button Code
     */
    /**
     * This is to check the Previous Button on the Content Slot.
     */
    public void isPreviousButtonDisplayed(final WebElement elementContentSlot) {
        WebElement tempPreviousButton = elementContentSlot.findElement(previousButtonOnSlot);
        Assert.assertTrue(tempPreviousButton.isDisplayed(), "Previous Button is not displayed on the Content Slot");
        Reporter.log("Previous Button is displayed on the Content Slot");
    }

    /**
     * This is to check the Play/Pause Button on the Content Slot.
     */
    public void isPlayAndPauseButtonDisplayed(final WebElement elementContentSlot) {
        WebElement tempPlayButton = elementContentSlot.findElement(playButtonOnSlot);
        WebElement tempPauseButton = elementContentSlot.findElement(pauseButtonOnSlot);
        Assert.assertTrue((tempPlayButton.isDisplayed()) || (tempPauseButton.isDisplayed()),
            "Play/Pause Button is not displayed on the Content Slot");
        Reporter.log("Play/Pause Button is displayed on the Content Slot");
    }

    /**
     * This is to check the Next Button on the Content Slot.
     */
    public void isNextButtonDisplayed(final WebElement elementContentSlot) {
        WebElement tempNextButton = elementContentSlot.findElement(nextButtonOnSlot);
        Assert.assertTrue(tempNextButton.isDisplayed(), "Next Button is not displayed on the Content Slot");
        Reporter.log("Next Button is displayed on the Content Slot");
    }

    /**
     * This is to scroll the webelement into view of the page.
     */
    public void scrollWebElementIntoView(final WebElement elementScrollIntoView) {
        wait.until(ExpectedConditions.visibilityOf(elementScrollIntoView));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", elementScrollIntoView);
    }

    public WebElement getLeftContentSlotDashboardPage() {
        return leftContentSlotDashboardPage;
    }

    /** Blank implementations of functions specific for UK entity **/

    public void verifyDashboardRightContentSlot() {}

    public void verifyRightContentSlot(final WebElement rightContentSlot) {}

}
