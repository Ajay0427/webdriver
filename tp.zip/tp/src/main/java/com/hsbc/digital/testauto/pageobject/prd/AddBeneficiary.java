package com.hsbc.digital.testauto.pageobject.prd;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.pageobject.AddBeneficiaryModel;

public class AddBeneficiary extends com.hsbc.digital.testauto.pageobject.AddBeneficiaryModel {

    private final WebDriverWait wait;

    private final By locatorPayeeNameManagePerson = By.xpath(".//div//dd[contains(@data-dojo-attach-point, '_payeeName')]");

    private final By locatorBankNameAndBranch = By.xpath(".//div[contains(@data-dojo-attach-point, '_bankNameNode')]");

    private final By locatorPayeeName = By.xpath(".//td[contains(@class, 'payeeName')]//strong");

    private final By locatorPayeeAccountNumber = By.xpath(".//td[contains(@class, 'payeeName')]//span");

    public AddBeneficiary(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30000);
    }

    private boolean isHSBCBankPayee(boolean domesticHSBCPayee, String entity, String accountLocation,
        WebElement bankNameAndBranchLabel) {
        return domesticHSBCPayee && !bankNameAndBranchLabel.isDisplayed() && entity.equalsIgnoreCase(accountLocation);
    }

    private boolean isOtherBankPayee(boolean domesticHSBCPayee, String entity, String accountLocation,
        WebElement bankNameAndBranchLabel) {
        return !domesticHSBCPayee && bankNameAndBranchLabel.isDisplayed() && entity.equalsIgnoreCase(accountLocation);
    }

    private boolean isValidDomesticAccount(boolean domesticHSBCPayee, String entity, String accountLocation,
        WebElement bankNameAndBranchLabel) {
        return isHSBCBankPayee(domesticHSBCPayee, entity, accountLocation, bankNameAndBranchLabel)
            || isOtherBankPayee(domesticHSBCPayee, entity, accountLocation, bankNameAndBranchLabel);
    }

    @Override
    protected List<AccountDetails> validPersonPayeeDetails(final String entityCurrency, final boolean domesticHSBCPayee,
        final boolean domesticAccount, final boolean domesticCurrency) {
        List<AccountDetails> storeAccountValue = new ArrayList<>();
        String entity = entityCountry.getText();
        List<WebElement> payeeList = driver.findElements(locatorAllPayeesRow);
        for (WebElement payee : payeeList) {
            jsx.executeScript(AddBeneficiaryModel.SCROLL_TO_VIEW, payee);
            if (payee.findElement(locatorPayeeType).getAttribute("alt").equalsIgnoreCase(AddBeneficiaryModel.PERSON_PAYEE)) {
                String personPayeeName = payee.findElement(locatorPayeeName).getText();
                String personPayeeNumber = payee.findElement(locatorPayeeAccountNumber).getText();
                String payeeAccountLocation = payee.findElement(locatorPayeeCountry).getText();
                WebElement btnView = payee.findElement(locatorViewPayee);
                wait.until(ExpectedConditions.elementToBeClickable(btnView));
                btnView.click();
                wait.until(ExpectedConditions.textToBePresentInElementLocated(locatorPayeeNameManagePerson, personPayeeName));
                WebElement elemManagePerson = payee.findElement(locatorManagePerson);
                WebElement bankNameAndBranchLabel = elemManagePerson.findElement(locatorBankNameAndBranch);
                String personPayeeBankCountry = isValidDomesticAccount(domesticHSBCPayee, entity, payeeAccountLocation,
                    bankNameAndBranchLabel) ? payeeAccountLocation : (String) jsx.executeScript(
                    AddBeneficiaryModel.GET_HIDDEN_TEXT, elemManagePerson.findElement(locatorPayeeBankCountry));
                String personPayeeCurrency = elemManagePerson.findElement(locatorPayeeCurrency).getText();
                if (isValidPayee(domesticAccount, domesticCurrency, entity, entityCurrency, personPayeeBankCountry,
                    personPayeeCurrency) && !personPayeeBankCountry.trim().isEmpty()) {
                    AccountDetails accountDetails = addPayeeAccountInformation(personPayeeName, personPayeeNumber,
                        personPayeeBankCountry, personPayeeCurrency);
                    storeAccountValue.add(accountDetails);
                }
            }
        }
        return storeAccountValue;
    }

}
