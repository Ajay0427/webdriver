/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.cbh;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.OpenAccountDetails;
import com.hsbc.digital.testauto.pageobject.OpenAccountOptionsModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for cbh
 * entity. </b> VAibhav
 * </p>
 */
public class OpenAccountOptions extends OpenAccountOptionsModel {

    final WebDriver driver;
    final WebDriverWait wait;

    @FindBy(xpath = "//div[contains(@class,'currency-text')]")
    private WebElement newAccountCurrency;

    @FindBy(xpath = "//div[@data-dojo-attach-point='_disclaimerForTFSA' and not (contains(@class,'dijitHidden'))]//input[contains(@id,'disclaimerchkboxforTFSA')]")
    private List<WebElement> disclaimerCheckboxforTFSA;

    // Option Page Locators

    @FindBy(xpath = "//li[contains(@class,'Debit')]//input[contains(@id,'arrowid') and contains(@id,'SelectDropDown')]")
    private WebElement debitAccountIcon;

    @FindBy(xpath = "//div[contains(@class,'SelectDropDown')]//table[contains(@class,'MenuTable')]//tr")
    private List<WebElement> debitAccountList;

    @FindBy(xpath = "//table[contains(@id,'SelectDropDown')]//span[contains(@class,'accountDetailsactSlOption')]")
    private WebElement selecteddebitAccount;

    @FindBy(xpath = "//input[contains(@id,'ammountToBePlaced')]")
    private WebElement amountToDeposit;

    @FindBy(xpath = "//input[contains(@id,'arrowid') and contains(@id,'reasonForOpeningAccount')]")
    private WebElement reasonForOpeningAccountIcon;

    @FindBy(xpath = "//div[contains(@class,'SelectDropDown')]//table[contains(@class,'MenuTable')]//tr//span[@class='balance']")
    private List<WebElement> accountBalanceList;

    @FindBy(xpath = "//div[contains(@class,'SelectDropDown')]//table[contains(@class,'MenuTable')]//tr//span[contains(@class,'accountDetails accountDetailsactSlOption')]")
    private List<WebElement> accountCustomerNuber;

    @FindBy(xpath = "//li[contains(@data-dojo-attach-point,'reason')]//input[contains(@id,'arrowid')]")
    private WebElement reasonIcon;

    @FindBy(xpath = "//div[contains(@id,'reasonForOpeningAccount')]//table[contains(@class,'MenuTable')]//tr")
    private List<WebElement> reasonForOpeningAccountList;

    @FindBy(xpath = "//p[@class='greyBackAccount']")
    private WebElement exchnageRate;

    @FindBy(xpath = "//table[contains(@id,'reasonForOpeningAccount')]//span")
    private WebElement selectedReasonForOpeningAccountList;

    @FindBy(xpath = "//button[text()='Continue']")
    private WebElement continueButton;

    @FindBy(xpath = "//li[@data-dojo-attach-point='accountTerm']//input[contains(@id,'arrowid')]")
    private WebElement accountTermIcon;

    @FindBy(xpath = "//div[contains(@class,'accountTerm')]//table//tr")
    private List<WebElement> accountTermList;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(OpenAccountOptions.class);

    public OpenAccountOptions(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        this.driver = driver;
        wait = new WebDriverWait(driver, 30);
    }

    @Override
    public String selectNewAccountCurrency() {
        Reporter.log("Currency Stored is: " + newAccountCurrency.getText() + ".");
        return newAccountCurrency.getText();
    }

    /**
     * Clicks disclaimer checkbox if displayed
     */
    @Override
    public void clickTnCCheckbox() {
        if (!disclaimerCheckboxforTFSA.isEmpty()) {
            disclaimerCheckboxforTFSA.get(0).click();
            Reporter.log("disclaimerCheckboxforTFSA clicked.");
        }

    }

    @Override
    public OpenAccountDetails captureDetailsForSavingOnOptionPage(final Map<String, String> profileProperties) {
        OpenAccountDetails objOpenAccountDetails = new OpenAccountDetails();
        objOpenAccountDetails.setDebitAccount(selectDebitAccount(profileProperties));
        objOpenAccountDetails.setDepositAmount(enterAmount());
        // wait.until(ExpectedConditions.visibilityOf(exchnageRate));
        objOpenAccountDetails.setReason(selectReasonOpeningAccount());
        clickContinueButton();
        return objOpenAccountDetails;
    }

    @Override
    public OpenAccountDetails captureDetailsForTermDepositOnOptionPage(final Map<String, String> profileProperties) {
        OpenAccountDetails objOpenAccountDetails = new OpenAccountDetails();
        objOpenAccountDetails.setDebitAccount(selectDebitAccount(profileProperties));
        objOpenAccountDetails.setDepositAmount(enterAmount());
        clickContinueButton();
        return objOpenAccountDetails;
    }

    public OpenAccountDetails captureDetailsForTermDepositOnOptionPage() {
        OpenAccountDetails objOpenAccountDetails = new OpenAccountDetails();
        Map<String, String> profileProperties = null;
        objOpenAccountDetails.setDebitAccount(selectDebitAccount(profileProperties));
        objOpenAccountDetails.setDepositAmount(enterAmount());
        clickContinueButton();
        return objOpenAccountDetails;
    }

    public void selectTerm() {

        Assert.assertTrue(accountTermIcon.isDisplayed(), "Account term Icon to expand list is not displayed");
        Reporter.log("Click on Account Term Icon to expand list is displayed");

        if (!accountTermList.isEmpty()) {
            int randomIndex = RandomUtil.generateIntNumber(1, accountTermList.size());
            WebElement row = accountTermList.get(randomIndex);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", row);
            row.click();
        }

    }


    public String selectResaon() {

        Assert.assertTrue(reasonForOpeningAccountIcon.isDisplayed(), "Reason to open Account Icon to expand list is not displayed");
        Reporter.log("Click on Reason to open Account Icoun to expand list is displayed");

        if (!reasonForOpeningAccountList.isEmpty()) {
            int randomIndex = RandomUtil.generateIntNumber(1, reasonForOpeningAccountList.size());
            WebElement row = reasonForOpeningAccountList.get(randomIndex);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", row);
            row.click();
        }
        return selectedReasonForOpeningAccountList.getText();
    }

    public String enterAmount() {
        Assert.assertTrue(amountToDeposit.isDisplayed(), "Amount to Desposit text field is not displayed");
        String amount = Integer.toString(RandomUtil.generateIntNumber(5000, 5555));
        amountToDeposit.sendKeys(amount);
        Reporter.log("Amount is entered as " + amount);
        return amount;
    }

    public String selectDebitAccount(final Map<String, String> profileProperties) {
        Assert.assertTrue(debitAccountIcon.isDisplayed(), "Debit Account Icon to expand list is not displayed");
        debitAccountIcon.click();
        Reporter.log("Debit Account Icoun to expand list is displayed");
        String accountNumber = profileProperties.get("CustomerAccNumber");
        if (!debitAccountList.isEmpty()) {
            for (int i = 0; i < accountBalanceList.size(); i++) {
                WebElement accountsRow = accountCustomerNuber.get(i);
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", accountsRow);
                if (accountsRow.getText().contains(accountNumber)) {
                    accountsRow.click();
                    break;
                }
            }
        }
        return selecteddebitAccount.getText();
    }

    public String selectReasonOpeningAccount() {
        reasonIcon.click();
        Reporter.log("Click on reason for opening account icon");
        if (!reasonForOpeningAccountList.isEmpty()) {
            int randonIndex = RandomUtil.generateIntNumber(1, reasonForOpeningAccountList.size());
            WebElement row = reasonForOpeningAccountList.get(randonIndex);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", row);
            row.click();
        }
        return selectedReasonForOpeningAccountList.getText();

    }
}
