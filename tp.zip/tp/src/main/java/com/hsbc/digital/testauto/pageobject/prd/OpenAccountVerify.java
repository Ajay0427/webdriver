/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.prd;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hsbc.digital.testauto.pageobject.OpenAccountVerifyModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for PRD(China)
 * entity. </b>
 * </p>
 */
public class OpenAccountVerify extends OpenAccountVerifyModel {

    private WebDriverWait wait;

    @FindBy(xpath = "//div[contains(@class,'acceptTermsRowTnC')]//input[@type='checkbox']")
    protected WebElement tNcCheckBox;

    public OpenAccountVerify(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30);
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.OpenAccountVerifyModel#clickTnCCheckbox()
     */
    @Override
    public void clickTnCCheckbox() {
        wait.until(ExpectedConditions.elementToBeClickable(tNcCheckBox));
        tNcCheckBox.click();
    }

}
