package com.hsbc.digital.testauto.pageobject.us;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.models.TransactionFlow;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;

public class MoveMoneyCapturePage extends MoveMoneyCapturePageModel {

    protected static final String ENTITY_BANK_COUNTRY = "United states of america";
    private static final String SCROLL_TO_VIEW = "arguments[0].scrollIntoView(true);";
    private static final String COUNTRY_US = "United states";
    protected static final String VALIDEMAILADDRESS = "tESTUSER@ABC.COM";
    protected static final String UNTILFURTHERNOTICE = "Until further notice";
    private final JavascriptExecutor jsx;
    private static final String COMPANY_PAYEE_DETAIL_ENTITY = "us";
    protected static final String PRODUCT_TYPE = "CHQ";
    private static final int MIN_RANGE_NUMBER_OF_PAYMENT = 2;
    private static final String ADDRSS_VALIDTN_WRNG_MSG = "The Address You entered is not valid";
    private static final String ZIP_CODE_SEPARATOR = "-";
    private String invalidaddressString = "";

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(MoveMoneyCapturePage.class);


    // *************************** Transaction end date dropdown
    // .//div[text()='Transaction end
    // date']//following-sibling::div[contains(@class,'dijit dijitReset
    // dijitInline dijitLeft dijitDownArrowButton')]
    @FindBy(xpath = ".//*[text()='Transaction end date']//following-sibling::div[contains(@class,'dijitSelectMenu selectDropDown')]/table//td[2]/input")
    private WebElement transactionEndDate;
    @FindBy(xpath = "//div[contains(@id, 'fromAccount')]//div[contains(@class,'selectDropDown')]")
    private WebElement productTypeFromAccount;

    // ************************ Payee Search Options Fill up
    // ********************
    @FindBy(xpath = "//div[@class='alertPanel info']/p")
    private WebElement addNewPayeeDisclaimer;
    @FindBy(xpath = "//input[starts-with(@id,'companyName')]")
    private WebElement companyNameTxt;
    @FindBy(xpath = ".//input[starts-with(@id,'zipCodeLabel')]")
    private WebElement companyZipTxt;
    @FindBy(xpath = ".//input[starts-with(@id,'actNumLabel')]")
    private WebElement accountNumberTxt;
    @FindBy(xpath = ".//input[starts-with(@id,'confirmActNumLabel')]")
    private WebElement confirmAccountNumberTxt;
    @FindBy(xpath = "//button[@value='Search Payee' and @class='btnSecondary']")
    private WebElement searchPayeeBtn;
    @FindBy(xpath = "//button[@data-dojo-attach-point='_searchPayee']")
    private WebElement searchCompanyPayeeBtn;

    // **************************** Add Payee Options Pop UP
    // ************************
    @FindBy(xpath = "//div[@class='searchDialog']/h1")
    private WebElement searchPayeePopUpTxt;
    @FindBy(xpath = "//div[contains(@class,'gridxRow')]")
    private List<WebElement> searchedPayeeList;
    @FindBy(xpath = ".//button[contains(@class,'addPayee')]")
    private List<WebElement> addPayeeBtn;
    @FindBy(xpath = ".//button[@data-dojo-attach-point='_addPayeeManual']")
    private WebElement addPayeeManuallyBtn;

    // ***************************** After Selecting Existing Searched Payee
    // ****************************
    @FindBy(xpath = "//td[@class='gridxCell']/div/label")
    private List<WebElement> payeeNameLabel;
    @FindBy(xpath = "//span[@data-dojo-attach-point='_BillPayeeNameValue']")
    private WebElement payeeNameValue;
    @FindBy(xpath = "//div[@class='addressSeperator']")
    private WebElement payeeAdressValue;
    @FindBy(xpath = ".//input[contains(@id,'_teleNo')]")
    private WebElement payeeTelephoneNumberTxt;

    // ****************************** After Selecting Manually Add Payee
    // ************************
    @FindBy(xpath = "//input[contains(@id,'payeeNameLabel')]")
    private WebElement addManualPayeeName;
    @FindBy(xpath = ".//input[contains(@id,'addressLabel')]")
    private WebElement addPayeeFirstAddress;
    @FindBy(xpath = ".//input[contains(@id,'addressLabel1')]")
    private WebElement addPayeeSecondAddress;
    @FindBy(xpath = ".//input[contains(@id,'cityLabel')]")
    private WebElement addManuallyPayeeCity;
    @FindBy(xpath = "//table[contains(@aria-labelledby,'AddCompanyManually')]//td[contains(@class,'dijitArrowButton')]")
    private WebElement payeeStateDropDownArrow;
    @FindBy(xpath = "//div[contains(@id,'Select_')]//tr")
    private List<WebElement> payeeStateList;
    @FindBy(xpath = ".//input[contains(@id,'_zipCodeLabel')]")
    private WebElement addManuallyPayeeZip;
    @FindBy(xpath = ".//input[contains(@id,'_BillPayeeAccountNum')]")
    private WebElement toPayeeAccountNumber;
    @FindBy(xpath = ".//input[contains(@id,'confirmBillPayeeAccountNum')]")
    private WebElement confirmPayeeAccountNumber;
    @FindBy(xpath = ".//input[contains(@id,'telephoneLabel')]")
    private WebElement addManuallyPayeeTelephone;

    @FindBy(xpath = "//input[(contains(@id,'SelectPayee')) and (@aria-required='true')]")
    private WebElement myPayees;

    @FindBy(xpath = "//div[contains(@class,'newTransactionMyPayees')]")
    private List<WebElement> newTransMyPayees;

    @FindBy(xpath = "//div[@data-dojo-attach-point='_trnsfrLimitAttach']")
    private WebElement minAmountLabel;

    @FindBy(xpath = "//input[contains(@id,'CurrencyTextBox')]")
    private WebElement amountField;

    @FindBy(css = "span[class$='newTransactionMyPayeesCountryFlag']")
    protected WebElement myPayeeText;

    private static final By locatorInternationalAmountField = By
        .cssSelector("input[id$='_CurrencyTextBox'][data-dojo-attach-point='textbox,focusNode']");

    private final By locatorPayeeAccountNumber = By
        .xpath("//div[contains(@id, 'Capture')]//div[contains(@data-dojo-attach-point, '_payeeDetailsContainer')]//div[contains(@data-dojo-attach-point,'_payeeAcctNumber')]");

    // *********************** Address Validation popUp Elements***************

    @FindBy(xpath = "//div[contains(@aria-labelledby,'ValidatePayee')]//div[contains(@class,'dijitDialogPaneContent')]")
    private WebElement addressValidationPopUp;
    @FindBy(xpath = "//p[contains(@data-dojo-attach-point,'warning')]")
    private WebElement warningMsgAddressValidation;
    @FindBy(xpath = "//div[contains(@class,'addPayeeVerifyDialog')]//button[contains(@data-dojo-attach-point,'continue')]")
    private WebElement continueBtnOnAddrssValidtnPopUp;
    @FindBy(xpath = "//div[contains(@class,'addPayeeVerifyDialog')]//button[contains(@data-dojo-attach-point,'Cancel')]")
    private WebElement cancelBtnOnAddrssValidtnPopUp;
    @FindBy(xpath = "//div[contains(@class,'validatePayeeAdrssContent')]/div[contains(@class,'addressList')]")
    private List<WebElement> validAddressList;
    private final By companyAddress = By.xpath("//span[contains(@class,'billAddrss')]");
    private final By companyStreet = By.xpath("//span[contains(@class,'billStreet')]");
    private final By companyCity = By.xpath("//span[contains(@class,'billCity')]");
    private final By companyState = By.xpath("//span[contains(@class,'billState')]");
    private final By companyZipCode = By.xpath("//span[contains(@class,'billZipCode')]");

    private static final Map<TransactionFlow, By> transferAmountElements = new HashMap<>();

    private static final int DEFAULT_DECIMAL_PLACES = 2;
    private static final int AMOUNT_START_RANGE = 100;
    private static final int AMOUNT_END_RANGE = 200;

    static {
        transferAmountElements.put(TransactionFlow.M2MINTERNATIONAL_TRANSFER, LocatorM2MInternationalAmountfield);
        transferAmountElements.put(TransactionFlow.M2M_TRANSFER, locatorM2MAmountField);
        transferAmountElements.put(TransactionFlow.M2NMHSBC_TRANSFER, locatorM2NMHSBCAmountField);
        transferAmountElements.put(TransactionFlow.M2NMNONHSBC_TRANSFER, locatorNonHSBCAmountField);
        transferAmountElements.put(TransactionFlow.M2NMINTERNATIONAL_TRANSFER, locatorInternationalAmountField);
        transferAmountElements.put(TransactionFlow.M2COMPANY_TRANSFER, locatorM2CompanyAmountField);
    }

    public MoveMoneyCapturePage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        jsx = (JavascriptExecutor) driver;
    }

    /**
     * @return the locatorPayeeAccountNumber
     */
    @Override
    protected By getLocatorPayeeAccountNumber() {
        return locatorPayeeAccountNumber;
    }


    @Override
    protected String getPayeeAccountNumber() {
        return driver.findElement(getLocatorPayeeAccountNumber()).getText();

    }

    /**
     * method to check if the acc is valid for US entity
     * 
     * @author Md Tanbir Hossain
     */
    @Override
    protected boolean isValidAccount(final boolean domesticAccount, final String entity, final String accountlocation) {

        return (domesticAccount && accountlocation.equalsIgnoreCase(COUNTRY_US))

        || (!domesticAccount && !accountlocation.equalsIgnoreCase(entity));
    }

    /**
     * method to check if the acc is valid for M2C transaction
     * 
     * @author Md Tanbir Hossain
     */

    @Override
    protected AccountDetails selectAccountM2C(final String entityCurrency, final WebElement accountDropIcon,
        final boolean domesticAccount, final boolean domesticCurrency) {
        int index;
        List<AccountDetails> accountValue = validAccountDetails(entityCurrency, accountDropIcon, listDropdown, domesticAccount,
            domesticCurrency);
        String productType;
        Assert.assertTrue(!accountValue.isEmpty(), "No valid account found.");
        do {
            index = RandomUtil.generateIntNumber(DEFAULT_LIST_STARTING_INDEX, accountValue.size());
            selectAccountByAccountDetail(accountDropIcon, accountValue.get(index));
            productType = productTypeFromAccount.getAttribute("aria-valuenow");
        } while (!productType.contains(PRODUCT_TYPE));
        return accountValue.get(index);
    }

    /**
     * method to handle the absence of reference text field
     * 
     * @author Md Tanbir Hossain
     */
    @Override
    public String enterYourReferenceText(final Transaction transactionDetail) {
        String yourReference = null;
        List<WebElement> countYourReference = driver
            .findElements(yourReferenceElements.get(transactionDetail.getTransactionFlow()));
        if (!countYourReference.isEmpty()) {
            WebElement fieldYourReference = driver.findElement(yourReferenceElements.get(transactionDetail.getTransactionFlow()));
            if (fieldYourReference.isDisplayed()) {
                yourReference = RandomUtil.generateAlphaNumericText(DEFAULT_REFERENCE_TEXT_LENGTH);
                fieldYourReference.click();
                fieldYourReference.clear();
                fieldYourReference.sendKeys(yourReference);
                fieldYourReference.sendKeys(Keys.RETURN);
                Reporter.log("Your Reference entered is :" + yourReference);
            } else {
                Reporter.log("Your Reference field is not displayed");
            }
        }
        return yourReference;
    }


    /**
     * @author Ranadeep Banik Overriding the method of adding new payee It is
     *         changed according to the US requirements
     */
    private void setInvalidAddressString(final String invalidaddressString) {
        this.invalidaddressString = invalidaddressString;
    }

    private String getInvalidAddressString() {
        return invalidaddressString;
    }

    @Override
    public AccountDetails enterNewCompanyPayeeDetails() {
        Map<String, String> properties = FileUtil.getConfigProperties(COMPANY_PAYEE_DETAIL_ENTITY);
        AccountDetails accountDetails = new AccountDetails();
        super.clickTabsToOpenNewCompanyPayeeDetails();
        String companyAccountNumber = RandomUtil.generateIntNumber(DEFAULT_ACCOUNT_NUMBER_LENGTH);
        String companyName = properties.get("CompanyName");
        String zipCode = properties.get("ZipCode");
        enterCompanyName(companyName);
        enterCompanyAddressZip(zipCode);
        enterCompanyAccountNumber(companyAccountNumber);
        accountDetails.setAccountNumber(companyAccountNumber);
        clickSearchPayeeTab();
        wait.until(ExpectedConditions.visibilityOf(searchPayeePopUpTxt));
        return selectAddPayeeProcess(DEFAULT_LIST_STARTING_INDEX, COMPANY_PAYEE_DETAIL_ENTITY, searchedPayeeList, addPayeeBtn,
            accountDetails, payeeStateDropDownArrow, payeeStateList);
    }

    /**
     * @author Ranadeep Banik Method Added for Adding new Payee Manually
     *         According to US Requirements
     */

    @Override
    public AccountDetails enterNewCompanyPayeeInvalidDetails() {
        setInvalidAddressString(RandomUtil.generateAlphaNumericText(3));
        return enterNewCompanyPayeeDetails();
    }

    private AccountDetails addManualPayee(final String entity, final WebElement dropDownicon, final List<WebElement> dropDownItems,
        final AccountDetails accountDetails) {
        Map<String, String> properties = FileUtil.getConfigProperties(entity);
        String payeeName = RandomUtil.generateAlphabatic(RandomUtil.generateIntNumber(3, 10));
        String payeeAdd1 = getInvalidAddressString() + properties.get("PayeeAdd1");
        String payeeAdd2 = getInvalidAddressString() + properties.get("PayeeAdd2");
        String payeeCity = getInvalidAddressString() + properties.get("PayeeCity");
        String payeeState = properties.get("PayeeState");
        String payeeZipCode = properties.get("PayeeZip");
        String telephone = properties.get("Telephone");
        clickAddPayeeManuallyButton();
        addPayeeName(payeeName);
        accountDetails.setAccountName(payeeName);
        addPayeeAddress(payeeAdd1, payeeAdd2);
        addPayeeCity(payeeCity);
        selectRandomPayeeState(payeeState, dropDownicon, dropDownItems);
        addPayeeZipCode(payeeZipCode);
        addPayeeTelephone(telephone);
        if (accountDetails.getAccountNumber().equals(toPayeeAccountNumber.getAttribute("value"))) {
            Reporter.log("Account Number is Matched :" + accountDetails.getAccountNumber());
        }
        return accountDetails;
    }

    /**
     * @author Ranadeep Banik Method for adding new Payee Name
     * 
     */
    private void addPayeeName(final String payeeName) {
        wait.until(ExpectedConditions.visibilityOf(addManualPayeeName));
        addManualPayeeName.clear();
        addManualPayeeName.sendKeys(payeeName);
    }

    /**
     * @author Ranadeep Banik Method for adding New Payee Address
     * 
     */
    private void addPayeeAddress(final String address1, final String address2) {
        addPayeeFirstAddress.clear();
        addPayeeFirstAddress.sendKeys(address1);
        addPayeeSecondAddress.clear();
        addPayeeSecondAddress.sendKeys(address2);
    }

    /**
     * @author Ranadeep Banik Method for Adding new Payee City
     * 
     */
    private void addPayeeCity(final String city) {
        addManuallyPayeeCity.clear();
        addManuallyPayeeCity.sendKeys(city);
    }

    /**
     * @author Ranadeep Banik Method for Adding new PayeeZip
     * 
     */
    private void addPayeeZipCode(final String zip) {
        addManuallyPayeeZip.clear();
        addManuallyPayeeZip.sendKeys(zip);
    }

    /**
     * @author Ranadeep Banik Method for adding new Payee Telephone
     * 
     */
    private void addPayeeTelephone(final String telephone) {
        addManuallyPayeeTelephone.clear();
        addManuallyPayeeTelephone.sendKeys(telephone);
    }

    /**
     * @author Ranadeep Banik
     * 
     * 
     */
    public int getRandomPayeeNumber(final List<WebElement> payeelist) {
        return payeelist.size() > 1 ? RandomUtil.generateIntNumber(DEFAULT_LIST_STARTING_INDEX, payeelist.size() - 1) : 0;
    }

    /**
     * @author Ranadeep Banik Method created for adding new existing searched
     *         Payee According to US requirements
     */
    public AccountDetails addExistingSearchedPayee(final String entity, final List<WebElement> payeelist,
        final List<WebElement> addPayeebutton, final AccountDetails accountDetails) {
        String telephone = FileUtil.getConfigProperties(entity).get("Telephone");
        Assert.assertTrue(!payeelist.isEmpty(), "Searched payee list not displayed");
        int index = getRandomPayeeNumber(payeelist);
        jsx.executeScript(SCROLL_TO_VIEW, payeelist.get(index));
        wait.until(ExpectedConditions.elementToBeClickable(addPayeebutton.get(index)));
        addPayeebutton.get(index).click();
        wait.until(ExpectedConditions.visibilityOf(payeeNameValue));
        accountDetails.setAccountName(payeeNameValue.getText());
        this.enterPayeeTelephoneNumber(telephone);
        return accountDetails;
    }

    /**
     * @author Ranadeep Banik
     * 
     * 
     */

    private AccountDetails selectAddPayeeProcess(final int startingIndex, final String entity, final List<WebElement> payeelist,
        final List<WebElement> addPayeebutton, final AccountDetails accountDetails, final WebElement dropDownIcon,
        final List<WebElement> dropDownList) {
        int randomNumber = RandomUtil.generateIntNumber(startingIndex, 100);
        switch (randomNumber % 2) {
        case 0:
            return addExistingSearchedPayee(entity, payeelist, addPayeebutton, accountDetails);
        case 1:
            return addManualPayee(entity, dropDownIcon, dropDownList, accountDetails);
        default:
            return addExistingSearchedPayee(entity, payeelist, addPayeebutton, accountDetails);
        }
    }


    /**
     * @author Ranadeep Banik
     * 
     * 
     */
    private void enterCompanyAccountNumber(final String accNum) {
        accountNumberTxt.clear();
        accountNumberTxt.sendKeys(accNum);
        accountNumberTxt.sendKeys(Keys.RETURN);
        if (confirmAccountNumberTxt.isDisplayed()) {
            confirmAccountNumberTxt.clear();
            confirmAccountNumberTxt.sendKeys(accNum);
            confirmAccountNumberTxt.sendKeys(Keys.RETURN);
        }
    }

    /**
     * @author Ranadeep Banik
     * 
     * 
     */
    private void enterCompanyName(final String compName) {
        companyNameTxt.clear();
        companyNameTxt.sendKeys(compName);
    }

    /**
     * @author Ranadeep Banik
     * 
     * 
     */
    private void enterCompanyAddressZip(final String zip) {
        companyZipTxt.clear();
        companyZipTxt.sendKeys(zip);
    }

    /**
     * @author Ranadeep Banik
     * 
     * 
     */
    private void clickAddPayeeManuallyButton() {
        wait.until(ExpectedConditions.elementToBeClickable(addPayeeManuallyBtn));
        addPayeeManuallyBtn.click();
    }

    /**
     * @author Ranadeep Banik
     * 
     * 
     */
    private void enterPayeeTelephoneNumber(final String telephone) {
        wait.until(ExpectedConditions.visibilityOf(payeeTelephoneNumberTxt));
        payeeTelephoneNumberTxt.clear();
        payeeTelephoneNumberTxt.sendKeys(telephone);
    }

    /**
     * @author Ranadeep Banik
     * 
     * 
     */
    private void clickSearchPayeeTab() {
        WebElement searchTab = searchPayeeBtn.isDisplayed() ? searchPayeeBtn : searchCompanyPayeeBtn;
        wait.until(ExpectedConditions.elementToBeClickable(searchTab));
        searchTab.click();
    }

    /**
     * @author Ranadeep Banik
     * 
     * 
     */
    private void selectRandomPayeeState(final String payeeState, final WebElement dropDownIcon, final List<WebElement> dropDownItems) {
        dropDownIcon.click();
        for (WebElement state : dropDownItems) {
            jsx.executeScript(SCROLL_TO_VIEW, state);
            if (state.getText().contains(payeeState)) {
                state.click();
            }
        }
    }

    /**
     * @author Ranadeep Banik
     * 
     * 
     */
    @Override
    protected String getEntityBankCountry() {
        return ENTITY_BANK_COUNTRY;
    }

    @Override
    public String selectTransactionEnddate() {
        String endDateDropDownValue = selectRandamValue(transactionEndDateDropIcon, listDropdown);
        Reporter.log("Frequency value selected is :" + endDateDropDownValue);
        return endDateDropDownValue;
    }

    @Override
    public String selectTransactionEnddateUntilFurtherNotice() {
        String endDateDropDownValue = selectUntilFurtherFromRandamValue(transactionEndDateDropIcon, listDropdown);
        Reporter.log("Frequency value selected is :" + endDateDropDownValue);
        return endDateDropDownValue;
    }

    @Override
    public String selectLanguajeEnglish() {
        return selectRandamValue(languageNotification, listDropdown);
    }

    @Override
    public String verifyNumberOfPayements() {
        String noOfPayements = null;
        if (numberOfPaymentsText.isDisplayed()) {
            noOfPayements = RandomUtil.generateIntNumber(2);
            numberOfPaymentsText.sendKeys(noOfPayements);
            return noOfPayements;
        } else {
            return noOfPayements;
        }
    }

    @Override
    public void inputEmailaddress() {
        emailAddress.clear();
        emailAddress.sendKeys(VALIDEMAILADDRESS);
    }


    private String selectUntilFurtherFromRandamValue(final WebElement dropDownIcon, final WebElement dropDownItems) {
        dropDownIcon.click();
        wait.until(ExpectedConditions.visibilityOf(dropDownItems));
        List<WebElement> valueElements = dropDownItems.findElements(menuText).isEmpty() ? dropDownItems.findElements(menuPopup)
            : dropDownItems.findElements(menuText);
        WebElement untilfurther = null;
        for (WebElement value : valueElements) {
            if (value.getText().equals(UNTILFURTHERNOTICE)) {
                untilfurther = value;
                break;
            }
        }
        if (untilfurther != null) {
            jsx.executeScript(SCROLL_TO_VIEW, untilfurther);
            String selectedValue = untilfurther.getText();
            wait.until(ExpectedConditions.elementToBeClickable(untilfurther));
            untilfurther.click();
            Reporter.log("Item Selected:" + selectedValue);
            return selectedValue;
        } else {
            Reporter.log("Null result found for until further element selection.");
        }
        return null;
    }

    @Override
    public void processPayeeSelection(AccountDetails accountDetail) {
        clickMyPayeeTab();
        myPayees.sendKeys(accountDetail.getAccountNickName());
        if (newTransMyPayees.size() == 1) {
            newTransMyPayees.get(0).click();
        } else if (newTransMyPayees.size() > 1) {
            selectMatchingMyPayee(accountDetail);
        } else {
            Assert.fail("Either My payees list not displayed or no valid payee shown. | ");
        }
        logger.info("Account with Name: " + accountDetail.getAccountName() + " and Number: " + accountDetail.getAccountNumber()
            + " is selected.| ");
        Reporter.log("Account with Name: " + accountDetail.getAccountName() + " and Number: " + accountDetail.getAccountNumber()
            + " is selected.| ");
        logger.info(accountDetail.getAccountNickName() + " selected as \'My payees\' . | ");
        Reporter.log(accountDetail.getAccountNickName() + " selected as \'My payees\' . | ");
    }

    private void selectMatchingMyPayee(AccountDetails accountDetail) {
        for (int eachPayee = 0; eachPayee < newTransMyPayees.size(); eachPayee++) {
            String myPayeeCountry = newTransMyPayees.get(eachPayee).getText().split("\\r?\\n")[1];
            if (myPayeeCountry.equalsIgnoreCase(accountDetail.getAccountCountry())) {
                newTransMyPayees.get(eachPayee).click();
                break;
            }
        }
    }

    @Override
    public String enterTransferAmount(Transaction transactionDetail) {
        String amount = StringUtils.EMPTY;
        if (transactionDetail.getFromAccount().getDoubleAccountBalance() < AMOUNT_START_RANGE) {
            logger.error("Available balance is not enough to proceed with the transaction.");
            Assert.fail("Available balance is not enough to proceed with the transaction.");
        } else if (transactionDetail.getFromAccount().getDoubleAccountBalance() < AMOUNT_END_RANGE) {
            int endRange = transactionDetail.getFromAccount().getDoubleAccountBalance().intValue();
            amount = RandomUtil.generateDoubleNumber(AMOUNT_START_RANGE, endRange, DEFAULT_DECIMAL_PLACES);
        } else {
            amount = RandomUtil.generateDoubleNumber(AMOUNT_START_RANGE, AMOUNT_END_RANGE, DEFAULT_DECIMAL_PLACES);
        }
        WebElement fieldAmount = getAmountField(transactionDetail);
        jsx.executeScript(SCROLL_TO_VIEW, fieldAmount);
        fieldAmount.clear();
        fieldAmount.sendKeys(amount);
        Reporter.log("Transfer Amount entered is: " + amount);
        return amount;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel#
     * getAmountField(com.hsbc.digital.testauto.models.Transaction)
     */
    @Override
    protected WebElement getAmountField(Transaction transactionDetail) {
        return driver.findElement(transferAmountElements.get(transactionDetail.getTransactionFlow()));
    }

    /**
     * Minimum number of payment to be initiated as 2 in US
     */
    @Override
    public String enterNumberOfPayment(final Transaction transactionDetails) {
        selectNumberOfTransfer(transactionDetails);
        String valueNop = String.valueOf(RandomUtil.generateIntNumber(MIN_RANGE_NUMBER_OF_PAYMENT, MAX_RANGE_NUMBER_OF_PAYMENT));
        numberOfPaymentsText.click();
        numberOfPaymentsText.clear();
        numberOfPaymentsText.sendKeys(valueNop);
        numberOfPaymentsText.sendKeys(Keys.RETURN);
        Reporter.log("Number of Payement entered is :" + valueNop);
        return valueNop;
    }

    @Override
    public void clickCancelButton(final boolean isCancel, Transaction transaction) {
        wait.until(ExpectedConditions.elementToBeClickable(cancelButton));
        cancelButton.click();
        if (isCancel) {
            clickCancelPopUpCancelButton();
        } else {
            clickContinuePopupContinueButton();
            verifyCaptureDetailsForM2NM(transaction);
        }
    }

    @Override
    protected String myPayeeAcctName() {
        return myPayeeText.getText();
    }

    /**
     * @author Md Tanbir Hossain methods to validate address validation field
     */

    public AccountDetails validateAddressList(final List<AccountDetails> accDetailsList) {
        if (accDetailsList.size() > 1) {
            int randomIndex = RandomUtil.generateIntNumber(DEFAULT_LIST_STARTING_INDEX, accDetailsList.size() - 1);
            return accDetailsList.get(randomIndex);
        }
        return accDetailsList.get(0);
    }

    public AccountDetails validateAddress(AccountDetails accountDetails) {
        List<AccountDetails> validAccDetailsList = new ArrayList<>();
        if (!validAddressList.isEmpty()) {
            for (WebElement addressLine : validAddressList) {
                jsx.executeScript(SCROLL_TO_VIEW, addressLine);
                String address = addressLine.findElement(companyAddress).getText();
                String street = addressLine.findElement(companyStreet).getText();
                String city = addressLine.findElement(companyCity).getText();
                String zipCode = addressLine.findElement(companyZipCode).getText();
                String state = addressLine.findElement(companyState).getText();
                accountDetails.setAddress(address);
                accountDetails.setStreeName(street);
                accountDetails.setCityName(city);
                accountDetails.setPostalCode(zipCode);
                accountDetails.setState(state);
                validAccDetailsList.add(accountDetails);
            }
        }
        return validateAddressList(validAccDetailsList);
    }

    @Override
    public AccountDetails validateAddressFromFinalistMapi(Transaction transaction) {
        Assert.assertTrue(addressValidationPopUp.isDisplayed(), "Validation Pop up Not Displayed");
        Assert.assertTrue(warningMsgAddressValidation.getText().contains(ADDRSS_VALIDTN_WRNG_MSG),
            "Address Validation Warning Message not Shown");
        return validateAddress(transaction.getToAccount());
    }

    @Override
    public void clickContinueOnAddressValidationPopUp() {
        wait.until(ExpectedConditions.elementToBeClickable(continueBtnOnAddrssValidtnPopUp));
        continueBtnOnAddrssValidtnPopUp.click();
        logger.info("Continue Button Clicked on Address Validation Pop Up");
    }

    @Override
    public void clickCancelOnAddressValidationPopUp() {
        wait.until(ExpectedConditions.elementToBeClickable(cancelBtnOnAddrssValidtnPopUp));
        cancelBtnOnAddrssValidtnPopUp.click();
        logger.info("Cancel Button Clicked on Address Validation Pop Up");
    }

    @Override
    public void reEnterCompanyPayeeDetailsFromFinalistMapi(final AccountDetails accountDetails) {
        String zipCode = accountDetails.getPostalCode().contains(ZIP_CODE_SEPARATOR) ? accountDetails.getPostalCode().substring(
            DEFAULT_LIST_STARTING_INDEX, accountDetails.getPostalCode().indexOf(ZIP_CODE_SEPARATOR.charAt(0))) : accountDetails
            .getPostalCode();
        addPayeeAddress(accountDetails.getAddress(), accountDetails.getStreeName());
        addPayeeCity(accountDetails.getCityName());
        selectRandomPayeeState(accountDetails.getState(), payeeStateDropDownArrow, payeeStateList);
        addPayeeZipCode(zipCode);
    }
}
