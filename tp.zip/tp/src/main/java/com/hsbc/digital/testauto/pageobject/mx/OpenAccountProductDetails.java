/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.mx;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.pageobject.OpenAccountProductDetailsModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Mexico
 * entity. </b>
 * </p>
 */
public class OpenAccountProductDetails extends OpenAccountProductDetailsModel {

    public OpenAccountProductDetails(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.OpenAccountProductDetailsModel#clickApplyButtonForRandomProduct()
     */
    @Override
    public int clickApplyButtonForRandomProduct() {
        int randomNumber = RandomUtil.generateIntNumber(0, 9);
        switch (randomNumber) {
        case 0:
            super.clickApplyPagareMonedaNacional();
            break;
        case 1:
            super.clickApplyInversionExpress();
            break;
        case 2:
            super.clickLessThan50000DollarTab();
            super.clickApplyCEDETasaFija();
            break;
        case 3:
            super.clickLessThan50000DollarTab();
            super.clickApplyPagareMonedaNacional();
            break;
        case 4:
            super.clickLessThan50000DollarTab();
            super.clickApplyInversionExpress();
            break;
        case 5:
            super.clickMoreThan50000DollarTab();
            super.clickApplyCEDETasaVariableCETE();
            break;
        case 6:
            super.clickMoreThan50000DollarTab();
            super.clickApplyCEDETasaVariableTIIE();
            break;
        case 7:
            super.clickMoreThan50000DollarTab();
            super.clickApplyCEDETasaFija();
            break;
        case 8:
            super.clickMoreThan50000DollarTab();
            super.clickApplyPagareMonedaNacional();
            break;
        case 9:
            super.clickMoreThan50000DollarTab();
            super.clickApplyInversionExpress();
            break;
        }
        return randomNumber;
    }
}
