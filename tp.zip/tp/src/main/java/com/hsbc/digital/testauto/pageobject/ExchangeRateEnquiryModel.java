/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.digital.testauto.pageobject;

import java.text.NumberFormat;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;

/**
 * <p>
 * <b> This Model class will hold locators and functionality related methods
 * for Story Exchange Rate Enquiry that can be used around all entities </b>
 * </p>
 * 
 * @version 1.0.0
 * @author Deepti Patil
 * 
 */

public abstract class ExchangeRateEnquiryModel {

    private final WebDriver driver;

    private static final String EXPECTED_DEFAULT_AMOUNT = "1";

    private static final int AMOUNT_RANGE = 999999999;

    // Locators on Currency converter tool
    @FindBy(xpath = "//div[@id='fxCalculator']/h2")
    private WebElement currencyConverterTitle;

    @FindBy(xpath = "//div[@id='fxCalculator']")
    private WebElement currencyConverterWidget;

    // Locators for To Currency Fields
    @FindBy(xpath = "//table[contains(@id,'toCurrencyField')]//input[contains(@id,'toCurrencyField')]")
    private WebElement toCurrencyDropDownIcon;

    @FindBy(xpath = "//div[contains(@id,'toCurrencyField')]/table[contains(@class,'dijitMenuTable')]")
    private WebElement toCurrencyDropDownTable;

    @FindBy(xpath = "//div[contains(@id,'toCurrencyField')]//span[contains(@id,'dijit_MenuItem') and contains(@id,'text')]/../span[1]")
    private List<WebElement> actualToCurrencyMenu;

    @FindBy(xpath = "//input[contains(@id,'toCurrencyField_CurrencyTextBox')]/following-sibling::span/following-sibling::input")
    protected WebElement toAmountValue;

    @FindBy(xpath = "//div[contains(@id,'toCurrencyField')]//span[contains(@class,'ValidationTextBoxLabel')]")
    protected WebElement toCurrency;

    @FindBy(xpath = "//input[contains(@id,'toCurrencyField_CurrencyTextBox')]")
    protected WebElement toAmount;


    // Locators for From Currency Fields
    @FindBy(xpath = "//table[contains(@id,'fromCurrencyField')]//input[contains(@id,'fromCurrencyField')]")
    private WebElement fromCurrencyDropDownIcon;

    @FindBy(xpath = "//div[contains(@id,'fromCurrencyField')]/table[contains(@class,'dijitMenuTable')]")
    private WebElement fromCurrencyDropDownTable;

    @FindBy(xpath = "//div[contains(@id,'fromCurrencyField')]//span[contains(@id,'dijit_MenuItem') and contains(@id,'text')]/../span[1]")
    private List<WebElement> actualFromCurrencyMenu;

    @FindBy(xpath = "//div[contains(@id,'fromCurrencyField')]//span[contains(@class,'ValidationTextBoxLabel')]")
    protected WebElement fromCurrency;

    @FindBy(xpath = "//input[contains(@id,'fromCurrencyField_CurrencyTextBox')]/following-sibling::span/following-sibling::input")
    protected WebElement fromAmountValue;

    @FindBy(xpath = "//input[contains(@id,'fromCurrencyField_CurrencyTextBox')]")
    private WebElement fromAmount;

    // Locators for Transfer or Payment Rate
    @FindBy(xpath = "//p[contains(@data-dojo-attach-point,'conversionResults')]")
    protected WebElement transferOrPaymentRateResult;

    // Locators for Switch Currency Button
    @FindBy(xpath = "//button[@class='btnTertiary converterBtn']")
    private WebElement switchCurrencyButton;

    // Locators for Reset Currency Button
    @FindBy(xpath = "//div[@id='swapperRow']/button[text()='Reset']")
    private WebElement resetCurrencyButton;

    // Locators for New Transaction Button
    @FindBy(xpath = "//a[contains(@class,'moveMoney btnReset')]")
    private WebElement newTransactionButton;

    // Locators for New Transaction Page Title
    @FindBy(xpath = "//h2[contains(@data-dojo-attach-point,'transactionTitle')]")
    private WebElement newTransactionPageTitle;


    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(ExchangeRateEnquiryModel.class);

    public ExchangeRateEnquiryModel(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    private void verifyFromCurrencyOrder() {
        fromCurrencyDropDownIcon.click();
        Reporter.log("From Currency Drop Down clicked");
        verifyList(getExpectedCurrencyList(), actualFromCurrencyMenu);
        Reporter.log("From Currency is in alphabetical order");
        fromCurrencyDropDownIcon.click();
        Reporter.log("From Currency Drop Down clicked");
    };

    /**
     * Method to verify To Currency list alphabetical order
     * 
     */
    private void verifyToCurrencyOrder() {
        toCurrencyDropDownIcon.click();
        Reporter.log("To Currency Drop Down clicked");
        verifyList(getExpectedCurrencyList(), actualToCurrencyMenu);
        Reporter.log("To Currency is in alphabetical order");
        toCurrencyDropDownIcon.click();
        Reporter.log("To Currency Drop Down clicked");
    };


    public abstract List<String> getExpectedCurrencyList();

    public abstract String getDefaultCurrency();

    /**
     * Method to verify default value in From Currency
     * 
     */
    private void verifyFromCurrencyDefaultValue() {
        Assert.assertTrue(fromCurrency.isDisplayed() && fromCurrency.getText().equals(getDefaultCurrency()),
            "Default currency not displayed");
        Reporter.log("Default currency displayed");
    };

    /**
     * Method to verify elements on Exchange Rate tool.
     * 
     */
    public void isExchageRateEnquiryToolDisplayed() {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", currencyConverterWidget);
        isElementDisplayed(currencyConverterTitle);
        isElementDisplayed(switchCurrencyButton);
        isElementDisplayed(resetCurrencyButton);
        isElementDisplayed(newTransactionButton);
    }

    /**
     * Method to carry out currency conversion.
     * 
     */
    public void performExchangeRateTransaction() {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", currencyConverterWidget);
        fromCurrencyDropDownIcon.click();
        Reporter.log("From Currency Drop down clicked");
        String fromCurrencyText = selectCurrency(actualFromCurrencyMenu);
        Reporter.log("From Currency selected :" + fromCurrencyText);
        toCurrencyDropDownIcon.click();
        Reporter.log("To Currency Drop down clicked");
        String toCurrencyText = selectCurrency(actualToCurrencyMenu);
        Reporter.log("To Currency selected :" + toCurrencyText);
        enterAmount(fromAmount);
    }

    /**
     * Method to verify if payment or transfer rate is applied.
     * 
     */
    public void isRateApplied() {
        isElementDisplayed(transferOrPaymentRateResult);
        verifyRateApplied(fromAmountValue, toAmountValue);
        enterAmount(toAmount);
        Reporter.log("To Amount Entered");
        verifyRateApplied(fromAmountValue, toAmountValue);
    }

    /**
     * Method to verify the rate applied while conversion.
     * 
     * @param amount
     * 
     */
    private void verifyRateApplied(final WebElement fromAmountValue, final WebElement toAmountValue) {
        String formatedAmountFrom = NumberFormat.getCurrencyInstance()
            .format(Double.parseDouble(fromAmountValue.getAttribute("value"))).toString().replace("$", "");
        String formatedAmountTo = NumberFormat.getCurrencyInstance()
            .format(Double.parseDouble(toAmountValue.getAttribute("value"))).toString().replace("$", "");
        String rateResultText = transferOrPaymentRateResult.getText();
        Assert.assertTrue(rateResultText.contains(formatedAmountFrom) && rateResultText.contains(formatedAmountTo)
            && rateResultText.contains(fromCurrency.getText()) && rateResultText.contains(toCurrency.getText()),
            "Exchange Rate is not applied");
        Reporter.log("Exchange Rate is applied");
    }

    /**
     * Method to verify the order of From and To currency.
     * 
     */
    public void verifyCurrencyOrder() {
        verifyFromCurrencyOrder();
        verifyToCurrencyOrder();
    }

    /**
     * Method to verify default currency and amount in from field.
     * 
     */
    public void verifyCurrencyDefaultValues() {
        verifyFromCurrencyDefaultValue();
        verifyFromAmountDefaultValue();
    }

    /**
     * Method to verify reset button functionality.
     * 
     */
    public void verifyResetCurrency() {
        resetCurrencyButton.click();
        verifyCurrencyDefaultValues();
    }

    /**
     * Method to verify reverse currency functionality.
     * 
     */
    public void verifyReverseCurrency() {
        String fromCurrencyValue = fromCurrency.getText();
        String toCurrencyValue = toCurrency.getText();
        switchCurrencyButton.click();
        Assert.assertTrue(toCurrency.getText().equals(fromCurrencyValue) && fromCurrency.getText().equals(toCurrencyValue),
            "Switch Currency functionality not verified");
        Reporter.log("Switch Currency functionality verified");
    }

    /**
     * Method to check if an element is displayed.
     * 
     * @param WebElement
     * 
     */
    protected void isElementDisplayed(final WebElement element) {
        Assert.assertTrue(element.isDisplayed(), "Element not displayed");
    }

    /**
     * Method to verify order of the currency.
     * 
     * @param Expected
     *            List, Actual List
     * 
     * @return true/false
     * 
     */
    public boolean verifyList(final List<String> expectedList, final List<WebElement> actualCurrencyList) {
        boolean isListMatches = true;
        if (actualCurrencyList.size() != expectedList.size()) {
            return false;
        }
        for (int i = 0; i < actualCurrencyList.size(); i++) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", actualCurrencyList.get(i));
            if (!expectedList.get(i).equals(actualCurrencyList.get(i).getText())) {
                isListMatches = false;
            }
        }
        return isListMatches;
    }

    /**
     * Method to select currency.
     * 
     * @param Currency
     *            list to be selected
     * 
     */
    private String selectCurrency(final List<WebElement> currencyList) {
        int randomIndex = RandomUtil.generateIntNumber(1, currencyList.size());
        WebElement currencyRow = currencyList.get(randomIndex);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", currencyRow);
        currencyRow.click();
        return currencyRow.getText();
    }

    /**
     * Method to verify default amount in from currency.
     * 
     */
    public void verifyFromAmountDefaultValue() {
        Assert.assertTrue(fromAmountValue.getAttribute("value").equals(ExchangeRateEnquiryModel.EXPECTED_DEFAULT_AMOUNT),
            "Default Amount not displayed");
        Reporter.log("Default Amount displayed");
    }

    /**
     * Method to enter amount.
     * 
     * @param From
     *            /To amount input field
     * 
     */
    protected void enterAmount(final WebElement amountInputField) {
        String randomAmount = String.valueOf(RandomUtil.generateIntNumber(1, ExchangeRateEnquiryModel.AMOUNT_RANGE));
        amountInputField.clear();
        amountInputField.sendKeys(randomAmount);
        Reporter.log("Amount entered is :" + randomAmount);
        clickWidget();
    }

    private void clickWidget() {
        currencyConverterTitle.click();
    }

    /**
     * Method to verify new transaction functionality.
     * 
     */
    public void verifyNewTransactionButton() {
        newTransactionButton.click();
        Reporter.log("New Transaction Button Clicked");
        isElementDisplayed(newTransactionPageTitle);
        Reporter.log("New Transaction Page Title displayed");
    }


}
