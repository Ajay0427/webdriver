/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.mx;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.UserInterfaceRequirementDashboardModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for User
 * Interface Requirement Dashboard for Canada entity. </b>
 * </p>
 */
public class UserInterfaceRequirementDashboard extends UserInterfaceRequirementDashboardModel {

    private final WebDriverWait wait;
    /*
     * Masthead
     */
    @FindBy(xpath = "//span[contains(@id,'LanguageToggle')]")
    private WebElement languageToggleText;

    /*
     * HSBC LOGO
     */
    @FindBy(xpath = "//*[@alt='HSBC Retail']")
    private WebElement hsbcLogoForMass;

    @FindBy(xpath = "//*[@alt='HSBC Advance']")
    private WebElement hsbcLogoForAdvance;

    /*
     * -------- HEADER LINKS --------
     */
    @FindBy(xpath = "//a[contains(@class,'navigation-link')]/span[text()='My banking']")
    protected WebElement myBankingLinkHeader;

    @FindBy(xpath = "//a[contains(@class,'navigation-link')]/span[text()='Investments']")
    private WebElement investmentsLinkHeader;

    @FindBy(xpath = "//a[contains(@class,'navigation-link')]/span[text()='Products & services']")
    private WebElement productAndSevicesLinkHeader;

    @FindBy(xpath = "//a[contains(@class,'navigation-link')]/span[text()='Offers&rewards']")
    private WebElement offersAndRewardsLinkHeader;

    @FindBy(xpath = "//a[contains(@class,'navigation-link')]/span[text()='Contact']")
    private WebElement contactLinkHeader;

    /*
     * My Banking FlyerMenu - Column wise Links
     */
    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='My banking']]/descendant::li[preceding-sibling::li//h4/span[text()='Inquiries']]")
    private List<WebElement> firstColumnLinksMyBankingHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='My banking']]/descendant::ul[preceding-sibling::h3//span[text()='Direct Debits']]/li")
    private List<WebElement> thirdColumnLinksMyBankingHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='My banking']]/descendant::ul[preceding-sibling::h3//span[text()='Taxes']]/li")
    private List<WebElement> fourthColumnLinksMyBankingHeader;

    /*
     * Investments FlyerMenu - Column wise Links
     */
    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Investments']]/descendant::ul[preceding-sibling::h3//span[text()='Term deposits']]/li")
    private List<WebElement> firstColumnLinksInvestmentsHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Investments']]/descendant::ul[preceding-sibling::h3//span[text()='Investment funds']]/li")
    private List<WebElement> secondColumnLinksInvestmentsHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Investments']]/descendant::ul[preceding-sibling::h3//span[text()='Stockmarket connection']]/li")
    private List<WebElement> thirdColumnLinksInvestmentsHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Investments']]/descendant::ul[preceding-sibling::h3//span[text()='Reports and information']]/li")
    private List<WebElement> fourthColumnLinksInvestmentsHeader;


    /*
     * Products And services FlyerMenu - Column wise Links
     */
    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Products & services']]/descendant::ul[preceding-sibling::h3//span[text()='Accountst']]/li")
    private List<WebElement> firstColumnLinksProductsAndServicesHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Products & services']]/descendant::ul[preceding-sibling::h3//span[text()='Credit Cards']]/li")
    private List<WebElement> secondColumnLinksProductsAndServicesHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Products & services']]/descendant::ul[preceding-sibling::h3//span[text()='Loans']]/li")
    private List<WebElement> thirdColumnLinksProductsAndServicesHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Products & services']]/descendant::ul[preceding-sibling::h3//span[text()='Insurance']]/li")
    private List<WebElement> fourthColumnLinksProductsAndServicesHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Products & services']]/descendant::ul[preceding-sibling::h3/span[text()='HSBC Premier']]//h4/span")
    private List<WebElement> fourthColumnHSBCPremierHeadingLinksProductsAndServicesHeader;

    /*
     * Offers & Rewards FlyerMenu - Column wise Links
     */
    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Offers&rewards']]/descendant::ul[preceding-sibling::h3/span[text()='Personalized offers']]/li")
    private List<WebElement> firstColumnLinksOffersAndRewardsHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Offers&rewards']]/descendant::ul[preceding-sibling::h3/span[text()='Home & Away']]/li")
    private List<WebElement> secondColumnLinksOffersAndRewardsHeader;

    /*
     * Contact FlyerMenu - Column wise Links
     */
    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Contact']]/descendant::ul[preceding-sibling::h3/span[text()='Help']]/li")
    private List<WebElement> firstColumnLinksContactHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Contact']]/descendant::ul[preceding-sibling::h3/span[text()='Contact Us']]/li")
    private List<WebElement> secondColumnLinksContactHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Contact']]/descendant::ul[preceding-sibling::h3/span[text()='Report']]/li")
    private List<WebElement> thirdColumnLinksContactHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Contact']]/descendant::ul[preceding-sibling::h3/span[text()='Payroll portability']]/li")
    private List<WebElement> fourthColumnLinksContactHeader;

    /*
     * -------- FOOTER LINKS --------
     *  Above Footer Links
     */
    @FindBy(xpath = "//div[contains(@class,'footerTopLine')]//li")
    private List<WebElement> aboveFooterLinks;

    /*
     * Below Footer Links list
     */
    @FindBy(xpath = "//div[@class='footer clearfix']/ul//li")
    private List<WebElement> belowFooterLinks;

    /*
     * Middle Layer of Footer Links list
     */
    @FindBy(xpath = "//ul[preceding-sibling::h2[text()='Help and support']]/li")
    private List<WebElement> helpAndSupportLinksFooter;
    @FindBy(xpath = "//ul[preceding-sibling::h2[text()='Report']]/li")
    private List<WebElement> reportLinksFooter;
    @FindBy(xpath = "//ul[preceding-sibling::h2[text()='Products & services']]/li")
    private List<WebElement> productAndServicesLinksFooter;

    /*
     * My banking Links list
     */
    private static final List<String> FIRST_COLUMN_LINKS_TEXT_MYBANKING = Arrays.asList("Balances and history",
        "Statement and notification options", "E-Statements", "Exchange rate", "POS transaction history", "Mobile Banking",
        "Mobile Banking");
    private static final List<String> SECOND_COLUMN_LINKS_TEXT_MYBANKING = Arrays.asList("Transfer or pay", "Phone top up",
        "Manage future dated transactions", "Future dated history", "Ecommerce");
    private static final List<String> THIRD_COLUMN_LINKS_TEXT_MYBANKING = Arrays.asList("Set up Direct Debits",
        "Manage Direct Debits");
    private static final List<String> FOURTH_COLUMN_LINKS_TEXT_MYBANKING = Arrays.asList("State taxes", "Federal taxes",
        "Mexico City Treasury", "Set limits for tax payments");

    /*
     * Investments Links list
     */
    private static final List<String> FIRST_COLUMN_LINKS_TEXT_INVESTMENTS = Arrays.asList("View my term deposit",
        "Update maturity instruction", "Open a term deposit", "Term deposit simulator");
    private static final List<String> SECOND_COLUMN_LINKS_TEXT_INVESTMENTS = Arrays.asList("View my investment funds",
        "Operate my investment portfolio", "Open an investment contract", "Operation receipt", "Investment funds catalog ",
        "Investment fund simulator");
    private static final List<String> THIRD_COLUMN_LINKS_TEXT_INVESTMENTS = Arrays.asList("View my investment portfolio");
    private static final List<String> FOURTH_COLUMN_LINKS_TEXT_INVESTMENTS = Arrays.asList("Global Asset Management");

    /*
     * Products & services Links list
     */
    private static final List<String> FIRST_COLUMN_LINKS_TEXT_PRODUCT_AND_SERVICES = Arrays.asList("Cuenta Flexible",
        "Cuenta Flexible con Chequera", "HSBC Advance", "Cuenta Premier", "Producto B�sico General", "N�mina Flexible HSBC",
        "N�mina Ejecutiva sin Chequera", "Cuenta B�sica de N�mina", "View more accounts");
    private static final List<String> SECOND_COLUMN_LINKS_TEXT_PRODUCT_AND_SERVICES = Arrays.asList("B�sica HSBC", "HSBC Acceso",
        "Oro HSBC", "Cl�sica HSBC", "HSBC Platinum Visa", "HSBC Platinum Mastercard", "HSBC Advance Platinum",
        "HSBC Premier World Elite Mastercard�", "View more Credit Cards");
    private static final List<String> THIRD_COLUMN_LINKS_TEXT_PRODUCT_AND_SERVICES = Arrays.asList("Cr�dito Personal HSBC",
        "Cr�dito de N�mina HSBC", "Cr�dito Hipotecario", "Cr�dito Inmediauto", "View more loans");
    private static final List<String> FOURTH_COLUMN_LINKS_TEXT_PRODUCT_AND_SERVICES = Arrays.asList("Request car insurance",
        "Electronics insurance", "View more insurances");
    private static final List<String> FOURTH_COLUMN_HSBC_PREMIER_LINKS_TEXT_PRODUCT_AND_SERVICES = Arrays.asList("HSBC Advance");

    /*
     * Offers And Rewards Links list
     */
    private static final List<String> FIRST_COLUMN_LINKS_TEXT_OFFERS_AND_REWARDS = Arrays.asList("View my offers");
    private static final List<String> SECOND_COLUMN_LINKS_TEXT_OFFERS_AND_REWARDS = Arrays.asList("Promotions abroad");

    /*
     * Contact Links list
     */
    private static final List<String> FIRST_COLUMN_LINKS_TEXT_CONTACT = Arrays.asList("FAQs", "Help videos",
        "Security software with no charge");
    private static final List<String> SECOND_COLUMN_LINKS_TEXT_CONTACT = Arrays.asList("Chat", "My messages",
        "Complaints or inquiries", "Find branches or ATMs", "HSBC Contact Centre");
    private static final List<String> THIRD_COLUMN_LINKS_TEXT_CONTACT = Arrays.asList("Report a lost or stolen card",
        "Notify us of travel", "Block / Unblock Cards");
    private static final List<String> FOURTH_COLUMN_LINKS_TEXT_CONTACT = Arrays.asList("Receive your deposits at HSBC",
        "Portability", "View status");


    private static final List<String> ABOVE_FOOTER_LINKS_TEXT = Arrays.asList("Chat", "Find a branch or ATM");
    private static final List<String> BELOW_FOOTER_LINKS_TEXT = Arrays.asList("Terms and conditions", "Privacy policy",
        "Working hours", "Security information", "HSBC Group", "�HSBC M�xico 2017");
    /* Middle layer footer */
    private static final List<String> HELPANDSUPPORT_LINKS_FOOTER_TEXT = Arrays.asList("HSBC Contact Centre", "Help videos",
        "Working hours");
    private static final List<String> REPORT_LINKS_FOOTER_TEXT = Arrays.asList("Report a lost or stolen card");
    private static final List<String> PRODUCTANDSERVICES_LINKS_FOOTER_TEXT = Arrays.asList("Accounts", "Credit Cards", "Loans",
        "Insurance", "HSBC Premier", "HSBC Advance");

    public UserInterfaceRequirementDashboard(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30);
    }

    /**
     * This is to verify the Country Toggle in the Masthead on the dashboard
     */
    @Override
    public void languageToggle() {
        assertAndReportElementIsDisplayed(languageToggleText, "Country/language toggle text on Masthead is displayed",
            "Country/language toggle text on Masthead is not displayed");
    }

    /**
     * This is to verify the All the Header links for the Premier on the
     * dashboard
     */
    @Override
    public void verifyAllHeaderLinksForPremier(FlyerMenuNavigationModel navigationModel) {
        verifyMyBankingLinksHeader(navigationModel);
        verifyInvestmentsLinksHeader(navigationModel);
        verifyProductAndServicesLinksHeader(navigationModel);
        verifyOffersAndRewardsLinksHeader(navigationModel);
        verifyContactLinksHeader(navigationModel);
    }

    /**
     * This is to verify the All the Header links for the Advance on the
     * dashboard
     */
    public void verifyAllHeaderLinksForAdvance(FlyerMenuNavigationModel navigationModel) {
        verifyMyBankingLinksHeader(navigationModel);
        verifyInvestmentsLinksHeader(navigationModel);
        verifyProductAndServicesLinksHeader(navigationModel);
        verifyOffersAndRewardsLinksHeader(navigationModel);
        verifyContactLinksHeader(navigationModel);
    }

    /**
     * This is to verify the All the Header links for the Mass on the dashboard
     */
    public void verifyAllHeaderLinksForMass(FlyerMenuNavigationModel navigationModel) {
        verifyMyBankingLinksHeader(navigationModel);
        verifyInvestmentsLinksHeader(navigationModel);
        verifyProductAndServicesLinksHeader(navigationModel);
        verifyOffersAndRewardsLinksHeader(navigationModel);
        verifyContactLinksHeader(navigationModel);
    }

    /**
     * This is to verify All My Banking Links on the dashboard
     */
    private void verifyMyBankingLinksHeader(FlyerMenuNavigationModel navigationModel) {
        navigationModel.mouseOverOnMyBanking();
        wait.until(ExpectedConditions.visibilityOf(navigationModel.flyerMenu));
        super.validateAndCompareElement(firstColumnLinksMyBankingHeader, FIRST_COLUMN_LINKS_TEXT_MYBANKING,
            "My Banking Header first column");
        super.validateAndCompareElement(secondColumnLinksMyBankingHeader, SECOND_COLUMN_LINKS_TEXT_MYBANKING,
            "My Banking Header second column");
        super.validateAndCompareElement(thirdColumnLinksMyBankingHeader, THIRD_COLUMN_LINKS_TEXT_MYBANKING,
            "My Banking Header third column");
        super.validateAndCompareElement(fourthColumnLinksMyBankingHeader, FOURTH_COLUMN_LINKS_TEXT_MYBANKING,
            "My Banking Header fourth column");
    }

    /**
     * This is to verify All Investments Links on the dashboard
     */
    private void verifyInvestmentsLinksHeader(FlyerMenuNavigationModel navigationModel) {
        navigationModel.mouseOverOnHeader(investmentsLinkHeader);
        wait.until(ExpectedConditions.visibilityOf(navigationModel.flyerMenu));
        super.validateAndCompareElement(firstColumnLinksInvestmentsHeader, FIRST_COLUMN_LINKS_TEXT_INVESTMENTS,
            "Investments Header first column");
        super.validateAndCompareElement(secondColumnLinksInvestmentsHeader, SECOND_COLUMN_LINKS_TEXT_INVESTMENTS,
            "Investments Header second column");
        super.validateAndCompareElement(thirdColumnLinksInvestmentsHeader, THIRD_COLUMN_LINKS_TEXT_INVESTMENTS,
            "Investments Header third column");
        super.validateAndCompareElement(fourthColumnLinksInvestmentsHeader, FOURTH_COLUMN_LINKS_TEXT_INVESTMENTS,
            "Investments Header fourth column");
    }

    /**
     * This is to verify All Product And Services Links on the dashboard
     */
    private void verifyProductAndServicesLinksHeader(FlyerMenuNavigationModel navigationModel) {
        navigationModel.mouseOverOnHeader(productAndSevicesLinkHeader);
        wait.until(ExpectedConditions.visibilityOf(navigationModel.flyerMenu));
        super.validateAndCompareElement(firstColumnLinksProductsAndServicesHeader, FIRST_COLUMN_LINKS_TEXT_PRODUCT_AND_SERVICES,
            "Product And Services Header first column");
        super.validateAndCompareElement(secondColumnLinksProductsAndServicesHeader, SECOND_COLUMN_LINKS_TEXT_PRODUCT_AND_SERVICES,
            "Product And Services Header second column");
        super.validateAndCompareElement(thirdColumnLinksProductsAndServicesHeader, THIRD_COLUMN_LINKS_TEXT_PRODUCT_AND_SERVICES,
            "Product And Services Header third column");
        super.validateAndCompareElement(fourthColumnLinksProductsAndServicesHeader, FOURTH_COLUMN_LINKS_TEXT_PRODUCT_AND_SERVICES,
            "Product And Services Header fourth column");
        super.validateAndCompareElement(fourthColumnHSBCPremierHeadingLinksProductsAndServicesHeader,
            FOURTH_COLUMN_HSBC_PREMIER_LINKS_TEXT_PRODUCT_AND_SERVICES, "Product And Services Header fourth column HSBC Premier");

    }

    /**
     * This is to verify All Offers And Rewards Links on the dashboard
     */
    private void verifyOffersAndRewardsLinksHeader(FlyerMenuNavigationModel navigationModel) {
        navigationModel.mouseOverOnHeader(offersAndRewardsLinkHeader);
        wait.until(ExpectedConditions.visibilityOf(navigationModel.flyerMenu));
        super.validateAndCompareElement(firstColumnLinksOffersAndRewardsHeader, FIRST_COLUMN_LINKS_TEXT_OFFERS_AND_REWARDS,
            "Offers And Rewards Header first column");
        super.validateAndCompareElement(secondColumnLinksOffersAndRewardsHeader, SECOND_COLUMN_LINKS_TEXT_OFFERS_AND_REWARDS,
            "Offers And Rewards Header second column");
    }

    /**
     * This is to verify All Contact Links on the dashboard
     */
    private void verifyContactLinksHeader(FlyerMenuNavigationModel navigationModel) {
        navigationModel.mouseOverOnHeader(contactLinkHeader);
        wait.until(ExpectedConditions.visibilityOf(navigationModel.flyerMenu));
        super.validateAndCompareElement(firstColumnLinksContactHeader, FIRST_COLUMN_LINKS_TEXT_CONTACT,
            "Contact Header first column");
        super.validateAndCompareElement(secondColumnLinksContactHeader, SECOND_COLUMN_LINKS_TEXT_CONTACT,
            "Contact Header second column");
        super.validateAndCompareElement(thirdColumnLinksContactHeader, THIRD_COLUMN_LINKS_TEXT_CONTACT,
            "Contact Header third column");
        super.validateAndCompareElement(fourthColumnLinksContactHeader, FOURTH_COLUMN_LINKS_TEXT_CONTACT,
            "Contact Header fourth column");
    }

    /* Footer Methods */
    /**
     * This is to verify the Middle layer in the Footer on the dashboard
     */
    @Override
    public void footerLink() {
        validateAndCompareElement(helpAndSupportLinksFooter, HELPANDSUPPORT_LINKS_FOOTER_TEXT, "Help and Support links footer");
        validateAndCompareElement(reportLinksFooter, REPORT_LINKS_FOOTER_TEXT, "Report links footer");
        validateAndCompareElement(productAndServicesLinksFooter, PRODUCTANDSERVICES_LINKS_FOOTER_TEXT,
            "Products and services links footer");
    }

    /*
     * Above footer Methods
     */
    public List<WebElement> aboveFooterLinksList() {
        return aboveFooterLinks;
    }

    public List<String> aboveFooterLinkText() {
        return ABOVE_FOOTER_LINKS_TEXT;
    }

    /*
     * Below footer Methods
     */
    @Override
    public List<WebElement> belowFooterLinksList() {
        return belowFooterLinks;
    }

    @Override
    public List<String> belowFooterLinkText() {
        return BELOW_FOOTER_LINKS_TEXT;
    }

    /**
     * This is to verify the Quick Transfer Widget is not displayed on the
     * dashboard
     */
    @Override
    public void verifyQuickTransferWidget() {
        Assert.assertTrue(quickTransferWidget.isEmpty(), "Quick Transfer Widget is displayed");
        Reporter.log("Quick Transfer Widget is not displayed.");
    }

}
