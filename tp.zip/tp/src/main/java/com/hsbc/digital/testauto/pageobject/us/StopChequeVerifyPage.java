package com.hsbc.digital.testauto.pageobject.us;

import org.openqa.selenium.WebDriver;

import com.hsbc.digital.testauto.pageobject.StopChequeVerifyPageModel;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

public class StopChequeVerifyPage extends StopChequeVerifyPageModel {

    private static final String LABEL_CHEQUE_RANGE = "Check range";

    @Override
    protected String getLabelChequeRange() {
        return LABEL_CHEQUE_RANGE;
    }

    public StopChequeVerifyPage(final WebDriver driver) {
        super(driver);
        uiCommonUtil = new UICommonUtil(driver);
    }

}
