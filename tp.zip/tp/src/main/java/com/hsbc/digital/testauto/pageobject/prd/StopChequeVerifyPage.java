package com.hsbc.digital.testauto.pageobject.prd;

import org.openqa.selenium.WebDriver;

import com.hsbc.digital.testauto.pageobject.StopChequeVerifyPageModel;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

/**
 * <p>
 * <b> Stop Cheque Verify page object model to hold generic function and
 * locators for prd entity of story stop cheque</b>
 * </p>
 * 
 * @version 1.0.0
 * @author Neeraj Kumar
 */

public class StopChequeVerifyPage extends StopChequeVerifyPageModel {

    public StopChequeVerifyPage(final WebDriver driver) {
        super(driver);
        uiCommonUtil = new UICommonUtil(driver);
    }

}
