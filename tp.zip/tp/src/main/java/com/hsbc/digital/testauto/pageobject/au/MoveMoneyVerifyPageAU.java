package com.hsbc.digital.testauto.pageobject.au;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.hsbc.digital.testauto.pageobject.MoveMoneyVerifyPageModelNew;

public class MoveMoneyVerifyPageAU extends MoveMoneyVerifyPageModelNew {


    public MoveMoneyVerifyPageAU(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

}
