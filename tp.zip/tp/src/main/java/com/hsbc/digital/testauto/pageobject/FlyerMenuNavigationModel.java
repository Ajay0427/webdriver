package com.hsbc.digital.testauto.pageobject;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public abstract class FlyerMenuNavigationModel {
    protected final WebDriverWait wait;
    protected final WebDriver driver;

    /*
     * -------- HEADER LINKS --------
     */
    @FindBy(xpath = "//a[contains(@class,'navigation-link')]//span[contains(text(),'My banking')]")
    protected WebElement myBankingLinkHeader;

    @FindBy(xpath = "//a[contains(@class, 'navigation-link')]//span[contains(text(),'Products & services')]")
    protected WebElement productAndServicesLinkHeader;

    @FindBy(xpath = "//a[contains(@class, 'navigation-link')]//span[contains(text(),'Investments & financial planning')]")
    protected WebElement investmentAndFinancialPlanningLinkHeader;

    @FindBy(xpath = "//a[contains(@class,'navigation-link')]//span[contains(text(),'Contact')]")
    protected WebElement contactHSBCLinkHeader;

    /*
     * My Banking - Move Money Header Links
     */
    @FindBy(linkText = "My payees")
    protected WebElement myPayeesLinkMoveMoneyMyBankingHeader;

    /*
     * Existing locators
     */

    @FindBy(xpath = "//a[contains(@class, 'navigation-link')]//span[contains(text(), 'Products & services')]")
    public WebElement productAndServices;

    @FindBy(xpath = "//a[contains(text(),'Statements / Advices')]")
    public WebElement statementsLnk;

    @FindBy(xpath = "//div[@class='doormat-wrapper']")
    public WebElement flyerMenu;

    @FindBy(linkText = "My Accounts")
    public WebElement myAccount;

    @FindBy(linkText = "Pay or transfer")
    public WebElement payOrTransfer;

    @FindBy(xpath = ".//a[@data-uid='myPayees']")
    public WebElement myPayee;

    @FindBy(xpath = "//a[contains(text(), 'Future dated transfers')]")
    public WebElement futurePayment;

    @FindBy(css = "div.row.futureDatedPaymentsHeading")
    public WebElement futureDatedTransfersHeading;

    @FindBy(linkText = "autoPay")
    public WebElement autoPay;

    @FindBy(linkText = "Bill payment")
    public WebElement billPayement;

    @FindBy(linkText = "Financial Calendar")
    public WebElement financialCal;

    @FindBy(linkText = "Apply for integrated account")
    public WebElement apIntAcc;

    @FindBy(linkText = "Place time deposit")
    public WebElement plTimeDep;

    @FindBy(linkText = "Update maturity instructions")
    public WebElement upMatIns;

    @FindBy(linkText = "Manage eStatements")
    public WebElement manageStatement;

    @FindBy(linkText = "Add/remove international accounts")
    public WebElement manageIntAccount;

    @FindBy(linkText = "Global Transfer")
    public WebElement globalTrans;

    @FindBy(linkText = "Daily transfer limits")
    public WebElement dailyTransLimit;

    @FindBy(linkText = "overseas ATM withdrawal limit")
    public WebElement overATMLimit;

    @FindBy(linkText = "Request ATM card PIN")
    public WebElement reqATMPIN;

    @FindBy(linkText = "Manage online accounts")
    public WebElement manageOnAcc;

    @FindBy(linkText = "Request chequebook")
    public WebElement reqCheque;

    @FindBy(linkText = "Manage eAlerts")
    public WebElement manageAlert;

    @FindBy(css = "span.title")
    public WebElement myBankingLabel;

    @FindBy(css = "span.countryAccount")
    public WebElement lhmMyAccount;

    @FindBy(css = "span.countryAccount")
    public List<WebElement> lhmMyAccounts;

    @FindBy(linkText = "Direct Debits")
    public WebElement directDebits;

    @FindBy(xpath = "//div[@id ='accountsummary']//*[text()='Move money']")
    public WebElement dashboardMMButton;

    @FindBy(id = "_TransactionModel")
    private WebElement moveMoneyPageTransaction;

    @FindBy(xpath = "//span[contains(text(),'Balance')]//following-sibling::span[@data-dojo-attach-point='_dapAccountBalance']")
    public WebElement AccBalance;

    @FindBy(linkText = "Order checkbook")
    public WebElement orderChequeBook;

    @FindBy(linkText = "Request stop check")
    private WebElement stopAChequeLinkChequesMyBankingHeader;

    protected WebElement getStopAChequeLinkChequesMyBankingHeader() {
        return stopAChequeLinkChequesMyBankingHeader;
    }

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(FlyerMenuNavigationModel.class);

    public FlyerMenuNavigationModel(final WebDriver driver) {
        this.driver = driver;
        // This initElements method will create all WebElements
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30000);
    }

    /*
     * Story 38 - User Interface Dashboard
     */
    /*
     * Header Methods
     */

    /**
     * This is to verify the All the Header links for the MASS on the dashboard
     */
    public void verifyAllHeaderLinksForMass() {}


    /**
     * This is to verify the All the Header links for the Advance on the
     * dashboard
     */
    public void verifyAllHeaderLinksForAdvance() {}

    /**
     * This is to verify the All the Header links for the Premier on the
     * dashboard
     */
    public void verifyAllHeaderLinksForPremier() {}


    /*
     * Generic Methods
     */

    /**
     * 
     * <p>
     * This is to mouse over the WebElement
     * </p>
     * 
     * @param headerElement
     *            - WebElement to mouseover
     */
    public void mouseOverOnHeader(final WebElement headerElement) {
        Actions action = new Actions(driver);
        action.moveToElement(headerElement).build().perform();
        // wait.until(ExpectedConditions.visibilityOf(flyerMenu));
    }

    /*
     * ------------------ Navigations Flows ------------------
     */
    public void mouseOverOnMyBanking() {
        Actions action = new Actions(driver);
        action.moveToElement(myBankingLinkHeader).build().perform();
    }

    public void mouseOverOnProductAndServices() {
        Actions action = new Actions(driver);
        action.moveToElement(productAndServicesLinkHeader).build().perform();
    }

    public void mouseOverOnInvestmentAndFinancialPlanning() {
        Actions action = new Actions(driver);
        action.moveToElement(investmentAndFinancialPlanningLinkHeader).build().perform();
    }

    public void mouseOverOnContactHSBC() {
        Actions action = new Actions(driver);
        action.moveToElement(contactHSBCLinkHeader).build().perform();
    }

    public void myMenu(final WebElement elem) {
        mouseOverOnMyBanking();
        elem.click();
    }

    public void myMenuContact(final WebElement elem) {
        mouseOverOnContactHSBC();
        elem.click();
    }

    public void myMenuHeader(final WebElement header, final WebElement elem) {
        mouseOverOnHeader(header);
        elem.click();
    }

    public void myMenuProductAndServices(final WebElement elem) {
        this.mouseOverOnProductAndServices();
        elem.click();
    }

    public void navigateToMyAccount() {
        myMenu(myAccount);
    }

    public void clickDashboardMMButton() {
        wait.until(ExpectedConditions.elementToBeClickable(dashboardMMButton));
        dashboardMMButton.click();
        wait.until(ExpectedConditions.visibilityOf(moveMoneyPageTransaction));
    }

    public String getAccBalance() {
        return AccBalance.getText();
    }

    public void navigateToNewTransactionPage() {
        myMenu(payOrTransfer);
    }

    public void navigateToMypayeesPage() {
        myMenu(myPayee);
    }

    public void navigateToOrderChequeBookPage() {
        myMenu(orderChequeBook);
    }

    public void navigateToStopAChequePage() {
        myMenu(getStopAChequeLinkChequesMyBankingHeader());
    }

    public void navigateToStatementsAndAdvices() {}

    public void navigateToGlobalViewPage() {}

    public void navigateToApplyOpenNewTD() {}

    public void navigateToManageInternetBankingLimits() {}

    public void navigateToReportLostOrStolenCardPage() {}

    public void navigateToRenameAccountsPage() {}

    public void navigateToRequestReplacementPin() {}

    public void navigateToFutureDatedTransaction() {}

    public void navigateToBillPaymentHistory() {}

    public void navigateToUpdateContactDetails() {}

    public void navigateToTFSA() {}

    public void navigateToEverydayBanking() {}

    public void navigateToMobileAlertService() {}

    public void navigateToStatementOrNotificationOptions() {}

    public void navigateToAlertSettings() {}

    public void navigateToMyDocuments() {}

    public void navigateToMyStatementsAndOtherDocuments() {}

    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     */
    public void navigateToApplySavingsAccount() {


    }

    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     */
    public void navigateToApplyTermDepositAccount() {
        // TODO Auto-generated method stub

    }

    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     */
    public void navigateToApplyOpenNewSaving() {
        // TODO Auto-generated method stub

    }

    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     */
    public void navigateToApplyCurentAccount() {
        // TODO Auto-generated method stub

    }

    public boolean navigateTnCPage() {
        return false;
    }

    /** UK **/
    public void navigateToCP() {

    }

}
