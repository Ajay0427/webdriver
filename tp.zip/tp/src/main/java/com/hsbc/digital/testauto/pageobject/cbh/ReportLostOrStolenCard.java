/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.cbh;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.pageobject.ReportLostOrStolenCardModel;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class ReportLostOrStolenCard extends ReportLostOrStolenCardModel {

    @FindBy(xpath = "//div[@id='Manage']//button[@class='iconButton manage' and @aria-selected='false']")
    private List<WebElement> manageButtonList;

    // Locator for report Lost Or Stolen disclaimer
    @FindBy(xpath = "//div[contains(@id,'Dialog') and not(contains(@style,'display: none'))]//div/p[1]")
    private WebElement disclaimer;

    /**
     * @param driver
     */
    public ReportLostOrStolenCard(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);

    }

    public List<WebElement> getManageButtonList() {
        return manageButtonList;
    }

    /**
     * Method to check if Disclaimer message is Displayed.
     * 
     */
    public void isDisclaimerDisplayed() {
        Assert.assertTrue(disclaimer.isDisplayed(), "Disclaimer message not displayed. ");
        Reporter.log("Disclaimer message is displayed. ");
    }


}
