/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.library;

import java.text.DecimalFormat;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * <b> Class to generate different types of random Numbers,String or Special
 * characters.</b>
 * 
 * @author Shrikant Joshi
 * @version 1.0.0
 *          </p>
 */
public class RandomUtil {

    private static final String SPECIAL_CHARS = "!#$%&'()*+,-./:;<=>?@[]^_`{|}~";
    private static final String NUMBER_FORMAT_EXP = "#.";
    private static final String NUMBER_FORMAT_DECIMAL_EXP = "0";

    private RandomUtil() {}

    public static String generateSpecialCharacterText(final int length) {
        char[] specialChars = RandomUtil.SPECIAL_CHARS.toCharArray();
        return RandomStringUtils.random(length, 0, specialChars.length, false, false, specialChars);
    }

    /**
     * 
     * <p>
     * <b> Generates Alphabetic and Numeric Text for given length. </b>
     * </p>
     * 
     * @param length
     * @return alphanumeric text
     */
    public static String generateAlphaNumericText(final int length) {
        return RandomStringUtils.randomAlphanumeric(length);
    }

    /**
     * 
     * <p>
     * <b> Generates String of Integer numbers for given length. </b>
     * </p>
     * 
     * @param length
     * @return Numeric String
     */
    public static String generateIntNumber(final int length) {
        return RandomStringUtils.randomNumeric(length);
    }

    /**
     * 
     * <p>
     * <b> Generates Integer number randomly between given start and end
     * integers. </b>
     * </p>
     * 
     * @param start
     *            - starting limit for random integer
     * @param end
     *            - end limit(exclusive) for random integer
     * @return Integer number
     */
    public static int generateIntNumber(final int start, final int end) {
        return ThreadLocalRandom.current().nextInt(start, end);
    }

    /**
     * 
     * <p>
     * <b> Generates double number in given start and end range. </b>
     * </p>
     * 
     * @param start
     *            - starting limit for random double
     * @param end
     *            - end limit for random double
     * @return Double number
     */
    public static double generateDoubleNumber(final int start, final int end) {
        return ThreadLocalRandom.current().nextDouble(start, end);
    }

    /**
     * 
     * <p>
     * <b>Generates String representation of Double number for given range and
     * given No.Of decimal places. </b>
     * </p>
     * 
     * @param start
     *            - starting limit for random double
     * @param end
     *            - end limit for random double
     * @param decimalPlaces
     *            - No of decimal places required
     * @return String containing Double number
     */
    public static String generateDoubleNumber(final int start, final int end, final int decimalPlaces) {
        double number = generateDoubleNumber(start, end);
        return formatDouble(number, getDecimalFormat(decimalPlaces));
    }

    /**
     * 
     * <p>
     * <b> Gets Decimal format for given decimal precision. </b>
     * </p>
     * 
     * @param decimalPlaces
     *            no of decimal places
     * @return format for Java Decimal formatter in String format.
     */
    public static String getDecimalFormat(final int decimalPlaces) {
        return new StringBuilder(RandomUtil.NUMBER_FORMAT_EXP).append(
            StringUtils.repeat(RandomUtil.NUMBER_FORMAT_DECIMAL_EXP, decimalPlaces)).toString();
    }

    /**
     * 
     * <p>
     * <b> Formats given double number in given format. </b>
     * </p>
     * 
     * @param number
     *            - Double number to format.
     * @param format
     *            - Format in which double number need to be modified.
     * @return String of double formatted
     */
    public static String formatDouble(final double number, final String format) {
        DecimalFormat df = new DecimalFormat(format);
        return df.format(number);
    }

    /**
     * 
     * <p>
     * <b> Generates Alphabetic String for given length randomly. </b>
     * </p>
     * 
     * @param length
     *            - length of String required
     * @return String of random alphabetic character
     */
    public static String generateAlphabatic(final int length) {
        return RandomStringUtils.randomAlphabetic(length);
    }
}
