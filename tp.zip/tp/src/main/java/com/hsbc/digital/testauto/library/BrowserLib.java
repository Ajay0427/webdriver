/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.library;


import java.net.MalformedURLException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.hsbc.digital.testauto.exceptions.UnsupportedBrowserException;

/**
 * <p>
 * <b> Class is used for Driver initialisation, browser screen maximize,
 * minimize & quit. </b>
 * 
 * @version 1.0.0
 * @author Shrikant Joshi
 * 
 *         </p>
 */
public class BrowserLib {

    /**
     * Driver instance declaration
     */
    WebDriver driver = null;
    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(BrowserLib.class);
    private static final String FIREFOX = "firefox";
    private static final String INTERNET_EXP = "ie";
    private static final String CHROME = "chrome";


    /**
     * Constructor for initializing class with given browser type based on
     * configuration.
     * 
     * @param browser
     *            :Browser name which will be passed from configuration/caller
     */
    public BrowserLib(final String browser) {
        try {
            this.setupDriver(browser);
        } catch (Exception e) {
            BrowserLib.logger.error("Exception thrown:", e);
        }
    }

    /**
     * Method to instantiate Driver instance for this class based on browser
     * passed.
     * 
     * @param browser
     * @throws MalformedURLException
     * @throws Exception
     */
    public void setupDriver(final String browser) throws MalformedURLException {

        // Check if parameter passed from TestNG is 'firefox'
        if (BrowserLib.FIREFOX.equalsIgnoreCase(browser)) {
            DesiredCapabilities capabilities = DesiredCapabilities.firefox();
            capabilities.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
            driver = new FirefoxDriver(capabilities);
        } else if (BrowserLib.CHROME.equalsIgnoreCase(browser)) {
            System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/src/main/resources/"
                + "chromedriver.exe");
            DesiredCapabilities capabilities = DesiredCapabilities.chrome();
            capabilities.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
            driver = new ChromeDriver(capabilities);
        } else if (BrowserLib.INTERNET_EXP.equalsIgnoreCase(browser)) {
            // set path to IEdriver.exe You may need to download it from
            // 32 bits
            // http://selenium-release.storage.googleapis.com/2.42/IEDriverServer_Win32_2.42.0.zip
            // 64 bits
            // http://selenium-release.storage.googleapis.com/2.42/IEDriverServer_x64_2.42.0.zip
            System.setProperty("webdriver.ie.driver", System.getProperty("user.dir") + "/src/main/resources/"
                + "IEDriverServer.exe");
            // create IE instance
            driver = new InternetExplorerDriver();

        } else {
            // If no browser passed throw exception
            throw new UnsupportedBrowserException();
        }
        this.browserMaximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


    }

    /**
     * Method to maximize browser window for current instance.
     */
    public void browserMaximize() {
        driver.manage().window().maximize();
    }

    /**
     * Method to minimize browser window for current instance.
     */
    public void browserMinimize() {
        driver.manage().window().maximize();
    }

    /**
     * Method to close all browser window for current instance.
     */
    public void closeAllBrowsers() {
        driver.quit();
    }

    /**
     * Returns current instance of driver.
     * 
     * @return driver
     */
    public WebDriver getDriver() {
        return this.driver;
    }

}
