package com.hsbc.digital.testauto.pageobject.uk;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.hsbc.digital.testauto.pageobject.VerifiedByVisaModel;


/**
 * Contains locators and functions of Verified by Visa story for UK - Capture
 * Page
 * 
 * @author Neha Rajesh Gupta
 * @version 1.0.0
 * 
 * **/

public class VerifiedByVisa extends VerifiedByVisaModel {


    public VerifiedByVisa(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }


}
