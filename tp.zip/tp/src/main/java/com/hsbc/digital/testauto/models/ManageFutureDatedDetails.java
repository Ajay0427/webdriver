/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.models;

import org.apache.commons.lang3.StringUtils;

/**
 * This class holds the values for Manage Future Dated Payment
 * 
 * @author Nirmalkumar L
 * 
 */
public class ManageFutureDatedDetails {

    private String minimumAmountInList;
    private String maximumAmountInList;

    private String minimumDateInList;
    private String maximumDateInList;

    private String defaultValueInByAccount;
    private String defaultValueInByType;
    private String defaultValueInByFrequency;

    private String randomAmount;

    private String fromAccountSelected;
    private String toAccountSelected;
    private String amountSelected;
    private String transferDate;

    private String accountFromDropdown;
    private String transferFrequencyFromDropdown;
    private String transferTypeFromDropdown;
    private String fromDateFilter;
    private String toDateFilter;
    private String fromAmountFilter;
    private String toAmountFilter;

    public ManageFutureDatedDetails() {
        this.accountFromDropdown = StringUtils.EMPTY;
        this.transferFrequencyFromDropdown = StringUtils.EMPTY;
        this.transferTypeFromDropdown = StringUtils.EMPTY;
        this.fromDateFilter = StringUtils.EMPTY;
        this.toDateFilter = StringUtils.EMPTY;
        this.fromAmountFilter = StringUtils.EMPTY;
        this.toAmountFilter = StringUtils.EMPTY;
    }

    /**
     * @return the minimumAmountInList
     */
    public String getMinimumAmountInList() {
        return minimumAmountInList;
    }

    /**
     * @param minimumAmountInList
     *            the minimumAmountInList to set
     */
    public void setMinimumAmountInList(final String minimumAmountInList) {
        this.minimumAmountInList = minimumAmountInList;
    }

    /**
     * @return the maximumAmountInList
     */
    public String getMaximumAmountInList() {
        return maximumAmountInList;
    }

    /**
     * @param maximumAmountInList
     *            the maximumAmountInList to set
     */
    public void setMaximumAmountInList(final String maximumAmountInList) {
        this.maximumAmountInList = maximumAmountInList;
    }

    /**
     * @return the minimumDateInList
     */
    public String getMinimumDateInList() {
        return minimumDateInList;
    }

    /**
     * @param minimumDateInList
     *            the minimumDateInList to set
     */
    public void setMinimumDateInList(final String minimumDateInList) {
        this.minimumDateInList = minimumDateInList;
    }

    /**
     * @return the maximumDateInList
     */
    public String getMaximumDateInList() {
        return maximumDateInList;
    }

    /**
     * @param maximumDateInList
     *            the maximumDateInList to set
     */
    public void setMaximumDateInList(final String maximumDateInList) {
        this.maximumDateInList = maximumDateInList;
    }

    /**
     * @return the defaultValueInByAccount
     */
    public String getDefaultValueInByAccount() {
        return defaultValueInByAccount;
    }

    /**
     * @param defaultValueInByAccount
     *            the defaultValueInByAccount to set
     */
    public void setDefaultValueInByAccount(final String defaultValueInByAccount) {
        this.defaultValueInByAccount = defaultValueInByAccount;
    }

    /**
     * @return the defaultValueInByType
     */
    public String getDefaultValueInByType() {
        return defaultValueInByType;
    }

    /**
     * @param defaultValueInByType
     *            the defaultValueInByType to set
     */
    public void setDefaultValueInByType(final String defaultValueInByType) {
        this.defaultValueInByType = defaultValueInByType;
    }

    /**
     * @return the defaultValueInByFrequency
     */
    public String getDefaultValueInByFrequency() {
        return defaultValueInByFrequency;
    }

    /**
     * @param defaultValueInByFrequency
     *            the defaultValueInByFrequency to set
     */
    public void setDefaultValueInByFrequency(final String defaultValueInByFrequency) {
        this.defaultValueInByFrequency = defaultValueInByFrequency;
    }

    /**
     * @return the randomAmount
     */
    public String getRandomAmount() {
        return randomAmount;
    }

    /**
     * @param randomAmount
     *            the randomAmount to set
     */
    public void setRandomAmount(final String randomAmount) {
        this.randomAmount = randomAmount;
    }

    /**
     * @return the fromAccountSelected
     */
    public String getFromAccountSelected() {
        return fromAccountSelected;
    }

    /**
     * @param fromAccountSelected
     *            the fromAccountSelected to set
     */
    public void setFromAccountSelected(final String fromAccountSelected) {
        this.fromAccountSelected = fromAccountSelected;
    }

    /**
     * @return the toAccountSelected
     */
    public String getToAccountSelected() {
        return toAccountSelected;
    }

    /**
     * @param toAccountSelected
     *            the toAccountSelected to set
     */
    public void setToAccountSelected(final String toAccountSelected) {
        this.toAccountSelected = toAccountSelected;
    }

    /**
     * @return the amountSelected
     */
    public String getAmountSelected() {
        return amountSelected;
    }

    /**
     * @param amountSelected
     *            the amountSelected to set
     */
    public void setAmountSelected(final String amountSelected) {
        this.amountSelected = amountSelected;
    }

    /**
     * @return the transferDate
     */
    public String getTransferDate() {
        return transferDate;
    }

    /**
     * @param transferDate
     *            the transferDate to set
     */
    public void setTransferDate(final String transferDate) {
        this.transferDate = transferDate;
    }

    /**
     * @return the accountFromDropdown
     */
    public String getAccountFromDropdown() {
        return accountFromDropdown;
    }

    /**
     * @param accountFromDropdown
     *            the accountFromDropdown to set
     */
    public void setAccountFromDropdown(final String accountFromDropdown) {
        this.accountFromDropdown = accountFromDropdown;
    }

    /**
     * @return the transferFrequencyFromDropdown
     */
    public String getTransferFrequencyFromDropdown() {
        return transferFrequencyFromDropdown;
    }

    /**
     * @param transferFrequencyFromDropdown
     *            the transferFrequencyFromDropdown to set
     */
    public void setTransferFrequencyFromDropdown(final String transferFrequencyFromDropdown) {
        this.transferFrequencyFromDropdown = transferFrequencyFromDropdown;
    }

    /**
     * @return the transferTypeFromDropdown
     */
    public String getTransferTypeFromDropdown() {
        return transferTypeFromDropdown;
    }

    /**
     * @param transferTypeFromDropdown
     *            the transferTypeFromDropdown to set
     */
    public void setTransferTypeFromDropdown(final String transferTypeFromDropdown) {
        this.transferTypeFromDropdown = transferTypeFromDropdown;
    }

    /**
     * @return the fromDateFilter
     */
    public String getFromDateFilter() {
        return fromDateFilter;
    }

    /**
     * @param fromDateFilter
     *            the fromDateFilter to set
     */
    public void setFromDateFilter(final String fromDateFilter) {
        this.fromDateFilter = fromDateFilter;
    }

    /**
     * @return the toDateFilter
     */
    public String getToDateFilter() {
        return toDateFilter;
    }

    /**
     * @param toDateFilter
     *            the toDateFilter to set
     */
    public void setToDateFilter(final String toDateFilter) {
        this.toDateFilter = toDateFilter;
    }

    /**
     * @return the fromAmountFilter
     */
    public String getFromAmountFilter() {
        return fromAmountFilter;
    }

    /**
     * @param fromAmountFilter
     *            the fromAmountFilter to set
     */
    public void setFromAmountFilter(final String fromAmountFilter) {
        this.fromAmountFilter = fromAmountFilter;
    }

    /**
     * @return the toAmountFilter
     */
    public String getToAmountFilter() {
        return toAmountFilter;
    }

    /**
     * @param toAmountFilter
     *            the toAmountFilter to set
     */
    public void setToAmountFilter(final String toAmountFilter) {
        this.toAmountFilter = toAmountFilter;
    }


}
