package com.hsbc.digital.testauto.pageobject.ca;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.AddBeneficiaryDetails;
import com.hsbc.digital.testauto.models.BankDetails;
import com.hsbc.digital.testauto.pageobject.AddBeneficiaryModel;

public class AddBeneficiary extends com.hsbc.digital.testauto.pageobject.AddBeneficiaryModel {
    private final WebDriverWait wait;
    private final JavascriptExecutor jsx;

    /**
     * Web Elements for story-40-Add beneficiary- CANADA---------Starts
     */

    /**
     * Field Label on Verify page
     */
    private static final String SCROLL_TO_VIEW = "arguments[0].scrollIntoView(true);";
    private static final String LABEL_PAYEENAME = "Payee name";
    private static final String LABEL_BANK_COUNTRY = "Bank country";
    private static final String LABEL_ACCOUNT_TYPE = "Account type";
    private static final String LABEL_ACC_NUMBER = "Account number";
    private static final String Label_INTERNATIONAL_ACC_NUMBER = "Account number";
    private static final String LABEL_ACC_CURRENCY = "Account currency";
    private static final String LABEL_BANK_NAME = "Bank name";
    private static final String LABEL_PAYEE_ADDRESS = "Address line 1";
    private static final String LABEL_BANK_CITY = "Bank city";
    private static final String LABEL_BANK_CODE = "Bank code";
    private static final String LABEL_BANK_ADDRESS = "Bank Address";
    private static final String SUCESS_MSG = "Your new payee has been added";
    private static final String BANK_COUNTRY = "Canada";
    private static final String PAYEE_TYPE_HSBC = "HSBC Bank Account";
    private static final String PAYEE_TYPE_NONHSBC = "Other Local bank";
    private static final String PAYEE_TYPE_COMPANY = "COMPANY PAYEE";
    private static final String LABEL_COMPANYNAME = "Company Name";
    private static final String LABEL_COMPANY_REFERENCE = "Company reference";

    @FindBy(xpath = ".//input[starts-with(@id,'accountNumberInput_group_gpib_mvmny_bijit_Add') and @data-dojo-attach-point='textbox,focusNode']")
    protected WebElement domAccountNumberField;

    protected final By locatorPayeeName = By.xpath(".//td[contains(@class, 'payeeName')]/strong");

    @FindBy(xpath = ".//*[starts-with(@id,'dijit_form_Button')and text()='Next to personal details']")
    private WebElement addPayeeDetailsBtn;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='_payeeAddress1Field']//input[@id='group_gpib_mvmny_bijit_AddPersonStandaloneNew_0_payeeAddress1']")
    private WebElement payeeAddress1;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='_payeeAddress2Field']//input[@id='group_gpib_mvmny_bijit_AddPersonStandaloneNew_0_payeeAddress2']")
    private WebElement payeeAddress2;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='_payeeAddress3Field']//input[@id='group_gpib_mvmny_bijit_AddPersonStandaloneNew_0_payeeAddress3']")
    private WebElement payeeAddress3;


    @FindBy(xpath = ".//div[starts-with(@id,'hdx_bijits_mvmny_bijit_AddPayeeVerifyDialog') and @role='dialog']")
    private WebElement reviewDialog;

    @FindBy(xpath = "//div[contains(@id, 'Verify')]")
    private WebElement verifyPage;

    @FindBy(xpath = ".//div[@class='alertPanel confirmation']//p")
    private WebElement confirmPayeeMsg;

    @FindBy(xpath = ".//button[@data-dojo-attach-point='continueButton' and  @type='button']")
    private WebElement confirmButton;

    @FindBy(xpath = ".//button[@data-dojo-attach-point='closeButton' and  @type='button']")
    private WebElement closeBtn;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='companyLabel']")
    protected WebElement addNewCompanyPayeeBtn;

    @FindBy(xpath = "//div[@id='PayeeForm']//h2[contains(@class, 'managePayeesTitle')]")
    protected WebElement payeePageTitle;


    @FindBy(xpath = ".//div[contains(@id,'verifyDeleteInteracPayee') and contains(@class,'dijitDialogFixed')]")
    WebElement delPayeeDialog;


    @FindBy(xpath = ".//div[contains(@class,'submitButtonsPanel ')]//button[contains(@data-dojo-attach-point,'_closePanelBtn')]")
    protected WebElement closeBut;

    @FindBy(xpath = ".//div[contains(@class,'formSpacer ')]//span[contains(@data-dojo-attach-point,'_payeeName')]")
    private WebElement payeeNameOnDialog;

    @FindBy(xpath = ".//div[contains(@class,'confirmDeleteDialog')]//div[contains(@class,'formSpacer ')]//span[contains(@data-dojo-attach-point,'_payeeName')]")
    private WebElement deletedPayeeName;

    private final By cancelBtnOnDialog = By.xpath(".//button[@class='btnTertiary' and @data-dojo-attach-point='_cancelBtn']");
    private final By deletBtnOnDialog = By.xpath(".//button[@class='btnPrimary' and @data-dojo-attach-point='_confirmBtn']");

    private final By emailField = By.xpath(".//li[contains(@data-dojo-attach-point,'_emailLi')]//dt");
    private final By emailvalue = By.xpath(".//dd[contains(@data-dojo-attach-point,'_emailAddress')]");
    private final By notifyPayeeByValue = By.xpath(".//dd[contains(@data-dojo-attach-point,'_notifypayee')]");
    private final By notifyPayeeByField = By.xpath(".//li[contains(@data-dojo-attach-point,'_notifyByLi')]//dt");

    private final By languageValue = By.xpath(".//dd[contains(@data-dojo-attach-point,'_language')]");
    private final By languageField = By.xpath(".//li[contains(@data-dojo-attach-point,'_languageLi')]//dt");

    private final By securityQuestionValue = By.xpath(".//dd[contains(@data-dojo-attach-point,'_secQuestion')]");
    private final By securityQuestionField = By.xpath(".//li[contains(@data-dojo-attach-point,'_seqQueLi')]//dt");

    private final By closeButton = By.xpath(".//button[@data-dojo-attach-point='_closeNode']");
    /**
     * Locators for Field label and Field value on Review dialog
     */
    private final By locatorVerifyPageFieldValue = By.xpath("//following-sibling::div[contains(@class, 'itemValue')]");

    private final By locatorVerifyPageFieldName = By.xpath("//div[contains(@id, 'Verify')]//div[contains(@class, 'itemLabel')]");

    private final By localCurrencyLocator = By.xpath(".//div[contains(text(),'Canadian Dollar')]");


    public AddBeneficiary(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30000);
        jsx = (JavascriptExecutor) driver;
    }

    @Override
    public int addCompanyPayee() {
        wait.until(ExpectedConditions.elementToBeClickable(newPayeeTab));
        newPayeeTab.click();
        wait.until(ExpectedConditions.elementToBeClickable(addNewCompanyPayeeBtn));
        addNewCompanyPayeeBtn.click();
        Reporter.log("Company  payee button selected");
        return getAllpayeesCount();
    }

    @Override
    public String enterHSBCPayeeName() {
        return enterPayeeName();
    }

    /**
     * This method enters the HSBC payee Bank details like account number and
     * account currency
     */
    @Override
    public BankDetails enterHSBCBankDetails(final String accountNumber) {
        BankDetails bankDetails = new BankDetails();
        bankDetails.setBankCntry(AddBeneficiary.BANK_COUNTRY);
        bankDetails.setAccountCCY(selectCurrency(true));
        enterDomesticAccountNumber(accountNumber);
        bankDetails.setAccountNumber(accountNumber);
        return bankDetails;
    }

    /**
     * This method randomly select the Account currency
     * 
     * @param element
     *            : Currency List
     */
    @Override
    public String selectCurrency(final boolean isLocalCurrency) {
        String selectedCurrency;
        currencyListDropDownIcon.click();
        wait.until(ExpectedConditions.visibilityOf(currencyList));
        List<WebElement> currencyRows = driver.findElements(currencyLocator);
        if (!isLocalCurrency) {
            int randomValue = RandomUtil.generateIntNumber(0, currencyRows.size());
            WebElement currencyRow = currencyRows.get(randomValue);
            jsx.executeScript(AddBeneficiary.SCROLL_TO_VIEW, currencyRow);
            selectedCurrency = currencyRow.getText();
            currencyRow.click();
        } else {
            WebElement localCCY = currencyList.findElement(localCurrencyLocator);
            jsx.executeScript(AddBeneficiary.SCROLL_TO_VIEW, localCCY);
            selectedCurrency = localCCY.getText();
            localCCY.click();

        }
        Reporter.log("Currency selected is " + selectedCurrency);
        return selectedCurrency;
    }

    /**
     * This method populates Other Local bank Payee details like account number
     * Randomly generates valid account number for NON HSBC bank payee. And
     * populates in Account number field
     * 
     * @return : Account number
     */
    @Override
    public BankDetails enterNonHSBCBankDetails(final String searchText) {
        BankDetails objBankDetails = new BankDetails();
        objBankDetails.setBankName(selectOtherLocalBank(searchText, localBankNameList));
        String accountNum = RandomUtil.generateIntNumber(10);
        enterDomesticAccountNumber(accountNum);
        objBankDetails.setAccountNumber(accountNum);
        objBankDetails.setBankCntry(AddBeneficiary.BANK_COUNTRY);
        Reporter.log("Account number entered is :" + accountNum);
        return objBankDetails;
    }

    /**
     * This method enters the domestic HSBC or NON HSBC Bank (Other Local bank)
     * account number
     * 
     * @param accountNumber
     *            : Account number to be populated
     */
    @Override
    public void enterDomesticAccountNumber(final String accountNumber) {
        domAccountNumberField.click();
        domAccountNumberField.clear();
        domAccountNumberField.sendKeys(accountNumber);
        Reporter.log("Account Number Entered for new payee :" + accountNumber);

    }

    /**
     * This method randomly select the Local Bank name from Bank Drop down list
     * 
     * @param element
     *            : Bank/Bank Branch List
     */
    @Override
    public String selectOtherLocalBank(final String text, final WebElement element) {
        // serach character is not required for Canada
        localBankNameListDropdownIcon.click();
        wait.until(ExpectedConditions.visibilityOf(element));
        List<WebElement> listings = element.findElements(otherLocalBankLocator);
        int randomValue = RandomUtil.generateIntNumber(0, listings.size());
        WebElement bankSelected = listings.get(randomValue);// Clicking on the
        jsx.executeScript(AddBeneficiary.SCROLL_TO_VIEW, bankSelected);
        bankSelected.click();
        return bankSelected.getText();

    }

    /**
     * This method enters the Payee Address details
     * 
     * @param obj
     *            : AddBeneficiary JAVA object populate payee address fields
     */
    @Override
    public String enterPayeeAddressDetails() {
        String addLine1 = RandomUtil.generateAlphaNumericText(10);
        String addLine2 = RandomUtil.generateAlphaNumericText(10);
        String addLine3 = RandomUtil.generateAlphaNumericText(10);
        payeeAddress1.clear();
        payeeAddress1.sendKeys(addLine1);
        payeeAddress2.clear();
        payeeAddress2.sendKeys(addLine2);
        payeeAddress3.clear();
        payeeAddress3.sendKeys(addLine3);
        return addLine1 + "::" + addLine2 + "::" + addLine3;
    }

    /**
     * This method review the Payee details on Review dialog box
     */
    @Override
    public void verifyPayeeReviewPage(final AddBeneficiaryDetails addBeneficiaryDetails) {
        if (addBeneficiaryDetails.getAccountType().equalsIgnoreCase(AddBeneficiary.PAYEE_TYPE_HSBC)
            && addBeneficiaryDetails.getBankDetails().getBankCntry().equalsIgnoreCase(AddBeneficiary.BANK_COUNTRY)) {
            verifyHSBCBankPayeeReviewPage(addBeneficiaryDetails);
        } else if (addBeneficiaryDetails.getAccountType().equalsIgnoreCase(AddBeneficiary.PAYEE_TYPE_NONHSBC)
            && (addBeneficiaryDetails.getBankDetails().getBankCntry().equalsIgnoreCase(AddBeneficiary.BANK_COUNTRY))) {
            verifyOtherLocalbankPayeeReviewPage(addBeneficiaryDetails);
        } else if (!(addBeneficiaryDetails.getBankDetails().getBankCntry().equalsIgnoreCase(AddBeneficiary.BANK_COUNTRY))
            && (addBeneficiaryDetails.getBankDetails().getBankCode() == null)) {
            verifyInternationalPayeeReviewPage(addBeneficiaryDetails);
        } else if (addBeneficiaryDetails.getAccountType().equalsIgnoreCase(AddBeneficiary.PAYEE_TYPE_COMPANY)) {
            verifyCompanyPayeeReviewPage(addBeneficiaryDetails);
        } else {
            verifyOtherCityInternationalPayeeReviewPage(addBeneficiaryDetails);
        }
    }

    /**
     * This method verifies the field label and Field Values correctly
     * displayed on Review page for HSBC bank payee
     */
    public void verifyHSBCBankPayeeReviewPage(final AddBeneficiaryDetails addBeneficiaryDetails) {
        wait.until(ExpectedConditions.visibilityOf(reviewDialog));
        reviewDialog.isDisplayed();
        isPayeeNameDisplayed(AddBeneficiary.LABEL_PAYEENAME, addBeneficiaryDetails.getPayeeName());
        isBankCountryDisplayed(AddBeneficiary.LABEL_BANK_COUNTRY, addBeneficiaryDetails.getBankDetails().getBankCntry());
        isAccountTypeDisplayed(AddBeneficiary.LABEL_ACCOUNT_TYPE, addBeneficiaryDetails.getAccountType());
        isAccountNumberDisplayed(AddBeneficiary.LABEL_ACC_NUMBER, addBeneficiaryDetails.getBankDetails().getAccountNumber());
        isAccountCCYDispalyed(AddBeneficiary.LABEL_ACC_CURRENCY, addBeneficiaryDetails.getBankDetails().getAccountCCY());
        Reporter.log("HSBC  bank payee details  Details verified on Verify Page.");
    }

    /**
     * This method verifies the field label and Field Values correctly
     * displayed on Review page for NON HSBC BANK payee
     */
    public void verifyOtherLocalbankPayeeReviewPage(final AddBeneficiaryDetails addBeneficiaryDetails) {
        wait.until(ExpectedConditions.visibilityOf(reviewDialog));
        reviewDialog.isDisplayed();
        isPayeeNameDisplayed(AddBeneficiary.LABEL_PAYEENAME, addBeneficiaryDetails.getPayeeName());
        isBankCountryDisplayed(AddBeneficiary.LABEL_BANK_COUNTRY, addBeneficiaryDetails.getBankDetails().getBankCntry());
        isAccountTypeDisplayed(AddBeneficiary.LABEL_ACCOUNT_TYPE, addBeneficiaryDetails.getAccountType());
        isBankNameDisplayed(AddBeneficiary.LABEL_BANK_NAME, addBeneficiaryDetails.getBankDetails().getBankName());
        isAccountNumberDisplayed(AddBeneficiary.LABEL_ACC_NUMBER, addBeneficiaryDetails.getBankDetails().getAccountNumber());
        isPayeeAddressDisplayed(AddBeneficiary.LABEL_PAYEE_ADDRESS, addBeneficiaryDetails.getPayeeAddress1());
        Reporter.log("Other LOcal  bank payee details  Details verified on Verify Page.");
    }

    /**
     * This method verifies the field label and Field Values correctly
     * displayed on Review page for International Payee
     */
    public void verifyInternationalPayeeReviewPage(final AddBeneficiaryDetails addBeneficiaryDetails) {
        wait.until(ExpectedConditions.visibilityOf(reviewDialog));
        reviewDialog.isDisplayed();
        isPayeeNameDisplayed(AddBeneficiary.LABEL_PAYEENAME, addBeneficiaryDetails.getPayeeName());
        isBankCountryDisplayed(AddBeneficiary.LABEL_BANK_COUNTRY, addBeneficiaryDetails.getBankDetails().getBankCntry());
        isBankCityDisplayed(AddBeneficiary.LABEL_BANK_CITY, addBeneficiaryDetails.getBankDetails().getBankCity());
        isBankNameDisplayed(AddBeneficiary.LABEL_BANK_NAME, addBeneficiaryDetails.getBankDetails().getBankName());
        isAccountNumberDisplayed(AddBeneficiary.Label_INTERNATIONAL_ACC_NUMBER, addBeneficiaryDetails.getBankDetails()
            .getAccountNumber());
        isPayeeAddressDisplayed(AddBeneficiary.LABEL_PAYEE_ADDRESS, addBeneficiaryDetails.getPayeeAddress1());
        Reporter.log("International   bank payee details  Details verified on Verify Page.");
    }

    /**
     * This method verifies the field label and Field Values correctly
     * displayed on Review page for Other Bank/City International Payee
     */
    public void verifyOtherCityInternationalPayeeReviewPage(final AddBeneficiaryDetails addBeneficiaryDetails) {
        wait.until(ExpectedConditions.visibilityOf(reviewDialog));
        reviewDialog.isDisplayed();
        isPayeeNameDisplayed(AddBeneficiary.LABEL_PAYEENAME, addBeneficiaryDetails.getPayeeName());
        isBankCountryDisplayed(AddBeneficiary.LABEL_BANK_COUNTRY, addBeneficiaryDetails.getBankDetails().getBankCntry());
        isAccountNumberDisplayed(AddBeneficiary.Label_INTERNATIONAL_ACC_NUMBER, addBeneficiaryDetails.getBankDetails()
            .getAccountNumber());
        isBankNameDisplayed(AddBeneficiary.LABEL_BANK_NAME, addBeneficiaryDetails.getBankDetails().getBankName());
        isBankAddDisplayed(AddBeneficiary.LABEL_BANK_ADDRESS, addBeneficiaryDetails.getBankDetails().getBankAddress1());
        isBankCodeDisplayed(AddBeneficiary.LABEL_BANK_CODE, addBeneficiaryDetails.getBankDetails().getBankCode());
        isPayeeAddressDisplayed(AddBeneficiary.LABEL_PAYEE_ADDRESS, addBeneficiaryDetails.getPayeeAddress1());
        Reporter.log("Other country/City international  bank payee details  Details verified on Verify Page.");
    }

    public void verifyCompanyPayeeReviewPage(final AddBeneficiaryDetails addBeneficiaryDetails) {
        wait.until(ExpectedConditions.visibilityOf(reviewDialog));
        reviewDialog.isDisplayed();
        isPayeeNameDisplayed(AddBeneficiary.LABEL_COMPANYNAME, addBeneficiaryDetails.getPayeeName());
        isAccountNumberDisplayed(AddBeneficiary.LABEL_COMPANY_REFERENCE, addBeneficiaryDetails.getBankDetails().getAccountNumber());
    }

    /**
     * This method validates if payee Name Label and value on review page is
     * correct
     * 
     * @param fieldName
     *            : Payee Name
     * @param fieldValue
     *            : payee Name value
     */
    public void isPayeeNameDisplayed(final String fieldName, final String fieldValue) {
        Assert.assertTrue(textByParentAndSibling(fieldName, fieldValue), "Given Payee Name not found.");
        Reporter.log("From Payee Name displayed is :" + fieldValue);
    }

    /**
     * This method validates if Bank Country Label and value on review page is
     * correct
     * 
     * @param fieldName
     *            : Bank Country
     * @param fieldValue
     *            :Bank Country value
     */
    public void isBankCountryDisplayed(final String fieldName, final String fieldValue) {
        Assert.assertTrue(textByParentAndSibling(fieldName, fieldValue), "Given Bank Country  not found.");
        Reporter.log("From Bank Country displayed is :" + fieldValue);
    }

    /**
     * This method validates if Payee Type Label and value on review page is
     * correct
     * 
     * @param fieldName
     *            : Payee Type
     * @param fieldValue
     *            :Payee Type value
     */
    public void isAccountTypeDisplayed(final String fieldName, final String fieldValue) {
        Assert.assertTrue(textByParentAndSibling(fieldName, fieldValue), "Given Payee Type not found.");
        Reporter.log("From Payee Type displayed is :" + fieldValue);
    }

    /**
     * This method validates if Account number Label and value on review page
     * is correct
     * 
     * @param fieldName
     *            : Account number
     * @param fieldValue
     *            :Account number value
     */
    public void isAccountNumberDisplayed(final String fieldName, final String fieldValue) {
        Assert.assertTrue(textByParentAndSibling(fieldName, fieldValue), "Given Account Number not found.");
        Reporter.log("From Account Number displayed is :" + fieldValue);
    }

    /**
     * This method validates if Account Currency Label and value on review page
     * is correct
     * 
     * @param fieldName
     *            : Account Currency
     * @param fieldValue
     *            :Account Currency value
     */
    public void isAccountCCYDispalyed(final String fieldName, final String fieldValue) {
        Assert.assertTrue(textByParentAndSibling(fieldName, fieldValue), "Given Account Currency not found.");
        Reporter.log("From Account Currency displayed is :" + fieldValue);
    }

    /**
     * This method validates if BANK Name Label and value on review page is
     * correct
     * 
     * @param fieldName
     *            : BANK Name
     * @param fieldValue
     *            :BANK Name value
     */
    public void isBankNameDisplayed(final String fieldName, final String fieldValue) {
        Assert.assertTrue(textByParentAndSibling(fieldName, fieldValue), "Given BANK Name not found.");
        Reporter.log("From BANK Name displayed is :" + fieldValue);
    }

    /**
     * This method validates if payee address Label and value on review page is
     * correct
     * 
     * @param fieldName
     *            : payee address
     * @param fieldValue
     *            :payee address value
     */
    public void isPayeeAddressDisplayed(final String fieldName, final String fieldValue) {
        Assert.assertTrue(textByParentAndSibling(fieldName, fieldValue), "Given Payee Address  not found.");
        Reporter.log("From payee address displayed is :" + fieldValue);
    }

    /**
     * This method validates if BANK City Label and value on review page is
     * correct
     * 
     * @param fieldName
     *            : BANK City
     * @param fieldValue
     *            :BANK City value
     */
    public void isBankCityDisplayed(final String fieldName, final String fieldValue) {
        Assert.assertTrue(textByParentAndSibling(fieldName, fieldValue), "Given  Bank city  not found.");
        Reporter.log("From BANK City displayed is :" + fieldValue);
    }

    /**
     * This method validates if BANK code Label and value on review page is
     * correct
     * 
     * @param fieldName
     *            : BANK code
     * @param fieldValue
     *            :BANK code value
     */
    public void isBankCodeDisplayed(final String fieldName, final String fieldValue) {
        Assert.assertTrue(textByParentAndSibling(fieldName, fieldValue), "Given Bank code  not found.");
        Reporter.log("From BANK code displayed is :" + fieldValue);
    }

    /**
     * This method validates if BANK address Label and value on review page is
     * correct
     * 
     * @param fieldName
     *            : BANK address
     * @param fieldValue
     *            :BANK address value
     */
    public void isBankAddDisplayed(final String fieldName, final String fieldValue) {
        Assert.assertTrue(textByParentAndSibling(fieldName, fieldValue), "Given Bank Address  not found.");
        Reporter.log("From BANK address displayed is :" + fieldValue);
    }

    /**
     * Method to return true if text and its corresponding field match the
     * criteria user specifies else return false
     */
    public boolean textByParentAndSibling(final String fieldLabel, final String fieldValue) {
        boolean flag = false;
        List<WebElement> fieldLabels = verifyPage.findElements(locatorVerifyPageFieldName);
        for (WebElement elem : fieldLabels) {
            jsx.executeScript(AddBeneficiary.SCROLL_TO_VIEW, elem);
            if (elem.isDisplayed() && elem.getText().contains(fieldLabel)) {
                List<WebElement> valueElements = elem.findElements(locatorVerifyPageFieldValue);
                if (isValuePresent(valueElements, fieldValue)) {
                    flag = true;
                    break;
                }

            }
        }
        return flag;
    }

    /**
     * Method to return true if field value matches the expected field value
     */
    private boolean isValuePresent(final List<WebElement> valueElements, final String fieldValue) {
        boolean flag = false;
        for (WebElement elem : valueElements) {
            if (elem.isDisplayed() && elem.getText().contains(fieldValue)) {
                flag = true;
                break;
            }
        }
        return flag;
    }

    /**
     * This method verify success/fail message displayed on My Payees page on
     * completing the add New payee flow
     * 
     * @param payeeName
     *            : Newly added payee name
     */
    @Override
    public void verifySucessMessage(final AddBeneficiaryDetails obj) {
        wait.until(ExpectedConditions.visibilityOf(confirmPayeeMsg));
        Assert.assertTrue(AddBeneficiary.SUCESS_MSG.contains(confirmPayeeMsg.getText()), "Payee is not sucessfully added");
        Reporter.log("Payee " + obj.getPayeeName() + " is  sucessfully added");
    }

    @Override
    public void clickConfirmOnReviewPage() {
        confirmButton.isDisplayed();
        confirmButton.click();
        Reporter.log("Confirm Dbutton ids clicked");
    }

    /**
     * This method close the Add Payee confirm Dialog box
     */
    @Override
    public void closeConfirmDialog() {
        closeBtn.isDisplayed();
        closeBtn.click();
        Reporter.log("Confirm Dialog box is closed");
    }

    @Override
    public AccountDetails domesticHSBCPersonIELCYPayees(final String entityCurrency) {
        wait.until(ExpectedConditions.visibilityOf(payeePageTitle));
        return selectPersonIEPayeeFromPersonIEPayeeList(entityCurrency, true, true, true);
    }

    @Override
    public AccountDetails selectPersonIEPayeeFromPersonIEPayeeList(final String entityCurrency, final boolean domesticHSBCPayee,
        final boolean domesticAccount, final boolean domesticCurrency) {
        List<AccountDetails> payeeList = validPersonPayeeDetailsIETransfer(entityCurrency, domesticHSBCPayee, domesticAccount,
            domesticCurrency);
        int index = RandomUtil.generateIntNumber(AddBeneficiaryModel.DEFAULT_LIST_STARTING_INDEX, payeeList.size());
        Assert.assertTrue(index >= AddBeneficiaryModel.DEFAULT_LIST_STARTING_INDEX, "No Payees found.");
        return payeeList.get(index);
    }


    @Override
    protected List<AccountDetails> validPersonPayeeDetailsIETransfer(final String entityCurrency, final boolean domesticHSBCPayee,
        final boolean domesticAccount, final boolean domesticCurrency) {
        List<AccountDetails> storeAccountValue = new ArrayList<>();
        List<WebElement> payeeList = driver.findElements(locatorAllPayeesRow);
        for (WebElement payee : payeeList) {
            jsx.executeScript(AddBeneficiaryModel.SCROLL_TO_VIEW, payee);
            if (payee.findElement(locatorPayeeType).getAttribute("alt").equalsIgnoreCase(AddBeneficiaryModel.PERSON_PAYEE)) {
                String personPayeeName = payee.findElement(locatorPayeeName).getText();
                WebElement btnView = payee.findElement(locatorViewPayee);
                wait.until(ExpectedConditions.elementToBeClickable(btnView));
                btnView.click();
                wait.until(ExpectedConditions.visibilityOf(payee.findElement(locatorManagePerson)));
                AccountDetails accountDetails = addPayeeAccountInformation_new(personPayeeName);
                storeAccountValue.add(accountDetails);
            }
        }
        return storeAccountValue;
    }

    @Override
    protected AccountDetails addPayeeAccountInformation_new(final String personPayeeName) {
        AccountDetails accountInformations = new AccountDetails();
        accountInformations.setAccountName(personPayeeName);
        return accountInformations;
    }

    @Override
    public WebElement selectPayee() {
        List<WebElement> allPayeeRows = allPayeesTable.findElements(By.tagName("tr"));
        int randomValue = RandomUtil.generateIntNumber(0, allPayeeRows.size());
        WebElement payeeSelected = allPayeeRows.get(randomValue);
        Actions builder = new Actions(driver);
        builder.moveToElement(payeeSelected).build().perform();
        Reporter.log("Payee selected  is " + payeeSelected.getText());
        return payeeSelected;
    }

    @Override
    public void cancelDeletePayee(final WebElement payeeRow) {
        String displayName = payeeRow.findElement(payeeName).getText();
        WebElement deleteBtn = payeeRow.findElement(deleteButton);
        deleteBtn.isEnabled();
        deleteBtn.click();
        wait.until(ExpectedConditions.visibilityOf(delPayeeDialog));
        if (displayName.equalsIgnoreCase(getPayeeNameOnDialog().getText())) {
            Reporter.log("Payee Name is present on delete popup");
        } else {
            Reporter.log("Payee Name is not present on delete popup");
        }
        delPayeeDialog.findElement(cancelBtnOnDialog).click();
        wait.until(ExpectedConditions.not(ExpectedConditions.visibilityOf(delPayeeDialog)));
        Reporter.log("Delete Payee flow is Cancelled");
    }


    public void clickcloseButton() {
        wait.until(ExpectedConditions.elementToBeClickable(closeBut));
        closeBut.click();
        Reporter.log("Close button is clicked.");
    }

    @Override
    public void deletePayee(final WebElement element) {
        String displayName = element.findElement(payeeName).getText();
        int beforeCnt = getAllpayeesCount();
        WebElement button = element.findElement(deleteButton);
        button.isEnabled();
        button.click();
        wait.until(ExpectedConditions.visibilityOf(delPayeeDialog));
        if (displayName.equalsIgnoreCase(getPayeeNameOnDialog().getText())) {
            Reporter.log("Payee Name is  present on delete popup");
        } else {
            Reporter.log("Payee Name is not present on delete popup");
        }
        delPayeeDialog.findElement(deletBtnOnDialog).isEnabled();
        delPayeeDialog.findElement(deletBtnOnDialog).click();
        wait.until(ExpectedConditions.visibilityOf(sucessMsg));
        if (displayName.equalsIgnoreCase(deletedPayeeName.getText())) {
            Reporter.log("Payee Name is  present on delete popup");
        } else {
            Reporter.log("Payee Name is not present on delete popup");
        }
        Reporter.log("Payee Name " + deletedPayeeName.getText() + "is  present in sucess message");
        clickcloseButton();
        Assert.assertTrue(getAllpayeesCount() == beforeCnt - 1, "All Payees count is NOT updated");
        Reporter.log("All Payees count is decremented:" + getAllpayeesCount());
    }


    @Override
    public void verifyPayeeDetails(final WebElement payeeRow) {
        wait.until(ExpectedConditions.visibilityOf(payeePageTitle));
        String payeeType = payeeRow.findElement(locatorPayeeType).getAttribute("alt");
        List<WebElement> country = payeeRow.findElements(payeeCountry);
        if (payeeType.equalsIgnoreCase(AddBeneficiaryModel.COMPANY_PAYEE) && !country.isEmpty()) {
            Reporter.log("Selected Payee is Company payee");
            verifyCompanyPayeeDetails(payeeRow);
        } else if (payeeType.equalsIgnoreCase(AddBeneficiaryModel.PERSON_PAYEE) && !country.isEmpty()) {
            Reporter.log("Selected Payee is Interact Transfer bank payee");
            verifyHSBCPersoPayeeDetails(payeeRow);
        } else {
            verifyPersonPayeeDetails(payeeRow);
            Reporter.log("Selected Payee is  NON HSBC Bank  payee");
        }
    }

    /**
     * This method verify HSBC bank Payee details displayed when View button is
     * clicked
     * 
     * @param payeeName
     */
    @Override
    public void verifyHSBCPersoPayeeDetails(final WebElement element) {
        String displayName = element.findElement(payeeName).getText();
        WebElement viewButtonElement = element.findElement(viewButton);
        viewButtonElement.isEnabled();
        viewButtonElement.click();
        wait.until(ExpectedConditions.visibilityOf(personPayeeDetailsView));
        String name = verifyPayeeNameField(personPayeeDetailsView, LABEL_PAYEE_NAME);
        Assert.assertTrue(displayName.equals(name), "Person payee name is NOT  matched in Details pane");
        verifyField(personPayeeDetailsView, notifyPayeeByField, notifyPayeeByValue);
        verifyField(personPayeeDetailsView, emailField, emailvalue);
        verifyField(personPayeeDetailsView, languageField, languageValue);
        verifyField(personPayeeDetailsView, securityQuestionField, securityQuestionValue);
        personPayeeDetailsView.findElement(closeButton).click();
    }

    @Override
    protected WebElement getPayeeNameOnDialog() {
        return payeeNameOnDialog;
    }
}
