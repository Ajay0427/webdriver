/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.uk;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.pageobject.UpdatePersonelInformationModel;

/**
 * <p>
 * <b> Contains locators and functions for Story - Update Personal Information
 * for UK entity </b>
 * </p>
 */
public class UpdatePersonelInformation extends UpdatePersonelInformationModel {

    /* Locators for Capture Page */

    @FindBy(xpath = "//div[contains(@id,'content')]//h1")
    private WebElement capturePageHeadingOnCapturePage;

    @FindBy(xpath = "//div[contains(@class,'extPibRow hsbcRow')]/h3")
    private WebElement pageHeadingOnCapturePage;

    @FindBy(xpath = "//select[contains(@id,'maritalStatus')]")
    private WebElement dropDownButtonForFieldMaritalStatus;

    @FindBy(xpath = "//input[contains(@id,'salutation')]")
    private WebElement onlineGreetingFieldOnCapturePage;

    @FindBy(xpath = "//select[contains(@id,'maritalStatus')]//option")
    private WebElement dropDownContentForFieldMaritalStatus;

    @FindBy(xpath = "//input[contains(@id,'noChildren')]")
    private WebElement noOfDependentOnCapturePage;

    @FindBy(xpath = "//input[contains(@id,'eMailAddress')]")
    private WebElement emailAddressOnCapturePage;

    @FindBy(xpath = "//div[contains(@class,'hsbcButtonCenter')]/a[contains(text(),'Confirm')]")
    private WebElement confirmButtonOnCapturePage;

    private final By maritalStatus = By.xpath("//select[@id='maritalStatus']");

    public UpdatePersonelInformation(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }


    @Override
    public void clickOnConfirmButtonOnCapturePage() {
        confirmButtonOnCapturePage.click();
        Reporter.log("Confirm button on the capture page is clicked successfully");
    }

    @Override
    public void capturePageHeadingDisplayed() {
        Assert.assertTrue(capturePageHeadingOnCapturePage.isDisplayed(), "Heading on capture page not displayed.");
    }

    @Override
    public String enterOnlineGreetingField() {
        onlineGreetingFieldOnCapturePage.click();
        onlineGreetingFieldOnCapturePage.clear();
        String random = RandomUtil.generateAlphabatic(25);
        onlineGreetingFieldOnCapturePage.sendKeys(random);
        Reporter.log("Online greeting field is inputed as : " + random);
        return random;
    }

    @Override
    public String enterNoOfDependentField() {
        noOfDependentOnCapturePage.click();
        noOfDependentOnCapturePage.clear();
        String randomNoOfDependent = Integer.toString(RandomUtil.generateIntNumber(1, 99));
        noOfDependentOnCapturePage.sendKeys(randomNoOfDependent);
        Reporter.log("No of dependent field is inputed as : " + randomNoOfDependent);
        return randomNoOfDependent;
    }

    @Override
    public String enterEmailAddress() {
        emailAddressOnCapturePage.click();
        emailAddressOnCapturePage.clear();
        String randomEmail = RandomUtil.generateAlphabatic(5) + "@gmail.com";
        emailAddressOnCapturePage.sendKeys(randomEmail);
        Reporter.log("Email field is inputed as : " + randomEmail);
        return randomEmail;

    }

    @Override
    public void enterInvalidEmailAddress() {
        emailAddressOnCapturePage.click();
        emailAddressOnCapturePage.clear();
        String randomEmail = RandomUtil.generateAlphabatic(5);
        emailAddressOnCapturePage.sendKeys(randomEmail);
        Reporter.log("Email field is inputed as : " + randomEmail);

    }

    @Override
    public void pageHeadingDisplayedOnCapturePage() {
        Assert.assertTrue(pageHeadingOnCapturePage.isDisplayed(), "Page Heading is not displayed on capture page.");
    }

    @Override
    public String enterMaritalStatus() {
        Select select = new Select(driver.findElement(maritalStatus));
        select.selectByIndex(RandomUtil.generateIntNumber(0, select.getOptions().size()));
        return select.getFirstSelectedOption().getText();
    }

}
