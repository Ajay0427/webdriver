/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.digital.testauto.pageobject;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;

/**
 * <p>
 * <b> This Model class will hold locators and functionality related methods
 * for Story Order Cheque Book Capture Page that can be used around all
 * entities </b>
 * </p>
 * 
 * @version 1.0.0
 * @author Deepti Patil
 * 
 */

public abstract class OrderChequeBookCapturePageModel {

    protected final WebDriver driver;

    // Locator for list of Accounts in Account Summary Section
    @FindBy(xpath = "//div[contains(@id,'TitlePane')]/span[@isgspentity='yes']")
    protected List<WebElement> accountsLists;

    // Locator for Manage button on overview section
    @FindBy(xpath = "//button[contains(@class,'manage')]")
    protected List<WebElement> manageButtonList;

    // Locator for Dashboard Page Heading Title
    @FindBy(xpath = "//div[@id='_dashboardHeading']//span[@class='title']")
    protected WebElement dashboradHeading;

    // Locator for Dashboard Page Heading Title
    @FindBy(xpath = "//div[@class='managePanelOpen']//a[text()='Order check book']")
    protected List<WebElement> orderChequesLink;

    // Locator for Dormant Account
    @FindBy(xpath = "//span[@class='dormant']")
    protected List<WebElement> dormantAccount;

    /********************** Locators on Capture Page ******************************/
    // Locator for order cheque book page heading
    @FindBy(xpath = "//div[@id='orderChequeBookId']//h2")
    protected WebElement orderChequeBookCapturePage;

    // Locator for applicable accounts to order cheque book
    @FindBy(xpath = "//td[contains(@id,'MenuItem') and contains(@id,'text')]")
    private List<WebElement> applicableAccountsList;

    // Locator for account drop down button
    @FindBy(xpath = "//div[contains(@class,'orderChequeBookAccount')]//td[contains(@class,'DownArrowButton')]")
    private WebElement accountDropDownButton;

    // Locator for number Of Cheques drop down button
    @FindBy(xpath = "//table[contains(@id,'numberOfBook')]//td[contains(@class,'ArrowButton')]")
    private WebElement numberOfChequesDropDownButton;

    // Locator for number Of Cheques books List
    @FindBy(xpath = "//div[contains(@id,'numberOfBook')]//td[contains(@id,'MenuItem') and contains(@id,'text')]")
    protected List<WebElement> numberOfChequeBookList;

    // Locator for Continue button
    @FindBy(xpath = "//button[text()='Continue']")
    private WebElement continueButton;

    // Locator for Cancel button
    @FindBy(xpath = "//div[@data-dojo-attach-point='_editOrderContentPane']//button[text()='Cancel']")
    private WebElement capturePageCancelButton;

    // Locator for Cancel button on Cancel dialog box
    @FindBy(xpath = "//button[@data-dojo-attach-point='_editOrderCancelDialogYesBtn' and text()='Cancel']")
    private WebElement capturePageSecondaryCancelButton;

    // Locator for selected account
    @FindBy(xpath = "//table[contains(@id,'Select')]//div[contains(@class,'InputField')]")
    protected WebElement selectedAccount;

    // Locator for invalid Account Error Message
    @FindBy(xpath = "//div[@id='orderChequeBookId']//p[@data-dojo-attach-point='_errormsg']")
    private WebElement invalidAccountErrorMessage;

    // Locator for Cancel message on Cancel dialog box
    @FindBy(xpath = "//div[@data-dojo-attach-point='_editOrderCancelDialog']//p")
    private WebElement capturePageCancelMessage2;

    // Locator for Cancel message on Cancel dialog box
    @FindBy(xpath = "//h2[@data-dojo-attach-point='editOrderCancelDialogTitle']")
    private WebElement capturePageCancelMessage1;

    private static final int EXPECTED_MAX_NUMBER_OF_BOOKS = 2;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(OrderChequeBookCapturePageModel.class);

    public OrderChequeBookCapturePageModel(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void isOrderChequeCapturePageDisplayed() {}

    public void selectNumberOfChequeBooks() {}

    public void isDeliveryAddressDisplayed() {}

    public void selectNumberOfPages() {}

    public abstract AccountDetails setAccountDetails();

    public void verifyCapturePage() {
        isOrderChequeCapturePageDisplayed();
        clickContinueButton();
    }

    public AccountDetails selectAllDetails() {
        isOrderChequeCapturePageDisplayed();
        return selectDetailsOnCapturePage();
    }

    /**
     * Method to select details on capture page of order cheque book.
     * 
     * @return Account details
     * 
     */
    public AccountDetails selectDetailsOnCapturePage() {
        selectAccount();
        selectNumberOfChequeBooks();
        selectNumberOfPages();
        isDeliveryAddressDisplayed();
        AccountDetails accDetail = setAccountDetails();
        clickContinueButton();
        return accDetail;
    }

    /**
     * Method to select details on capture page of order cheque book for manage
     * flow.
     * 
     * @return Account details
     * 
     */
    public AccountDetails selectOtherDetailsOnCapturePage() {
        selectNumberOfChequeBooks();
        selectNumberOfPages();
        isDeliveryAddressDisplayed();
        AccountDetails accDetail = setAccountDetails();
        clickContinueButton();
        return accDetail;
    }

    /**
     * Method to select Account on capture page
     * 
     */
    public void selectAccount() {
        clickAccountDropDownButton();
        selectValues(applicableAccountsList);
        Reporter.log("Account Selected. ");
    }

    /**
     * Method to verify maximum number of cheque books that user can order.
     * 
     */
    public void verifyMaximumNumberOfChequeBooks() {
        Assert
            .assertTrue(
                Integer.parseInt(numberOfChequeBookList.get(numberOfChequeBookList.size() - 1).getText()) == EXPECTED_MAX_NUMBER_OF_BOOKS,
                "Maximum number of books in list is not as expected. ");
        Reporter.log("Maximum number of books in list is as expected. ");
    }

    /**
     * Method to select random value from a list
     * 
     * @param list
     *            of webElements
     * 
     */
    public void selectValues(final List<WebElement> list) {
        int index = RandomUtil.generateIntNumber(1, list.size());
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", list.get(index));
        list.get(index).click();
    }

    /**
     * Method to click on account selection drop down button on capture page.
     * 
     */
    public void clickAccountDropDownButton() {
        accountDropDownButton.click();
        Reporter.log("Accounts selection drop down button clicked. ");
    }

    /**
     * Method to click on continue button on capture page
     * 
     */
    public void clickContinueButton() {
        continueButton.click();
        Reporter.log("Continue button clicked. ");
    }

    /**
     * Method to click on cancel button on capture page.
     * 
     */
    public void clickCapturePageCancelButton() {
        capturePageCancelButton.click();
        Reporter.log("Cancel button on capture page clicked. ");
    }

    /**
     * Method to click on cancel button on capture page cancel dialog box.
     * 
     */
    public void clickCapturePageSecondaryCancelButton() {
        capturePageSecondaryCancelButton.click();
        Reporter.log("Cancel button clicked. ");
    }

    /**
     * Method to click on order cheque book link on manage tab.
     * 
     */
    public void clickOrderChequeBookLink() {
        orderChequesLink.get(0).click();
        Reporter.log("Order chequebook link clicked. ");
    }

    /**
     * Method to click on number of cheque books selection drop down button on
     * capture page.
     * 
     */
    public void clickNumberOfChequesDropDownButton() {
        numberOfChequesDropDownButton.click();
        Reporter.log("Number of Pages in Cheque Book selection drop down button clicked. ");
    }

    /**
     * Method to verify error message for invalid account.
     * 
     */
    public void isOrderChequeInvalidAccountMessageDisplayed() {
        Assert.assertTrue(invalidAccountErrorMessage.isDisplayed() && !invalidAccountErrorMessage.getText().isEmpty(),
            "Error Message is not displayed. ");
        Reporter.log("Error message for invalid account selection is displayed. ");
    }

    /**
     * Method to verify message on capture page cancel dialog box.
     * 
     */
    public void isCancelMessageOnCapturePageDisplayed() {
        Assert.assertTrue(capturePageCancelMessage1.isDisplayed() && capturePageCancelMessage2.isDisplayed()
            && !capturePageCancelMessage1.getText().isEmpty() && !capturePageCancelMessage2.getText().isEmpty(),
            "Cancel message on cancel dialog of Capture page is not displayed. ");
        Reporter.log("Cancel message on cancel dialog of Capture Page is displayed. ");
    }

    /**
     * Method to verify Dashboard Page is displayed.
     * 
     */
    public void isDashboardHeadingTitleDisplayed() {
        Assert.assertTrue(dashboradHeading.isDisplayed(), "Dashboard Page not displayed. ");
        Reporter.log("Dashboard Page displayed. ");
    }

    /**
     * Method to verify order cheque book link on manage tab is displayed.
     * 
     */
    public boolean isOrderChequeBookLinkDisplayed() {
        if (!orderChequesLink.isEmpty()) {
            Reporter.log("Order Cheque Book link in manage tab is displayed. ");
            return true;
        } else {
            return false;
        }
    }

    /**
     * Method to click on manage tab on overview section.
     * 
     */
    public void clickManageButton() {
        manageButtonList.get(0).click();
        Reporter.log("Manage button clicked. ");
    }

    /**
     * Method to verify invalid accounts for ordering a cheque book.
     * 
     */
    public void verifyInvalidAccounts() {}

    public void navigateToOrderChequeBookPageViaManage() {
        for (WebElement account : accountsLists) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", account);
            account.click();
            if (manageButtonList.isEmpty()) {
                Reporter.log("Manage button not displayed for the account. ");
            } else {
                clickManageButton();
                if (isOrderChequeBookLinkDisplayed()) {
                    clickOrderChequeBookLink();
                    isOrderChequeCapturePageDisplayed();
                    break;
                } else {
                    Reporter.log("Order cheque book not applicable for this account. ");
                }
            }
        }
    }

    /**
     * Method to verify flow for duplicate checkbook.
     * 
     * @param objAccountDetails
     */
    public void captureDetailsForDuplicateCheque(AccountDetails objAccountDetails) {}
}
