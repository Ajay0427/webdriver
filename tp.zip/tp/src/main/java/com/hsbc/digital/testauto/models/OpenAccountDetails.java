/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.models;


public class OpenAccountDetails {

    private String product;
    private String productName;
    private AccountDetails debitAccount;
    private AccountDetails creditAccount;
    private String termDuration;
    private String interestPaidInterval;
    private String currency;
    private Double selectedAmount;
    private String interestRate;
    private String interestAmount;
    private String maturityDate;
    private String newAccountNumber;
    private String investmentAccount;
    private String maturityInstruction;
    private String additionalOnlineRate;
    private String totalRate;
    private Boolean isTermInMonths;
    private String typeOfProduct;
    boolean isNewInvestmentAcct;

    private String debitAccountCbh;
    private String depositAmount;
    private String selectedResaon;
    private String createdAccount;

    public void setProduct(final String product) {
        this.product = product;
    }

    public String getProduct() {
        return product;
    }

    public void setProductName(final String productName) {
        this.productName = productName;
    }

    public String getProductName() {
        return productName;
    }

    public void setDebitAccount(final AccountDetails debitAccount) {
        this.debitAccount = debitAccount;
    }

    public AccountDetails getDebitAccount() {
        return debitAccount;
    }

    public void setCreditAccount(final AccountDetails creditAccount) {
        this.creditAccount = creditAccount;
    }

    public AccountDetails getCreditAccount() {
        return creditAccount;
    }

    public void setCurrency(final String currency) {
        this.currency = currency;
    }

    public String getCurrency() {
        return currency;
    }

    public void setAmount(final Double amount) {
        selectedAmount = amount;
    }

    public Double getAmount() {
        return selectedAmount;
    }

    public void setTermDuration(final String termDuration) {
        this.termDuration = termDuration;
    }

    public String getTermDuration() {
        return termDuration;
    }

    public void setInterestPaidInterval(final String interestPaidInterval) {
        this.interestPaidInterval = interestPaidInterval;
    }

    public String getInterestPaidInterval() {
        return interestPaidInterval;
    }

    public void setInterestRate(final String interestRate) {
        this.interestRate = interestRate;
    }

    public String getInterestRate() {
        return interestRate;
    }

    public void setInterestAmount(final String interestAmount) {
        this.interestAmount = interestAmount;
    }

    public String getInterestAmount() {
        return interestAmount;
    }

    public void setMaturityDate(final String maturityDate) {
        this.maturityDate = maturityDate;
    }

    public String getMaturityDate() {
        return maturityDate;
    }

    public void setNewAccountNumber(final String newAccountNumber) {
        this.newAccountNumber = newAccountNumber;
    }

    public String getNewAccountNumber() {
        return newAccountNumber;
    }

    public void setIsNewInvestmentAcct(boolean isNewInvestmentAcct) {
        this.isNewInvestmentAcct = isNewInvestmentAcct;
    }

    public Boolean getIsNewInvestmentAcct() {
        return isNewInvestmentAcct;
    }

    public void setInvestmentAccount(final String investmentAccount) {
        this.investmentAccount = investmentAccount;
    }

    public String getInvestmentAccount() {
        return investmentAccount;
    }

    public void setMaturityInstruction(final String maturityInstruction) {
        this.maturityInstruction = maturityInstruction;
    }

    public String getMaturityInstruction() {
        return maturityInstruction;
    }

    public void setAdditionalOnlineRate(final String additionalOnlineRate) {
        this.additionalOnlineRate = additionalOnlineRate;
    }

    public String getAdditionalOnlineRate() {
        return additionalOnlineRate;
    }

    public void setTotalRate(final String totalRate) {
        this.totalRate = totalRate;
    }

    public String getTotalRate() {
        return totalRate;
    }

    public void setIsTermInMonths(Boolean isTermInMonths) {
        this.isTermInMonths = isTermInMonths;
    }

    public Boolean getIsTermInMonths() {
        return isTermInMonths;
    }

    public void setTypeOfProduct(String typeOfProduct) {
        this.typeOfProduct = typeOfProduct;
    }

    public String getTypeOfProduct() {
        return typeOfProduct;
    }

    // getter setter for cbh

    public void setDebitAccount(final String debitAccountCbh) {
        this.debitAccountCbh = debitAccountCbh;
    }

    public String getDebitAccountCbh() {
        return debitAccountCbh;
    }

    public void setDepositAmount(final String depositAmount) {
        this.depositAmount = depositAmount;
    }

    public String getDepositAmount() {
        return depositAmount;
    }

    public void setReason(final String selectedResaon) {
        this.selectedResaon = selectedResaon;
    }

    public String getReason() {
        return selectedResaon;
    }

    public void setCreatedAccount(final String createdAccount) {
        this.createdAccount = createdAccount;
    }

    public String getCreatedAccount() {
        return createdAccount;
    }
}
