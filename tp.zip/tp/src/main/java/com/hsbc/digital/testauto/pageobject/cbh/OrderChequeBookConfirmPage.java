/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.cbh;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.pageobject.OrderChequeBookConfirmPageModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Order
 * Cheque Book for US entity. </b>
 * </p>
 */
public class OrderChequeBookConfirmPage extends OrderChequeBookConfirmPageModel {

    @FindBy(xpath = "//dd[@data-dojo-attach-point='_confirmAssociatedAccount']")
    private WebElement accountNumberConfirmPage;

    @FindBy(xpath = "//div[contains(@data-dojo-attach-point,'confirmation')]//div[contains(@class,'sectionedFooter')]/p")
    private WebElement disclaimerMessageConfirmPage;

    @FindBy(xpath = "//dd[@data-dojo-attach-point='_confirmNumberOfPagesInChequeBook']")
    private WebElement numberOfPagesInCheckbookConfirmPage;

    @FindBy(xpath = "//dd[@data-dojo-attach-point='_confirmNumberOfChequeBook']")
    private WebElement numberOfCheckBooks;

    public OrderChequeBookConfirmPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    /**
     * Method to verify number of cheque books on confirmation page
     * 
     * @param accountDetails
     */
    @Override
    public void verifyNumberOfChequeBookConfirmPage(final AccountDetails accountDetails) {
        Assert.assertTrue(accountDetails.getNumberOfChequeBooks().equals(numberOfCheckBooks.getText()),
            "Number of Cheques on confirmation page does not match. ");
        Reporter.log("Number of Pages in Cheque Book on confirmation page are same as selected. ");
    }

    public void verifyNumberOfPagesConfirmPage(final AccountDetails accountDetails) {
        Assert.assertTrue(accountDetails.getNumberOfPages().equals(numberOfPagesInCheckbookConfirmPage.getText()),
            "Number of Cheques on confirmation page does not match. ");
        Reporter.log("Number of Pages in Cheque Book on confirmation page are same as selected. ");
    }

    public void verifyAccountDetailsConfirmPage(final AccountDetails accountDetails) {
        Assert.assertTrue(accountDetails.getAccountNumber().equals(accountNumberConfirmPage.getText()),
            "Account Details on Confirmation page does not match. ");
        Reporter.log("Account Details on Confirmation page are same as selected. ");
    }

    public void isDisclaimerMessageOnConfirmPageDisplayed() {
        Assert.assertTrue(disclaimerMessageConfirmPage.isDisplayed(), "Disclaimer Message On Confirm Page is not displayed. ");
        Reporter.log("Disclaimer Message On Confirm Page is displayed. ");
    }


    public void verifyDetailsOnConfirmPage(final AccountDetails accountDetails) {
        isOrderChequeConfirmPageDisplayed();
        isConfirmationMessageDisplayed();
        verifyAccountDetailsConfirmPage(accountDetails);
        verifyNumberOfChequeBookConfirmPage(accountDetails);
        isDisclaimerMessageOnConfirmPageDisplayed();
        verifyNumberOfPagesConfirmPage(accountDetails);
    }
}
