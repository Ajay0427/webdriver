/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.library.ScreenShot;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.StopChequeDetails;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

/**
 * <p>
 * <b> Stop Cheque Capture page object model to hold generic function and
 * locators for story stop cheque</b>
 * </p>
 * 
 * @version 1.0.0
 * @author Vaibhav Sharma & Neeraj Kumar
 */
public abstract class StopChequeCapturePageModel {

    protected final WebDriver driver;
    private final JavascriptExecutor jsx;
    private final WebDriverWait wait;
    protected UICommonUtil uiCommonUtil;

    private static final int DEFAULT_LIST_STARTING_INDEX = 0;
    private static final int DEFAULT_DECIMAL_PLACES = 2;
    private static final String ELEMENT_VALUE_ATTRIBUTE = "value";
    private static final int DEFAULT_DAYS_TO_ADD_TO_AVOID_SATURDAY = 2;
    private static final int DEFAULT_DAYS_TO_ADD_TO_AVOID_SUNDAY = 1;
    private static final int AMOUNT_START_RANGE = 1;
    private static final int AMOUNT_END_RANGE = 100;
    private static final int DEFAULT_STARTING_INDEX_REASON_TO_STOP_CHEQUE = 1;
    private static final String SCROLL_TO_VIEW = "arguments[0].scrollIntoView(true);";
    protected static final int CHEQUE_START_RANGE = 100;
    protected static final int CHEQUE_END_RANGE = 999;
    private static final String VALUE_REASON_TO_STOP_CHEQUE = "Other";

    // Locators on Dashboard page
    @FindBy(xpath = "//button[@title='Manage']")
    protected WebElement manageButton;

    @FindBy(xpath = "//div[@class='manageContainer']//a[text()='Stop cheque']")
    public List<WebElement> stopChequeLinkManageMenuList;

    @FindBy(xpath = "//span[@class='title']")
    public WebElement dashboardtitle;

    @FindBy(xpath = "//div[@class='tooltiptext']//p")
    public List<WebElement> helpToolTipTextList;

    // Locators on Stop Cheque capture page
    @FindBy(xpath = "//div[contains(@id, 'StopCheque')]//div[contains(@class, 'steptracker-heading')]")
    private WebElement capturePageTitle;

    @FindBy(xpath = "//div[contains(@id, 'StopCheque')]//div[contains(@data-dojo-attach-point, '_NoOFAaccterrorPage')]")
    private List<WebElement> errorMessagesNoValidAccounts;

    @FindBy(xpath = "//span[contains(@id, 'singleOption')]//span[contains(@class, 'title')]")
    private List<WebElement> valuesAccountName;

    @FindBy(xpath = "//span[contains(@id, 'singleOption')]//span[contains(@class, 'accountDetails')]")
    private List<WebElement> valuesAccountNumber;

    @FindBy(xpath = "//table[contains(@id, 'Account')]//input[contains(@id, 'Select') and contains(@class, 'dijitArrowButtonInner')]")
    private WebElement accountDropIcon;

    protected WebElement getAccountDropIcon() {
        return accountDropIcon;
    }

    @FindBy(xpath = "//div[contains(@class,'dijitMenuActive')]")
    private WebElement listDropDown;

    @FindBy(xpath = "//div[contains(@id,'SelectAccount')]//table[contains(@id,'Account')]//span[contains(@class,'title') and not(contains(@class,'noDisplay'))]")
    private WebElement issueChequeAccountName;

    protected WebElement getIssueChequeAccountName() {
        return issueChequeAccountName;
    }

    @FindBy(xpath = "//div[contains(@id,'SelectAccount')]//table[contains(@id,'Account')]//span[contains(@class,'accountDetails')]")
    private WebElement issueChequeAccountNumber;

    protected WebElement getIssueChequeAccountNumber() {
        return issueChequeAccountNumber;
    }

    @FindBy(xpath = "//input[contains(@id, 'RadioButton') and contains(@aria-labelledby, 'chequeTypeRange')]")
    private WebElement chequeTypeRange;

    protected WebElement getChequeTypeRange() {
        return chequeTypeRange;
    }

    @FindBy(css = "input[id*='chequeRangeInputOne'][data-dojo-attach-point='textbox,focusNode']")
    private WebElement chequeStartRange;

    protected WebElement getChequeStartRange() {
        return chequeStartRange;
    }

    @FindBy(css = "input[id*='chequeRangeInputTwo'][data-dojo-attach-point='textbox,focusNode']")
    private WebElement chequeEndRange;

    protected WebElement getChequeEndRange() {
        return chequeEndRange;
    }

    @FindBy(xpath = "//input[contains(@id,'StopChequeForm') and contains(@id,'beneName')]")
    private WebElement payeeNameText;

    @FindBy(xpath = "//input[@id='chequeNumber']")
    private WebElement chequeNumberText;

    @FindBy(xpath = "//input[contains(@id,'StopChequeForm') and contains(@id,'amountField_CurrencyTextBox')]")
    private WebElement amountText;

    @FindBy(xpath = "//input[contains(@id,'chqueDate') and contains(@data-dojo-attach-point, 'textbox,focusNode')]")
    private WebElement issueDateText;

    @FindBy(xpath = "//input[contains(@id,'arrowid_reasonToStop')]")
    private WebElement reasonDropIcon;

    @FindBy(xpath = "//div[contains(@id,'TitlePane')]/span[@isgspentity='yes']")
    protected List<WebElement> accountsLists;

    @FindBy(xpath = "//div[@id = 'reasonToStop_menu']//tr[contains(@widgetid,'dijit_MenuItem')]")
    private List<WebElement> reasonToStopChequeList;

    @FindBy(xpath = "//input[@id='otherReason']")
    private List<WebElement> otherReasonInputTexts;

    @FindBy(xpath = "//div[@id='otherReasonLabel']")
    private List<WebElement> otherReasonLabelist;

    @FindBy(xpath = "//table[contains(@id, 'reasonToStop')]//span[contains(@role, 'option')]")
    private WebElement reasonToStopChequeValue;

    @FindBy(xpath = "//button[@type='submit' and text()='Continue']")
    private WebElement continueButton;

    @FindBy(xpath = "//div[@class='submitButtonsPanel']//button[@type='button' and text()='Cancel']")
    private WebElement cancelButton;

    @FindBy(xpath = "//div[@class='disclaimer']//p[contains(text(),'We cannot process')]")
    private WebElement disclamierContainerCapture;

    protected WebElement getDisclamierContainerCapture() {
        return disclamierContainerCapture;
    }

    @FindBy(xpath = "//div[@class='disclaimer']//p[contains(text(),'We cannot process')]")
    private WebElement callSupportText;

    protected WebElement getCallSupportText() {
        return callSupportText;
    }

    @FindBy(xpath = "//td[contains(@id,'MenuItem') and text()='Other']")
    private WebElement valueOtherReasonDropDown;

    @FindBy(xpath = "//div[contains(@id, 'Dialog')]//a[@class='btnSecondary']")
    private WebElement cancelPopUpDialogButton;

    private final By locatorContinuePopUpDialogButton = By
        .xpath("//div[contains(@id, 'Dialog')]//button[contains(@class, 'btnTertiary')]");

    private final By cancelDialog = By.xpath("//div[contains(@id,'Dialog')]");

    // Locate the error message

    @FindBy(xpath = "//div[contains(@id,'beneName')]//span[contains(@class,'validationMessage')]")
    private WebElement errorMessagePayeeName;

    @FindBy(xpath = "//div[@id='widget_chequeNumber']//span[contains(@class,'validationMessage')]")
    protected WebElement errorMessageChequeNumber;

    @FindBy(xpath = "//span[contains(@id,'chqueDate_validationMessage')]")
    private WebElement errorMessageIssueDate;

    @FindBy(xpath = "//div[@id='widget_otherReason']//span[@class='validationMessage']")
    private WebElement errorMessageOtherReason;

    @FindBy(xpath = "//div[contains(@id,'widget_hdx_bijits_StopChequeForm') and contains(@id,'amountField')]//span[contains(@class,'validationMessage')]")
    protected WebElement errorMessageAmount;

    @FindBy(xpath = "//span[contains(@id, 'reasonToStop_validationMessage')]")
    private WebElement errorMessageReasonToStopCheque;

    private final By menuText = By.cssSelector("[id$='_text']");

    private final By locatorAccountName = By.cssSelector("span.title");

    private final By locatorAccountNumber = By.cssSelector("span.accountDetails");

    private final By locatorHelpIcon = By.xpath("//span[contains(@class, 'infoIcon')]//span[contains(@class, 'icon')]");


    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(StopChequeCapturePageModel.class);


    // private static final String SUCCESS = "Success";

    public StopChequeCapturePageModel(final WebDriver driver) {
        PageFactory.initElements(driver, this);
        this.driver = driver;
        wait = new WebDriverWait(driver, 30000);
        jsx = (JavascriptExecutor) driver;
        uiCommonUtil = new UICommonUtil(driver);
    }

    public void checkAccountAndDisclaimer(final StopChequeDetails stopCheque) {
        Assert.assertTrue(
            getIssueChequeAccountNumber().getText().equalsIgnoreCase(stopCheque.getIssueChequeAccount().getAccountNumber()),
            "Selected account number is not displayed on Capture page");
        Reporter.log("Selected account number is displayed oncapture page");
        disclaimerMessageCapturePage();
        callSupportMessageCapturePage();

    }

    public StopChequeDetails enterStopChequeDetails(final StopChequeDetails stopCheque) throws ParseException {
        StopChequeDetails tempStopCheque = new StopChequeDetails();
        tempStopCheque.setPayeeName(enterPayeeName(stopCheque));
        tempStopCheque.setIssueDate(enterIssueDate(stopCheque));
        tempStopCheque.setChequeNumber(enterChequeNumber(stopCheque));
        tempStopCheque.setAmount(enterAmount(stopCheque));
        return tempStopCheque;
    }


    public StopChequeDetails enterStopChequeRange(final StopChequeDetails stopChequeDetails) {
        StopChequeDetails tempStopCheque = new StopChequeDetails();
        getChequeTypeRange().click();
        String[] chequeRange = enterChequeRange(stopChequeDetails);
        tempStopCheque.setChequeNumber(chequeRange[0]);
        tempStopCheque.setChequeEndNumber(chequeRange[1]);
        ScreenShot.takeScreenShot(driver);
        return tempStopCheque;
    }

    private String[] enterChequeRange(final StopChequeDetails stopChequeDetails) {
        String chequeStartRange = null;
        String chequeEndRangeNumber = null;
        int chequeNumber = stopChequeDetails.getIssueChequeAccount().getCheckStartRange() != null ? RandomUtil.generateIntNumber(
            Integer.parseInt(stopChequeDetails.getIssueChequeAccount().getCheckStartRange()),
            Integer.parseInt(stopChequeDetails.getIssueChequeAccount().getCheckEndRange())) : RandomUtil.generateIntNumber(
            CHEQUE_START_RANGE, CHEQUE_END_RANGE);
        if (chequeNumber != Integer.parseInt(stopChequeDetails.getIssueChequeAccount().getCheckEndRange())) {
            chequeStartRange = Integer.toString(chequeNumber);
            chequeEndRangeNumber = Integer.toString(chequeNumber + 1);
        } else {
            chequeEndRangeNumber = Integer.toString(chequeNumber);
            chequeStartRange = Integer.toString(chequeNumber - 1);
        }
        enterChequeStartRange(chequeStartRange);
        enterChequeEndRange(chequeEndRangeNumber);
        Reporter.log("Stop cheque range entered is:" + chequeStartRange + " - " + chequeEndRangeNumber);
        return new String[] {chequeStartRange, chequeEndRangeNumber};
    }

    private void enterChequeStartRange(final String chequeNumber) {
        getChequeStartRange().clear();
        getChequeStartRange().sendKeys(chequeNumber);
    }


    private void enterChequeEndRange(final String chequeNumber) {
        getChequeEndRange().clear();
        getChequeEndRange().sendKeys(chequeNumber);
    }

    protected String enterPayeeName(final StopChequeDetails stopCheque) {
        String payeeName = stopCheque.getPayeeName() != null ? stopCheque.getPayeeName() : RandomUtil.generateAlphabatic(10);
        payeeNameText.clear();
        payeeNameText.sendKeys(payeeName);
        Reporter.log("Entered Payee name as : " + payeeName);
        return payeeName;
    }

    protected String enterChequeNumber(final StopChequeDetails stopCheque) {
        int chequeNumber = stopCheque.getIssueChequeAccount().getCheckStartRange() != null ? RandomUtil.generateIntNumber(
            Integer.parseInt(stopCheque.getIssueChequeAccount().getCheckStartRange()),
            Integer.parseInt(stopCheque.getIssueChequeAccount().getCheckEndRange())) : RandomUtil.generateIntNumber(
            CHEQUE_START_RANGE, CHEQUE_END_RANGE);
        String chequeNumberString = stopCheque.getChequeNumber() != null ? stopCheque.getChequeNumber() : Integer
            .toString(chequeNumber);
        enterChequeNumber(chequeNumberString);
        return chequeNumberString;
    }

    public void enterChequeNumber(final String chequeNumber) {
        Assert.assertTrue(chequeNumberText.isDisplayed(), "Cheque number input field is not displayed");
        chequeNumberText.clear();
        chequeNumberText.sendKeys(chequeNumber);
        Reporter.log("enter cheque number as : " + chequeNumber);
    }

    protected String enterAmount(final StopChequeDetails stopCheque) {
        String amount = stopCheque.getAmount() != null ? stopCheque.getAmount() : RandomUtil.generateDoubleNumber(
            AMOUNT_START_RANGE, AMOUNT_END_RANGE, DEFAULT_DECIMAL_PLACES);
        Assert.assertTrue(amountText.isDisplayed(), "Amount text field is not displayed");
        amountText.clear();
        amountText.sendKeys(amount);
        Reporter.log("enter amount as : " + amount);
        return amount;
    }

    public String selectReasonToStopCheque() {
        String uiReason = null;
        reasonDropIcon.click();
        int randomIndex = RandomUtil.generateIntNumber(DEFAULT_STARTING_INDEX_REASON_TO_STOP_CHEQUE, reasonToStopChequeList.size());
        for (WebElement reasonRow : reasonToStopChequeList) {
            jsx.executeScript(SCROLL_TO_VIEW, reasonRow);
            if (reasonRow.isDisplayed() && reasonRow.equals(reasonToStopChequeList.get(randomIndex))) {
                uiReason = reasonRow.getText();
                reasonRow.click();
                break;
            }
        }
        String reason = enterOtherReason();
        return !reason.isEmpty() ? reason : uiReason;
    }

    private String enterOtherReason() {
        String otherReason = StringUtils.EMPTY;
        if (!otherReasonInputTexts.isEmpty() && otherReasonInputTexts.get(0).isDisplayed()) {
            otherReason = RandomUtil.generateAlphabatic(10);
            otherReasonInputTexts.get(DEFAULT_LIST_STARTING_INDEX).sendKeys(otherReason);
            Reporter.log("Other reason is entered as : " + otherReason);
        }
        return otherReason;
    }

    public void selectReasontoStopChequeForDuplicateFlow(final StopChequeDetails stopCheque) {
        String result = selectByValue(stopCheque.getReasonToStopCheque());
        if (!result.equalsIgnoreCase(stopCheque.getReasonToStopCheque())) {
            wait.until(ExpectedConditions.visibilityOf(otherReasonInputTexts.get(DEFAULT_LIST_STARTING_INDEX)));
            otherReasonInputTexts.get(DEFAULT_LIST_STARTING_INDEX).sendKeys(stopCheque.getReasonToStopCheque());
        }

    }

    public void selectOtherReasonToStopCheque() {
        selectByValue(VALUE_REASON_TO_STOP_CHEQUE);
    }

    private String selectByValue(String value) {
        String reason = null;
        reasonDropIcon.click();
        for (WebElement reasonRow : reasonToStopChequeList) {
            jsx.executeScript(SCROLL_TO_VIEW, reasonRow);
            wait.until(ExpectedConditions.elementToBeClickable(reasonRow));
            if (reasonRow.isDisplayed()
                && reasonRow.getText().equalsIgnoreCase(value)
                || reasonRow.isDisplayed()
                && reasonRow.equals(reasonToStopChequeList.get(reasonToStopChequeList.size()
                    - DEFAULT_STARTING_INDEX_REASON_TO_STOP_CHEQUE))) {
                reason = reasonRow.getText();
                reasonRow.click();
                break;
            }
        }
        return reason;
    }

    /**
     * Method to return hub date and if its not specified, return system date
     * 
     * @throws ParseException
     */
    protected String enterIssueDate(final StopChequeDetails stopCheque) throws ParseException {
        Date parseDate = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(parseDate);
        int dayofWeek = cal.get(Calendar.DAY_OF_WEEK);
        if (dayofWeek == Calendar.SATURDAY) {
            cal.add(Calendar.DAY_OF_YEAR, DEFAULT_DAYS_TO_ADD_TO_AVOID_SATURDAY);
            parseDate = cal.getTime();
        } else if (dayofWeek == Calendar.SUNDAY) {
            cal.add(Calendar.DAY_OF_YEAR, DEFAULT_DAYS_TO_ADD_TO_AVOID_SUNDAY);
            parseDate = cal.getTime();
        } else {
            parseDate = cal.getTime();
        }
        String issueDate = stopCheque.getIssueDate() != null ? stopCheque.getIssueDate() : DateUtil.getDateToString(
            DateUtil.DATE_FORMAT_MMDDYYYY, parseDate);
        issueDateText.clear();
        issueDateText.sendKeys(issueDate);
        return issueDate;
    }

    public void clickContinueButton() {
        continueButton.click();
        Reporter.log("Continue button clicked");
    }

    public void clickCancelButton() {
        wait.until(ExpectedConditions.elementToBeClickable(cancelButton));
        cancelButton.click();
        Reporter.log("Cancel Button is clicked.");
    }

    public void clickCancelPopUpCancelButton() {
        wait.until(ExpectedConditions.visibilityOf(uiCommonUtil.activeElement(cancelDialog)));
        cancelPopUpDialogButton.click();
        Reporter.log("Cancel Button on Cancel Dialog is clicked.");
    }

    public void clickContinuePopUpCancelButton() {
        wait.until(ExpectedConditions.visibilityOf(uiCommonUtil.activeElement(cancelDialog)));
        uiCommonUtil.activeElement(locatorContinuePopUpDialogButton).click();
        Reporter.log("Continue Button on Cancel Dialog is clicked.");
    }

    public void verifyPageTitle() {
        wait.until(ExpectedConditions.visibilityOf(capturePageTitle));
        Assert.assertTrue(capturePageTitle.isDisplayed(), "Stop Cheque capture page is not displayed");
        Reporter.log("Stop Cheque capture page is displayed after click on Stop Another Cheque");
    }

    protected void isIssueChequeAccountNameDisplayed(final StopChequeDetails stopChequeDetails) {
        Assert.assertTrue(
            getIssueChequeAccountName().getText().equalsIgnoreCase(stopChequeDetails.getIssueChequeAccount().getAccountName()),
            "Issue Cheque Account Name does not match expected value.");
        Reporter.log("Issue Cheque Account Name matches : " + stopChequeDetails.getIssueChequeAccount().getAccountName());
    }

    protected void isIssueChequeAccountNumberDisplayed(final StopChequeDetails stopChequeDetails) {
        Assert.assertTrue(
            getIssueChequeAccountNumber().getText().equalsIgnoreCase(stopChequeDetails.getIssueChequeAccount().getAccountNumber()),
            "Issue Cheque Account Number does not match expected value.");
        Reporter.log("Issue Cheque Account Number matches : " + stopChequeDetails.getIssueChequeAccount().getAccountNumber());
    }

    protected void isPayeeNameDisplayed(final StopChequeDetails stopChequeDetails) {
        Assert.assertTrue(payeeNameText.getAttribute(ELEMENT_VALUE_ATTRIBUTE).equalsIgnoreCase(stopChequeDetails.getPayeeName()),
            "Payee Name does not match the entered value.");
        Reporter.log("Payee Name matches entered value :" + stopChequeDetails.getPayeeName());
    }

    protected void isChequeIssueDateDisplayed(final StopChequeDetails stopChequeDetails) {
        Assert.assertTrue(issueDateText.getAttribute(ELEMENT_VALUE_ATTRIBUTE).equalsIgnoreCase(stopChequeDetails.getIssueDate()),
            "Cheque Issue Date does not match the entered value.");
        Reporter.log("Cheque Issue Date matches entered value :" + stopChequeDetails.getIssueDate());
    }

    protected void isChequeNumberDisplayed(final StopChequeDetails stopChequeDetails) {
        Assert.assertTrue(
            chequeNumberText.getAttribute(ELEMENT_VALUE_ATTRIBUTE).equalsIgnoreCase(stopChequeDetails.getChequeNumber()),
            "Cheque Number does not match the entered value.");
        Reporter.log("Cheque Number matches entered value :" + stopChequeDetails.getChequeNumber());
    }

    protected void isAmountDisplayed(final StopChequeDetails stopChequeDetails) {
        Assert.assertTrue(amountText.getAttribute(ELEMENT_VALUE_ATTRIBUTE).equalsIgnoreCase(stopChequeDetails.getAmount()),
            "Cheque Amount does not match the entered value.");
        Reporter.log("Cheque Amount matches entered value :" + stopChequeDetails.getAmount());
    }

    protected void isReasonToStopChequeDisplayed(final StopChequeDetails stopChequeDetails) {
        if (!otherReasonInputTexts.isEmpty() && otherReasonInputTexts.get(DEFAULT_LIST_STARTING_INDEX).isDisplayed()) {
            Assert.assertTrue(otherReasonInputTexts.get(DEFAULT_LIST_STARTING_INDEX).getAttribute(ELEMENT_VALUE_ATTRIBUTE)
                .equalsIgnoreCase(stopChequeDetails.getReasonToStopCheque()),
                "Reason to Stop Cheque does not match the entered value.");
            Reporter.log("Reason to Stop Cheque matches entered value :" + stopChequeDetails.getReasonToStopCheque());
        } else {
            Assert.assertTrue(reasonToStopChequeValue.getText().equalsIgnoreCase(stopChequeDetails.getReasonToStopCheque()),
                "Reason to Stop Cheque does not match the entered value.");
            Reporter.log("Reason to Stop Cheque matches entered value :" + stopChequeDetails.getReasonToStopCheque());

        }
    }

    // ?? Read text from cheque number help icon tool tip
    public void verifyHelpIcon() {
        uiCommonUtil.mouseMoveToElement(uiCommonUtil.activeElement(locatorHelpIcon));
        Assert.assertTrue(helpToolTipTextList.size() > 0, "Tool tip is not displayed for help text");
        Reporter.log("Tool Tip is displayed as :" + helpToolTipTextList.get(0).getText());
    }

    private void disclaimerMessageCapturePage() {
        Assert.assertTrue(getDisclamierContainerCapture().isDisplayed(), "Disclaimer message is not displayed on capture page");
        Reporter.log("Disclaimer message is displayed on capture page as :" + getDisclamierContainerCapture().getText());
    }

    private void callSupportMessageCapturePage() {
        Assert.assertTrue(getCallSupportText().isDisplayed(), "Call Support message is not displayed on capture page");
        Reporter.log("Call support message is displayed on capture page as :" + getCallSupportText().getText());
    }

    protected void isErrorOnBlankPayeeNameFieldDisplayed() {
        Assert.assertTrue(errorMessagePayeeName.isDisplayed(), "Error is not displayed for blank Payee Name");
        Reporter.log("Error displayed for blank Payee Name field is :" + errorMessagePayeeName.getText());
    }

    protected void isErrorOnBlankChequeNumberFieldDisplayed() {
        Assert.assertTrue(errorMessageChequeNumber.isDisplayed(), "Error is not displayed for blank Cheque Number");
        Reporter.log("Error displayed for blank Cheque Number field is :" + errorMessageChequeNumber.getText());
    }

    protected void isErrorOnBlankIssueDateFieldDisplayed() {
        Assert.assertTrue(errorMessageIssueDate.isDisplayed(), "Error is not displayed for blank Issue Date");
        Reporter.log("Error displayed for blank Issue Date field is :" + errorMessageIssueDate.getText());
    }

    protected void isErrorOnBlankAmountFieldDisplayed() {
        Assert.assertTrue(errorMessageAmount.isDisplayed(), "Error is not displayed for blank Amount");
        Reporter.log("Error displayed for blank Amount field is :" + errorMessageAmount.getText());
    }

    protected void isErrorOnNonSelectionOfReasonToStopChequeDisplayed() {
        Assert.assertTrue(errorMessageReasonToStopCheque.isDisplayed(),
            "Error message is not displayed when Reason To Stop Cheque is not selected.");
        Reporter.log("Error Message displayed for no selection of Reason to Stop Cheque is :"
            + errorMessageReasonToStopCheque.getText());
    }

    public void validateFieldErrorsCapturePage() {
        isErrorOnBlankPayeeNameFieldDisplayed();
        isErrorOnBlankChequeNumberFieldDisplayed();
        isErrorOnBlankIssueDateFieldDisplayed();
        isErrorOnBlankAmountFieldDisplayed();
        isErrorOnNonSelectionOfReasonToStopChequeDisplayed();
    }


    public void selectOtherReason() {
        reasonDropIcon.click();
        Assert.assertTrue(valueOtherReasonDropDown.isDisplayed(), "Option other is not displayed in Reason to stop drop down");
        Reporter.log("Option other is displayed in Reason to stop drop down");
        valueOtherReasonDropDown.click();
        Reporter.log("Selected Other reason in drop down");

    }

    public void otherReasonFieldErrorMessage() {
        Assert.assertTrue(errorMessageOtherReason.isDisplayed(), "Error is not displayed for blank Payee Name");
        Reporter.log("Error is displayed for blank Payee Name");
    }

    public AccountDetails populateAccountDetails(final Map<String, String> profileProperties) {
        AccountDetails accountDetails = new AccountDetails();
        String accountName = profileProperties.get("accountNameStopCheque");
        String accountNumber = profileProperties.get("accountNumberStopCheque");
        String chequeRange = profileProperties.get("chequeRange");
        if (StringUtils.isNotEmpty(accountNumber) && StringUtils.isNotEmpty(chequeRange)) {
            accountDetails.setAccountName(accountName);
            accountDetails.setAccountNumber(accountNumber);
            String[] checkRange = chequeRange.split("-");
            accountDetails.setCheckStartRange(checkRange[0]);
            accountDetails.setCheckEndRange(checkRange[1]);
        }
        return accountDetails;
    }

    public void validateChequeRangeReviewPage(final StopChequeDetails stopChequeDetails) {
        Reporter.log("Cheuque range not applicable here: " + stopChequeDetails);
    }

    public AccountDetails selectAccountOnStopACheckPage(AccountDetails accountDetails) {
        if (accountDetails.getAccountNumber() != null && !errorMessagesNoValidAccounts.isEmpty()) {
            return selectAccountByDetails(accountDetails);
        } else if (!errorMessagesNoValidAccounts.isEmpty()) {
            return selectRandomAccount(accountDetails);
        } else {
            return accountDetails;
        }
    }

    public AccountDetails selectRandomAccount(AccountDetails accountDetails) {
        wait.until(ExpectedConditions.visibilityOf(capturePageTitle));
        String currentAccountName = null;
        String currentAccountNumber = null;
        if (valuesAccountName.isEmpty()) {
            getAccountDropIcon().click();
            wait.until(ExpectedConditions.visibilityOf(listDropDown));
            List<WebElement> accountRows = listDropDown.findElements(menuText);
            int index = RandomUtil.generateIntNumber(DEFAULT_LIST_STARTING_INDEX, accountRows.size());
            jsx.executeScript(SCROLL_TO_VIEW, accountRows.get(index));
            currentAccountName = accountRows.get(index).findElement(locatorAccountName).getText();
            currentAccountNumber = accountRows.get(index).findElement(locatorAccountNumber).getText();
            accountRows.get(index).click();
        } else {
            currentAccountName = valuesAccountName.get(DEFAULT_LIST_STARTING_INDEX).getText();
            currentAccountNumber = valuesAccountName.get(DEFAULT_LIST_STARTING_INDEX).getText();
        }
        accountDetails.setAccountName(currentAccountName);
        accountDetails.setAccountNumber(currentAccountNumber);
        return accountDetails;
    }

    public AccountDetails selectAccountByDetails(AccountDetails accountDetails) {
        wait.until(ExpectedConditions.visibilityOf(capturePageTitle));
        if (valuesAccountName.isEmpty()) {
            getAccountDropIcon().click();
            wait.until(ExpectedConditions.visibilityOf(listDropDown));
            List<WebElement> accountRows = listDropDown.findElements(menuText);
            for (WebElement accountRow : accountRows) {
                jsx.executeScript(SCROLL_TO_VIEW, accountRow);
                String currentAccountName = accountRow.findElement(locatorAccountName).getText();
                String currentAccountNumber = accountRow.findElement(locatorAccountNumber).getText();
                if (currentAccountName.equalsIgnoreCase(accountDetails.getAccountName())
                    && currentAccountNumber.equalsIgnoreCase(accountDetails.getAccountNumber())) {
                    accountRow.click();
                    break;
                }
            }
        }
        return accountDetails;
    }

    public void verifyDetailsAfterNegatingCancelOnCapturePage(final StopChequeDetails stopCheque) {
        isIssueChequeAccountNameDisplayed(stopCheque);
        isIssueChequeAccountNumberDisplayed(stopCheque);
        isPayeeNameDisplayed(stopCheque);
        isChequeNumberDisplayed(stopCheque);
        isAmountDisplayed(stopCheque);
    }
}
