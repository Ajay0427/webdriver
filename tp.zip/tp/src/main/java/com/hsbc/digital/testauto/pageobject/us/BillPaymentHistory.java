/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.us;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.pageobject.BillPaymentHistoryModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Bill
 * Payment History for US entity. </b>
 * </p>
 */


public class BillPaymentHistory extends BillPaymentHistoryModel {

    private final JavascriptExecutor jsx;

    @FindBy(xpath = "//a[@id='helpIconLink']")
    private WebElement helpButton;

    @FindBy(xpath = "//div[contains(@class,'credittransferlimit') and not (contains(@style,'display: none'))]//button[@class='close btnSecondary']")
    private WebElement helpPopUpButton;

    @FindBy(xpath = "//div[contains(@id,'viewMoreButton')]//span[contains(@id,'dijit_form_Button')]")
    private WebElement viewMoreButton;

    @FindBy(xpath = "//div[contains(@id,'viewMoreButton')]//span[contains(@id,'dijit_form_Button')]")
    private List<WebElement> viewMoreButtonList;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_reviewClearSearch']")
    private WebElement clearSearchButton;

    private static final String ACCOUNT_NAME = "Select all accounts";
    private static final String SCROLL_TO_VIEW = "arguments[0].scrollIntoView(true);";

    public BillPaymentHistory(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        jsx = (JavascriptExecutor) driver;
    }

    /*
     *This method is to Select Account having Bill Payment History
     */
    @Override
    public void selectAccount() {
        int counter = 1;
        accountDropdownIcon.click();
        if (!accountDropDownList.isEmpty()) {
            for (int i = 1; i < accountDropDownList.size(); i++) {
                WebElement accountSelection = accountDropDownList.get(i);
                jsx.executeScript(SCROLL_TO_VIEW, accountSelection);
                accountSelection.click();
                counter++;
                if (!transactionDetailDisplayElements.isEmpty()) {
                    Reporter.log("Account is selected with some transaction history. ");
                    break;
                }
                accountDropdownIcon.click();
            }
            if (counter > accountDropDownList.size()) {
                Reporter.log("No account found for required condition , Please change profile to execute this scenario");
                Assert.fail("No Suitable Account found for this scenario");
            }
        } else {
            Assert.fail("Account not available for this scenario.");
        }
    }

    /*
     *This method is to Select SelectAllAccounts option
     */
    @Override
    public void selectSelectAllAccounts() {
        int counter = 0;
        accountDropdownIcon.click();
        if (!accountDropDownList.isEmpty()) {
            for (int i = 0; i < accountDropDownList.size(); i++) {
                WebElement accountSelection = accountDropDownList.get(i);
                String accountName = accountDropDownList.get(i).getText();
                if (accountName.equalsIgnoreCase(ACCOUNT_NAME)) {
                    jsx.executeScript(SCROLL_TO_VIEW, accountSelection);
                    accountSelection.click();
                    counter++;
                    if (!transactionDetailDisplayElements.isEmpty()) {
                        Reporter.log("Account is selected with some transaction history.");
                        break;
                    }
                    accountDropdownIcon.click();
                }
                if (counter > accountDropDownList.size()) {
                    Reporter.log("No account found for required condition , Please change profile to execute this scenario");
                    Assert.fail("No Suitable Account found for this scenario");
                }
            }
        } else {
            Assert.fail("Account not available for this scenario.");
        }
    }

    /*
     *This method is to verify Help Icon 
     */
    @Override
    public void verifyHelpIcon() {
        Assert.assertTrue(helpButton.isDisplayed(), "Print button is not displayed on Transaction History section");
        helpButton.click();
        Reporter.log("Print button is clicked on Transaction History section");
        Assert.assertTrue(helpPopUpButton.isDisplayed(), "Print popup dialog is not displayed.");
        Reporter.log("Print popup dialog is displayed.");
    }

    /**
     * This is to check if the view more button is visible or not
     * 
     */
    @Override
    public void verifyVisibilityOfViewMoreButton() {
        if (super.descriptionList.size() < 5) {
            Assert.assertTrue(viewMoreButtonList.isEmpty(), "View More button is visible for less transaction");
            Reporter.log("View More button is not visible");
        } else {
            if (!viewMoreButtonList.isEmpty() && viewMoreButtonList.get(0).isDisplayed()) {
                viewMoreButtonList.get(0).click();
                Assert.assertTrue(super.descriptionList.size() > 5,
                    "View More button displayed even if the transactions are not more than 5");
                Reporter.log("As Expected View More button displayed. | ");
            } else {
                Reporter.log("As Expected View More button not displayed. | ");
            }
        }
    }

    /**
     * This is to compare the Result by Description name
     * 
     * @param expname
     */
    @Override
    public void compareResultByName(final String expname) {
        while (true) {
            for (WebElement tempname : descriptionList) {
                jsx.executeScript(SCROLL_TO_VIEW, tempname);
                Assert.assertTrue(tempname.getText().contains(expname),
                    "Expected name: " + expname + " Actual name: " + tempname.getText());
            }
            if (!viewMoreButtonList.isEmpty() && viewMoreButtonList.get(0).isDisplayed()) {
                viewMoreButtonList.get(0).click();
            } else {
                break;
            }
        }
    }

    /**
     * This is to compare the Result is between the From and To Amount
     * 
     * @param fromAmt
     * @param toAmt
     */
    @Override
    public void compareResultByAmount(final Double fromAmt, final Double toAmt) {
        while (true) {
            for (WebElement tempAmount : super.amountList) {
                jsx.executeScript(SCROLL_TO_VIEW, tempAmount);
                Double actualAmount = Double.valueOf(tempAmount.getText().replace(",", ""));
                Assert.assertTrue(actualAmount >= fromAmt && actualAmount <= toAmt, "Amount is displaying as " + actualAmount
                    + " which dosen't lie between + " + fromAmt + " and " + toAmt);
            }
            if (!viewMoreButtonList.isEmpty() && viewMoreButtonList.get(0).isDisplayed()) {
                viewMoreButtonList.get(0).click();
            } else {
                break;
            }
        }
    }

    @Override
    public void validateDisclaimerText() {
        // TODO : enter code once functionality is present
    }

    @Override
    public void verifyClearSearchButton(final List<String> transactionsList) {
        Assert.assertTrue(clearSearchButton.isDisplayed(), "Clear Search button is not present");
        clearSearchButton.click();
        Reporter.log("Clear Search button clicked");
        List<String> transactionListAfterClear = super.transactionsList();
        if (super.transactionsList().size() <= 5 && transactionsList.equals(transactionListAfterClear)) {
            Reporter.log("\"Clear Search\" button functionality working properly. | ");
        }
    }

}
