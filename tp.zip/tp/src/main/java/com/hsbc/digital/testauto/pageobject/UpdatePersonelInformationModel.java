/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 *
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.UpdatePersonalInformation;


/***
 * <p>
 * <b> This model class will hold locators and functionality to Update Contact
 * Details page. </b>
 * </p>
 *
 * @author Midde Rajesh Kumar
 * @version 1.0.0
 */

public abstract class UpdatePersonelInformationModel {
    protected final WebDriver driver;

    @FindBy(xpath = "//button[contains(@class,'editIcon')]")
    private WebElement changeAddressButton;

    @FindBy(xpath = "//input[contains(@id,'email')]")
    private WebElement emailInput;

    @FindBy(xpath = "//input[contains(@id,'homePhNo')]")
    protected WebElement homePhoneInput;

    @FindBy(xpath = "//table[contains(@id,'mobilePhNoDrpDwn')]//td[contains(@class,'dijitArrowButtonContainer')]")
    private WebElement mobilePhoneIcon;

    @FindBy(xpath = "//div[contains(@id,'mobilePhNoDrpDwn_menu')]//td[contains(@id,'dijit_MenuItem')]")
    private List<WebElement> mobilePhoneList;

    @FindBy(xpath = "//input[contains(@id,'mobilePhNoText')]")
    private WebElement mobilePhoneInput;

    @FindBy(xpath = "//input[contains(@id,'workPhNo')]")
    protected WebElement workPhoneInput;

    @FindBy(xpath = "//input[contains(@id,'homeCountry')]")
    private WebElement countryInput;

    @FindBy(xpath = "//div[contains(@id,'homeCountry')]/div[contains(@class,'dijitValidationContainer')]")
    private WebElement errorIcon;

    @FindBy(xpath = "//input[contains(@id,'streetNumber')]")
    private WebElement streetNumberInput;

    @FindBy(xpath = "//input[contains(@id,'streetName')]")
    private WebElement streetNameInput;

    @FindBy(xpath = "//input[contains(@id,'city')]")
    private WebElement cityInput;

    @FindBy(xpath = "//input[contains(@id,'state')]")
    private WebElement provinceIcon;

    @FindBy(xpath = "//div[contains(@id,'state_menu')]//td[@class='dijitReset dijitMenuItemLabel']")
    private List<WebElement> provinceList;

    @FindBy(xpath = "//input[contains(@id,'postCode')]")
    private WebElement postalCodeInput;

    @FindBy(xpath = "//div[contains(@id,'addrSinceDate')]//input[@class='dijitReset dijitInputInner']")
    private WebElement dateInput;

    @FindBy(linkText = "Employment details")
    private WebElement employeDetailsLink;

    @FindBy(xpath = "//input[contains(@id,'empStatus')]")
    private WebElement employeeStatusIcon;

    @FindBy(xpath = "//div[contains(@id,'empStatus_menu')]//td[@class='dijitReset dijitMenuItemLabel']")
    private List<WebElement> employmentStatusList;

    @FindBy(xpath = "//input[contains(@id,'businessInd')]")
    private WebElement typeOfBussinessIcon;

    @FindBy(xpath = "//div[contains(@id,'businessInd_menu')]//td[@class='dijitReset dijitMenuItemLabel']")
    private List<WebElement> typeOfBussinessList;

    @FindBy(xpath = "//table[contains(@id,'occupation')]/tbody/tr/td[contains(@class,'dijitArrowButtonContainer')]")
    private WebElement occupationIcon;

    @FindBy(xpath = "//div[contains(@id,'occupation_menu')]//td[@class='dijitReset dijitMenuItemLabel']")
    private List<WebElement> occupationList;

    @FindBy(xpath = "//input[contains(@id,'prevBusinessInd')]")
    private WebElement typeOfPreviousBussinessIcon;

    @FindBy(xpath = "//div[contains(@id,'prevBusinessInd_menu')]//td[@class='dijitReset dijitMenuItemLabel']")
    private List<WebElement> typeOfPreviousBussinessList;

    @FindBy(xpath = "//table[contains(@id,'prevOccupation')]/tbody/tr/td[contains(@class,'dijitArrowButtonContainer')]")
    private WebElement typeOfPreviousOccupationIcon;

    @FindBy(xpath = "//div[contains(@id,'prevOccupation_menu')]//td[@class='dijitReset dijitMenuItemLabel']")
    private List<WebElement> typeOfPreviousOccupationList;

    @FindBy(xpath = "//input[contains(@id,'job')]")
    private WebElement jobTitleInput;

    @FindBy(xpath = "//input[contains(@id,'address1')]")
    private WebElement addressLine1Input;

    @FindBy(xpath = "//button[text()='Update details']")
    private WebElement updateDetailsButton;

    @FindBy(xpath = "//button[@class='btnTertiary']")
    private WebElement cancelButton;

    @FindBy(xpath = "//input[contains(@id,'employer')]")
    private WebElement employersNameInput;

    /* ******* Verification Page Elements ************** */
    @FindBy(xpath = "//button[contains(@class,'editIcon')]")
    protected WebElement ediDetailsButton;

    @FindBy(xpath = "//span[contains(@id,'dijit_form_Button')]")
    private WebElement confirmButton;

    @FindBy(xpath = "//button[@class='btnTertiary']")
    private WebElement verifyPageCancelButton;

    @FindBy(xpath = "//button[contains(@id,'ok')]")
    private WebElement popUpCancelButton;

    @FindBy(xpath = "//span[contains(@id,'dijit_form_Button')]")
    private WebElement popUpDontCancelButton;

    /* ******* Confirmation Page Elements ************** */

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_GlobalAlert')]/p")
    private WebElement successMessageLabel;

    @FindBy(xpath = "//a[contains(text(),'Back to My Accounts')]")
    private WebElement backToMyAccountsButton;

    /* ******* DashBoard Page Elements ************** */
    @FindBy(xpath = "//span[text()='Move money' and @class='icon']")
    private WebElement moveMoneyButton;

    /* ******* Declaration of Constants ************** */
    protected static final String ERROR_MESSAGE = "Unable to navigate to Required page";
    private static final String SUCCESS_MESSAGE = "Your details have been successfully updated";
    private static final String FAILURE_MESSAGE = "Error icon is displayed";

    /* ****** Test Data ********** */
    private static final String HOME_PHONE = "456789";
    private static final String MOBILE_PHONE = "9955668489";
    private static final String WORK_PHONE = "66556655";
    private static final String STREET_NUMBER = "12345";
    private static final String STREET_NAME = "RKSTREET";
    private static final String CITY = "KANPUR";
    private static final String POSTAL_CODE = "560100";
    private static final String DATE = "07/05/2016";
    private static final String EMPLOYERS_NAME = "TATA";
    private static final String JOBTITLE = "CONSULTANT";
    private static final String ADDRESS_LINE1 = "NEWSTREET";
    private static final String VERIFY_STATUS_EMPLOYED = "Employed";
    private static final String VERIFY_STATUS_SELFEMPLOYED = "Self Employed";

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(UpdatePersonelInformationModel.class);

    public UpdatePersonelInformationModel(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    /**
     *
     * This method is to give Input on the Contact Details Page
     *
     */
    public AccountDetails inputContactDetails() {
        AccountDetails objAccountDetails = new AccountDetails();
        homePhoneInput.sendKeys(UpdatePersonelInformationModel.HOME_PHONE);
        selectFormDropDownList(mobilePhoneIcon, mobilePhoneList);
        mobilePhoneInput.sendKeys(UpdatePersonelInformationModel.MOBILE_PHONE);
        workPhoneInput.sendKeys(UpdatePersonelInformationModel.WORK_PHONE);
        changeAddressButton.click();
        selectFormDropDownList(provinceIcon, provinceList);
        streetNumberInput.sendKeys(UpdatePersonelInformationModel.STREET_NUMBER);
        streetNameInput.sendKeys(UpdatePersonelInformationModel.STREET_NAME);
        cityInput.sendKeys(UpdatePersonelInformationModel.CITY);
        selectFormDropDownList(provinceIcon, provinceList);
        postalCodeInput.sendKeys(UpdatePersonelInformationModel.POSTAL_CODE);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", dateInput);
        dateInput.sendKeys(UpdatePersonelInformationModel.DATE);
        employeDetailsLink.click();
        String employmentStatusSelected = selectEmploymentStatus();
        if (employmentStatusSelected.equalsIgnoreCase(UpdatePersonelInformationModel.VERIFY_STATUS_EMPLOYED)) {
            selectFormDropDownList(typeOfBussinessIcon, typeOfBussinessList);
            selectFormDropDownList(occupationIcon, occupationList);
            employersNameInput.sendKeys(UpdatePersonelInformationModel.EMPLOYERS_NAME);
            jobTitleInput.sendKeys(UpdatePersonelInformationModel.JOBTITLE);
            addressLine1Input.sendKeys(UpdatePersonelInformationModel.ADDRESS_LINE1);
        } else if (employmentStatusSelected.equalsIgnoreCase(UpdatePersonelInformationModel.VERIFY_STATUS_SELFEMPLOYED)) {
            selectFormDropDownList(typeOfBussinessIcon, typeOfBussinessList);
            selectFormDropDownList(occupationIcon, occupationList);
            jobTitleInput.sendKeys(UpdatePersonelInformationModel.JOBTITLE);
            addressLine1Input.sendKeys(UpdatePersonelInformationModel.ADDRESS_LINE1);
        } else {
            selectFormDropDownList(typeOfPreviousBussinessIcon, typeOfPreviousBussinessList);
            selectFormDropDownList(typeOfPreviousOccupationIcon, typeOfPreviousOccupationList);
        }
        return objAccountDetails;
    }

    /**
     *
     * This method is to give Input With out Country On Contact Details Page
     *
     */
    public void inputContactDetailsWithCountryInput() {
        changeAddressButton.click();
        countryInput.clear();
        streetNumberInput.sendKeys(UpdatePersonelInformationModel.STREET_NUMBER);
        streetNameInput.sendKeys(UpdatePersonelInformationModel.STREET_NAME);
        cityInput.sendKeys(UpdatePersonelInformationModel.CITY);
        selectFormDropDownList(provinceIcon, provinceList);
        postalCodeInput.sendKeys(UpdatePersonelInformationModel.POSTAL_CODE);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", dateInput);
        dateInput.sendKeys(UpdatePersonelInformationModel.DATE);
        employeDetailsLink.click();
        String employmentStatusSelected = selectEmploymentStatus();
        if (employmentStatusSelected.equalsIgnoreCase(UpdatePersonelInformationModel.VERIFY_STATUS_EMPLOYED)) {
            selectFormDropDownList(typeOfBussinessIcon, typeOfBussinessList);
            selectFormDropDownList(occupationIcon, occupationList);
            employersNameInput.sendKeys(UpdatePersonelInformationModel.EMPLOYERS_NAME);
            jobTitleInput.sendKeys(UpdatePersonelInformationModel.JOBTITLE);
            addressLine1Input.sendKeys(UpdatePersonelInformationModel.ADDRESS_LINE1);
        } else if (employmentStatusSelected.equalsIgnoreCase(UpdatePersonelInformationModel.VERIFY_STATUS_SELFEMPLOYED)) {
            selectFormDropDownList(typeOfBussinessIcon, typeOfBussinessList);
            selectFormDropDownList(occupationIcon, occupationList);
            jobTitleInput.sendKeys(UpdatePersonelInformationModel.JOBTITLE);
            addressLine1Input.sendKeys(UpdatePersonelInformationModel.ADDRESS_LINE1);
        } else {
            selectFormDropDownList(typeOfPreviousBussinessIcon, typeOfPreviousBussinessList);
            selectFormDropDownList(typeOfPreviousOccupationIcon, typeOfPreviousOccupationList);
        }
    }

    /**
     *
     * This method is to Verify Error Message for With out Country Input on the
     * Contact Details Page
     *
     */
    public void verificaitonForWithoutCountryInput() {
        Assert.assertTrue(errorIcon.isDisplayed(), UpdatePersonelInformationModel.FAILURE_MESSAGE);
        Reporter.log("Successfully Verified Error Message");
    }

    /**
     *
     * This method is to select the Employment Status from drop down list
     *
     */
    public String selectEmploymentStatus() {
        String employeeStatusSelected = StringUtils.EMPTY;
        employeeStatusIcon.click();
        if (!employmentStatusList.isEmpty()) {
            int listCount = employmentStatusList.size();
            int selectedElementNumber = RandomUtil.generateIntNumber(1, listCount);
            for (int count = 0; count < listCount; count++) {
                WebElement tempAccDropDown = employmentStatusList.get(count);
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", tempAccDropDown);
                if (count == selectedElementNumber) {
                    employeeStatusSelected = tempAccDropDown.getText();
                    Reporter.log("Account Selected:" + tempAccDropDown.getText());
                    tempAccDropDown.click();
                    break;
                }
            }
        } else {
            Assert.fail("List is Empty ");
        }
        return employeeStatusSelected;
    }


    /**
     *
     * This method is to select the values form drop down
     *
     */
    public void selectFormDropDownList(final WebElement dropDownIconElement, final List<WebElement> dropDownList) {
        dropDownIconElement.click();
        if (!dropDownList.isEmpty()) {
            int listCount = dropDownList.size();
            int selectedElementNumber = RandomUtil.generateIntNumber(1, listCount);
            for (int count = 0; count < listCount; count++) {
                WebElement tempDropDown = dropDownList.get(count);
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", tempDropDown);
                if (count == selectedElementNumber) {
                    Reporter.log("Account Selected:" + tempDropDown.getText());
                    tempDropDown.click();
                    break;
                }
            }
        } else {
            Assert.fail("List is Empty ");
        }
    }

    /**
     *
     * This method is to Click on Update Details Button
     *
     */
    public void clickOnUpdateDetails() {
        updateDetailsButton.click();
    }

    /**
     *
     * This method is to Click on Confirm Button
     *
     */
    public void clickOnConfirm() {
        confirmButton.click();
        verifyConfirmationMessage();
    }

    /**
     *
     * This method is to verify the confirmation message
     *
     */
    public void verifyConfirmationMessage() {
        Assert.assertEquals(UpdatePersonelInformationModel.SUCCESS_MESSAGE, successMessageLabel.getText());
    }

    /**
     *
     * This method is to Click on Back To MyAccounts Button
     *
     */
    public void clickOnBackToMyAccounts() {
        backToMyAccountsButton.click();
    }

    /**
     *
     * This method is to Click Cancel Button
     *
     */
    public void clickOnCancel() {
        cancelButton.click();
    }

    /**
     *
     * This method is to Click Edit Details Button
     *
     */
    public void clickOnEditDetailsButton() {
        ediDetailsButton.click();
    }

    /**
     *
     * This method is to verify edit functionality
     *
     */
    public void verifyEditDetailsFunctionality() {
        Assert.assertTrue(confirmButton.isDisplayed(), UpdatePersonelInformationModel.ERROR_MESSAGE);
    }

    /**
     *
     * This method is to Click to verify popup cancel flow
     *
     */
    public void verifyPopUpCancel() {
        popUpCancelButton.click();
        verifyDashBoardPageIsDisplayed();
    }

    /**
     *
     * This method is to Click and Verify PopUp Dont Cancel Button
     *
     */
    public void clickAndVerifyPopUpDontCancel() {
        popUpDontCancelButton.click();
        Assert.assertTrue(ediDetailsButton.isDisplayed(), UpdatePersonelInformationModel.ERROR_MESSAGE);
        Reporter.log("Successfully Verified PopUpDontCancel Button");

    }

    /**
     *
     * This method is to verify DashBoard Page
     *
     */
    public void verifyDashBoardPageIsDisplayed() {
        Assert.assertTrue(moveMoneyButton.isDisplayed(), UpdatePersonelInformationModel.ERROR_MESSAGE);
        Reporter.log("Successfully Verified Dash Board Page");
    }

    /**
     *
     * This method is to verify Pop up page
     *
     */
    public void verifyPopUpPage() {
        Assert.assertTrue(popUpCancelButton.isDisplayed(), UpdatePersonelInformationModel.ERROR_MESSAGE);
        Reporter.log("Successfully Verified PopUp Page");
    }


    public void verifyUpdatedDetailsOnCapturePage(AccountDetails objAccountDetails) {
        // Vaibhav : needs to be impletemented in Canada, refer cbh available
        // implemented function in cbh an ddo the chnages as per entity

    }

    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     *
     * @param profileProperties
     */
    public void verifyReviewPage(final Map<String, String> profileProperties, final AccountDetails objAccountDetails)
        throws IOException {
        // Vaibhav : needs to be impletemented in Canada, refer cbh available
        // implemented function in cbh an ddo the chnages as per entity

    }

    public void CancelFlowFromCapturePage() {
        clickOnCancel();
        verifyPopUpCancel();
    }

    public void CancelFlowFromReviewPage() {
        clickOnCancel();
        verifyPopUpCancel();
    }

    /** Blank implementations of functions for UK entity **/


    public void capturePageHeadingDisplayed() {}

    public String enterOnlineGreetingField() {
        return null;
    }

    public String enterNoOfDependentField() {
        return null;
    }

    public String enterEmailAddress() {
        return null;
    }

    public void clickOnConfirmButtonOnCapturePage() {}

    public void validateConfirmPage(UpdatePersonalInformation updatePersonalInformation) {}

    public void enterInvalidEmailAddress() {}

    public void invalidEmailAddressMessageDisplayed() {}

    public void clickOnOKButtonOnErrorPage() {}

    public void pageHeadingDisplayedOnCapturePage() {}

    public String enterMaritalStatus() {
        return null;
    }

    public UpdatePersonalInformation updatePersonalInfoCapturePage() {
        capturePageHeadingDisplayed();
        UpdatePersonalInformation updatePersonalInformation = new UpdatePersonalInformation();
        updatePersonalInformation.setOnlineGreeting(enterOnlineGreetingField());
        updatePersonalInformation.setNoOfDependent(enterNoOfDependentField());
        updatePersonalInformation.setMaritalStatus(enterMaritalStatus());
        updatePersonalInformation.setEmailAddress(enterEmailAddress());
        clickOnConfirmButtonOnCapturePage();
        return updatePersonalInformation;
    }

    public void printButtonDisplayed() {}

    public void myAccountsButtonDisplayed() {}

    public void confirmationMessageDisplayed() {}

    public void capturePageFlowForInvalidEmail() {
        capturePageHeadingDisplayed();
        enterInvalidEmailAddress();
        clickOnConfirmButtonOnCapturePage();
    }

	public void contactFieldLengthValidation() {

	}

	public void addressFieldDetailsValidation() {

	}

}
