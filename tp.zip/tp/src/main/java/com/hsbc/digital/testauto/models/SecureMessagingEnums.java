package com.hsbc.digital.testauto.models;

/*
 * This class is written for Enums defined for Story15-Secure Messaging Author
 * - Aniket Chinake
 */
public class SecureMessagingEnums {
    public enum ProblemReasonEnum {
        LATE_PAYMENT("Late Payment"), INCORRECT_PAY_AMT("Incorrect Payment Amount"), PAY_NOT_RECD("Payment Not Received"), OTHER_PAY_PROB(
            "Other Payment Problem");
        private final String value;

        private ProblemReasonEnum(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    public enum ProblemWithTxnArrayEnum {
        TRANSFER_NT_RECD("Transfer not received"), INCORRECT_AMT("Incorrect amount"), WRONG_ACC("Wrong account"), OTHER("Other");
        private final String value;

        private ProblemWithTxnArrayEnum(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    public enum TypeOfTxnArrayEnum {
        ALL_TXNS("All Types"), DEBIT_TXN("Debit transaction"), CREDIT_TXN("Credit transaction"), WITHDRW_TXN(
            "Withdrawal transaction"), CHECK_TXN("Check transaction"), DEPOSIT_TXN("Deposit transaction"), FEE_TXN(
            "Fee transaction"), CHANGE_TXN("Change transaction"), TAX_TXN("Tax transaction"), REBATE_TXN("Rebate transaction"), INTEREST_TXN(
            "Interest transaction"), CREDIT_INTRST_TXN("Credit interest transaction"), DEBIT_INTRST_TXN(
            "Debit interest transaction"), MANUAL_TXN("Manual transaction"), ADJUST_TXN("Adjusted transaction"), NONFIC_TXN(
            "Non-Financial transaction");
        private final String value;

        private TypeOfTxnArrayEnum(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    public enum PaymentFreqEnum {
        WEEKLY("Weekly"), BI_WEEKLY("Bi-weekly"), BI_MONTHLY("Bi-monthly"), MONTHLY("Monthly"), QUARTERLY("Quarterly"), HALF_YEARLY(
            "Halfyearly"), YEARLY("Yearly");
        private final String value;

        private PaymentFreqEnum(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

}
