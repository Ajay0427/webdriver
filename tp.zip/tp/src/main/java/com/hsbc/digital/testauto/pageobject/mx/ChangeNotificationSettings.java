/**
 * <p>
 * <b> This class will hold POM for story 11 - Notification Settings - MX entity
 * </b>
 * </p>
 *
 * @version 1.0.0
 * @author Bhargav Choudhury
 *
 */
package com.hsbc.digital.testauto.pageobject.mx;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Reporter;
import com.hsbc.digital.testauto.pageobject.ChangeNotificationSettingsModel;

public class ChangeNotificationSettings extends ChangeNotificationSettingsModel {

	private static final  String SUCCESS_MESSAGE = "Your preferences have been successfully saved.";

	@FindBy(xpath ="//input[contains(@id,'popup_gen')][@name='PIBSMS'][@aria-checked='false']")
    private WebElement subscriptionCheckBox;

	@FindBy(xpath = "//form[@data-dojo-attach-point='popupForm']//div[contains(@class,'submitButtonsPanel')]//following-sibling::button[contains(@class,'btnPrimary')]")
	private WebElement popUpSaveButton;

	@FindBy(xpath ="//div[contains(@class,'notificationSubmitMX')]//following-sibling::button[contains(@class,'btnPrimary')]")
	public WebElement mxSaveBtn;

	@FindBy(xpath ="//*[@id='notifSettings']//div[@data-dojo-attach-point='dapSettingsSaved']//p")
	public WebElement successMessage;

	public ChangeNotificationSettings(WebDriver driver) {
		super(driver);
	}

	public void subscribeAlerts(){

		subscribeButton.click();
        subscriptionCheckBox.click();
        popUpSaveButton.click();
        mxSaveBtn.click();
        if((successMessage.getText()).equals(SUCCESS_MESSAGE)){
        	Reporter.log(SUCCESS_MESSAGE);
        }else{
        	Reporter.log("Fail");
        }

	}

}
