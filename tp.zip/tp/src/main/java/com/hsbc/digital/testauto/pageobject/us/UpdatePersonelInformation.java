/**
 * <p>
 * <b> This class will hold locators and specific implementation for Update
 * Personal Information details US entity. </b>
 * @version 1.0.0
 * @author Bhargav Choudhury
 * </p>
 */

package com.hsbc.digital.testauto.pageobject.us;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hsbc.digital.testauto.pageobject.UpdatePersonelInformationModel;

public class UpdatePersonelInformation extends UpdatePersonelInformationModel {

	WebDriverWait wait;

	/*Test Data*/

	private static final String MAX_LENGTH = "maxlength";
	private static final String VALUE = "value";
	private static final String EMAIL_MAX_LENGTH = "65";
	private static final String EMAIL_MIN_LENGTH = "6";
	private static final String TWENTY_THREE_DIGIT_INPUT = "01234567895478963214023";
	private static final String THIRTY_DIGIT_INPUT = "896321402301234567893698521470";


	/*Contact & address details*/

	@FindBy(xpath = "//span[@data-dojo-attach-point='custPhoneMobile']")
    protected WebElement custPrimaryNumber;

	@FindBy(xpath = "//p[@data-dojo-attach-point='custPhoneHome']")
    protected WebElement custAlternateNumber;

	@FindBy(xpath = "//p[@data-dojo-attach-point='custPhoneWork']")
    protected WebElement custWorkNumber;

	@FindBy(xpath = "//p[@data-dojo-attach-point='custEmailAddress']")
	protected WebElement custEmailAddress;

	@FindBy(xpath = "//button[@data-dojo-attach-point='dapEditDetails']/span")
	protected WebElement editContactDetails;

	@FindBy(xpath = "//a[@data-dojo-attach-point='dapCorrespondenceTitle']")
	protected WebElement correspondenceTitle;

	/*Capture Page - Address details*/

	@FindBy(xpath = "//button[@data-dojo-attach-point='dapEditCustAddrDetails']/span")
	protected WebElement editCorrespondenceDetails;

	@FindBy(xpath = "//input[contains(@id,'corrPostCode')]//following-sibling::span")
	protected WebElement inputZipcode;

	@FindBy(xpath = "//input[contains(@id,'city')]//following-sibling::span")
	protected WebElement inputCity;

	/*Capture Page - Contact details*/

	@FindBy(xpath = "//input[contains(@id,'primNumbr')]//following-sibling::span")
	protected WebElement inputPrimaryNum;

	@FindBy(xpath = "//input[contains(@id,'inputAltNumber')]//following-sibling::span")
	protected WebElement inputAlternateNum;

	@FindBy(xpath = "//input[contains(@id,'inputWorkNumber')]//following-sibling::span")
	protected WebElement inputWorkNum;

	@FindBy(xpath = "//input[contains(@id,'extWorkNumber')]")
	protected WebElement inputWorkExtNum;

	@FindBy(xpath = "//input[contains(@id,'email')]//following-sibling::span")
	protected WebElement inputEmail;

	@FindBy(xpath = "//div[contains(@class,'customerDetailsFormSection')]//button[@data-dojo-attach-point='dapContinueButton']")
	protected WebElement editContactDetailsPageContinueBtn;

	@FindBy(xpath = "//div[contains(@class,'customerDetailsFormSection')]//button[@data-dojo-attach-point='dapCancelButton']")
	protected WebElement editContactDetailsPageCancelBtn;

    public UpdatePersonelInformation(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    public void contactFieldLengthValidation(){

    	wait.until(ExpectedConditions.elementToBeClickable(editContactDetails));
    	editContactDetails.click();

    	inputPrimaryNum.clear();
		inputPrimaryNum.sendKeys(TWENTY_THREE_DIGIT_INPUT);
		inputAlternateNum.clear();
		inputAlternateNum.sendKeys(TWENTY_THREE_DIGIT_INPUT);
		inputWorkNum.clear();
		inputWorkNum.sendKeys(TWENTY_THREE_DIGIT_INPUT);
		inputWorkExtNum.clear();
		inputWorkExtNum.sendKeys(TWENTY_THREE_DIGIT_INPUT);

		if((inputPrimaryNum.getAttribute(VALUE).length())!=(TWENTY_THREE_DIGIT_INPUT.length())){

			UpdatePersonelInformationModel.logger.info("PRIMARY NUMBER Cannot Input more than: "+inputPrimaryNum.getAttribute(VALUE).length());

		}else{
			UpdatePersonelInformationModel.logger.info("PRIMARY NUMBER Can Input more than: "+inputPrimaryNum.getAttribute(VALUE).length());
		}

		if((inputAlternateNum.getAttribute(VALUE).length())!=(THIRTY_DIGIT_INPUT.length())){

			UpdatePersonelInformationModel.logger.info("ALTERNATE NUMBER Cannot Input more than: "+inputAlternateNum.getAttribute(VALUE).length());

		}else{
			UpdatePersonelInformationModel.logger.info("ALTERNATE NUMBER Can Input more than: "+inputAlternateNum.getAttribute(VALUE).length());
		}

		if((inputWorkNum.getAttribute(VALUE).length())!=(TWENTY_THREE_DIGIT_INPUT.length())){

			UpdatePersonelInformationModel.logger.info("WORK NUMBER Cannot Input more than: "+inputWorkNum.getAttribute(VALUE).length());

		}else{
			UpdatePersonelInformationModel.logger.info("WORK NUMBER Can Input more than: "+inputWorkNum.getAttribute(VALUE).length());
		}

		if((inputWorkExtNum.getAttribute(VALUE).length())!=(TWENTY_THREE_DIGIT_INPUT.length())){

			UpdatePersonelInformationModel.logger.info("WORK EXT NUMBER Cannot Input more than: "+inputWorkExtNum.getAttribute(VALUE).length());

		}else{
			UpdatePersonelInformationModel.logger.info("WORK EXT NUMBER Can Input more than: "+inputWorkExtNum.getAttribute(VALUE).length());
		}


    	if(((inputEmail.getAttribute(MAX_LENGTH)).equalsIgnoreCase(EMAIL_MAX_LENGTH))&&((inputEmail.getAttribute("min")).equalsIgnoreCase(EMAIL_MIN_LENGTH))){

    		UpdatePersonelInformationModel.logger.info("MaxLength for Email: "+inputEmail.getAttribute(MAX_LENGTH));
    		UpdatePersonelInformationModel.logger.info("Min for Email: "+inputEmail.getAttribute("min"));


    	}else{
    		UpdatePersonelInformationModel.logger.info("MaxLength for Email is not: "+inputEmail.getAttribute(MAX_LENGTH));
    		UpdatePersonelInformationModel.logger.info("Min for Email is not: "+inputEmail.getAttribute("min"));
    	}

    }

    public void addressFieldLengthValidation(){
    	wait.until(ExpectedConditions.elementToBeClickable(editCorrespondenceDetails));
    	editCorrespondenceDetails.click();




    }

}
