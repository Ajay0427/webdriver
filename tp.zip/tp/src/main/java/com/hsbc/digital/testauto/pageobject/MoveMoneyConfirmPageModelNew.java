/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.MoveMoneyLabels;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.models.TransactionFrequency;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

/**
 * <p>
 * <b> Abstract Class is used to define all the common function required for
 * Confirm page of Move Money stories With Primary story being Story 39 </b>
 * 
 * @version 1.0.0
 * @author Neeraj Kumar & Pramesh
 * 
 *         </p>
 */
public abstract class MoveMoneyConfirmPageModelNew {

    protected final WebDriverWait wait;
    protected final UICommonUtil uiCommonUtil;
    private final WebDriver driver;
    /**
     * Field Label on Verify page
     */
    protected static final String SCROLL_TO_VIEW = "arguments[0].scrollIntoView(true);";
    protected static final String DEFAULT_PAYMENT_DATE_VALUE = "Now";
    private final String DATE_FORMAT = "EEEEE, dd MMMMM yyyy";
    protected static final String PAYMENT_RECURRING_VALUE = "Recurring ";
    private static final String LABEL_REFERENCE_NUMBER = "Reference number";
    protected static final String FEES_PAID_FOR_SENDINGFUND = "Party sending funds";
    protected Map<MoveMoneyLabels, String> labels;

    protected List<String> listLabels;

    @FindBy(xpath = "//div[contains(@id, 'Confirm')]")
    protected WebElement confirmPage;

    @FindBy(xpath = "//div[contains(@id, 'Confirm')]//div[contains(@class, 'steptracker-heading')]")
    protected WebElement confirmPageTitle;

    @FindBy(xpath = "//div[contains(@id, 'ConfirmOtrHSBCPymt')]//input[@value='New transfer']")
    protected WebElement newTransactionButton;

    @FindBy(xpath = "//*[@value='My accounts' or (contains(text(),'My accounts') and @data-dojo-attach-point='_accntSummaryNavigation')]")
    protected WebElement backtoMyAccountsButton;

    @FindBy(xpath = "//div[contains(@class, 'submitButtonsPanel')]//*[contains(@class, 'printIcon') or contains(@class, 'PrintIcon')]")
    private WebElement printButton;

    @FindBy(xpath = "//div[contains(@id, 'PrintFriendlyFormatDialog') and contains(@aria-labelledby, 'title')]")
    private WebElement printPage;

    @FindBy(xpath = "//div[contains(@id, 'PrintFriendlyFormatDialog')]//*[contains(@class, 'printFriendlyHeading')]")
    private WebElement printPageTitle;

    @FindBy(xpath = "//div[contains(@id, 'PrintFriendlyFormatDialog') and contains(@aria-labelledby, 'title')]//button[@data-dojo-attach-point= 'closeButton']")
    private WebElement cancelOnPrintDialogButton;

    @FindBy(xpath = "//div[contains(@id, 'PrintFriendlyFormatDialog') and contains(@aria-labelledby, 'title')]//button[@data-dojo-attach-point= 'printButton']")
    private WebElement printOnPrintDialogButton;

    private final By locatorReferenceNumber = By.xpath("//div[contains(@class, 'itemLabel') and contains(text(), '"
        + LABEL_REFERENCE_NUMBER + "')]//following-sibling::div[contains(@class, 'itemValue')]");

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(MoveMoneyConfirmPageModelNew.class);


    /**
     * // This initElements method will create all WebElements
     * 
     * @param driver
     */
    public MoveMoneyConfirmPageModelNew(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30000);
        uiCommonUtil = new UICommonUtil(driver);
        labels = new HashMap<>();
    }

    public void verifyConfirmPageTitle() {
        wait.until(ExpectedConditions.visibilityOf(confirmPageTitle));
        Assert.assertTrue(confirmPageTitle.isDisplayed(), "Confirm Page is not displayed.");
        Reporter.log("Confirm Page is displayed.");
    }

    public void verifyPrintPageTitle() {
        wait.until(ExpectedConditions.visibilityOf(printPageTitle));
        Assert.assertTrue(printPageTitle.isDisplayed(), "Print Page is not displayed.");
        Reporter.log("Print Page is displayed.");
    }

    public void clickNewTransactionButton() {
        wait.until(ExpectedConditions.elementToBeClickable(newTransactionButton));
        newTransactionButton.click();
        Reporter.log("Confirm button is clicked.");
    }

    public void clickBacktoMyAccountsButton() {
        wait.until(ExpectedConditions.elementToBeClickable(backtoMyAccountsButton));
        backtoMyAccountsButton.click();
        Reporter.log("Cancel button is clicked.");
    }

    public void clickPrintButton() {
        wait.until(ExpectedConditions.elementToBeClickable(printButton));
        printButton.click();
        Reporter.log("Edit Details button is clicked.");
    }

    public void clickCancelOnPrintDialog() {
        wait.until(ExpectedConditions.elementToBeClickable(cancelOnPrintDialogButton));
        cancelOnPrintDialogButton.click();
        wait.until(ExpectedConditions.not(ExpectedConditions.visibilityOf(printPage)));
        Reporter.log("Print page is closed.");
    }

    protected List<WebElement> getFieldLabels() {
        return driver.findElement(UICommonUtil.confirmPage).findElements(UICommonUtil.pageFieldLabels);
    }

    protected String getLabel(MoveMoneyLabels labelName) {
        return labels.get(labelName);
    }


    /**
     * Set the All Label as Displayed in UI
     * 
     */
    protected void setAllLabel() {
        Boolean[] fromAndToFlag = new Boolean[] {new Boolean(true)};
        labels.clear();
        List<WebElement> fieldLabels = getFieldLabels();
        for (WebElement elem : fieldLabels) {
            Boolean[] executionFlow = new Boolean[] {new Boolean(true)};
            if (elem.isDisplayed()) {
                setFromLabel(elem.getText(), executionFlow, fromAndToFlag);
                setToLabel(elem.getText(), executionFlow, fromAndToFlag);
                setDebitAmountLabel(elem.getText(), executionFlow);
                setYourReferenceLabel(elem.getText(), executionFlow);
                setStartDateLabel(elem.getText(), executionFlow);
                setRecurringLabel(elem.getText(), executionFlow);
                setFrequencyLabel(elem.getText(), executionFlow);
                setPaymentDateLabel(elem.getText(), executionFlow);
                setPayeeAccountNumberLabel(elem.getText(), executionFlow);
                setNumberOfPaymentLabel(elem.getText(), executionFlow);
                setPayeeReferenceLabel(elem.getText(), executionFlow);
                setPayeeAddressLabel(elem.getText(), executionFlow);
                setTransactionEndDateLabel(elem.getText(), executionFlow);
                setReasonForTransactionLabel(elem.getText(), executionFlow);
                setFeesPaidByLabel(elem.getText(), executionFlow);
                setCreditCurrency(elem.getText(), executionFlow);
                setPayeeNameLabel(elem.getText(), executionFlow);
            }
        }

    }

    public void setFromLabel(String label, Boolean[] successful, Boolean[] fromAndToFlag) {
        if (successful[0] && fromAndToFlag[0]) {
            List<String> preDefinedLabels = new ArrayList<>(Arrays.asList("From", "Account", "From Account"));
            if (preDefinedLabels.contains(label)) {
                labels.put(MoveMoneyLabels.LABEL_FROM, label);
                successful[0] = false;
                fromAndToFlag[0] = false;
            }
        }
    }

    public void setToLabel(String label, Boolean[] successful, Boolean[] fromAndToFlag) {
        if (successful[0] && !fromAndToFlag[0]) {
            List<String> preDefinedLabels = new ArrayList<>(Arrays.asList("To", "Account", "To Account", "Move money to",
                "Payee Account Number"));
            if (preDefinedLabels.contains(label)) {
                labels.put(MoveMoneyLabels.LABEL_TO, label);
                successful[0] = false;
            }
        }
    }

    public void setAmountLabel(String label, Boolean[] successful) {
        if (successful[0]) {
            List<String> preDefinedLabels = new ArrayList<>(Arrays.asList("Amount", "Transfer amount", "Debit amount"));
            if (preDefinedLabels.contains(label)) {
                labels.put(MoveMoneyLabels.LABEL_AMOUNT, label);
                successful[0] = false;
            }
        }
    }

    public void setCreditCurrency(String label, Boolean[] successful) {
        if (successful[0]) {
            List<String> preDefinedLabels = new ArrayList<>(Arrays.asList("Credit currency"));
            if (preDefinedLabels.contains(label)) {
                labels.put(MoveMoneyLabels.LABEL_CREDIT_CURRECNCY, label);
                successful[0] = false;
            }
        }
    }

    public void setDebitAmountLabel(String label, Boolean[] successful) {
        if (successful[0]) {
            List<String> preDefinedLabels = new ArrayList<>(Arrays.asList("Amount", "Transfer amount", "Debit amount",
                "Debit Amount"));
            if (preDefinedLabels.contains(label)) {
                labels.put(MoveMoneyLabels.LABEL_DEBIT_AMOUNT, label);
                successful[0] = false;
            }
        }
    }


    public void setYourReferenceLabel(String label, Boolean[] successful) {
        if (successful[0]) {
            List<String> preDefinedLabels = new ArrayList<>(Arrays.asList("Your reference"));
            if (preDefinedLabels.contains(label)) {
                labels.put(MoveMoneyLabels.LABEL_YOUR_REFERENCE, label);
                successful[0] = false;
            }
        }
    }

    public void setPaymentDateLabel(String label, Boolean[] successful) {
        if (successful[0]) {
            List<String> preDefinedLabels = new ArrayList<>(Arrays.asList("Payment date", "Transaction date"));
            if (preDefinedLabels.contains(label)) {
                labels.put(MoveMoneyLabels.LABEL_PAYMENT_DATE, label);
                successful[0] = false;
            }
        }
    }

    public void setPayeeAccountNumberLabel(String label, Boolean[] successful) {
        if (successful[0]) {
            List<String> preDefinedLabels = new ArrayList<>(Arrays.asList("Payee account number"));
            if (preDefinedLabels.contains(label)) {
                labels.put(MoveMoneyLabels.LABEL_PAYEEACCOUNTNUMBER, label);
                successful[0] = false;
            }
        }
    }


    public void setFrequencyLabel(String label, Boolean[] successful) {
        if (successful[0]) {
            List<String> preDefinedLabels = new ArrayList<>(Arrays.asList("Frequency"));
            if (preDefinedLabels.contains(label)) {
                labels.put(MoveMoneyLabels.LABEL_FREQUENCY, label);
                successful[0] = false;
            }
        }
    }

    public void setStartDateLabel(String label, Boolean[] successful) {
        if (successful[0]) {
            List<String> preDefinedLabels = new ArrayList<>(Arrays.asList("Start date", "Start Date", "Transaction start date"));
            if (preDefinedLabels.contains(label)) {
                labels.put(MoveMoneyLabels.LABEL_START_DATE, label);
                successful[0] = false;
            }
        }
    }

    public void setNumberOfPaymentLabel(String label, Boolean[] successful) {
        if (successful[0]) {
            List<String> preDefinedLabels = new ArrayList<>(Arrays.asList("Number of payments", "Number of transactions"));
            if (preDefinedLabels.contains(label)) {
                labels.put(MoveMoneyLabels.LABEL_NUMBER_OF_PAYMENT, label);
                successful[0] = false;
            }
        }
    }


    public void setRecurringLabel(String label, Boolean[] successful) {
        if (successful[0]) {
            List<String> preDefinedLabels = new ArrayList<>(Arrays.asList("Recurring ", "Recurring"));
            if (preDefinedLabels.contains(label)) {
                labels.put(MoveMoneyLabels.PAYMENT_RECURRING_VALUE, label);
                successful[0] = false;
            }
        }
    }

    public void setPayeeReferenceLabel(String label, Boolean[] successful) {
        if (successful[0]) {
            List<String> preDefinedLabels = new ArrayList<>(Arrays.asList("Payee's reference"));
            if (preDefinedLabels.contains(label)) {
                labels.put(MoveMoneyLabels.LABEL_PAYEE_REFERENCE, label);
                successful[0] = false;
            }
        }
    }

    public void setPayeeAddressLabel(String label, Boolean[] successful) {
        if (successful[0]) {
            List<String> preDefinedLabels = new ArrayList<>(Arrays.asList("Payee address"));
            if (preDefinedLabels.contains(label)) {
                labels.put(MoveMoneyLabels.LABEL_PAYEE_ADDRESS, label);
                successful[0] = false;
            }
        }
    }

    public void setTransactionEndDateLabel(String label, Boolean[] successful) {
        if (successful[0]) {
            List<String> preDefinedLabels = new ArrayList<>(Arrays.asList("Transaction end date"));
            if (preDefinedLabels.contains(label)) {
                labels.put(MoveMoneyLabels.LABEL_TRANSACTION_END_DATE, label);
                successful[0] = false;
            }
        }
    }

    public void setReasonForTransactionLabel(String label, Boolean[] successful) {
        if (successful[0]) {
            List<String> preDefinedLabels = new ArrayList<>(Arrays.asList("Reason for transaction", "Purpose of transaction"));
            if (preDefinedLabels.contains(label)) {
                labels.put(MoveMoneyLabels.LABEL_REASON_FOR_TRANSACTION, label);
                successful[0] = false;
            }
        }
    }

    public void setFeesPaidByLabel(String label, Boolean[] successful) {
        if (successful[0]) {
            List<String> preDefinedLabels = new ArrayList<>(Arrays.asList("Fees paid by"));
            if (preDefinedLabels.contains(label)) {
                labels.put(MoveMoneyLabels.LABEL_FEES_PAIDBY, label);
                successful[0] = false;
            }
        }
    }

    public void setPayeeNameLabel(String label, Boolean[] successful) {
        if (successful[0]) {
            List<String> preDefinedLabels = new ArrayList<>(Arrays.asList("Payee Name"));
            if (preDefinedLabels.contains(label)) {
                labels.put(MoveMoneyLabels.LABEL_PAYEENAME, label);
                successful[0] = false;
            }
        }
    }

    /**
     * Label Value Verification Methods
     * 
     */

    protected void isFromAccountNameDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(getLabel(MoveMoneyLabels.LABEL_FROM), accountDetail.getAccountName(),
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given From Account Name not found.");
        Reporter.log("From Account Name displayed is :" + accountDetail.getAccountName());
    }

    protected void isFromAccountNumberDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(getLabel(MoveMoneyLabels.LABEL_FROM),
            accountDetail.getAccountNumber(), UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given From Account Number not found.");
        Reporter.log("From Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    protected void isToAccountNameDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(getLabel(MoveMoneyLabels.LABEL_TO), accountDetail.getAccountName(),
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Name not found.");
        Reporter.log("To Account Name displayed is :" + accountDetail.getAccountName());
    }

    protected void isToAccountNumberDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(getLabel(MoveMoneyLabels.LABEL_TO), accountDetail.getAccountNumber(),
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given To Account Number not found.");
        Reporter.log("To Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    protected void isCreditCurrencyDisplayed(String currency) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(getLabel(MoveMoneyLabels.LABEL_CREDIT_CURRECNCY), currency,
            UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Credit Currency not found.");
        Reporter.log("Credit Currency displayed is :" + currency);
    }

    protected void isAmountDisplayed(String amount) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(getLabel(MoveMoneyLabels.LABEL_AMOUNT), amount,
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Transfer Amount not found.");
        Reporter.log("Amount displayed is :" + amount);
    }

    protected void isDebitAmountDisplayed(String amount) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(getLabel(MoveMoneyLabels.LABEL_DEBIT_AMOUNT), amount,
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Transfer Amount not found.");
        Reporter.log("Amount displayed is :" + amount);
    }

    protected void isPaymentDateDisplayed(String paymentDate) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(getLabel(MoveMoneyLabels.LABEL_PAYMENT_DATE), "Now",
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Payment Date not found.");
        Reporter.log("Payment Date displayed is :" + paymentDate);
    }

    protected void isPaymentDateAsLaterDateDisplayed(Transaction transaction) {
        String paymentDate;
        try {
            paymentDate = DateUtil.getDateToString(DATE_FORMAT, transaction.getLaterDate());
            Assert
                .assertTrue(uiCommonUtil.textByParentAndSibling(getLabel(MoveMoneyLabels.LABEL_PAYMENT_DATE), paymentDate,
                    UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
                    "Given Payment Date not found.");
            Reporter.log("Payment Date displayed is :" + paymentDate);
        } catch (ParseException e) {
            MoveMoneyConfirmPageModel.logger.error(e);
            Assert.fail("Parsing to Payment Date Fail " + e.getMessage(), e);
        }
    }

    protected void isYourReferenceTextDisplayed(String yourReference) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(getLabel(MoveMoneyLabels.LABEL_YOUR_REFERENCE), yourReference,
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given Your Reference Text not found.");
        Reporter.log("Your Reference Text displayed is :" + yourReference);
    }

    protected void isStartDateDisplayed(Transaction transaction) {
        try {
            String startDate = DateUtil.getDateToString(DATE_FORMAT, transaction.getFirstDateOfTransaction());
            Assert.assertTrue(uiCommonUtil.textByParentAndSibling(getLabel(MoveMoneyLabels.LABEL_START_DATE), startDate,
                UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Start Date not found.");
            Reporter.log("Start Date displayed is :" + startDate);
        } catch (ParseException e) {
            MoveMoneyCapturePageModel.logger.error(e);
            Assert.fail("Parsing to Payment Date Fail " + e.getMessage(), e);
        }

    }

    protected void isTransactionEndDateDisplayed(TransactionFrequency transactionFrequency) {
        Assert
            .assertTrue(
                uiCommonUtil.textByParentAndSibling(getLabel(MoveMoneyLabels.LABEL_TRANSACTION_END_DATE),
                    transactionFrequency.getValue(), UICommonUtil.confirmPage, UICommonUtil.pageFieldName,
                    UICommonUtil.pageFieldValue), "Given Transaction End Date dropdown value not found.");
        Reporter.log("Transaction End Date dropdown value displayed is :" + transactionFrequency.getValue());
    }

    protected void isFrequencyDisplayed(String frequencyValue) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(getLabel(MoveMoneyLabels.LABEL_FREQUENCY), frequencyValue,
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Frequency Value not found.");
        Reporter.log("Frequency Value displayed is :" + frequencyValue);
    }

    protected void isRecurringFrequencyDisplayed(String frequencyValue) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(getLabel(MoveMoneyLabels.LABEL_FREQUENCY), PAYMENT_RECURRING_VALUE
            + frequencyValue, UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given Frequency Value not found.");
        Reporter.log("Frequency Value displayed is :" + frequencyValue);
    }

    protected void isNumberOfPaymentDisplayed(String valueNOP) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(getLabel(MoveMoneyLabels.LABEL_NUMBER_OF_PAYMENT), valueNOP,
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given Number Of Payment not found.");
        Reporter.log("Number Of Payment displayed is :" + valueNOP);
    }

    protected void isReasonForTransaction(String reasonForTransaction) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(getLabel(MoveMoneyLabels.LABEL_REASON_FOR_TRANSACTION),
            reasonForTransaction, UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given Reason For Transaction not found.");
        Reporter.log("Reason For Transaction Field is Displayed :- " + reasonForTransaction);
    }

    protected void isFeesPaidByDisplayed(String feesPaidBy) {
        String feesPaidValue = StringUtils.EMPTY;
        if (feesPaidBy.equalsIgnoreCase(FEES_PAID_FOR_SENDINGFUND)) {
            feesPaidValue = "Charge to debit account";
        } else {
            feesPaidValue = "Charge to credit account";
        }
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(getLabel(MoveMoneyLabels.LABEL_FEES_PAIDBY), feesPaidValue,
            UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given Reason For Transaction not found.");
        Reporter.log("Fees Paid By displayed is :-" + feesPaidValue);
    }

    /* private void isPayeeAdressDisplayed(String address) {
         Assert
             .assertTrue(uiCommonUtil.textByParentAndSibling(getLabel(MoveMoneyLabels.LABEL_PAYEE_ADDRESS), address,
                 UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
                 "Given Number Of Payment not found.");
         Reporter.log("Number Of Payment displayed is :" + address);
     }
    */
    private void isPayeeNameDisplayed(String name) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(getLabel(MoveMoneyLabels.LABEL_PAYEENAME), name,
            UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Payee Name not found.");
        Reporter.log("Payeee Name displayed is :" + name);
    }

    protected void isPayeeReferenceTextDisplayed(String payeeReference) {
        Reporter.log("Payee Reference is not Applicable for Srilanka");
    }

    /**
     * Method to return transaction reference number from Confirm page
     */
    public Transaction referenceNumber(Transaction transactionDetail) {
        WebElement referenceNumberValue = confirmPage.findElement(locatorReferenceNumber);
        transactionDetail.setReferenceNumber(referenceNumberValue.getText());
        return transactionDetail;
    }

    /**
     * Common Verification Method
     */

    protected void validateNowFlow(Transaction transaction) {
        wait.until(ExpectedConditions.visibilityOf(confirmPageTitle));
        setAllLabel();
        isFromAccountNameDisplayed(transaction.getFromAccount());
        isFromAccountNumberDisplayed(transaction.getFromAccount());
        if (StringUtils.isNotEmpty(transaction.getToAccount().getAccountName())) {
            isToAccountNameDisplayed(transaction.getToAccount());
        }
        isToAccountNumberDisplayed(transaction.getToAccount());
        isPaymentDateDisplayed(DEFAULT_PAYMENT_DATE_VALUE);
        isYourReferenceTextDisplayed(transaction.getYourReference());
    }

    protected void validateLaterFlow(Transaction transaction) {
        wait.until(ExpectedConditions.visibilityOf(confirmPageTitle));
        setAllLabel();
        isFromAccountNameDisplayed(transaction.getFromAccount());
        isFromAccountNumberDisplayed(transaction.getFromAccount());
        if (StringUtils.isNotEmpty(transaction.getToAccount().getAccountName())) {
            isToAccountNameDisplayed(transaction.getToAccount());
        }
        isToAccountNumberDisplayed(transaction.getToAccount());
        isPaymentDateAsLaterDateDisplayed(transaction);
        isYourReferenceTextDisplayed(transaction.getYourReference());
    }


    protected void validateRecurringFlow(Transaction transaction) {
        wait.until(ExpectedConditions.visibilityOf(confirmPageTitle));
        setAllLabel();
        isFromAccountNameDisplayed(transaction.getFromAccount());
        isFromAccountNumberDisplayed(transaction.getFromAccount());
        if (StringUtils.isNotEmpty(transaction.getToAccount().getAccountName())) {
            isToAccountNameDisplayed(transaction.getToAccount());
        }

        isToAccountNumberDisplayed(transaction.getToAccount());
        isYourReferenceTextDisplayed(transaction.getYourReference());
        isStartDateDisplayed(transaction);
    }


    /************ Story Wise method *****************************/


    /******* Story 49 M2M Domestic Methods ****************/

    /********** M2M Domestic Methods ************/
    public void verifyM2MLCY2LCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Confirm Page.");
    }


    public void verifyM2MLCY2FCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2FCYNow Transaction Details verified on Confirm Page.");
    }

    public void verifyM2MFCY2LCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("FCY2LCYNow Transaction Details verified on Confirm Page.");
    }

    public void verifyM2MFCY2FCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("FCY2FCYNow Transaction Details verified on Confirm Page.");
    }

    /********* M2M Later Method **************/
    public void verifyM2MLCY2LCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Confirm Page.");
    }

    public void verifyM2MLCY2FCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2FCYLater Transaction Details verified on Confirm Page.");
    }

    public void verifyM2MFCY2LCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("FCY2LCYLater Transaction Details verified on Confirm Page.");
    }

    public void verifyM2MFCY2FCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("FCY2FCYLater Transaction Details verified on Confirm Page.");
    }

    /********** M2M Recurring Method **********/
    public void verifyM2MLCY2LCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }

    public void verifyM2MLCY2FCYRecurringTransactionDetailsOnConfirmPage(final Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2FCYRecurring Transaction Details Verified on Confirm Page");
    }

    public void verifyM2MFCY2LCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("FCY2LCYRecurring Transaction Details Verified on Confirm Page");
    }

    public void verifyM2MFCY2FCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isTransactionEndDateDisplayed(transactionDetail.getTransactionFrequency());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("FCY2LFYRecurring Transaction Details Verified on Confirm Page");
    }


    /******* Story 313 M2M Domestic Methods ****************/
    /**
     * M2M International Now Flow
     */
    public void verifyM2MInternationalLCY2LCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    public void verifyM2MInternationalFCY2FCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    /**** Later Flow ****/
    public void verifyM2MInternationalFCY2FCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isReasonForTransaction(transactionDetail.getReasonForTransaction());
        Reporter.log("FCY2FCYLater Transaction Details verified on Verify Page.");
    }

    /***** Recurring *****/
    public void verifyM2MFCY2FCYInternationalRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isTransactionEndDateDisplayed(transactionDetail.getTransactionFrequency());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        isReasonForTransaction(transactionDetail.getReasonForTransaction());
        Reporter.log("FCY2LFYRecurring Transaction Details Verified on Confirm Page");
    }

    /******* Story 39 M2NM Domestic Methods ****************/
    /**
     * M2NM Domestic Now Flow
     */
    /*** Existing ***/
    /*** HSBC ***/
    public void verifyM2NMLCY2LCYHsbcNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMLCY2FCYHsbcNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMFCY2LCYHsbcNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMFCY2FCYHsbcNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    /*** Non HSBC ****/
    public void verifyM2NMLCY2LCYNonHsbcNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMLCY2FCYNonHsbcNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMFCY2LCYNonHsbcNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMFCY2FCYNonHsbcNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    /*** **********In Line*********** ***/
    /*** HSBC ***/
    public void verifyM2NMLCY2LCYHsbcInlineNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMLCY2FCYHsbcInlineNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMFCY2LCYHsbcInlineNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMFCY2FCYHsbcInlineNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    /*** Non HSBC ****/
    public void verifyM2NMLCY2LCYNonHsbcInlineNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isPayeeNameDisplayed(transactionDetail.getToAccount().getAccountName());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMLCY2FCYNonHsbcInlineNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMFCY2LCYNonHsbcInlineNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMFCY2FCYNonHsbcInlineNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    /************** M2NM Later Method ****************/
    /*** Existing ***/
    /*** HSBC ***/
    public void verifyM2NMLCY2LCYHsbcLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMLCY2FCYHsbcLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMFCY2LCYHsbcLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMFCY2FCYHsbcLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Verify Page.");
    }

    /*** Non HSBC ****/
    public void verifyM2NMLCY2LCYNonHsbcLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMLCY2FCYNonHsbcLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMFCY2LCYNonHsbcLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMFCY2FCYNonHsbcLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Verify Page.");
    }

    /*** **********In line *******************/
    /*** HSBC ***/
    public void verifyM2NMLCY2LCYHsbcInlineLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMLCY2FCYHsbcInlineLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMFCY2LCYHsbcInlineLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMFCY2FCYHsbcInlineLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Verify Page.");
    }

    /*** Non HSBC ****/
    public void verifyM2NMLCY2LCYNonHsbcInlineLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMLCY2FCYNonHsbcInlineLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMFCY2LCYNonHsbcInlineLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMFCY2FCYNonHsbcInlineLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Verify Page.");
    }

    /********** M2NM Recurring Method **********/
    /*** Existing ***/
    /*** HSBC ***/
    public void verifyM2NMLCY2LCYHsbcRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }

    public void verifyM2NMLCY2FCYHsbcRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }

    public void verifyM2NMFCY2LCYHsbcRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }

    public void verifyM2NMFCY2FCYHsbcRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }

    /*** Non HSBC ****/
    public void verifyM2NMLCY2LCYNonHsbcRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }

    public void verifyM2NMLCY2FCYNonHsbcRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }

    public void verifyM2NMFCY2LCYNonHsbcRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }

    public void verifyM2NMFCY2FCYNonHsbcRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }

    /*** *************In line**************** ***/
    /*** HSBC ***/
    public void verifyM2NMLCY2LCYHsbcInlineRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }

    public void verifyM2NMLCY2FCYHsbcInlineRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }

    public void verifyM2NMFCY2LCYHsbcInlineRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }

    public void verifyM2NMFCY2FCYHsbcInlineRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }

    /*** Non HSBC ****/
    public void verifyM2NMLCY2LCYNonHsbcInlineRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }

    public void verifyM2NMLCY2FCYNonHsbcInlineRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }

    public void verifyM2NMFCY2LCYNonHsbcInlineRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }

    public void verifyM2NMFCY2FCYNonHsbcInlineRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }

    /******* Story 314 M2NM International Methods ****************/
    /**
     * M2NM International Now Flow
     */
    /***** Now Flow ****/
    public void verifyM2NMInternationalLCY2LCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isReasonForTransaction(transactionDetail.getReasonForTransaction());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMInternationalFCY2LCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isReasonForTransaction(transactionDetail.getReasonForTransaction());
        isFeesPaidByDisplayed(transactionDetail.getFeesPaidBy());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMInternationalFCY2FCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isReasonForTransaction(transactionDetail.getReasonForTransaction());
        isFeesPaidByDisplayed(transactionDetail.getFeesPaidBy());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    /***** Later Flow ****/
    public void verifyM2NMInternationalFCY2LCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isReasonForTransaction(transactionDetail.getReasonForTransaction());
        isFeesPaidByDisplayed(transactionDetail.getFeesPaidBy());
        isCreditCurrencyDisplayed(transactionDetail.getFromAccount().getCurrency());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    public void verifyM2NMInternationalFCY2FCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isReasonForTransaction(transactionDetail.getReasonForTransaction());
        isFeesPaidByDisplayed(transactionDetail.getFeesPaidBy());
        isCreditCurrencyDisplayed(transactionDetail.getFromAccount().getCurrency());
        Reporter.log("LCY2LCYNow Transaction Details verified on Verify Page.");
    }

    /***** Recurring Flow ****/
    public void verifyM2NMInternationalFCY2FCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        isReasonForTransaction(transactionDetail.getReasonForTransaction());
        isFeesPaidByDisplayed(transactionDetail.getFeesPaidBy());
        isCreditCurrencyDisplayed(transactionDetail.getFromAccount().getCurrency());
        Reporter.log("FCY2LFYRecurring Transaction Details Verified on Verify Page");
    }

    public void verifyM2NMInternationalFCY2LCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        isReasonForTransaction(transactionDetail.getReasonForTransaction());
        isFeesPaidByDisplayed(transactionDetail.getFeesPaidBy());
        isCreditCurrencyDisplayed(transactionDetail.getFromAccount().getCurrency());
        Reporter.log("FCY2LFYRecurring Transaction Details Verified on Verify Page");
    }

    /******* Story 312 M2Company Methods ****************/
    /**
     * M2C Now Existing Flow
     */
    public void verifyM2CLCY2LCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCY Now Transaction Details verified on Verify Page.");
    }

    public void verifyM2CFCY2LCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCY Now Transaction Details verified on Verify Page.");
    }

    public void verifyM2CLCY2LCYNowInlineTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCY Now Transaction Details verified on Verify Page.");
    }

    public void verifyM2CFCY2LCYNowInlineTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCY Now Transaction Details verified on Verify Page.");
    }

    /**
     * M2C Later Existing Flow
     */
    public void verifyM2CLCY2LCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCY Now Transaction Details verified on Verify Page.");
    }

    public void verifyM2CFCY2LCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCY Now Transaction Details verified on Verify Page.");
    }

    public void verifyM2CLCY2LCYLaterInlineTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCY Now Transaction Details verified on Verify Page.");
    }

    public void verifyM2CFCY2LCYLaterInlineTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCY Now Transaction Details verified on Verify Page.");
    }

    /**
     * M2C Recurring Existing Flow
     */
    public void verifyM2CLCY2LCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCY Now Transaction Details verified on Verify Page.");
    }

    public void verifyM2CFCY2LCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCY Now Transaction Details verified on Verify Page.");
    }

    public void verifyM2CLCY2LCYRecurringInlineTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCY Now Transaction Details verified on Verify Page.");
    }

    public void verifyM2CFCY2LCYRecurringInlineTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCY Now Transaction Details verified on Verify Page.");
    }
}
