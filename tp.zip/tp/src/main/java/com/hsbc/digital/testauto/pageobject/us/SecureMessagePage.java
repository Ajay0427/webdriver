/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.us;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.library.ScreenShot;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.SecureMessage;
import com.hsbc.digital.testauto.models.SecureMessagingEnums;
import com.hsbc.digital.testauto.pageobject.SecureMessageModel;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

/**
 * <p>
 * <b>This class will have locators and specific behaviours for Canada for
 * Secure Messaging story. </b>
 * </p>
 */
public class SecureMessagePage extends SecureMessageModel {

    private final WebDriverWait wait;
    private final WebDriver driver;
    private int messageCount = 0;
    private String msgTitle = null;
    private String amountValueTxnSummary = null;
    private String selectedAccNm = null;
    private String selectedAccNum = null;
    private final JavascriptExecutor jsx;
    private static final String SCROLL_TO_VIEW = "arguments[0].scrollIntoView(true);";
    private AccountDetails ad;
    private final SecureMessage sm;
    protected final UICommonUtil uiCommonUtil;

    @FindBy(xpath = "//h2[@data-dojo-attach-point='_heading']")
    public WebElement printPopUpHeading2;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_printButton']")
    private WebElement printButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='printButton']")
    private WebElement printPopUpPrintButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='closeButton']")
    private WebElement printPopUpCancelButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='closeButton']")
    private WebElement logoPrintPrev;

    @FindBy(xpath = ".//*[@id='delete']")
    private WebElement deleteMessageButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_deleteDialogYesBtn']")
    private WebElement deletePopupYesButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_deleteDialogNoBtn']")
    private WebElement deletePopupNoButton;

    @FindBy(xpath = ".//*[@id='dijit_form_DropDownButton_0_label']")
    private WebElement messageCenterIcon;

    @FindBy(xpath = "//a[@class='viewAllLink' and @data-dojo-attach-point='_viewAllMessagesLink']")
    private WebElement viewAllMsgLink;

    private final By viewAllMgsLocator = By.xpath("//a[@class='viewAllLink' and @data-dojo-attach-point='_viewAllMessagesLink']");

    private final By messageListLoader = By.xpath("//div[@id='MsgsListSidebar']//li[contains(@class,'loading')]");

    private final By messageListContainer = By.xpath("//div[contains(@class,'scrollPaneWrapper')]//ul[@class='listbox']");

    private final By menuText = By.cssSelector("[id$='_text']");

    protected final By menuPopup = By.cssSelector("div.dijitReset.dijitMenuItem[id*='_popup']");

    private final By activDialog = By.xpath("//div[contains(@class,'dijitDialogFixed') and not(contains(@style,'display: none'))]");

    @FindBy(xpath = "//span[@data-dojo-attach-point='_dapNickname']")
    public WebElement selectedAccNickname;

    @FindBy(xpath = "//p[@data-dojo-attach-point='_dapAccountNumber']")
    public WebElement selectedAccNumber;

    // @FindBy(xpath =
    // "//div[@aria-label='Transaction Summary']//div[@class='gridxMain']//tr[1]//a[contains(text(),'Report a problem')]")
    @FindBy(xpath = "//div[@aria-label='Transaction Summary']//div[@class='gridxMain']//tr[1]//a[contains(text(),'Need Help')]")
    protected WebElement reportAProblemLink;

    @FindBy(xpath = "//div[@aria-label='Transaction Summary']//div[@class='gridxMain']//tr[1]//a[contains(text(),'Need Help')]")
    protected List<WebElement> listReportAProblemLink;

    @FindBy(xpath = "//div[@aria-label='Transaction Summary']//div[@class='gridxMain']//tr[1]//span[@class='payeeItem0']")
    protected WebElement firstTxnDetails;

    @FindBy(xpath = "//div[@aria-label='Transaction Summary']//div[@class='gridxMain']//tr[1]//td[@colid='colAmount']")
    protected WebElement firstTxnAmount;

    @FindBy(xpath = "//div[contains(@id,'ReportTransactionDialog') and not(contains(@style,'display: none')) and @role='dialog']")
    protected WebElement reportingProblemDialog;

    @FindBy(xpath = "//div[@class='scrollWindow']//span[contains(@class,'row')]//span[@class='itemDetails'][contains(.,'CHECKING') or contains(.,'HSBC')]")
    protected List<WebElement> listCheckingAcc;

    @FindBy(xpath = "//h1//span[text()='My accounts']")
    protected WebElement dashboardPageTitle;

    // Submit billing dispute
    @FindBy(xpath = "//button[text()='Bill pay problem']")
    protected WebElement billPayProblemButton;

    @FindBy(xpath = "//h2[@data-dojo-attach-point='_submitBillingDisputeheading']")
    protected WebElement submitBillingDisputeTitle;

    @FindBy(xpath = "//div[contains(@class,'dijitMenuActive')]")
    protected WebElement activeMenuDropdown;

    @FindBy(xpath = "//input[contains(@id,'reasonForDispute')]")
    protected WebElement problemReasonArrow;

    @FindBy(xpath = "//input[contains(@id,'mername')]")
    protected WebElement payeeNameInput;

    @FindBy(xpath = "//textarea[contains(@id,'additionalComments')]")
    protected WebElement additionalCommentsBillingInput;

    @FindBy(xpath = "//label[@data-dojo-attach-point='additionalCommentLbl' or @data-dojo-attach-point='lblAdditionalComments']")
    protected WebElement additionalCommentsLabel;

    protected static final By visibleParentElement = By.xpath("//div[contains(@class,'dijitVisible')]");

    /******** Page Elements *******/
    protected final By pageFieldValue = By.xpath("//dd");

    protected final By pageFieldName = By.xpath("//dt");

    // Report a Transaction Problem
    @FindBy(xpath = "//button[text()='Other problem']")
    protected WebElement otherProblemButton;

    @FindBy(xpath = "//h2[@data-dojo-attach-point='mainHeading']")
    protected WebElement reportAProblemTitle;

    // @FindBy(xpath = "//input[contains(@id,'transactionType')]")
    @FindBy(xpath = "//div[contains(@id,'transactionType')]//following-sibling::div//input[contains(@id,'Select')]")
    protected WebElement typeOfTransactionArrow;

    // @FindBy(xpath = "//input[contains(@id,'problemReason')]")
    @FindBy(xpath = "//div[contains(@id,'problemReason')]//following-sibling::div//input[contains(@id,'Select')]")
    protected WebElement problemWithTxnArrow;

    @FindBy(xpath = "//div[text()='Payment amount' or text()='Amount']//following-sibling::div//span[@name='currencyField1ReadOnly']")
    protected WebElement amountValue;

    @FindBy(xpath = "//textarea[contains(@id,'additionalComments')]")
    protected WebElement additionalCommentsInput;

    @FindBy(xpath = "//button[text()='Continue']")
    protected WebElement continueButton;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//button[@data-dojo-attach-point='cancelCaptureBtn' or @data-dojo-attach-point='cancelVerifyBtn']")
    protected WebElement cancelButton;

    @FindBy(xpath = "//div[contains(@class,'dijitDialogFixed') and not(contains(@style,'display: none'))]")
    protected List<WebElement> listCancelDialog;

    @FindBy(xpath = "//div[contains(@class,'dijitDialogFixed')]//button[@data-dojo-attach-point='cancelCaptureDialogYes' or @data-dojo-attach-point='cancelVerifyDialogYes']")
    protected WebElement cancelPopUpYesButton;

    @FindBy(xpath = "//div[contains(@class,'dijitDialogFixed')]//button[@data-dojo-attach-point='cancelCaptureDialogNo' or @data-dojo-attach-point='cancelVerifyDialogNo']")
    protected WebElement cancelPopUpNoButton;

    @FindBy(xpath = "//span[contains(@data-dojo-attach-point,'requiredCommentMessage')]")
    protected WebElement errorMandatoryComment;

    // Verify page
    @FindBy(xpath = "//span[text()='Edit']//ancestor::span[contains(@id,'Button') and @role='button']")
    protected WebElement editButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='sendVerifyBtn' or @data-dojo-attach-point='btnSendVerify']")
    protected WebElement sendButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='dashboardBtn' or @data-dojo-attach-point='msgCenterBtn' or @data-dojo-attach-point='btnDashboard']")
    protected WebElement myAccountsBtn;

    // smart search
    // @FindBy(xpath =
    // "//span[@title='Search']//ancestor::span[1][contains(@class,'Button')]")
    @FindBy(xpath = "//span[@title='Search'][@class='icon']")
    protected WebElement searchBtnDashbrd;

    @FindBy(xpath = "//input[contains(@id,'fromAmount') and contains(@id,'CurrencyTextBox')]")
    protected WebElement fromAmountInput;

    @FindBy(xpath = "//input[contains(@id,'toAmount') and contains(@id,'CurrencyTextBox')]")
    protected WebElement toAmountInput;

    @FindBy(xpath = "//button[@title='View results']")
    protected WebElement viewResultsBtn;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_reviewtransnotlisted'][text()='Check not listed' or text()='Transaction not listed']")
    protected WebElement transactionNtListedBtn;

    // Report a problem with a bill payment page with smart search
    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//input[contains(@id,'SecureMsgsAccountSelect')]")
    protected WebElement accountDropArrow;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//input[contains(@id,'transactionDate') and contains(@class,'dijitArrowButtonInner')]")
    protected WebElement transactionDateIcon;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//input[contains(@id,'postingdate') or contains(@id,'transactionDate')][contains(@class,'dijitArrowButtonInner')]")
    protected WebElement apprPostingDateIcon;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//div[text()='Payment frequency (optional)']//following-sibling::div//input[contains(@id,'Select')]")
    protected WebElement paymentFreqDropArrow;

    @FindBy(xpath = "//table[contains(@id,'postingdate_popup') or contains(@id,'transactionDate_popup')]")
    protected WebElement approPostingDateTable;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//input[contains(@id,'transactionAmountOptional_CurrencyTextBox')]")
    protected WebElement paymentAmountInput;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//input[contains(@id,'transactionAmount_CurrencyTextBox')]")
    protected WebElement amountInput;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//div[@class='title prodDesc']")
    protected WebElement selectedAcctName;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//span[@class='row']//span[contains(@class,'accountDetails')]")
    protected WebElement selectedAcctNumber;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//input[contains(@id,'postingdate') and @role='textbox']//following-sibling::input")
    protected WebElement dateDisplayedValue;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//label[text()='Approximate posting date']")
    protected WebElement apprPostingDateLabel;

    @FindBy(xpath = "//div[contains(@class,'dijitMenuActive')]//tr//td[contains(@id,'text')]")
    protected List<WebElement> dropdownElemList;

    /*Request Check Image*/
    @FindBy(xpath = "//input[contains(@id,'dateFrom')][contains(@class,'dijitArrowButtonInner')]")
    protected WebElement fromDateIconSearch;

    @FindBy(xpath = "//input[contains(@id,'dateTo')][contains(@class,'dijitArrowButtonInner')]")
    protected WebElement toDateIconSearch;

    @FindBy(xpath = "//table[contains(@class,'dijitCalendarFocused')]")
    protected WebElement dateActiveTable;

    @FindBy(xpath = "//input[contains(@id,'fromChequeValue')]")
    protected WebElement fromCheckRange;

    @FindBy(xpath = "//input[contains(@id,'toChequeValue')]")
    protected WebElement toCheckRange;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_reviewtransnotlisted'][text()='Check not listed']")
    protected WebElement checkNotListedBtn;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//input[contains(@id,'DateTextBox')][contains(@class,'dijitArrowButtonInner')]")
    protected WebElement datePostedToAccIcon;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//label[contains(text(),'Check number')]//following-sibling::div//input[contains(@id,'ValidationTextBox')]")
    protected WebElement checkNumberInput;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//div//input[contains(@id,'Amount') and contains(@id,'CurrencyTextBox_CurrencyTextBox') and not(contains(@id,'arrowid'))]")
    protected WebElement amountInputbox;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//input[contains(@id,'_Select')]")
    protected WebElement reasonForRequestArrow;

    @FindBy(xpath = "//textarea[contains(@id,'SimpleTextarea_')]")
    protected WebElement pleaseGiveDetailsInput;

    @FindBy(xpath = "//p[contains(@data-dojo-attach-point,'lblAdditionalCommentsLen')]")
    protected WebElement errorMandatoryDetails;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//button[@data-dojo-attach-point='btnCancelCapture' or @data-dojo-attach-point='btnCancelVerify']")
    protected WebElement cancelCheckImgButton;

    @FindBy(xpath = "//div[contains(@class,'dijitDialogFixed')]//button[@data-dojo-attach-point='btnCancelCaptureDialogYes' or @data-dojo-attach-point='btnCancelVerifyDialogYes']")
    protected WebElement cancelCheckImgPopUpYesButton;

    @FindBy(xpath = "//div[contains(@class,'dijitDialogFixed')]//button[@data-dojo-attach-point='btnCancelCaptureDialogNo' or @data-dojo-attach-point='btnCancelVerifyDialogNo']")
    protected WebElement cancelCheckImgPopUpNoButton;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(SecureMessagePage.class);

    public SecureMessagePage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        this.driver = driver;
        wait = new WebDriverWait(driver, 30);
        jsx = (JavascriptExecutor) driver;
        uiCommonUtil = new UICommonUtil(driver);
        sm = new SecureMessage();
    }

    public String selectAccountDashboard(final AccountDetails accountDetails, final List<WebElement> list) {
        int randomIndex = RandomUtil.generateIntNumber(1, list.size());
        String accountText = StringUtils.EMPTY;
        for (int index = 0; index < list.size(); index++) {
            WebElement element = list.get(index);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
            if ((accountDetails != null && element.getText().contains(accountDetails.getAccountNumber()))
                || (accountDetails == null && index == randomIndex)) {
                accountText = element.getText();
                element.click();
                break;
            }
        }
        return accountText;
    }

    protected void selectValueDropdown(final WebElement arrowDrop, final WebElement menuDrop, final String valueToSelect) {
        arrowDrop.click();
        wait.until(ExpectedConditions.visibilityOf(menuDrop));
        List<WebElement> valueElements = menuDrop.findElements(menuText).isEmpty() ? menuDrop.findElements(menuPopup) : menuDrop
            .findElements(menuText);
        for (WebElement valueElement : valueElements) {
            jsx.executeScript(SCROLL_TO_VIEW, valueElement);
            if (valueElement.getText().contains(valueToSelect)) {
                wait.until(ExpectedConditions.elementToBeClickable(valueElement));
                valueElement.click();
                Reporter.log(valueToSelect + " is selected in dropdown.");
                break;
            }
        }
    }

    @Override
    public void printMessage() {
        printButton.click();
        wait.until(ExpectedConditions.visibilityOf(printPopUpHeading2));
        Reporter.log("Print pop up displayed");
        if (printPopUpPrintButton.isDisplayed() && printPopUpCancelButton.isDisplayed()) {
            Reporter.log("Print and Cancel buttons are displayed");
            ScreenShot.takeScreenShot(driver);
            printPopUpCancelButton.click();
        } else {
            Reporter.log("Print and Cancel buttons are not displayed");
            Assert.fail("Print pop up not verified.");
        }
    }

    @Override
    public void deleteCurrentMessage(final boolean deleteConfirmation) {
        msgTitle = super.readMessage();
        String xpath = "//span[@class='subject']//span[contains(text(),'" + msgTitle + "')]";
        messageCount = driver.findElements(By.xpath(xpath)).size();
        deleteMessageButton.click();
        if (deletePopupYesButton.isDisplayed() && deletePopupNoButton.isDisplayed()) {
            logger.info("Delete message pop up verified.");
        }
        ScreenShot.takeScreenShot(driver);
        if (deleteConfirmation) {
            deletePopupYesButton.click();
            Reporter.log("Yes button is clicked on Delete confirmation.");
        } else {
            deletePopupNoButton.click();
            logger.info("No button is clicked on Delete confirmation.");
        }
    }

    @Override
    public void isMessageExist(final String messageTitle) {
        String xpath = "//span[@class='subject']//span[contains(text(),'" + msgTitle + "')]";
        int oldCount = messageCount;
        messageCount = driver.findElements(By.xpath(xpath)).size();
        if (messageCount == oldCount) {
            Assert.fail("Deleted Message exist");
        } else {
            logger.info("Message deleted successfully :" + messageTitle);
        }
    }

    @Override
    public void navigateToMessageCenter() {
        messageCenterIcon.click();
        wait.until(ExpectedConditions.presenceOfElementLocated(viewAllMgsLocator));
        viewAllMsgLink.click();
        wait.until(ExpectedConditions.presenceOfElementLocated(messageListContainer));
        wait.until(ExpectedConditions.invisibilityOfElementLocated(messageListLoader));
    }

    @Override
    public void navigateToReportProblem(WebElement btn) {
        selectAccountDashboard(ad, listCheckingAcc);
        while (listReportAProblemLink.isEmpty()) {
            selectAccountDashboard(ad, listCheckingAcc);
        }
        selectedAccNm = selectedAccNickname.getText().trim();
        selectedAccNum = selectedAccNumber.getText().trim();
        sm.setAccountName(selectedAccNm);
        sm.setAccountNumber(selectedAccNum);
        reportAProblemLink.click();
        amountValueTxnSummary = firstTxnAmount.getText();
        sm.setPaymentAmount(amountValueTxnSummary);
        wait.until(ExpectedConditions.visibilityOf(reportingProblemDialog));
        if (btn.equals(billPayProblemButton)) {
            billPayProblemButton.click();
            wait.until(ExpectedConditions.visibilityOf(submitBillingDisputeTitle));
            ScreenShot.takeScreenShot(driver);
        } else if (btn.equals(otherProblemButton)) {
            otherProblemButton.click();
            wait.until(ExpectedConditions.visibilityOf(reportAProblemTitle));
            ScreenShot.takeScreenShot(driver);
        }
    }

    @Override
    public void navigateToSubmitBillingDispute() {
        navigateToReportProblem(billPayProblemButton);
    }

    @Override
    public void navigateToReportTxnProblem() {
        navigateToReportProblem(otherProblemButton);
    }

    @Override
    public void enterBillingDisputeDetailsTxnSummary(boolean additionalComments) {
        String problemReason;
        String payeeName = DEFAULT_PAYEE_NAME;
        sm.setPayeeName(payeeName);
        if (amountValue.getText().equalsIgnoreCase(amountValueTxnSummary)) {
            logger.info("Amount value displayed as per the amount displayed on Transaction summary");
        } else
            logger.error("Amount value is not displayed as per the amount displayed on Transaction summary");
        payeeNameInput.clear();
        payeeNameInput.sendKeys(payeeName);
        if (additionalComments) {
            problemReason = SecureMessagingEnums.ProblemReasonEnum.OTHER_PAY_PROB.getValue();
            selectValueDropdown(problemReasonArrow, activeMenuDropdown, problemReason);
            continueButton.click();
            wait.until(ExpectedConditions.visibilityOf(errorMandatoryComment));
            if (errorMandatoryComment.isDisplayed())
                logger.info(errorMandatoryComment.getText() + " error displayed");
            else
                logger.error("No error displayed");
            ScreenShot.takeScreenShot(driver);
            additionalCommentsInput.sendKeys(SecureMessageModel.DEFAULT_ADDITIONAL_COMMENT);
            additionalCommentsLabel.click();
            sm.setAdditionalComments(SecureMessageModel.DEFAULT_ADDITIONAL_COMMENT);
            sm.setProblemReason(problemReason);
        } else {
            problemReason = selectRandomValue(problemReasonArrow);
            sm.setProblemReason(problemReason);
        }
        ScreenShot.takeScreenShot(driver);
    }

    @Override
    public void clickContinueButton() {
        continueButton.click();
    }

    @Override
    public void clickEditButton() {
        editButton.click();
    }

    @Override
    public void clickSendButton() {
        sendButton.click();
    }

    @Override
    public void clickMyAccounts() {
        myAccountsBtn.click();
        wait.until(ExpectedConditions.visibilityOf(dashboardPageTitle));
        logger.info("Navigated to Dashboard page");

    }

    @Override
    public void enterReportProblemDetailsTxnSummary(boolean additionalComments) {
        String typeOfTxn;
        String problemWithTxn;
        typeOfTxn = selectRandomValue(typeOfTransactionArrow);
        sm.setTypeOfTxn(typeOfTxn);
        if (amountValue.getText().equalsIgnoreCase(amountValueTxnSummary)) {
            logger.info("Amount value displayed as per the amount displayed on Transaction summary");
        } else
            logger.error("Amount value is not displayed as per the amount displayed on Transaction summary");

        if (additionalComments) {
            problemWithTxn = SecureMessagingEnums.ProblemWithTxnArrayEnum.OTHER.getValue();
            selectValueDropdown(problemWithTxnArrow, activeMenuDropdown, problemWithTxn);
            continueButton.click();
            wait.until(ExpectedConditions.visibilityOf(errorMandatoryComment));
            if (errorMandatoryComment.isDisplayed())
                logger.info(errorMandatoryComment.getText() + " error displayed");
            else
                logger.error("No error displayed");
            ScreenShot.takeScreenShot(driver);
            additionalCommentsInput.sendKeys(SecureMessageModel.DEFAULT_ADDITIONAL_COMMENT);
            additionalCommentsLabel.click();
            sm.setAdditionalComments(SecureMessageModel.DEFAULT_ADDITIONAL_COMMENT);
            sm.setProblemWithTxn(problemWithTxn);
        } else {
            problemWithTxn = selectRandomValue(problemWithTxnArrow);
            sm.setProblemWithTxn(problemWithTxn);
        }
        ScreenShot.takeScreenShot(driver);
    }

    @Override
    public void cancelBillingDispute(final boolean isConfirm) {
        cancelProblem(isConfirm);
    }

    @Override
    public void cancelProblem(final boolean isConfirm) {
        cancelButton.click();
        while (listCancelDialog.isEmpty()) {
            cancelButton.click();
        }
        if (isConfirm) {
            cancelPopUpYesButton.click();
            wait.until(ExpectedConditions.invisibilityOfElementLocated(activDialog));
            logger.info("Cancel button clicked from Pop up.");
        } else {
            cancelPopUpNoButton.click();
            wait.until(ExpectedConditions.invisibilityOfElementLocated(activDialog));
            logger.info("Don't Cancel button clicked from Pop up.");
            wait.until(ExpectedConditions.elementToBeClickable(cancelButton));
        }
    }

    @Override
    public void verifyProblem(final WebElement pageTitle, final boolean isCancel) {
        if (isCancel && dashboardPageTitle.isDisplayed()) {
            Reporter.log("Older session doesnot exists and Cancel successful");
        } else if (!isCancel && pageTitle.isDisplayed()) {
            Reporter.log("Older session exists");
        } else {
            Assert.fail("Report problem cancellation not worked");
        }
    }

    @Override
    public void verifyCancelSubmitBillingDispute(boolean isCancel) {
        verifyProblem(submitBillingDisputeTitle, isCancel);
    }

    @Override
    public void verifyCancelReportTxnProblem(boolean isCancel) {
        verifyProblem(reportAProblemTitle, isCancel);
    }

    @Override
    public void validateSubmitBillingDispute() {
        isAccountNumberDisplayed(sm);
        isAccountNameDisplayed(sm);
        isProblemReasonDisplayed(sm);
        isPaymentAmountDisplayed(sm);
        isPayeeNameDisplayed(sm);
        ScreenShot.takeScreenShot(driver);
    }

    @Override
    public void validateReportTxnProblem() {
        isAccountNumberDisplayed(sm);
        isAccountNameDisplayed(sm);
        isTypeOfTxnDisplayed(sm);
        isAmountDisplayed(sm);
        isProblemWithTxnDisplayed(sm);
        ScreenShot.takeScreenShot(driver);
    }

    @Override
    public void navigateToRprtPrblmSmartSearch(WebElement btn) {
        selectAccountDashboard(ad, listCheckingAcc);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By
            .xpath("//span[@class='ajaxLoader'][@style='display: inline-block;']")));
        searchBtnDashbrd.click();
        if (!fromAmountInput.isDisplayed())
            searchBtnDashbrd.click();
        wait.until(ExpectedConditions.visibilityOf(fromAmountInput));
        fromAmountInput.sendKeys("0");
        toAmountInput.sendKeys("100");
        viewResultsBtn.click();
        wait.until(ExpectedConditions.visibilityOf(transactionNtListedBtn));
        transactionNtListedBtn.click();
        wait.until(ExpectedConditions.visibilityOf(reportingProblemDialog));
        if (btn.equals(billPayProblemButton)) {
            billPayProblemButton.click();
            wait.until(ExpectedConditions.visibilityOf(submitBillingDisputeTitle));
            ScreenShot.takeScreenShot(driver);
        } else if (btn.equals(otherProblemButton)) {
            otherProblemButton.click();
            wait.until(ExpectedConditions.visibilityOf(reportAProblemTitle));
            ScreenShot.takeScreenShot(driver);
        }
    }

    @Override
    public void navigateToBillingDisputeSmartSearch() {
        navigateToRprtPrblmSmartSearch(billPayProblemButton);
    }

    @Override
    public void navigateToTxnProblemSmartSearch() {
        navigateToRprtPrblmSmartSearch(otherProblemButton);
    }

    public Date enterPrevPostingDate(final Map<String, String> envProperties, int daysSubAdd) throws ParseException {
        return uiCommonUtil.selectDate(apprPostingDateIcon, approPostingDateTable, prevDate(envProperties, daysSubAdd));
    }

    public Date enterFromCheckRangeDate(final Map<String, String> envProperties, int daysSubAdd) throws ParseException {
        return uiCommonUtil.selectDate(fromDateIconSearch, dateActiveTable, prevDate(envProperties, daysSubAdd));
    }

    public Date enterToCheckRangeDate(final Map<String, String> envProperties, int daysSubAdd) throws ParseException {
        return uiCommonUtil.selectDate(toDateIconSearch, dateActiveTable, prevDate(envProperties, daysSubAdd));
    }

    public Date enterDatePostedToAcc(final Map<String, String> envProperties, int daysSubAdd) throws ParseException {
        return uiCommonUtil.selectDate(datePostedToAccIcon, dateActiveTable, prevDate(envProperties, daysSubAdd));
    }

    @Override
    public void enterBillingDisputeDetailsSmartSearch(final Map<String, String> envProperties, boolean additionalComments)
        throws ParseException {
        String accountName;
        String accountNumber;
        Date postingDate;
        String problemReason;
        String paymentFreq;
        accountName = selectedAcctName.getText();
        accountNumber = selectedAcctNumber.getText();
        sm.setAccountName(accountName);
        sm.setAccountNumber(accountNumber);
        postingDate = enterPrevPostingDate(envProperties, SecureMessageModel.DEFAULT_DAYS_TO_SUB_FOR_VALID_PREV_DATE);
        apprPostingDateLabel.click();
        sm.setApprPostingDate(postingDate);
        paymentFreq = selectRandomValue(paymentFreqDropArrow);
        sm.setPaymentFreq(paymentFreq);
        paymentAmountInput.clear();
        paymentAmountInput.sendKeys(SecureMessageModel.DEFAULT_PAYMENT_AMOUNT);
        sm.setPaymentAmount(SecureMessageModel.DEFAULT_PAYMENT_AMOUNT);
        payeeNameInput.clear();
        payeeNameInput.sendKeys(SecureMessageModel.DEFAULT_PAYEE_NAME);
        sm.setPayeeName(SecureMessageModel.DEFAULT_PAYEE_NAME);
        if (additionalComments) {
            problemReason = SecureMessagingEnums.ProblemReasonEnum.OTHER_PAY_PROB.getValue();
            selectValueDropdown(problemReasonArrow, activeMenuDropdown, problemReason);
            continueButton.click();
            wait.until(ExpectedConditions.visibilityOf(errorMandatoryComment));
            if (errorMandatoryComment.isDisplayed())
                logger.info(errorMandatoryComment.getText() + " error displayed");
            else
                logger.error("No error displayed");
            ScreenShot.takeScreenShot(driver);
            additionalCommentsInput.sendKeys(SecureMessageModel.DEFAULT_ADDITIONAL_COMMENT);
            additionalCommentsLabel.click();
            sm.setAdditionalComments(SecureMessageModel.DEFAULT_ADDITIONAL_COMMENT);
            sm.setProblemReason(problemReason);
        } else {
            problemReason = selectRandomValue(problemReasonArrow);
            sm.setProblemReason(problemReason);
        }
        ScreenShot.takeScreenShot(driver);
    }

    @Override
    public void enterReportProblemDetailsSmartSearch(final Map<String, String> envProperties, boolean additionalComments)
        throws ParseException {
        String accountName;
        String accountNumber;
        String typeOfTxn;
        String problemWithTxn;
        Date txnDate;
        accountName = selectedAcctName.getText();
        accountNumber = selectedAcctNumber.getText();
        sm.setAccountName(accountName);
        sm.setAccountNumber(accountNumber);
        typeOfTxn = selectRandomValue(typeOfTransactionArrow);
        sm.setTypeOfTxn(typeOfTxn);
        txnDate = enterPrevPostingDate(envProperties, SecureMessageModel.DEFAULT_DAYS_TO_SUB_FOR_VALID_PREV_DATE);
        sm.setTransactionDate(txnDate);
        amountInput.clear();
        amountInput.sendKeys(SecureMessageModel.DEFAULT_PAYMENT_AMOUNT);
        sm.setPaymentAmount(SecureMessageModel.DEFAULT_PAYMENT_AMOUNT);
        if (additionalComments) {
            problemWithTxn = SecureMessagingEnums.ProblemWithTxnArrayEnum.OTHER.getValue();
            selectValueDropdown(problemWithTxnArrow, activeMenuDropdown, problemWithTxn);
            continueButton.click();
            wait.until(ExpectedConditions.visibilityOf(errorMandatoryComment));
            if (errorMandatoryComment.isDisplayed())
                logger.info(errorMandatoryComment.getText() + " error displayed");
            else
                logger.error("No error displayed");
            ScreenShot.takeScreenShot(driver);
            additionalCommentsInput.sendKeys(SecureMessageModel.DEFAULT_ADDITIONAL_COMMENT);
            additionalCommentsLabel.click();
            sm.setAdditionalComments(SecureMessageModel.DEFAULT_ADDITIONAL_COMMENT);
            sm.setProblemWithTxn(problemWithTxn);
        } else {
            problemWithTxn = selectRandomValue(problemWithTxnArrow);
            sm.setProblemWithTxn(problemWithTxn);
        }
        ScreenShot.takeScreenShot(driver);
    }

    /**
     * Method to return valid later or recurring date, avoiding Saturday/Sunday
     * 
     * @throws ParseException
     */
    private Date prevDate(final Map<String, String> envProperties, int daysToSubAdd) throws ParseException {
        Date parseDate = validDate(envProperties);
        Calendar cal = Calendar.getInstance();
        cal.setTime(parseDate);
        cal.add(Calendar.DAY_OF_YEAR, daysToSubAdd);
        int dayofWeek = cal.get(Calendar.DAY_OF_WEEK);
        if (dayofWeek == Calendar.SATURDAY) {
            cal.add(Calendar.DAY_OF_YEAR, SecureMessageModel.DEFAULT_DAYS_TO_SUB_TO_AVOID_SATURDAY);
            parseDate = cal.getTime();
        } else if (dayofWeek == Calendar.SUNDAY) {
            cal.add(Calendar.DAY_OF_YEAR, SecureMessageModel.DEFAULT_DAYS_TO_SUB_TO_AVOID_SUNDAY);
            parseDate = cal.getTime();
        } else {
            parseDate = cal.getTime();
        }
        return parseDate;
    }

    /**
     * Method to return hub date and if its not specified, return system date
     * 
     * @throws ParseException
     */
    private static Date validDate(final Map<String, String> envProperties) throws ParseException {
        if (!envProperties.get(SecureMessageModel.HUB_DATE).trim().isEmpty()) {
            return DateUtil.getStringToDate(envProperties.get(SecureMessageModel.HUB_DATE_FORMAT),
                envProperties.get(SecureMessageModel.HUB_DATE));
        } else {
            return new Date();
        }
    }

    @Override
    public void validateBillingDisputeSmartSearch() throws ParseException {
        isAccountNumberDisplayed(sm);
        isAccountNameDisplayed(sm);
        isProblemReasonDisplayed(sm);
        isPostingDateDisplayed(sm);
        isPaymentFrequency(sm);
        isPaymentAmountDisplayed(sm);
        isPayeeNameDisplayed(sm);
        ScreenShot.takeScreenShot(driver);
    }

    @Override
    public void validateReportTxnProblemSmartSearch() throws ParseException {
        isAccountNumberDisplayed(sm);
        isAccountNameDisplayed(sm);
        isTypeOfTxnDisplayed(sm);
        isTxnDateDisplayed(sm);
        isAmountDisplayed(sm);
        isProblemWithTxnDisplayed(sm);
        ScreenShot.takeScreenShot(driver);
    }

    public String selectRandomValue(WebElement dropdownArrow) {
        String uiReason = null;
        dropdownArrow.click();
        int randomIndex = RandomUtil.generateIntNumber(DEFAULT_INDEX, dropdownElemList.size() - 1);
        for (WebElement reasonRow : dropdownElemList) {
            jsx.executeScript(SCROLL_TO_VIEW, reasonRow);
            if (reasonRow.isDisplayed() && reasonRow.equals(dropdownElemList.get(randomIndex))) {
                uiReason = reasonRow.getText();
                reasonRow.click();
                break;
            }
        }
        return uiReason;
    }

    @Override
    public void verifySuccessMsgDisplayed() {
        wait.until(ExpectedConditions.visibilityOf(confirmPage));
        Assert.assertTrue(successMessage.isDisplayed(), "Success message displayed !");
    }

    @Override
    public void waitForReviewPageBillingDispute() {
        wait.until(ExpectedConditions.visibilityOf(reviewBillingDisputeTitle));
    }

    @Override
    public void waitForReviewPageTxnProblem() {
        wait.until(ExpectedConditions.visibilityOf(reviewTxnProbReportTitle));
    }

    @Override
    protected void isAccountNumberDisplayed(SecureMessage sm) {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_ACCOUNT, sm.getAccountNumber(), visibleParentElement,
            this.pageFieldName, this.pageFieldValue), "Account number not found.");
        SecureMessagePage.logger.info("Account Number displayed is :" + sm.getAccountNumber());
        Reporter.log("Account Number displayed is :" + sm.getAccountNumber());
    }

    @Override
    protected void isAccountNameDisplayed(SecureMessage sm) {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_ACCOUNT, sm.getAccountName(), visibleParentElement,
            this.pageFieldName, this.pageFieldValue), "Account Name not found.");
        SecureMessagePage.logger.info("Account Name displayed is :" + sm.getAccountName());
        Reporter.log("Account Name displayed is :" + sm.getAccountName());
    }

    @Override
    protected void isProblemReasonDisplayed(SecureMessage sm) {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_PROBLEM_REASON, sm.getProblemReason(),
            visibleParentElement, this.pageFieldName, this.pageFieldValue), "Problem reason not found.");
        SecureMessagePage.logger.info("Problem reason displayed is :" + sm.getProblemReason());
        Reporter.log("Problem reason displayed is :" + sm.getProblemReason());
    }

    @Override
    protected void isPaymentAmountDisplayed(SecureMessage sm) {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_PAYMENT_AMOUNT, sm.getPaymentAmount(),
            visibleParentElement, this.pageFieldName, this.pageFieldValue), "Payment amount not found.");
        SecureMessagePage.logger.info("Payment amount displayed is :" + sm.getPaymentAmount());
        Reporter.log("Payment amount displayed is :" + sm.getPaymentAmount());
    }

    @Override
    protected void isPayeeNameDisplayed(SecureMessage sm) {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_PAYEE_NAME, sm.getPayeeName(), visibleParentElement,
            this.pageFieldName, this.pageFieldValue), "Payee name not found.");
        SecureMessagePage.logger.info("Payee name displayed is :" + sm.getPayeeName());
        Reporter.log("Payee name displayed is :" + sm.getPayeeName());
    }

    @Override
    public void isAdditionalCommentsDisplayed() {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_ADDITIONAL_COMMENTS, sm.getAdditionalComments(),
            visibleParentElement, this.pageFieldName, this.pageFieldValue), "Additional Comment not found.");
        SecureMessagePage.logger.info("Additional comment displayed is :" + sm.getAdditionalComments());
        Reporter.log("Additional comment displayed is :" + sm.getAdditionalComments());
    }

    @Override
    protected void isAmountDisplayed(SecureMessage sm) {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_AMOUNT, sm.getPaymentAmount(), visibleParentElement,
            this.pageFieldName, this.pageFieldValue), "Amount not found.");
        SecureMessagePage.logger.info("Amount displayed is :" + sm.getPaymentAmount());
        Reporter.log("Amount displayed is :" + sm.getPaymentAmount());
    }

    @Override
    protected void isTypeOfTxnDisplayed(SecureMessage sm) {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_TYPE_OF_TXN, sm.getTypeOfTxn(), visibleParentElement,
            this.pageFieldName, this.pageFieldValue), "Type of Transaction not found.");
        SecureMessagePage.logger.info("Type of Transaction displayed is :" + sm.getTypeOfTxn());
        Reporter.log("Type of Transaction displayed is :" + sm.getTypeOfTxn());
    }

    @Override
    protected void isProblemWithTxnDisplayed(SecureMessage sm) {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_PROBLEM_WITH_TXN, sm.getProblemWithTxn(),
            visibleParentElement, this.pageFieldName, this.pageFieldValue), "Problem with Transaction not found.");
        SecureMessagePage.logger.info("Problem with Transaction displayed is :" + sm.getProblemWithTxn());
        Reporter.log("Problem with Transaction displayed is :" + sm.getProblemWithTxn());
    }

    @Override
    protected void isPaymentFrequency(SecureMessage sm) {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_PAYMENT_FREQUENCY, sm.getPaymentFreq(),
            visibleParentElement, this.pageFieldName, this.pageFieldValue), "Payment Frequency not found.");
        SecureMessagePage.logger.info("Payment Frequency displayed is :" + sm.getPaymentFreq());
        Reporter.log("Payment Frequency displayed is :" + sm.getPaymentFreq());
    }

    @Override
    protected void isPostingDateDisplayed(SecureMessage sm) throws ParseException {
        String postingDate = DateUtil.getDateToString(SecureMessagePage.DATE_FORMAT, sm.getApprPostingDate());
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_APPROX_POSTING_DATE, postingDate, visibleParentElement,
            this.pageFieldName, this.pageFieldValue), "Given Approximate Posting Date not found.");
        SecureMessagePage.logger.info("Approx posting Date displayed is :" + postingDate);

    }

    @Override
    protected void isTxnDateDisplayed(SecureMessage sm) throws ParseException {
        String txnDate = DateUtil.getDateToString(SecureMessagePage.DATE_FORMAT, sm.getTransactionDate());
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_TRANSACTION_DATE, txnDate, visibleParentElement,
            this.pageFieldName, this.pageFieldValue), "Given Transaction Date not found.");
        SecureMessagePage.logger.info("Transaction Date displayed is :" + txnDate);
    }

    @Override
    public void navigateToRequestCheckImage(final Map<String, String> envProperties) throws ParseException {
        selectAccountDashboard(ad, listCheckingAcc);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By
            .xpath("//span[@class='ajaxLoader'][@style='display: inline-block;']")));
        searchBtnDashbrd.click();
        wait.until(ExpectedConditions.visibilityOf(fromAmountInput));
        enterFromCheckRangeDate(envProperties, DEFAULT_DAYS_TO_SUB_FOR_VALID_TWO_YEAR_OLD_DATE);
        enterToCheckRangeDate(envProperties, DEFAULT_DAYS_TO_SUB_FOR_VALID_PREV_DATE);
        fromCheckRange.sendKeys(DEFAULT_FROM_RANGE);
        toCheckRange.sendKeys(DEFAULT_TO_RANGE);
        viewResultsBtn.click();
        wait.until(ExpectedConditions.visibilityOf(checkNotListedBtn));
        checkNotListedBtn.click();
        wait.until(ExpectedConditions.visibilityOf(requestCheckImageTitle));
        ScreenShot.takeScreenShot(driver);
    }

    @Override
    public void enterDetailsOnRequestCheckImage(final Map<String, String> envProperties, boolean otherDetails)
        throws ParseException {
        String checkNumber = RandomUtil.generateIntNumber(10);
        String reasonForRequest;
        String amount = DEFAULT_PAYMENT_AMOUNT;
        Date postedDate;
        String accountName = selectedAcctName.getText();
        String accountNumber = selectedAcctNumber.getText();
        sm.setAccountName(accountName);
        sm.setAccountNumber(accountNumber);
        postedDate = enterDatePostedToAcc(envProperties, DEFAULT_DAYS_TO_SUB_FOR_VALID_PREV_DATE);
        sm.setDatePostedToAccount(postedDate);
        checkNumberInput.sendKeys(checkNumber);
        sm.setCheckNumber(checkNumber);
        amountInputbox.sendKeys(amount);
        sm.setPaymentAmount(amount);
        if (otherDetails) {
            reasonForRequest = REASON_FOR_REQUEST_OTHER_OPTION;
            selectValueDropdown(reasonForRequestArrow, activeMenuDropdown, reasonForRequest);
            continueButton.click();
            wait.until(ExpectedConditions.visibilityOf(errorMandatoryDetails));
            if (errorMandatoryDetails.isDisplayed())
                logger.info(errorMandatoryDetails.getText() + " error displayed");
            else
                logger.error("No error displayed");
            ScreenShot.takeScreenShot(driver);
            pleaseGiveDetailsInput.sendKeys(SecureMessageModel.DEFAULT_OTHER_DETAILS);
            additionalCommentsLabel.click();
            sm.setOtherDetails(DEFAULT_OTHER_DETAILS);
            sm.setReasonForRequest(reasonForRequest);
        } else {
            reasonForRequest = selectRandomValue(reasonForRequestArrow);
            sm.setReasonForRequest(reasonForRequest);
        }
        ScreenShot.takeScreenShot(driver);
    }

    @Override
    public void cancelCheckImgReq(final boolean isConfirm) {
        cancelCheckImgButton.click();
        while (listCancelDialog.isEmpty()) {
            cancelCheckImgButton.click();
        }
        if (isConfirm) {
            cancelCheckImgPopUpYesButton.click();
            wait.until(ExpectedConditions.invisibilityOfElementLocated(activDialog));
            logger.info("Cancel button clicked from Pop up.");
        } else {
            cancelCheckImgPopUpNoButton.click();
            wait.until(ExpectedConditions.invisibilityOfElementLocated(activDialog));
            logger.info("Don't Cancel button clicked from Pop up.");
            wait.until(ExpectedConditions.elementToBeClickable(cancelCheckImgButton));
        }
    }

    @Override
    public void verifyCancelCheckImage(final boolean isCancel) {
        if (isCancel && dashboardPageTitle.isDisplayed()) {
            Reporter.log("Older session doesnot exists and Cancel successful");
        } else if (!isCancel && requestCheckImageTitle.isDisplayed()) {
            Reporter.log("Older session exists");
        } else {
            Assert.fail("Request for Check Image cancellation not worked");
        }
    }

    @Override
    public void validateRequestCheckImg() throws ParseException {
        isAccountNumberDisplayed(sm);
        isAccountNameDisplayed(sm);
        isDatePostedToAccDisplayed(sm);
        isCheckNumber(sm);
        isAmountDisplayed(sm);
        isReasonForRequest(sm);
        ScreenShot.takeScreenShot(driver);
    }

    @Override
    public void waitForReviewReqCheckImg() {
        wait.until(ExpectedConditions.visibilityOf(reviewReqCheckImgTitle));
    }

    @Override
    protected void isCheckNumber(SecureMessage sm) {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_CHECK_NUMBER, sm.getCheckNumber(), visibleParentElement,
            this.pageFieldName, this.pageFieldValue), "Check Number not found.");
        SecureMessagePage.logger.info("Check Number displayed is :" + sm.getCheckNumber());
        Reporter.log("Check Number displayed is :" + sm.getCheckNumber());
    }

    @Override
    protected void isReasonForRequest(SecureMessage sm) {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_REASON_FOR_REQUEST, sm.getReasonForRequest(),
            visibleParentElement, this.pageFieldName, this.pageFieldValue), "Reason for request not found.");
        SecureMessagePage.logger.info("Reason for request displayed is :" + sm.getReasonForRequest());
        Reporter.log("Reason for request displayed is :" + sm.getReasonForRequest());
    }

    @Override
    protected void isDatePostedToAccDisplayed(SecureMessage sm) throws ParseException {
        String datePostedToAcc = DateUtil.getDateToString(SecureMessagePage.DATE_FORMAT, sm.getDatePostedToAccount());
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_DATE_POSTED_TO_ACCOUNT, datePostedToAcc, visibleParentElement,
            this.pageFieldName, this.pageFieldValue), "Given Date Posted to Account not found.");
        SecureMessagePage.logger.info("Date Posted to account displayed is :" + datePostedToAcc);
    }

    @Override
    public void isDetails() {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_DETAILS, sm.getOtherDetails(), visibleParentElement,
            this.pageFieldName, this.pageFieldValue), "Other details not found.");
        SecureMessagePage.logger.info("Other Details displayed is :" + sm.getOtherDetails());
        Reporter.log("Othere details displayed is :" + sm.getOtherDetails());
    }
}
