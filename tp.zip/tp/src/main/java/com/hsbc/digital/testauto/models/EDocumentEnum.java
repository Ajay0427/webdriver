/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.models;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class EDocumentEnum {
    public enum dropDownSortingOptions {
        DATE_NEWEST("Date newest"), DATE_OLDEST("Date oldest"), ACCOUNT_NAME_AZ("Account name (A-Z)"), ACCOUNT_NAME_ZA(
            "Account name (Z-A)"), ACCOUNT_NUMBER_09("Account Number (0-9)"), ACCOUNT_NUMBER_90("Account Number (9-0)");
        private final String value;

        private dropDownSortingOptions(final String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }
}
