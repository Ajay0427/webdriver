package com.hsbc.digital.testauto.pageobject.us;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.models.TransactionFlow;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModelNew;

public class MoveMoneyCapturePageAU extends MoveMoneyCapturePageModelNew {

    private final static Map<String, String> companyReferenceValue = new HashMap<>();

    @FindBy(xpath = "//div[@data-dojo-attach-point='_pyeChargesNode']//div[contains(@class,'dijitDownArrowButton')]//input[contains(@id,'arrowid')]")
    private WebElement payeeChargeIcon;

    @FindBy(xpath = "//div[@data-dojo-attach-point='_purOfPymtbijit']//div[contains(@class,'dijitDownArrowButton')]//input[contains(@id,'arrowid')]")
    private WebElement reasonForTransactionIcon;

    @FindBy(xpath = "//input[(contains(@id,'SelectPayee')) and (@aria-required='true')]")
    private WebElement myPayees;

    @FindBy(xpath = "//div[contains(@class,'newTransactionMyPayees')]")
    private List<WebElement> newTransMyPayees;

    @FindBy(xpath = "//div[@data-dojo-attach-point='_trnsfrLimitAttach']")
    private WebElement minAmountLabel;

    @FindBy(xpath = "//input[contains(@id,'CurrencyTextBox')]")
    private WebElement amountField;

    @FindBy(css = "span[class$='newTransactionMyPayeesCountryFlag']")
    protected WebElement myPayeeText;

    private static final Map<TransactionFlow, By> transferAmountElements = new HashMap<>();

    private static final String ENTITY_BANK_COUNTRY = "United states of america";
    private static final int DEFAULT_DECIMAL_PLACES = 2;
    private static final int AMOUNT_START_RANGE = 100;
    private static final int AMOUNT_END_RANGE = 200;

    static {
        transferAmountElements.put(TransactionFlow.M2MINTERNATIONAL_TRANSFER, LocatorM2MInternationalAmountfield);
        transferAmountElements.put(TransactionFlow.M2M_TRANSFER, locatorM2MAmountField);
        transferAmountElements.put(TransactionFlow.M2NMHSBC_TRANSFER, locatorM2NMHSBCAmountField);
        transferAmountElements.put(TransactionFlow.M2NMNONHSBC_TRANSFER, locatorNonHSBCAmountField);
        transferAmountElements.put(TransactionFlow.M2NMINTERNATIONAL_TRANSFER, locatorInternationalAmountField);
        transferAmountElements.put(TransactionFlow.M2COMPANY_TRANSFER, locatorM2CompanyAmountField);
    }

    public MoveMoneyCapturePageAU(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);

    }
    static {
        companyReferenceValue.put("SRI LANKA TELECOM ( ALL SERVICES )", "12");
        companyReferenceValue.put("MOBITEL (PVT) LTD", "10");
    }

    @Override
    public String selectFeesPaidBy() {
        return selectRandamValue(payeeChargeIcon, listDropdown);
    }

    @Override
    public String selectReasonForTransaction(Transaction transaction) {
        return selectRandamValue(reasonForTransactionIcon, listDropdown);
    }

    @Override
    public AccountDetails enterNewCompanyPayeeDetails() {
        AccountDetails accountDetails = new AccountDetails();
        clickTabsToOpenNewCompanyPayeeDetails();
        Object[] values = companyReferenceValue.keySet().toArray();
        Object key = values[new Random().nextInt(values.length)];
        selectValue(companyListDropIcon, listMenuItems, key.toString());
        accountDetails.setAccountName(key.toString());
        String companyReference = RandomUtil.generateIntNumber(Integer.parseInt(companyReferenceValue.get(key)));
        companyReferenceText.clear();
        companyReferenceText.sendKeys(companyReference);
        companyReferenceText.sendKeys(Keys.RETURN);
        accountDetails.setAccountNumber(companyReference);
        return accountDetails;
    }

    @Override
    protected AccountDetails enterNewPayeeDetails(String payeeName, String payeeAccountNumber) {
        AccountDetails accountDetails = new AccountDetails();
        accountNumberText.clear();
        accountNumberText.sendKeys(payeeAccountNumber);
        accountDetails.setAccountNumber(payeeAccountNumber);
        accountNumberText.sendKeys(Keys.RETURN);
        return accountDetails;
    }

    @Override
    public String enterPayeeReferenceText() {
        return StringUtils.EMPTY;

    }

    @Override
    public String enterAddress() {
        return StringUtils.EMPTY;
    }

    @Override
    protected String myPayeeAcctName() {
        return myPayeeText.getText();
    }

    @Override
    public void processInternationalPayeeSelection(AccountDetails accountDetail) {
        clickMyPayeeTab();
        myPayees.sendKeys(accountDetail.getAccountNickName());
        if (newTransMyPayees.size() == 1) {
            newTransMyPayees.get(0).click();
        } else if (newTransMyPayees.size() > 1) {
            selectMatchingMyPayee(accountDetail);
        } else {
            Assert.fail("Either My payees list not displayed or no valid payee shown. | ");
        }
        logger.info("Account with Name: " + accountDetail.getAccountName() + " and Number: " + accountDetail.getAccountNumber()
            + " is selected.| ");
        Reporter.log("Account with Name: " + accountDetail.getAccountName() + " and Number: " + accountDetail.getAccountNumber()
            + " is selected.| ");
        logger.info(accountDetail.getAccountNickName() + " selected as \'My payees\' . | ");
        Reporter.log(accountDetail.getAccountNickName() + " selected as \'My payees\' . | ");
    }

    private void selectMatchingMyPayee(AccountDetails accountDetail) {
        for (int eachPayee = 0; eachPayee < newTransMyPayees.size(); eachPayee++) {
            String myPayeeCountry = newTransMyPayees.get(eachPayee).getText().split("\\r?\\n")[1];
            if (myPayeeCountry.equalsIgnoreCase(accountDetail.getAccountCountry())) {
                newTransMyPayees.get(eachPayee).click();
                break;
            }
        }
    }

    @Override
    public String enterTransferAmount(Transaction transactionDetail) {
        String amount = StringUtils.EMPTY;
        if (transactionDetail.getFromAccount().getDoubleAccountBalance() < AMOUNT_START_RANGE) {
            logger.error("Available balance is not enough to proceed with the transaction.");
            Assert.fail("Available balance is not enough to proceed with the transaction.");
        } else if (transactionDetail.getFromAccount().getDoubleAccountBalance() < AMOUNT_END_RANGE) {
            int endRange = transactionDetail.getFromAccount().getDoubleAccountBalance().intValue();
            amount = RandomUtil.generateDoubleNumber(AMOUNT_START_RANGE, endRange, DEFAULT_DECIMAL_PLACES);
        } else {
            amount = RandomUtil.generateDoubleNumber(AMOUNT_START_RANGE, AMOUNT_END_RANGE, DEFAULT_DECIMAL_PLACES);
        }
        WebElement fieldAmount = getAmountField(transactionDetail);
        jsx.executeScript(SCROLL_TO_VIEW, fieldAmount);
        fieldAmount.clear();
        fieldAmount.sendKeys(amount);
        Reporter.log("Transfer Amount entered is: " + amount);
        return amount;
    }

    @Override
    protected WebElement getAmountField(Transaction transactionDetail) {
        return driver.findElement(transferAmountElements.get(transactionDetail.getTransactionFlow()));
    }

    @Override
    protected String getEntityBankCountry() {
        return ENTITY_BANK_COUNTRY;
    }
}
