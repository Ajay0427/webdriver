package com.hsbc.digital.testauto.pageobject.uk;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.hsbc.digital.testauto.pageobject.MoveMoneyConfirmPageModel;

public class MoveMoneyConfirmPage extends MoveMoneyConfirmPageModel {

    public MoveMoneyConfirmPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

}
