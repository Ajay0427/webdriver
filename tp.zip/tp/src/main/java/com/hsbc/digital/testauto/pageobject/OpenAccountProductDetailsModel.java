/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

/***
 * <p>
 * <b> This model class will hold locators and functionality for Open Account
 * Product details page. </b>
 * </p>
 * 
 * @author SatyaPrakash S Vyas
 * @version 1.0.0
 */
public abstract class OpenAccountProductDetailsModel {

    private final WebDriverWait wait;

    @FindBy(xpath = "//button[@data-dojo-attach-point='findOutMore']")
    private WebElement findOutMoreButton;

    @FindBy(xpath = "//span[text()='Apply']")
    private WebElement applyNowButton;

    @FindBy(xpath = "//div[contains(@id,'actopening')]//h2[text()='US Dollar eTerm Deposit']/following-sibling::button[@data-dojo-attach-point='applyNow']")
    private WebElement applyNowUSDollerTD;

    @FindBy(xpath = "//div[@data-dojo-attach-point='tablistWrapper']/descendant::div[contains(@class,'dijitTabInner')]/span[text()='GIC']")
    private WebElement gICTab;

    @FindBy(xpath = "//div[contains(@id,'actopening')]//h2[text()='Non Redeemable eGIC (Simple interest)']/following-sibling::button[@data-dojo-attach-point='applyNow']")
    private WebElement applyNowNonRedeemableSimpleInterestGIC;

    @FindBy(xpath = "//div[contains(@id,'actopening')]//h2[text()='Non Redeemable eGIC (Compounded interest)']/following-sibling::button[@data-dojo-attach-point='applyNow']")
    private WebElement applyNowNonRedeemableCompoundedInterestGIC;

    @FindBy(xpath = "//div[contains(@id,'actopening')]//h2[text()='Redeemable eGIC']/following-sibling::button[@data-dojo-attach-point='applyNow']")
    private WebElement applyNowRedeemableGIC;

    @FindBy(xpath = "//div[contains(@id,'actopening')]//h2[text()='TFSA High Rate Savings']/following-sibling::button[@data-dojo-attach-point='applyNow']")
    private WebElement applyNowTFSASaving;

    @FindBy(xpath = "//div[contains(@id,'actopening')]//h2[text()='TFSA Redeemable eGIC']/following-sibling::button[@data-dojo-attach-point='applyNow']")
    private WebElement applyNowTFSARedeemableGIC;

    @FindBy(xpath = "//div[contains(@id,'actopening')]//h2[text()='TFSA eTerm Deposit']/following-sibling::button[@data-dojo-attach-point='applyNow']")
    private WebElement applyNowTFSAeTerm;

    @FindBy(xpath = "//div[contains(@id,'actopening')]//h2[contains(text(),'High-Rate Savings')]/following-sibling::button[@data-dojo-attach-point='applyNow']")
    private WebElement applyNowHighRateSaving;

    @FindBy(xpath = "//div[@data-dojo-attach-point='tablistWrapper']/descendant::div[contains(@class,'dijitTabInner')]/span[text()='Foreign currency savings']")
    private WebElement foreignCurrencySavingTab;

    @FindBy(xpath = "//div[contains(@id,'actopening')]//h2[contains(text(),'high rate savings')]/following-sibling::button[@data-dojo-attach-point='applyNow']")
    private WebElement applyNowForeignCurrencyHighRateSaving;

    @FindBy(xpath = "//div[contains(@id,'actopening')]//h2[contains(text(),'regular savings')]/following-sibling::button[@data-dojo-attach-point='applyNow']")
    private WebElement applyNowForeignCurrencyRegularSaving;

    @FindBy(xpath = "//div[@data-dojo-attach-point='tablistWrapper']/descendant::div[contains(@class,'dijitTabInner')]/span[text()='Less than $50,000']")
    private WebElement lessThan50000Dollar;

    @FindBy(xpath = "//div[@data-dojo-attach-point='tablistWrapper']/descendant::div[contains(@class,'dijitTabInner')]/span[text()='$50,000 or more']")
    private WebElement moreThan50000Dollar;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//button[@title='Apply CEDE Tasa Variable CETE']/span[text()='Apply']")
    private WebElement applyNowCEDETasaVariableCETEButton;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//button[@title='Apply CEDE Tasa Variable TIIE']/span[text()='Apply']")
    private WebElement applyNowCEDETasaVariableTIIEButton;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//button[@title='Apply CEDE Tasa Fija']/span[text()='Apply']")
    private WebElement applyNowCEDETasaFijaButton;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//button[@title='Apply Pagar� Moneda Nacional']/span[text()='Apply']")
    private WebElement applyNowPagar�MonedaNacionalButton;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//button[@title='Apply Inversi�n Express']/span[text()='Apply']")
    private WebElement applyNowInversi�nExpressButton;

    @FindBy(xpath = "//form[contains(@id,'hdx_dijits_form_Form')]")
    protected WebElement personalDetailsForm;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(OpenAccountProductDetailsModel.class);

    public OpenAccountProductDetailsModel(final WebDriver driver) {
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30);
    }

    /**
     * It takes us to Apply for account Page
     **/
    public void clickFindOutMoreButton() {
        wait.until(ExpectedConditions.visibilityOf(findOutMoreButton));
        findOutMoreButton.click();
        Reporter.log("find Out More Button clicked.");
    }

    /**
     * Click on Apply button which takes us to Confirm personal details Page
     **/
    public void clickApplyOnOpenTDPage() {
        wait.until(ExpectedConditions.visibilityOf(applyNowButton));
        applyNowButton.click();
        wait.until(ExpectedConditions.visibilityOf(personalDetailsForm));
        Reporter.log("Apply Button clicked and personal Details page shown.");
    }

    /**
     * Click on Open button which takes us to Confirm personal details Page
     **/

    public void clickApplyNowOfUSDollarTD() {
        wait.until(ExpectedConditions.elementToBeClickable(applyNowUSDollerTD));
        applyNowUSDollerTD.click();
    }

    /**
     * Click on Open button which takes us to Confirm personal details Page
     **/
    public void clickApplyNowTFSASaving() {
        wait.until(ExpectedConditions.elementToBeClickable(applyNowTFSASaving));
        applyNowTFSASaving.click();
    }

    /**
     * Click on Open button which takes us to Confirm personal details Page
     **/
    public void clickApplyNowTFSARedeemableGIC() {
        wait.until(ExpectedConditions.elementToBeClickable(applyNowTFSARedeemableGIC));
        applyNowTFSARedeemableGIC.click();
    }

    /**
     * Click on Open button which takes us to Confirm personal details Page
     **/
    public void clickApplyNowTFSAeTerm() {
        wait.until(ExpectedConditions.elementToBeClickable(applyNowTFSAeTerm));
        applyNowTFSAeTerm.click();
    }

    /**
     * Click on Open button which takes us to Confirm personal details Page
     **/
    public void clickOpenHighRateSaving() {
        wait.until(ExpectedConditions.elementToBeClickable(applyNowHighRateSaving));
        applyNowHighRateSaving.click();
    }

    /**
     * Click on Foreign currency saving tab
     **/
    public void clickGICTab() {
        wait.until(ExpectedConditions.elementToBeClickable(gICTab));
        if (!gICTab.isSelected()) {
            gICTab.click();
        }
        Reporter.log("GIC tab is selected.");
    }

    /**
     * Click on Open button which takes us to Confirm personal details Page
     */
    public void clickOpenNonRedeemableSimpleInterestGIC() {
        wait.until(ExpectedConditions.elementToBeClickable(applyNowNonRedeemableSimpleInterestGIC));
        applyNowNonRedeemableSimpleInterestGIC.click();
    }

    /**
     * Click on Open button which takes us to Confirm personal details Page
     */
    public void clickOpenNonRedeemableCompoundedInterestGIC() {
        wait.until(ExpectedConditions.elementToBeClickable(applyNowNonRedeemableCompoundedInterestGIC));
        applyNowNonRedeemableCompoundedInterestGIC.click();
    }

    /**
     * Click on Open button which takes us to Confirm personal details Page
     */
    public void clickOpenRedeemableGIC() {
        wait.until(ExpectedConditions.elementToBeClickable(applyNowRedeemableGIC));
        applyNowRedeemableGIC.click();
    }

    /**
     * Click on Foreign currency saving tab
     **/
    public void clickForeignCurrencySavingTab() {
        wait.until(ExpectedConditions.elementToBeClickable(foreignCurrencySavingTab));
        if (!foreignCurrencySavingTab.isSelected()) {
            foreignCurrencySavingTab.click();
        }
        Reporter.log("Foreign currency tab is selected.");
    }

    /**
     * Click on Open button which takes us to Confirm personal details Page
     */
    public void clickOpenForeignCurrencyHighRateSaving() {
        wait.until(ExpectedConditions.elementToBeClickable(applyNowForeignCurrencyHighRateSaving));
        applyNowForeignCurrencyHighRateSaving.click();
    }

    /**
     * Click on Open button which takes us to Confirm personal details Page
     */
    public void clickOpenForeignCurrencyRegularSaving() {
        wait.until(ExpectedConditions.elementToBeClickable(applyNowForeignCurrencyRegularSaving));
        applyNowForeignCurrencyRegularSaving.click();
    }

    public void clickLessThan50000DollarTab() {
        wait.until(ExpectedConditions.elementToBeClickable(lessThan50000Dollar));
        if (!lessThan50000Dollar.isSelected()) {
            lessThan50000Dollar.click();
        }
        Reporter.log("\'Less than $50,000\' tab is selected. | ");
    }

    public void clickMoreThan50000DollarTab() {
        wait.until(ExpectedConditions.elementToBeClickable(moreThan50000Dollar));
        if (!moreThan50000Dollar.isSelected()) {
            moreThan50000Dollar.click();
        }
        Reporter.log("\'$50,000 or more\' tab is selected. | ");
    }

    /**
     * Click on Apply button for CEDE Tasa Variable CETE
     **/
    public void clickApplyCEDETasaVariableCETE() {
        wait.until(ExpectedConditions.elementToBeClickable(applyNowCEDETasaVariableCETEButton));
        applyNowCEDETasaVariableCETEButton.click();
        Reporter.log("Apply button clicked for CEDE Tasa Variable CETE Product. | ");
    }

    /**
     * Click on Apply button for CEDE Tasa Variable TIIE
     **/
    public void clickApplyCEDETasaVariableTIIE() {
        wait.until(ExpectedConditions.elementToBeClickable(applyNowCEDETasaVariableTIIEButton));
        applyNowCEDETasaVariableTIIEButton.click();
        Reporter.log("Apply button clicked for CEDE Tasa Variable TIIE Product. | ");
    }

    /**
     * Click on Apply button for CEDE Tasa Fija
     **/
    public void clickApplyCEDETasaFija() {
        wait.until(ExpectedConditions.elementToBeClickable(applyNowCEDETasaFijaButton));
        applyNowCEDETasaFijaButton.click();
        Reporter.log("Apply button clicked for CEDE Tasa Fija Product. | ");
    }

    /**
     * Click on Apply button for Pagar� Moneda Nacional
     **/
    public void clickApplyPagareMonedaNacional() {
        wait.until(ExpectedConditions.elementToBeClickable(applyNowPagar�MonedaNacionalButton));
        applyNowPagar�MonedaNacionalButton.click();
        Reporter.log("Apply button clicked for Pagare Moneda Nocional. | ");
    }

    /**
     * Click on Apply button for Inversi�n Express
     **/
    public void clickApplyInversionExpress() {
        wait.until(ExpectedConditions.elementToBeClickable(applyNowInversi�nExpressButton));
        applyNowInversi�nExpressButton.click();
        Reporter.log("Apply button clicked for Inversion Express Product. | ");
    }

    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     */
    public void clickFindOutMoreButtonForSavingAccount() {
        // TODO Auto-generated method stub

    }

    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     */
    public void clickFindOutMoreButtonForCurrentAccount() {
        // TODO Auto-generated method stub

    }

    /**
     * <p>
     * <b> Clicks Apply button for random selected product. </b>
     * </p>
     */
    public int clickApplyButtonForRandomProduct() {
        return 0;
    }
}
