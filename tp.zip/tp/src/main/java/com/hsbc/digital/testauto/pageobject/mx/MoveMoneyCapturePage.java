package com.hsbc.digital.testauto.pageobject.mx;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;


public class MoveMoneyCapturePage extends MoveMoneyCapturePageModel {
    protected static final String ENTITY_BANK_COUNTRY = "Mexico";
    protected static final String TRANSACTION_END_DATE_AS_DATE = "Date";
    protected static final String TRANSACTION_END_DATE_AS_NOP = "Number of payments";
    private static final String COUNTRY_MEXICO = "Mexico";
    @FindBy(xpath = "//div[contains(@id,'_fromAccount')]//table[contains(@id,'group_gpib_mvmny_bijit_Select')]//span[contains(@class,'title') and not(contains(@class,'noDisplay'))]")
    private WebElement fromAccountName;
    @FindBy(xpath = "//div[contains(@id,'_fromAccount')]//table[contains(@id,'group_gpib_mvmny_bijit_Select')]//span[contains(@class,'accountDetailsactSlOption')]")
    private WebElement fromAccountNumber;
    @FindBy(xpath = "//div[contains(@id,'_toAccount')]//table[contains(@id,'group_gpib_mvmny_bijit_Select')]//span[contains(@class,'title')and not(contains(@class,'noDisplay'))]")
    private WebElement toAccountName;
    @FindBy(xpath = "//div[contains(@id,'_toAccount')]//table[contains(@id,'group_gpib_mvmny_bijit_Select')]//span[contains(@class,'accountDetailsactSlOption')]")
    private WebElement toAccountNumber;


    public MoveMoneyCapturePage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    protected String getEntityBankCountry() {
        return MoveMoneyCapturePage.ENTITY_BANK_COUNTRY;
    }

    @Override
    protected boolean isValidAccount(final boolean domesticAccount, final String entity, final String accountlocation) {

        return (domesticAccount && accountlocation.equalsIgnoreCase(MoveMoneyCapturePage.COUNTRY_MEXICO))

        || (!domesticAccount && !accountlocation.equalsIgnoreCase(entity));
    }

    @Override
    public String enterYourReferenceText(final Transaction transactionDetail) {
        String yourReference = RandomUtil.generateAlphaNumericText(MoveMoneyCapturePageModel.DEFAULT_REFERENCE_TEXT_LENGTH);
        List<WebElement> countYourReference = driver.findElements(MoveMoneyCapturePageModel.yourReferenceElements
            .get(transactionDetail.getTransactionFlow()));
        if (!countYourReference.isEmpty()) {
            WebElement fieldYourReference = driver.findElement(MoveMoneyCapturePageModel.yourReferenceElements
                .get(transactionDetail.getTransactionFlow()));
            if (fieldYourReference.isDisplayed()) {
                fieldYourReference.click();
                fieldYourReference.clear();
                fieldYourReference.sendKeys(yourReference);
                fieldYourReference.sendKeys(Keys.RETURN);
                Reporter.log("Your Reference entered is :" + yourReference);
            } else {
                Reporter.log("Your Reference field is not displayed");
                logger.info("Your Reference field is not displayed");
            }
        }
        return yourReference;
    }

    public void verifyDetailsAfterContinueCancelOnCapturePage(Transaction transactionDetail) {
        wait.until(ExpectedConditions.invisibilityOfElementLocated(cancelDialog));
        isFromAccountNameDisplayed(transactionDetail.getFromAccount());
        isFromAccountNumberDisplayed(transactionDetail.getFromAccount());
        isToAccountNameDisplayed(transactionDetail.getToAccount());
        isToAccountNumberDisplayed(transactionDetail.getToAccount());
        isTransferAmountDisplayed(transactionDetail);
        isYourReferenceDisplayed(transactionDetail);
        Reporter.log("Details verified after negating cancel.");
        logger.info("Details verified after negating cancel.");
    }

    private void isFromAccountNameDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(fromAccountName.getText().equalsIgnoreCase(accountDetail.getAccountName()),
            "From Account Name does not match expected value.");
        Reporter.log("From Account Name matches : " + accountDetail.getAccountName());
        logger.info("From Account Name matches : " + accountDetail.getAccountName());
    }

    private void isFromAccountNumberDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(fromAccountNumber.getText().equalsIgnoreCase(accountDetail.getAccountNumber()),
            "From Account Number does not match expected value.");
        Reporter.log("From Account Number matches : " + accountDetail.getAccountNumber());
        logger.info("From Account Number matches : " + accountDetail.getAccountNumber());
    }

    private void isToAccountNameDisplayed(AccountDetails accountDetail) {
        if (!ifSingleToAccountPresent.isEmpty() && !ifSingleToAccountPresent.get(DEFAULT_LIST_STARTING_INDEX).isDisplayed()) {
            Assert.assertTrue(toAccountName.getText().equalsIgnoreCase(accountDetail.getAccountName()),
                "To Account Name does not match expected value.");
            Reporter.log("To Account Name matches : " + accountDetail.getAccountName());
            logger.info("To Account Name matches : " + accountDetail.getAccountName());
        } else {
            Assert.assertTrue(singleAccountName.getText().equalsIgnoreCase(accountDetail.getAccountName()),
                "To Account Name does not match expected value.");
            Reporter.log("To Account Name matches : " + accountDetail.getAccountName());
            logger.info("To Account Name matches : " + accountDetail.getAccountName());
        }
    }

    private void isToAccountNumberDisplayed(AccountDetails accountDetail) {
        if (!ifSingleToAccountPresent.isEmpty() && !ifSingleToAccountPresent.get(DEFAULT_LIST_STARTING_INDEX).isDisplayed()) {
            Assert.assertTrue(toAccountNumber.getText().equalsIgnoreCase(accountDetail.getAccountNumber()),
                "To Account Number does not match expected value.");
            Reporter.log("To Account Number matches : " + accountDetail.getAccountNumber());
            logger.info("To Account Number matches : " + accountDetail.getAccountNumber());
        } else {
            Assert.assertTrue(singleAccountNumber.getText().equalsIgnoreCase(accountDetail.getAccountNumber()),
                "To Account Number does not match expected value.");
            Reporter.log("To Account Number matches : " + accountDetail.getAccountNumber());
            logger.info("To Account Number matches : " + accountDetail.getAccountNumber());
        }

    }

    private void isTransferAmountDisplayed(Transaction transactionDetail) {
        WebElement amountField = driver.findElement(transferAmountElements.get(transactionDetail.getTransactionFlow()));
        Assert.assertTrue(amountField.getAttribute(ELEMENT_VALUE_ATTRIBUTE).equalsIgnoreCase(transactionDetail.getAmount()),
            "Transfer Amount does not match expected value.");
        Reporter.log("Transfer Amount matches : " + transactionDetail.getAmount());
        logger.info("Transfer Amount matches : " + transactionDetail.getAmount());
    }

    private void isYourReferenceDisplayed(Transaction transactionDetail) {
        WebElement fieldYourReference = driver.findElement(yourReferenceElements.get(transactionDetail.getTransactionFlow()));
        if (fieldYourReference.isDisplayed()) {
            Assert.assertTrue(
                fieldYourReference.getAttribute(ELEMENT_VALUE_ATTRIBUTE).equalsIgnoreCase(transactionDetail.getYourReference()),
                "From Account Name does not match expected value.");
            Reporter.log("Your reference matches : " + transactionDetail.getYourReference());
            logger.info("Your reference matches : " + transactionDetail.getYourReference());
        } else {
            logger.info("Your reference is NA ");
        }
    }


    public AccountDetails selectDomesticToLCYAccount(final String entityCurrency) {
        /*
         * This ifSingleToAccountPresent() check is added to check if the
         * ToAccount has no dropdown present. i.e. only one Account present
         */
        wait.until(ExpectedConditions.visibilityOf(capturePageTitle));
        if (!ifSingleToAccountPresent.isEmpty() && !ifSingleToAccountPresent.get(DEFAULT_LIST_STARTING_INDEX).isDisplayed()) {
            return selectAccount(entityCurrency, toDropIcon, true, true);
        } else {
            List<AccountDetails> storeAccountValue = new ArrayList<>();
            AccountDetails accountInformations = new AccountDetails();
            String temp = singleAccountName.getText();
            accountInformations.setAccountName(temp);
            accountInformations.setAccountNumber(singleAccountNumber.getText());
            String singleStringbalance = singleBalance.getText();
            Double balance = Double.parseDouble(singleStringbalance.replace(",", ""));
            accountInformations.setAccountBalance(singleStringbalance);
            accountInformations.setDoubleAccountBalance(balance);
            accountInformations.setCurrency(singleCurrency.getText());
            storeAccountValue.add(accountInformations);
            return storeAccountValue.get(DEFAULT_LIST_STARTING_INDEX);
        }
    }

    protected AccountDetails selectAccount(final String entityCurrency, final WebElement accountDropIcon,
        final boolean domesticAccount, final boolean domesticCurrency) {
        int index;
        List<AccountDetails> accountValue = validAccountDetails(entityCurrency, accountDropIcon, listDropdown, domesticAccount,
            domesticCurrency);
        Assert.assertTrue(!accountValue.isEmpty(), "No valid account found.");
        do {
            index = RandomUtil.generateIntNumber(DEFAULT_LIST_STARTING_INDEX, accountValue.size());
            selectAccountByAccountDetail(accountDropIcon, accountValue.get(index));
        } while (myPayeesTabs.isEmpty() || typeOfAccountTo.getAttribute("value").contains(TYPEOFACCOUNT_To_CREDIT)
            || typeOfAccountTo.getAttribute("value").contains(TYPEOFACCOUNT_To_MASTERCARD)
            || typeOfAccountFrom.getAttribute("value").contains((TYPEOFACCOUNT_From_MASTERCARD)));
        return accountValue.get(index);
    }

    @Override
    public String selectTransactionEnddate() {
        String endDateDropDownValue = null;
        do {
            endDateDropDownValue = selectRandamValue(transactionEndDateDropIcon, listDropdown);
            Reporter.log("Frequency value selected is :" + endDateDropDownValue);
        } while (endDateDropDownValue.equalsIgnoreCase(TRANSACTION_END_DATE_AS_DATE));

        return endDateDropDownValue;
    }

    @Override
    public String selectTransactionEndNoOfPayment() {
        String endDateDropDownValue = null;
        do {
            endDateDropDownValue = selectRandamValue(transactionEndDateDropIcon, listDropdown);
            Reporter.log("Frequency value selected is :" + endDateDropDownValue);
        } while (!endDateDropDownValue.equalsIgnoreCase(TRANSACTION_END_DATE_AS_NOP));
        return endDateDropDownValue;
    }


    @Override
    public String verifyNumberOfPayements() {
        String noOfPayements = null;
        if (numberOfPaymentsText.isDisplayed()) {
            noOfPayements = RandomUtil.generateIntNumber(2);
            numberOfPaymentsText.sendKeys(noOfPayements);
            return noOfPayements;
        } else {
            return noOfPayements;
        }
    }

    @Override
    public AccountDetails selectDomesticFromLCYAccount(final String entityCurrency) {
        wait.until(ExpectedConditions.visibilityOf(capturePageTitle));
        return selectAccount(entityCurrency, fromDropIcon, true, true);
    }


}
