/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.ca;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.UpdateMaturiryInstructionsDetails;
import com.hsbc.digital.testauto.pageobject.UpdateMaturityInstructionModel;

/**
 * <p>
 * <b> This class will hold all locators and method of story # 85 , Update Maturity Instruction which are applicable to Canada entity  </b>
 * </p>
 * 
 * @version 1.0.0
 * @author Vaibhav Sharma
 * 
 */



public class UpdateMaturityInstruction extends UpdateMaturityInstructionModel {


	@FindBy(xpath = "//div[@class='manageSection']//a[contains(@data-uid,'editmaturityinstructions')]")
	protected List<WebElement> updateMaturityLinkManageMenuList;
	
	@FindBy(xpath = "//a[contains(text(),'Update maturity instructions')]")
	protected WebElement updateMaturityLinkManageMenu;
	
	 @FindBy(xpath = ".//li[(@data-dojo-attach-point='newFixedTerm')]//span")
	 protected WebElement newFixedTermFixed;
	 
	 @FindBy(xpath = "//div[@class='accountSummaryHeadContainer']//th[text()='Interest amount at maturity']//following-sibling::td")
	 protected WebElement selectedAccountInterestMaturity;
	 
	 @FindBy(xpath = "//input[@value='My accounts']")
	 protected WebElement backToMyAccountButton;
	 
	  @FindBy(xpath = "//p[text()='Request received']")
	    protected WebElement updateSuccessfulHeading;
	  
	  @FindBy(xpath = ".//*[@data-dojo-attach-point='editMaturityHeader']")
	    protected WebElement confirmationMessage;
	  
	  @FindBy(xpath = "//div[@class='editMaturityTandCcheckbox']")
		 private WebElement checkBoxTFSA;
	  
	  @FindBy(xpath = "//div[@class='fl accntInfo']//h2")
		 private WebElement tdAccountType;
	  
	
	  
	  protected static final String maturityOptionRenewTotalBalance = "Automatic renewal of principal and interest";
	  protected static final String maturityOptionDoNotRenew = "Do not renew; credit principal and interest back to account";
	    protected static final String maturityOptionRenewPrincipleAmount = "Automatic renewal of principal amount only";
	    protected static final String maturityOptionAddFunds = "Automatic renewal and add funds";
	    protected static final String maturityOptionAWithdrawFunds = "Automatic renewal and withdraw funds";
	  

	
    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(UpdateMaturityInstruction.class);

    public UpdateMaturityInstruction(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }
    
    @Override
    protected boolean isUpdateMaturityLinkDisplayed() {
        return !updateMaturityLinkManageMenuList.isEmpty() && updateMaturityLinkManageMenu.isDisplayed();
    }

    @Override
    protected void clickUpdateMaturityLink() {
        updateMaturityLinkManageMenuList.get(0).click();
    }
    
    @Override
    public String selectNewFixedTerm() {

        if (newFixedTermArrow.isDisplayed()) {

            newFixedTermArrow.click();
            int randomIndex = RandomUtil.generateIntNumber(1, newFixedTermList.size());
            WebElement row = newFixedTermList.get(randomIndex);
            row.click();
            return newFixedTermFixed.getText();
        }

        if (newFixedTermFixed.isDisplayed()) {
            Reporter.log("Term is fixed and displayed as " + newFixedTermFixed.getText());
            return newFixedTermFixed.getText();
        }

        return newFixedTermFixed.getText();
    }
    
  
    @Override
    public UpdateMaturiryInstructionsDetails captureUpdateMaturityDetails() {
        UpdateMaturiryInstructionsDetails objUpdateMaturiryInstructionsDetails = new UpdateMaturiryInstructionsDetails();
        String maturityType = selectOnMaturity();


        if (maturityType.contains(maturityOptionRenewTotalBalance)) {
            objUpdateMaturiryInstructionsDetails.setnewFixedTerm(selectNewFixedTerm());
        }

        if (maturityType.contains(maturityOptionDoNotRenew)) {
            objUpdateMaturiryInstructionsDetails.setSelectAddFundAccount(selectAddFundsToAccount());
        }

        if (maturityType.contains(maturityOptionRenewPrincipleAmount)) {
            objUpdateMaturiryInstructionsDetails.setSelectAddFundAccount(selectAddFundsToAccount());
            objUpdateMaturiryInstructionsDetails.setnewFixedTerm(selectNewFixedTerm());
        }

        if (maturityType.contains(maturityOptionAddFunds)) {
        	objUpdateMaturiryInstructionsDetails.setAmountToAdd(enterAmountToAdd());
            objUpdateMaturiryInstructionsDetails.setSelectAddFundAccount(selectAddFundsFromAccount());
            objUpdateMaturiryInstructionsDetails.setnewFixedTerm(selectNewFixedTerm());
            selectCheckBoxTFSA();
            
        }

        if (maturityType.contains(maturityOptionAWithdrawFunds)) {
        	objUpdateMaturiryInstructionsDetails.setAmountWithDraw(enterAmountToWithdraw());
            objUpdateMaturiryInstructionsDetails.setSelectAddFundAccount(selectAddFundsToAccount());
            objUpdateMaturiryInstructionsDetails.setnewFixedTerm(selectNewFixedTerm());
            
        }
        return objUpdateMaturiryInstructionsDetails;
    }

    
    public void selectCheckBoxTFSA()
    {
    	
    	if ( tdAccountType.getText().contains("TFSA") && !checkBoxTFSA.isSelected())
    	{ 
    		checkBoxTFSA.click();
    		Reporter.log("terms and condtions check box is selected for TFSA TD");
    	}
    }
    
    
    
    
    
    @Override
    public void verifyUpdateMaturityReviewPage(final UpdateMaturiryInstructionsDetails objUpdateMaturiryInstructionsDetails) {

    	
         Reporter.log("Verify Maturity page is displayed");

         String onMaturityReviewPage = onMaturitySelectedItem.getText();

         if (onMaturityReviewPage.contains(maturityOptionRenewTotalBalance)) {

             Assert.assertTrue(newFixedTermReview.getText().contains(objUpdateMaturiryInstructionsDetails.getnewFixedTerm()),
                 "Fixed term did not match");
         }


         if (onMaturityReviewPage.contains(maturityOptionDoNotRenew)) {

             Assert.assertTrue(
                 AddFundsToAccountReview.getText().contains(objUpdateMaturiryInstructionsDetails.getSelectAddFundAccount()),
                 "Add Funds To Account did not match");
         }

         if (onMaturityReviewPage.contains(maturityOptionRenewPrincipleAmount)) {

             Assert.assertTrue(newFixedTermReview.getText().contains(objUpdateMaturiryInstructionsDetails.getnewFixedTerm()),
                 "Fixed term did not match");
             Assert.assertTrue(
                 AddFundsToAccountReview.getText().contains(objUpdateMaturiryInstructionsDetails.getSelectAddFundAccount()),
                 "Add Funds To Account did not match");
         }

         if (onMaturityReviewPage.contains(maturityOptionAddFunds)) {

             Assert.assertTrue(newFixedTermReview.getText().contains(objUpdateMaturiryInstructionsDetails.getnewFixedTerm()),
                 "Fixed term did not match");
             Assert.assertTrue(
                 AddFundsToAccountReview.getText().contains(objUpdateMaturiryInstructionsDetails.getSelectAddFundAccount()),
                 "Add Funds To Account did not match");
             Assert.assertTrue(amountToAddReview.getText().contains(objUpdateMaturiryInstructionsDetails.getAmountToAdd()),
                 "Add Funds amount did not match");
         }

         if (onMaturityReviewPage.contains(maturityOptionAWithdraw)) {

             Assert.assertTrue(newFixedTermReview.getText().contains(objUpdateMaturiryInstructionsDetails.getnewFixedTerm()),
                 "Fixed term did not match");
             Assert.assertTrue(
                 AddFundsToAccountReview.getText().contains(objUpdateMaturiryInstructionsDetails.getSelectAddFundAccount()),
                 "Add Funds To Account did not match");
             Assert.assertTrue(amountToWithdraw.getText().contains(objUpdateMaturiryInstructionsDetails.getAmountWithdraw()),
                 "Add Funds amount did not match");
         }
     }
    
    @Override
    public void verifyCurrentMaturityInstruction() {

        Assert.assertTrue(selectedAccountBalance.isDisplayed(),
            "Account Balance field is not displayed under Current maturity instructions section");
        Reporter.log("Account Balance field is displayed as " + selectedAccountBalance.getText()
            + " under Current maturity instructions section");

        Assert.assertTrue(selectedAccountStartDate.isDisplayed(),
            "Start Date field is not displayed under Current maturity instructions section");
        Reporter.log("Start Date field is displayed as " + selectedAccountStartDate.getText()
            + " under Current maturity instructions section");

        Assert.assertTrue(selectedAccountTerm.isDisplayed(),
            "Account term field is not displayed under Current maturity instructions section");
        Reporter.log("Account term field is displayed as" + selectedAccountTerm.getText()
            + "  under Current maturity instructions section");

        Assert.assertTrue(selectedAccountMaturityDate.isDisplayed(),
            "Account maturity date field is not displayed under Current maturity instructions section");
        Reporter.log("Account maturity date field is displayed as" + selectedAccountMaturityDate.getText()
            + "   under Current maturity instructions section");

        Assert.assertTrue(selectedAccountInterestpaid.isDisplayed(),
            "Account Interest paid field is not displayed under Current maturity instructions section");
        Reporter.log("Account Interest paid field is displayed as" + selectedAccountInterestpaid.getText()
            + "   under Current maturity instructions section");

        Assert.assertTrue(selectedAccountInterestrate.isDisplayed(),
            "Account Interest rate field is not displayed under Current maturity instructions section");
        Reporter.log("Account Interest rate field is displayed as" + selectedAccountInterestrate.getText()
            + "   under Current maturity instructions section");

        Assert.assertTrue(selectedAccountInterestMaturity.isDisplayed(),
            "Account Interest maturity field is not displayed under Current maturity instructions section");
        Reporter.log("Account Interest maturity field is displayed as" + selectedAccountInterestMaturity.getText()
            + "   under Current maturity instructions section");

    }
    @Override
    public void verifyBackToMYAccountFunctionality() {
        Assert.assertTrue(backToMyAccountButton.isDisplayed(), "Back to My Account button is not displayed");
        Reporter.log("Back To My Account button is displayed");

        backToMyAccountButton.click();
        Reporter.log("Back to My Account button clicked");

        Assert.assertTrue(dashboardtitle.isDisplayed(),
            "Dashboard page is not displayed after clicking on Back to My Account button");
        Reporter.log("Dashboard page is displayed after clicking on Back To My Account button");
    }
    
    @Override
    public void verifyUpdateMaturityConfirmationPage() {

        Assert
            .assertTrue(updateSuccessfulHeading.isDisplayed(), "Upadet suuccessful heading is not displayed on Confirmation page");
        Reporter.log("Upadet suuccessful heading is displayed as" + updateSuccessfulHeading.getText());

        Assert.assertTrue(confirmationMessage.isDisplayed(), "Confirmation message is not displayed on confirmation page");
        Reporter.log("Confirmation message is displayed as " + confirmationMessage.getText());

    }
    
    @Override
    public String enterAmountToAdd() {
        Assert.assertTrue(amountToAddInput.isDisplayed(), "Amount to add text field is not displayed");
        Reporter.log("Amount to add text field is displayed");
        int randomAmount = RandomUtil.generateIntNumber(5000, 99999);
        String strRandomAmount = Integer.toString(randomAmount);
        amountToAddInput.click();
        amountToAddInput.sendKeys(strRandomAmount);
        return strRandomAmount;
    }


}
