package com.hsbc.digital.testauto.scripts.movemoney;


import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.models.AddBeneficiaryDetails;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.models.TransactionFlow;
import com.hsbc.digital.testauto.pageobject.AddBeneficiaryModel;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.ManageFutureDatedPaymentModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyConfirmPageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyVerifyPageModel;


/**
 * <p>
 * <b> This class is holding Test Case and functionality to View/Update/Delete
 * Payee details. Story 41</b>
 * </p>
 * 
 * @author Shweta Jain
 * @version 1.0.0
 */

public class ManageBeneficiary {
    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    AddBeneficiaryModel addPayeeModel;
    FlyerMenuNavigationModel navigate;
    MoveMoneyCapturePageModel mmCapturePageModel;
    MoveMoneyVerifyPageModel mmVerifyPageModel;
    MoveMoneyConfirmPageModel mmConfirmPageModel;
    ManageFutureDatedPaymentModel mmFDTmodel;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(ManageBeneficiary.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method testMethod) {
        try {
            browserLib = new BrowserLib(browser);
            driver = browserLib.getDriver();
            envProperties = FileUtil.getConfigProperties(entity);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            navigate = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", driver);
            addPayeeModel = (AddBeneficiaryModel) ReflectionUtil.getEntityPOM(entity, "AddBeneficiary", driver);
            mmCapturePageModel = (MoveMoneyCapturePageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyCapturePage", driver);
            mmVerifyPageModel = (MoveMoneyVerifyPageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyVerifyPage", driver);
            mmConfirmPageModel = (MoveMoneyConfirmPageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyConfirmPage", driver);
            mmFDTmodel = (ManageFutureDatedPaymentModel) ReflectionUtil.getEntityPOM(entity, "ManageFutureDatedPayment", driver);
            String profile = XMLUtil.getProfileName(testMethod, entity);
            loginModel.login(profile, envProperties);
            loginModel.switchLanguage("English");
        } catch (Exception e) {
            ManageBeneficiary.logger.error("Exception thrown at Login Contructor:", e);
        }
    }

    /**
     * Test Case is to verify if Payees are displayed in alphabetical order on
     * My payees page
     * 
     */
    @Test(groups = {"functionaltest"}, testName = "verifyPayeeListOrder")
    public void verifyPayeeListOrder() {
        try {
            navigate.navigateToMypayeesPage();
            addPayeeModel.isPayeeListOrdered();
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
            ManageBeneficiary.logger.error("Exception : ", e);
        }
    }


    /**
     * Test Case is to verify Payee details on clicking View button Also checks
     * the Close button functionality on selected Payee details pane
     * 
     */
    @Test(groups = {"functionaltest"}, testName = "viewPayeeDetails")
    public void viewPayeeDetails() {
        try {
            navigate.navigateToMypayeesPage();
            addPayeeModel.verifyPayeeDetails(addPayeeModel.selectPayee());
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
            ManageBeneficiary.logger.error("Exception:", e);
        }
    }


    /**
     * Test Case is to validate Cancel & confirm Delete Payee Flow
     */
    @Test(groups = {"functionaltest"}, testName = "verifyCancelDeletePayeeFlow AND verifyDeletePayeeFlowE2E")
    public void deletePayeeFlow() {
        try {
            navigate.navigateToMypayeesPage();
            addPayeeModel.cancelDeletePayee(addPayeeModel.selectPayee());
            addPayeeModel.deletePayee(addPayeeModel.selectPayee());
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
            ManageBeneficiary.logger.error("Exception:", e);
        }
    }


    // defect :57814 , pop up to delete Future transfer first is not getting
    // displayed
    // will complete this method once function is available
    /**
     * Test Case is to validate Cancel Delete payee Flow when payee has Pending
     * Future dated Transfer
     */
    // ?? how to check for below test case
    @Test(groups = {"functionaltest"}, testName = "cancelDeletePayeeWithFutureTransfer")
    public void cancelDeletePayeeWithFutureTransfer() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            addPayeeModel.payToSelectedPayee(transaction.getToAccount());
            transaction.setFromAccount(mmCapturePageModel.setDefaultFromAccountDetails());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2LCYLaterTransactionDetailsOnConfirmPage(transaction);
            navigate.navigateToMypayeesPage();
            addPayeeModel.cancelDeletePayee(transaction.getToAccount());
            Reporter.log("m2nmLCY2LCYLaterTransaction test passed");
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
            ManageBeneficiary.logger.error("Exception:", e);
        }
    }


    // defect :57814 , pop up to delete Future transfer first is not getting
    // displayed
    // will complete this method once function is available
    /**
     * Test Case is to validate Delete payee Flow when payee has Pending Future
     * dated Transfer
     */
    // ?? need to check below flow
    @Test(groups = {"functionaltest"}, testName = "verifyDeletePayeeWithFutureTransfer")
    public void deletePayeeWithFutureTransfer() {
        try {
            Transaction transaction = new Transaction();
            AddBeneficiaryDetails beneDetails = new AddBeneficiaryDetails();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            addPayeeModel.payToSelectedPayee(transaction.getToAccount());
            transaction.setFromAccount(mmCapturePageModel.setDefaultFromAccountDetails());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2LCYLaterTransactionDetailsOnConfirmPage(transaction);
            navigate.navigateToMypayeesPage();
            addPayeeModel.deletePayee(transaction.getToAccount());
            addPayeeModel.cancelCompanyPayeeWithFutureTransaction();
            addPayeeModel.deletePayee(transaction.getToAccount());
            addPayeeModel.viewPaymentsCompanyPayeeWithFutureTransaction();
            mmFDTmodel.deletePayeeTransaction(transaction.getToAccount());
            navigate.navigateToMypayeesPage();
            beneDetails.setPayeeCount(addPayeeModel.getAllpayeesCount());
            addPayeeModel.deletePayee(transaction.getToAccount());
            addPayeeModel.deletionSuccess(beneDetails, transaction.getToAccount());
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            ManageBeneficiary.logger.error(e);
        }
    }

    @Test(groups = {"functionaltest"}, enabled = true, testName = "verifyDeleteCompanyPayeeWithFutureTransfer")
    public void deleteCompanyPayeeWithFutureTransfer() {
        try {
            Transaction transaction = new Transaction();
            AddBeneficiaryDetails beneDetails = new AddBeneficiaryDetails();
            transaction.setTransactionFlow(TransactionFlow.M2COMPANY_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticCompanyPayees());
            addPayeeModel.payToSelectedPayee(transaction.getToAccount());
            transaction.setFromAccount(mmCapturePageModel.setDefaultFromAccountDetails());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2LCYLaterTransactionDetailsOnConfirmPage(transaction);
            navigate.navigateToMypayeesPage();
            addPayeeModel.deletePayee(transaction.getToAccount());
            addPayeeModel.cancelCompanyPayeeWithFutureTransaction();
            addPayeeModel.deletePayee(transaction.getToAccount());
            addPayeeModel.viewPaymentsCompanyPayeeWithFutureTransaction();
            mmFDTmodel.deletePayeeTransaction(transaction.getToAccount());
            navigate.navigateToMypayeesPage();
            beneDetails.setPayeeCount(addPayeeModel.getAllpayeesCount());
            addPayeeModel.deletePayee(transaction.getToAccount());
            addPayeeModel.deletionSuccess(beneDetails, transaction.getToAccount());
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            ManageBeneficiary.logger.error(e);
        }
    }

    /**
     * Test Case is to verify 'Pay' button functionality. User is navigated to
     * MM page when 'Pay' is clicked for selected payee
     */
    @Test(groups = {"functionaltest"}, testName = "paymentToSelectedPayee")
    public void paymentToSelectedPayee() {
        try {
            navigate.navigateToMypayeesPage();
            mmCapturePageModel.verifyPayeeOnMMpage(addPayeeModel.payToSelectedPayee(addPayeeModel.selectPayee()));
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
            ManageBeneficiary.logger.error("Exception:", e);
        }
    }


    /**
     * Test Case is to verify if appropriate warning message is displayed to
     * user if No Payees are present on My Payees page
     */
    @Test(groups = {"functionaltest"}, testName = "validateNoPayeesWarningMessage")
    public void validateNoPayeesMessage() {
        try {
            navigate.navigateToMypayeesPage();
            addPayeeModel.verifyIfNoPayeePresent();
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
            ManageBeneficiary.logger.error("Exception:", e);
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterMethod() {
        browserLib.closeAllBrowsers();
    }

    /**
     * 
     * <p>
     * <b> This method is used to take screen shot so every test script should
     * have it as it is used by Framework internally. </b>
     * </p>
     * 
     * @return driver
     */
    public WebDriver getDriver() {
        return driver;
    }
}
