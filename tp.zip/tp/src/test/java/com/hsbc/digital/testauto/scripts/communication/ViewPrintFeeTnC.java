/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.communication;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LandingPageModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.ViewPrintFeeTnCModel;

public class ViewPrintFeeTnC {

    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    String profile;
    LoginModel loginModel;
    ViewPrintFeeTnCModel objViewPrintFeeTnCModel;
    FlyerMenuNavigationModel navigate;
    LandingPageModel landingPageModel;
    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(ViewPrintFeeTnC.class);


    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void setup(final String browser, final String entity, final Method testMethod) {
        try {
            browserLib = new BrowserLib(browser);
            driver = browserLib.getDriver();
            envProperties = FileUtil.getConfigProperties(entity);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            objViewPrintFeeTnCModel = (ViewPrintFeeTnCModel) ReflectionUtil.getEntityPOM(entity, "ViewPrintFeeTnC", driver);
            navigate = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", driver);
            landingPageModel = (LandingPageModel) ReflectionUtil.getEntityPOM(entity, "LandingPage", driver);
            profile = XMLUtil.getProfileName(testMethod, entity);
            loginModel.login(profile, this.envProperties);
            loginModel.switchLanguage("English");
        } catch (Exception e) {
            ViewPrintFeeTnC.logger.error("Exception thrown at Login Contructor:", e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "downloadFeeTnC")
    public void downloadFeeTnC() {
        try {
            if (!navigate.navigateTnCPage()) {
                landingPageModel.selectAccountToAccessViewPrintFeeTnCLinkFromManage();
            }
            objViewPrintFeeTnCModel.downloadTnCFile();

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            ViewPrintFeeTnCModel.logger.error(e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "cancelViewTnCDownloadProcess")
    public void cancelViewTnCDownloadProcess() {
        try {
            if (!navigate.navigateTnCPage()) {
                landingPageModel.selectAccountToAccessViewPrintFeeTnCLinkFromManage();
            }
            objViewPrintFeeTnCModel.closeDownloadTab();

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            ViewPrintFeeTnCModel.logger.error(e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "updateNotificationSetting")
    public void updateNotificationSetting() {
        try {
            if (!navigate.navigateTnCPage()) {
                landingPageModel.selectAccountToAccessViewPrintFeeTnCLinkFromManage();
            }
            objViewPrintFeeTnCModel.navigateUpdateNotificationPage();
            objViewPrintFeeTnCModel.changeNotificationSetting();

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            ViewPrintFeeTnCModel.logger.error(e);
        }
    }


    @AfterMethod(alwaysRun = true)
    public void afterTest() {
        browserLib.closeAllBrowsers();
    }

    public WebDriver getDriver() {
        return this.driver;
    }

}
