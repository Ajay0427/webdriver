/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.accountservicing;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.OrderChequeBookCapturePageModel;
import com.hsbc.digital.testauto.pageobject.OrderChequeBookConfirmPageModel;
import com.hsbc.digital.testauto.pageobject.OrderChequeBookVerifyPageModel;

/**
 * <p>
 * <b> This class will hold testing scripts for story 93 Order Cheque Book </b>
 * </p>
 * 
 * @version 1.0.0
 * @author Deepti Patil
 * 
 */

public class OrderChequeBook {
    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    FlyerMenuNavigationModel navigate;
    OrderChequeBookCapturePageModel orderChequeBookCapturePage;
    OrderChequeBookVerifyPageModel orderChequeBookVerifyPage;
    OrderChequeBookConfirmPageModel orderChequeBookConfirmPage;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(OrderChequeBook.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method method) {
        try {
            this.browserLib = new BrowserLib(browser);
            this.driver = this.browserLib.getDriver();
            this.envProperties = FileUtil.getConfigProperties(entity);
            String profile = XMLUtil.getProfileName(method, entity);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            navigate = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", driver);
            orderChequeBookCapturePage = (OrderChequeBookCapturePageModel) ReflectionUtil.getEntityPOM(entity,
                "OrderChequeBookCapturePage", driver);
            orderChequeBookVerifyPage = (OrderChequeBookVerifyPageModel) ReflectionUtil.getEntityPOM(entity,
                "OrderChequeBookVerifyPage", driver);
            orderChequeBookConfirmPage = (OrderChequeBookConfirmPageModel) ReflectionUtil.getEntityPOM(entity,
                "OrderChequeBookConfirmPage", driver);
            loginModel.login(profile, envProperties);
        } catch (Exception e) {
            OrderChequeBook.logger.error("Exception thrown at Login Contructor:", e);
        }
    }

    @Test(testName = "Verify order Chequebook E2E flow from flyout menu", groups = {"functionaltest"})
    public void orderChequeBookFlyoutMenu() {
        try {
            navigate.navigateToOrderChequeBookPage();
            AccountDetails accountDetails = orderChequeBookCapturePage.selectAllDetails();
            orderChequeBookVerifyPage.verifyPageDetails(accountDetails);
            orderChequeBookConfirmPage.confirmPageDetails(accountDetails);
            orderChequeBookCapturePage.isDashboardHeadingTitleDisplayed();
        } catch (Exception e) {
            OrderChequeBook.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "Verify order Chequebook E2E flow from Manage menu", groups = {"functionaltest"})
    public void orderChequeBookManageFlow() {
        try {
            orderChequeBookCapturePage.navigateToOrderChequeBookPageViaManage();
            AccountDetails accountDetails = orderChequeBookCapturePage.selectOtherDetailsOnCapturePage();
            orderChequeBookVerifyPage.verifyDetailsOnVerifyPage(accountDetails);
            orderChequeBookVerifyPage.clickConfirmButton();
            orderChequeBookConfirmPage.verifyDetailsOnConfirmPage(accountDetails);
            orderChequeBookConfirmPage.clickMyAccountsButton();
            orderChequeBookCapturePage.isDashboardHeadingTitleDisplayed();
        } catch (Exception e) {
            OrderChequeBook.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "Verify order Chequebook for Invalid accounts", groups = {"functionaltest"})
    public void orderChequeBookForInvalidAccount() {
        try {
            orderChequeBookCapturePage.verifyInvalidAccounts();
        } catch (Exception e) {
            OrderChequeBook.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "Verify Edit Details and cancel flow on Verify Page", groups = {"functionaltest"})
    public void verifyPageEditDetailsAndCancelFlow() {
        try {
            orderChequeBookCapturePage.navigateToOrderChequeBookPageViaManage();
            AccountDetails accountDetails = orderChequeBookCapturePage.selectOtherDetailsOnCapturePage();
            orderChequeBookVerifyPage.verifyEditDetailsFlow(accountDetails);
            orderChequeBookCapturePage.verifyCapturePage();
            orderChequeBookVerifyPage.verifyPageCancelFlow();
            orderChequeBookCapturePage.isOrderChequeCapturePageDisplayed();
        } catch (Exception e) {
            OrderChequeBook.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "Verify order Chequebook E2E flow from flyout menu", groups = {"functionaltest"})
    public void verifyDuplicateChequeError() {
        try {
            navigate.navigateToOrderChequeBookPage();
            AccountDetails accountDetails = orderChequeBookCapturePage.selectAllDetails();
            orderChequeBookVerifyPage.verifyPageDetails(accountDetails);
            orderChequeBookConfirmPage.confirmPageDetails(accountDetails);
            orderChequeBookConfirmPage.clickMyAccountsButton();
            navigate.navigateToOrderChequeBookPage();
            orderChequeBookCapturePage.captureDetailsForDuplicateCheque(accountDetails);
            orderChequeBookVerifyPage.clickConfirmButton();
            orderChequeBookVerifyPage.isDuplicateErrorMessage();

        } catch (Exception e) {
            OrderChequeBook.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterTest() {
        this.browserLib.closeAllBrowsers();
    }

    public WebDriver getDriver() {
        return this.driver;
    }
}
