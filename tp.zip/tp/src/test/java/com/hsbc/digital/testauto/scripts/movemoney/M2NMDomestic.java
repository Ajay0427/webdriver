/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.movemoney;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.models.TransactionFlow;
import com.hsbc.digital.testauto.pageobject.AddBeneficiaryModel;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LandingPageModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyConfirmPageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyVerifyPageModel;

/**
 * <p>
 * <b> Class is used to define all the scenario for Story 39 - M2NM Domestic
 * </b>
 * 
 * @version 1.0.0
 * @author Neeraj Kumar
 * 
 *         </p>
 */

public class M2NMDomestic {

    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    String profile;
    LoginModel loginModel;
    FlyerMenuNavigationModel navigate;
    AddBeneficiaryModel addPayeeModel;
    LandingPageModel landingPageModel;
    MoveMoneyCapturePageModel mmCapturePageModel;
    MoveMoneyVerifyPageModel mmVerifyPageModel;
    MoveMoneyConfirmPageModel mmConfirmPageModel;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(M2NMDomestic.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method testMethod) {
        try {
            this.browserLib = new BrowserLib(browser);
            this.driver = this.browserLib.getDriver();
            this.envProperties = FileUtil.getConfigProperties(entity);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            navigate = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", driver);
            addPayeeModel = (AddBeneficiaryModel) ReflectionUtil.getEntityPOM(entity, "AddBeneficiary", driver);
            mmCapturePageModel = (MoveMoneyCapturePageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyCapturePage", driver);
            mmVerifyPageModel = (MoveMoneyVerifyPageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyVerifyPage", driver);
            mmConfirmPageModel = (MoveMoneyConfirmPageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyConfirmPage", driver);
            landingPageModel = (LandingPageModel) ReflectionUtil.getEntityPOM(entity, "LandingPage", driver);
            profile = XMLUtil.getProfileName(testMethod, entity);
            loginModel.login(profile, this.envProperties);
            loginModel.switchLanguage("English");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception thrown at Login Contructor:", e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "cancelLCY2LCYNowTransactionCapturePage")
    public void cancelLCY2LCYNowTransactionCapturePage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            // TODO : Need to uncomment for entity where its working properly.
            // mmCapturePageModel.isPaymentLimitLinkDisplayed();
            mmCapturePageModel.enterTransferAmount(transaction);
            mmCapturePageModel.enterYourReferenceText(transaction);
            mmCapturePageModel.clickCancelButton();
            mmCapturePageModel.clickCancelPopUpCancelButton();
            landingPageModel.isLeftHandMenuForAccountsOnDashboardDisplayed();
            Reporter.log("cancelLCY2LCYNowTransactionCapturePage test passed.");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "negateCancelLCY2LCYNowTransactionCapturePage")
    public void negateCancelLCY2LCYNowTransactionCapturePage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickCancelButton();
            mmCapturePageModel.clickContinuePopupContinueButton();
            mmCapturePageModel.verifyDetailsAfterNegatingCancelOnCapturePage(transaction);
            Reporter.log("negateCancelLCY2LCYNowTransactionCapturePage test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "cancelLCY2LCYNowTransactionVerifyPage")
    public void cancelLCY2LCYNowTransactionVerifyPage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickCancelButton();
            mmVerifyPageModel.clickCancelPopUpCancelButton();
            mmCapturePageModel.verifyPageTitle();
            Reporter.log("cancelLCY2LCYNowTransactionVerifyPage test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "negateCancelLCY2LCYNowTransactionVerifyPage")
    public void negateCancelLCY2LCYNowTransactionVerifyPage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickCancelButton();
            mmVerifyPageModel.clickContinuePopupContinueButton();
            mmVerifyPageModel.verifyPageTitle();
            Reporter.log("negateCancelLCY2LCYNowTransactionVerifyPage test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "editLCY2LCYNowTransaction")
    public void editLCY2LCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickEditDetailsButton();
            mmCapturePageModel.selectFromAccountByAccountDetail(transaction.getFromAccount());
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyPageTitle();
            mmVerifyPageModel.verifyLCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            Reporter.log("editLCY2LCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmLCY2LCYLaterTransaction")
    public void m2nmLCY2LCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2LCYLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmLCY2LCYLaterTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmLCY2LCYRecurringNumberOfPaymentTransaction")
    public void m2nmLCY2LCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2LCYRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmLCY2LCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmLCY2LCYNowTransaction")
    public void m2nmLCY2LCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2LCYNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            // landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmLCY2LCYNowTransaction test passed");

        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmLCY2LCYNowTransaction")
    public void m2nmLCY2FCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonFCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2FCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2FCYNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmLCY2FCYNowTransaction test passed");

        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmLCY2FCYLaterTransaction")
    public void m2nmLCY2FCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonFCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2FCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2FCYLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmLCY2FCYLaterTransaction test passed");

        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmLCY2FCYRecurringNumberOfPaymentTransaction")
    public void m2nmLCY2FCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonFCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2FCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2FCYRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmLCY2FCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmNonHSBCLCY2LCYNowTransaction")
    public void m2nmNonHSBCLCY2LCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.nonHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyNonHSBCLCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyNonHSBCLCY2LCYNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmNonHSBCLCY2LCYNowTransaction test passed");

        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmNonHSBCLCY2LCYLaterTransaction")
    public void m2nmNonHSBCLCY2LCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.nonHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyNonHSBCLCY2LCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyNonHSBCLCY2LCYLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmNonHSBCLCY2LCYLaterTransaction test passed");

        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmNonHSBCLCY2LCYRecurringNumberOfPaymentTransaction")
    public void m2nmNonHSBCLCY2LCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.nonHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyNonHSBCLCY2LCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyNonHSBCLCY2LCYRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmNonHSBCLCY2FCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmFCY2LCYNowTransaction")
    public void m2nmFCY2LCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyFCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyFCY2LCYNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmFCY2LCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmFCY2LCYLaterTransaction")
    public void m2nmFCY2LCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyFCY2LCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyFCY2LCYLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmFCY2LCYLaterTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmFCY2LCYRecurringNumberOfPaymentTransaction")
    public void m2nmFCY2LCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyFCY2LCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyFCY2LCYRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmFCY2LCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmFCY2FCYNowTransaction")
    public void m2nmFCY2FCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonFCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyFCY2FCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyFCY2FCYNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmFCY2FCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmFCY2FCYLaterTransaction")
    public void m2nmFCY2FCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonFCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyFCY2FCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyFCY2FCYLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmFCY2FCYLaterTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmFCY2FCYRecurringNumberOfPaymentTransaction")
    public void m2nmFCY2FCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonFCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyFCY2FCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyFCY2FCYRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmFCY2FCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmNonHSBCFCY2LCYNowTransaction")
    public void m2nmNonHSBCFCY2LCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.nonHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyNonHSBCFCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyNonHSBCFCY2LCYNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmNonHSBCFCY2LCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmNonHSBCFCY2LCYNowTransaction")
    public void m2nmNonHSBCFCY2FCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.nonHSBCPersonFCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyNonHSBCFCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyNonHSBCFCY2LCYNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmNonHSBCFCY2LCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmNonHSBCFCY2LCYLaterTransaction")
    public void m2nmNonHSBCFCY2LCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.nonHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyNonHSBCFCY2LCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyNonHSBCFCY2LCYLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmNonHSBCFCY2LCYLaterTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmNonHSBCFCY2LCYRecurringNumberOfPaymentTransaction")
    public void m2nmNonHSBCFCY2LCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.nonHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyNonHSBCFCY2LCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyNonHSBCFCY2LCYRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmNonHSBCFCY2LCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "cancelLCY2LCYNowInlineTransactionCapturePage")
    public void cancelInlineLCY2LCYNowTransactionCapturePage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            // mmCapturePageModel.isPaymentLimitLinkDisplayed();
            mmCapturePageModel.enterTransferAmount(transaction);
            mmCapturePageModel.enterYourReferenceText(transaction);
            mmCapturePageModel.clickCancelButton();
            mmCapturePageModel.clickCancelPopUpCancelButton();
            landingPageModel.isLeftHandMenuForAccountsOnDashboardDisplayed();
            Reporter.log("cancelLCY2LCYNowInlineTransactionCapturePage test passed.");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "negateCancelLCY2LCYNowInlineTransactionCapturePage")
    public void negateCancelInlineLCY2LCYNowTransactionCapturePage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickCancelButton();
            mmCapturePageModel.clickContinuePopupContinueButton();
            mmCapturePageModel.verifyInlineDetailsAfterNegatingCancelOnCapturePage(transaction);
            Reporter.log("negateCancelLCY2LCYNowInlineTransactionCapturePage test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "cancelInlineLCY2LCYNowTransactionVerifyPage")
    public void cancelInlineLCY2LCYNowTransactionVerifyPage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyLCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickCancelButton();
            mmVerifyPageModel.clickCancelPopUpCancelButton();
            mmCapturePageModel.verifyPageTitle();
            Reporter.log("cancelLCY2LCYNowTransactionVerifyPage test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "negateCancelInlineLCY2LCYNowTransactionVerifyPage")
    public void negateCancelInlineLCY2LCYNowTransactionVerifyPage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyLCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickCancelButton();
            mmVerifyPageModel.clickContinuePopupContinueButton();
            mmVerifyPageModel.verifyPageTitle();
            Reporter.log("negateCancelInlineLCY2LCYNowTransactionVerifyPage test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "editInlineLCY2LCYNowTransaction")
    public void editInlineLCY2LCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyLCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickEditDetailsButton();
            mmCapturePageModel.selectFromAccountByAccountDetail(transaction.getFromAccount());
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyPageTitle();
            mmVerifyPageModel.verifyLCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            Reporter.log("editInlineLCY2LCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineLCY2LCYNowTransaction")
    public void m2nmInlineLCY2LCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyLCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2LCYNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmInlineLCY2LCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineLCY2LCYLaterTransaction")
    public void m2nmInlineLCY2LCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyLCY2LCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2LCYLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmInlineLCY2LCYLaterTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineLCY2LCYRecurringNumberOfPaymentTransaction")
    public void m2nmInlineLCY2LCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyLCY2LCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2LCYRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmInlineLCY2LCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineLCY2FCYNowTransaction")
    public void m2nmInlineLCY2FCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticFCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyLCY2FCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2FCYNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmInlineLCY2FCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineLCY2FCYLaterTransaction")
    public void m2nmInlineLCY2FCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticFCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyLCY2FCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2FCYLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmInlineLCY2FCYLaterTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineLCY2FCYRecurringNumberOfPaymentTransaction")
    public void m2nmInlineLCY2FCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticFCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyLCY2FCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2FCYRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmInlineLCY2FCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmInlineNonHSBCLCY2LCYNowTransaction")
    public void m2nmInlineNonHSBCLCY2LCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewNonHSBCDomesticPayeeDetails());
            transaction.setAddress1(mmCapturePageModel.enterAddress());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyInlineNonHSBCLCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyInlineNonHSBCLCY2LCYNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmInlineNonHSBCLCY2LCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineNonHSBCLCY2LCYLaterTransaction")
    public void m2nmInlineNonHSBCLCY2LCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewNonHSBCDomesticPayeeDetails());
            transaction.setAddress1(mmCapturePageModel.enterAddress());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyInlineNonHSBCLCY2LCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyInlineNonHSBCLCY2LCYLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmInlineNonHSBCLCY2LCYLaterTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineNonHSBCLCY2LCYRecurringNumberOfPaymentTransaction")
    public void m2nmInlineNonHSBCLCY2LCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewNonHSBCDomesticPayeeDetails());
            transaction.setAddress1(mmCapturePageModel.enterAddress());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyInlineNonHSBCLCY2LCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyInlineNonHSBCLCY2LCYRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmInlineNonHSBCLCY2LCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineFCY2LCYNowTransaction")
    public void m2nmInlineFCY2LCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyFCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyFCY2LCYNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmInlineFCY2LCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineFCY2LCYLaterTransaction")
    public void m2nmInlineFCY2LCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyFCY2LCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyFCY2LCYLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmInlineFCY2LCYLaterTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineFCY2LCYRecurringNumberOfPaymentTransaction")
    public void m2nmInlineFCY2LCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyFCY2LCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyFCY2LCYRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmInlineFCY2LCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineFCY2FCYNowTransaction")
    public void m2nmInlineFCY2FCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticFCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyFCY2FCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyFCY2FCYNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmInlineFCY2FCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineFCY2FCYLaterTransaction")
    public void m2nmInlineFCY2FCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticFCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyFCY2FCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyFCY2FCYLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmInlineFCY2FCYLaterTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineFCY2FCYRecurringNumberOfPaymentTransaction")
    public void m2nmInlineFCY2FCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticFCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyFCY2FCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyFCY2FCYRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmInlineFCY2FCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineNonHSBCFCY2LCYNowTransaction")
    public void m2nmInlineNonHSBCFCY2LCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewNonHSBCDomesticPayeeDetails());
            transaction.setAddress1(mmCapturePageModel.enterAddress());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyInlineNonHSBCFCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyInlineNonHSBCFCY2LCYNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmInlineNonHSBCFCY2LCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineNonHSBCFCY2LCYLaterTransaction")
    public void m2nmInlineNonHSBCFCY2LCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewNonHSBCDomesticPayeeDetails());
            transaction.setAddress1(mmCapturePageModel.enterAddress());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyInlineNonHSBCFCY2LCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyInlineNonHSBCFCY2LCYLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmInlineNonHSBCFCY2LCYLaterTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineNonHSBCFCY2LCYRecurringNumberOfPaymentTransaction")
    public void m2nmInlineNonHSBCFCY2LCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewNonHSBCDomesticPayeeDetails());
            transaction.setAddress1(mmCapturePageModel.enterAddress());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyInlineNonHSBCFCY2LCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyInlineNonHSBCFCY2LCYRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmInlineNonHSBCFCY2LCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterTest() {
        this.browserLib.closeAllBrowsers();
    }

    /**
     * 
     * <p>
     * <b> This method is used to take screen shot so every test script should
     * have it as it is used by Framework internally. </b>
     * </p>
     * 
     * @return driver
     */
    public WebDriver getDriver() {
        return this.driver;
    }
}
