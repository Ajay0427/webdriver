/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.communication;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.pageobject.ContactMeAndContactRMModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;

/**
 * <p>
 * <b> This script is for Story 19&22 Contact us and Contact RM</b>
 * 
 * @author Vaibhav Sharma
 * @version 1.0.0
 *          </p>
 */
public class ContactMeAndContactRM {

    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    ContactMeAndContactRMModel contactMeAndContactRMModel;


    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(ContactMeAndContactRM.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method method) {
        try {
            browserLib = new BrowserLib(browser);
            driver = browserLib.getDriver();
            envProperties = FileUtil.getConfigProperties(entity);
            // String profile = "TEST_212";
            String profile = XMLUtil.getProfileName(method, entity);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            contactMeAndContactRMModel = (ContactMeAndContactRMModel) ReflectionUtil.getEntityPOM(entity, "ContactMeAndContactRM",
                driver);
            loginModel.login(profile, envProperties);
        } catch (Exception e) {
            ContactMeAndContactRM.logger.error("Exception thrown at Login Contructor:", e);
        }
    }

    // This will complete the flow of contact RM and verify functionality of
    // Back To My Account button
    @Test(testName = "Complete E2E flow of contact RM", groups = {"functionaltest"})
    public void contactRMFlowE2E() {
        try {
            // ?? move this to flyer navigation object
            contactMeAndContactRMModel.mouseOverOnContactUs();
            contactMeAndContactRMModel.navigateContactRMPage();
            Transaction transaction = contactMeAndContactRMModel.captureContactRMDetails();
            contactMeAndContactRMModel.clickSubmitButton();
            contactMeAndContactRMModel.validateReviewPage(transaction);
            contactMeAndContactRMModel.clickConfirmButton();
            contactMeAndContactRMModel.verifyConfirmationMessage();
            contactMeAndContactRMModel.verifyBackToMyAccountFunctionality();
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :", e);
            ContactMeAndContactRM.logger.error("Exception at:", e);
        }
    }

    @Test(testName = "Cancel the flow from capture page", groups = {"functionaltest"})
    public void capturePageCancelButton() {
        try {
            contactMeAndContactRMModel.mouseOverOnContactUs();
            contactMeAndContactRMModel.navigateContactRMPage();
            contactMeAndContactRMModel.captureContactRMDetails();
            contactMeAndContactRMModel.verifyCancelButtonFunctinalityCapture();
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :", e);
            ContactMeAndContactRM.logger.error("Exception :", e);
        }
    }

    @Test(testName = "Cancel the flow from review page", groups = {"functionaltest"})
    public void reviewPageCancelButton() {
        try {
            contactMeAndContactRMModel.mouseOverOnContactUs();
            contactMeAndContactRMModel.navigateContactRMPage();
            contactMeAndContactRMModel.captureContactRMDetails();
            contactMeAndContactRMModel.clickSubmitButton();
            contactMeAndContactRMModel.verifyCancelButtonFunctinalityReview();
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :", e);
            ContactMeAndContactRM.logger.error("Exception :", e);
        }
    }


    @Test(testName = "verify functionality of edit details button", groups = {"functionaltest"})
    public void reviewPageEditDetailsButton() {
        try {
            contactMeAndContactRMModel.mouseOverOnContactUs();
            contactMeAndContactRMModel.navigateContactRMPage();
            contactMeAndContactRMModel.captureContactRMDetails();
            contactMeAndContactRMModel.clickSubmitButton();
            contactMeAndContactRMModel.verifyEditDetailsFunctionality();
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :", e);
            ContactMeAndContactRM.logger.error("Exception :", e);
        }
    }

    @Test(testName = "E2E testing of Contact US", groups = {"functionaltest"})
    public void contactUsFlow() {
        try {
            contactMeAndContactRMModel.mouseOverOnContactUs();
            contactMeAndContactRMModel.navigateContactUSPage();
            contactMeAndContactRMModel.selectEnquiryAboutContactUs();
            contactMeAndContactRMModel.verifyLinksOnContactUsPage();
            contactMeAndContactRMModel.verifyRequestCallBackLinkFunctionality();
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :", e);
            ContactMeAndContactRM.logger.error("Exception :", e);
        }
    }


}
