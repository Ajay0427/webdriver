/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.movemoney;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.models.TransactionFlow;
import com.hsbc.digital.testauto.pageobject.AddBeneficiaryModel;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LandingPageModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModelNew;
import com.hsbc.digital.testauto.pageobject.MoveMoneyConfirmPageModelNew;
import com.hsbc.digital.testauto.pageobject.MoveMoneyVerifyPageModelNew;

/**
 * <p>
 * <b> Class is used to define all the scenario for Story 39 - M2NM Domestic
 * </b>
 * 
 * @version 1.0.0
 * @author Neeraj Kumar
 * 
 *         </p>
 */

public class M2NMDomesticAU {

    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    String profile;
    LoginModel loginModel;
    FlyerMenuNavigationModel navigate;
    AddBeneficiaryModel addPayeeModel;
    LandingPageModel landingPageModel;
    MoveMoneyCapturePageModelNew mmCapturePageModel;
    MoveMoneyVerifyPageModelNew mmVerifyPageModel;
    MoveMoneyConfirmPageModelNew mmConfirmPageModel;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(M2NMDomesticAU.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method testMethod) {
        try {
            this.browserLib = new BrowserLib(browser);
            this.driver = this.browserLib.getDriver();
            this.envProperties = FileUtil.getConfigProperties(entity);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            navigate = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", driver);
            addPayeeModel = (AddBeneficiaryModel) ReflectionUtil.getEntityPOM(entity, "AddBeneficiary", driver);
            mmCapturePageModel = (MoveMoneyCapturePageModelNew) ReflectionUtil.getEntityPOM(entity, "MoveMoneyCapturePageAU",
                driver);
            mmVerifyPageModel = (MoveMoneyVerifyPageModelNew) ReflectionUtil.getEntityPOM(entity, "MoveMoneyVerifyPageAU", driver);
            mmConfirmPageModel = (MoveMoneyConfirmPageModelNew) ReflectionUtil.getEntityPOM(entity, "MoveMoneyConfirmPageAU",
                driver);
            landingPageModel = (LandingPageModel) ReflectionUtil.getEntityPOM(entity, "LandingPage", driver);
            profile = XMLUtil.getProfileName(testMethod, entity);
            loginModel.login(profile, this.envProperties);
            loginModel.switchLanguage("English");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception thrown at Login Contructor:", e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "cancelLCY2LCYNowTransactionCapturePage")
    public void cancelLCY2LCYNowTransactionCapturePage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            // TODO : Need to uncomment for entity where its working properly.
            // mmCapturePageModel.isPaymentLimitLinkDisplayed();
            mmCapturePageModel.enterTransferAmount(transaction);
            mmCapturePageModel.enterYourReferenceText(transaction);
            mmCapturePageModel.clickCancelButton();
            mmCapturePageModel.clickCancelPopUpCancelButton();
            landingPageModel.isLeftHandMenuForAccountsOnDashboardDisplayed();
            Reporter.log("cancelLCY2LCYNowTransactionCapturePage test passed.");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "negateCancelLCY2LCYNowTransactionCapturePage")
    public void negateCancelLCY2LCYNowTransactionCapturePage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickCancelButton();
            mmCapturePageModel.clickContinuePopupContinueButton();
            mmCapturePageModel.verifyDetailsAfterNegatingCancelOnCapturePage(transaction);
            Reporter.log("negateCancelLCY2LCYNowTransactionCapturePage test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "cancelLCY2LCYNowTransactionVerifyPage")
    public void cancelLCY2LCYNowTransactionVerifyPage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMLCY2LCYHsbcNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickCancelButton();
            mmVerifyPageModel.clickCancelPopUpCancelButton();
            mmCapturePageModel.verifyPageTitle();
            Reporter.log("cancelLCY2LCYNowTransactionVerifyPage test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "negateCancelLCY2LCYNowTransactionVerifyPage")
    public void negateCancelLCY2LCYNowTransactionVerifyPage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMLCY2LCYHsbcNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickCancelButton();
            mmVerifyPageModel.clickContinuePopupContinueButton();
            mmVerifyPageModel.verifyPageTitle();
            Reporter.log("negateCancelLCY2LCYNowTransactionVerifyPage test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "editLCY2LCYNowTransaction")
    public void editLCY2LCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMLCY2LCYHsbcNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickEditDetailsButton();
            mmCapturePageModel.selectFromAccountByAccountDetail(transaction.getFromAccount());
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyPageTitle();
            mmVerifyPageModel.verifyM2NMLCY2LCYHsbcNowTransactionDetailsOnVerifyPage(transaction);
            Reporter.log("editLCY2LCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmLCY2LCYLaterTransaction")
    public void m2nmLCY2LCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMLCY2LCYHsbcLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMLCY2LCYHsbcLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmLCY2LCYLaterTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmLCY2LCYRecurringNumberOfPaymentTransaction")
    public void m2nmLCY2LCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMLCY2LCYHsbcRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMLCY2LCYHsbcRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmLCY2LCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmLCY2LCYNowTransaction")
    public void m2nmLCY2LCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMLCY2LCYHsbcNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMLCY2LCYHsbcNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmLCY2LCYNowTransaction test passed");

        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmLCY2LCYNowTransaction")
    public void m2nmLCY2FCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonFCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMLCY2FCYHsbcNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMLCY2FCYHsbcNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmLCY2FCYNowTransaction test passed");

        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmLCY2FCYLaterTransaction")
    public void m2nmLCY2FCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonFCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMLCY2FCYHsbcLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMLCY2FCYHsbcLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmLCY2FCYLaterTransaction test passed");

        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmLCY2FCYRecurringNumberOfPaymentTransaction")
    public void m2nmLCY2FCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonFCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMLCY2FCYHsbcRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMLCY2FCYHsbcRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmLCY2FCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmFCY2LCYNowTransaction")
    public void m2nmFCY2LCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMFCY2LCYHsbcNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMFCY2LCYHsbcNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmFCY2LCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmFCY2LCYLaterTransaction")
    public void m2nmFCY2LCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMFCY2LCYHsbcLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMFCY2LCYHsbcLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmFCY2LCYLaterTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmFCY2LCYRecurringNumberOfPaymentTransaction")
    public void m2nmFCY2LCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMFCY2LCYHsbcRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMFCY2LCYHsbcRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmFCY2LCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmFCY2FCYNowTransaction")
    public void m2nmFCY2FCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonFCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMFCY2FCYHsbcNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMFCY2FCYHsbcNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmFCY2FCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmFCY2FCYLaterTransaction")
    public void m2nmFCY2FCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonFCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMFCY2FCYHsbcLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMFCY2FCYHsbcLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmFCY2FCYLaterTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmFCY2FCYRecurringNumberOfPaymentTransaction")
    public void m2nmFCY2FCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonFCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMFCY2FCYHsbcRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMFCY2FCYHsbcRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmFCY2FCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmNonHSBCLCY2LCYNowTransaction")
    public void m2nmNonHSBCLCY2LCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.nonHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMLCY2LCYNonHsbcNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMLCY2LCYNonHsbcNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmNonHSBCLCY2LCYNowTransaction test passed");

        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmNonHSBCLCY2LCYLaterTransaction")
    public void m2nmNonHSBCLCY2LCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.nonHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMLCY2LCYNonHsbcLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMLCY2LCYNonHsbcLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmNonHSBCLCY2LCYLaterTransaction test passed");

        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmNonHSBCLCY2LCYRecurringNumberOfPaymentTransaction")
    public void m2nmNonHSBCLCY2LCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.nonHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMLCY2LCYNonHsbcRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMLCY2LCYNonHsbcRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmNonHSBCLCY2FCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmNonHSBCFCY2LCYNowTransaction")
    public void m2nmNonHSBCFCY2LCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.nonHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMFCY2LCYNonHsbcNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMFCY2LCYNonHsbcNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmNonHSBCFCY2LCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmNonHSBCFCY2LCYLaterTransaction")
    public void m2nmNonHSBCFCY2LCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.nonHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMFCY2LCYNonHsbcLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMFCY2LCYNonHsbcLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmNonHSBCFCY2LCYLaterTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmNonHSBCFCY2LCYRecurringNumberOfPaymentTransaction")
    public void m2nmNonHSBCFCY2LCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.nonHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMFCY2LCYNonHsbcRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMFCY2LCYNonHsbcRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmNonHSBCFCY2LCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmNonHSBCFCY2LCYNowTransaction")
    public void m2nmNonHSBCFCY2FCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.nonHSBCPersonFCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMFCY2FCYNonHsbcNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMFCY2FCYNonHsbcNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmNonHSBCFCY2LCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "cancelLCY2LCYNowInlineTransactionCapturePage")
    public void cancelInlineLCY2LCYNowTransactionCapturePage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            // mmCapturePageModel.isPaymentLimitLinkDisplayed();
            mmCapturePageModel.enterTransferAmount(transaction);
            mmCapturePageModel.enterYourReferenceText(transaction);
            mmCapturePageModel.clickCancelButton();
            mmCapturePageModel.clickCancelPopUpCancelButton();
            landingPageModel.isLeftHandMenuForAccountsOnDashboardDisplayed();
            Reporter.log("cancelLCY2LCYNowInlineTransactionCapturePage test passed.");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "negateCancelLCY2LCYNowInlineTransactionCapturePage")
    public void negateCancelInlineLCY2LCYNowTransactionCapturePage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickCancelButton();
            mmCapturePageModel.clickContinuePopupContinueButton();
            mmCapturePageModel.verifyInlineDetailsAfterNegatingCancelOnCapturePage(transaction);
            Reporter.log("negateCancelLCY2LCYNowInlineTransactionCapturePage test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "cancelInlineLCY2LCYNowTransactionVerifyPage")
    public void cancelInlineLCY2LCYNowTransactionVerifyPage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2NMLCY2LCYHsbcInlineNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickCancelButton();
            mmVerifyPageModel.clickCancelPopUpCancelButton();
            mmCapturePageModel.verifyPageTitle();
            Reporter.log("cancelLCY2LCYNowTransactionVerifyPage test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "negateCancelInlineLCY2LCYNowTransactionVerifyPage")
    public void negateCancelInlineLCY2LCYNowTransactionVerifyPage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyM2NMLCY2LCYHsbcInlineNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickCancelButton();
            mmVerifyPageModel.clickContinuePopupContinueButton();
            mmVerifyPageModel.verifyPageTitle();
            Reporter.log("negateCancelInlineLCY2LCYNowTransactionVerifyPage test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "editInlineLCY2LCYNowTransaction")
    public void editInlineLCY2LCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyM2NMLCY2LCYHsbcInlineNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickEditDetailsButton();
            mmCapturePageModel.selectFromAccountByAccountDetail(transaction.getFromAccount());
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyPageTitle();
            mmVerifyPageModel.verifyM2NMLCY2LCYHsbcInlineNowTransactionDetailsOnVerifyPage(transaction);
            Reporter.log("editInlineLCY2LCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmInlineLCY2LCYNowTransaction")
    public void m2nmInlineLCY2LCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyM2NMLCY2LCYHsbcInlineNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMLCY2LCYHsbcInlineNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmInlineLCY2LCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmInlineLCY2LCYLaterTransaction")
    public void m2nmInlineLCY2LCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyM2NMLCY2LCYHsbcInlineLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMLCY2LCYHsbcInlineLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmInlineLCY2LCYLaterTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmInlineLCY2LCYRecurringNumberOfPaymentTransaction")
    public void m2nmInlineLCY2LCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyM2NMLCY2LCYHsbcInlineRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMLCY2LCYHsbcInlineRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmInlineLCY2LCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmInlineLCY2FCYNowTransaction")
    public void m2nmInlineLCY2FCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticFCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyM2NMLCY2FCYHsbcInlineNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMLCY2FCYHsbcInlineNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmInlineLCY2FCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineLCY2FCYLaterTransaction")
    public void m2nmInlineLCY2FCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticFCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyM2NMLCY2FCYHsbcInlineLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMLCY2FCYHsbcInlineLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmInlineLCY2FCYLaterTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineLCY2FCYRecurringNumberOfPaymentTransaction")
    public void m2nmInlineLCY2FCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticFCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyM2NMLCY2FCYHsbcInlineRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMLCY2FCYHsbcInlineRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmInlineLCY2FCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineFCY2LCYNowTransaction")
    public void m2nmInlineFCY2LCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyM2NMFCY2LCYHsbcInlineNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMFCY2LCYHsbcInlineNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmInlineFCY2LCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmInlineFCY2LCYLaterTransaction")
    public void m2nmInlineFCY2LCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyM2NMFCY2LCYHsbcInlineLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMFCY2LCYHsbcInlineLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmInlineFCY2LCYLaterTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmInlineFCY2LCYRecurringNumberOfPaymentTransaction")
    public void m2nmInlineFCY2LCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticLCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyM2NMFCY2LCYHsbcInlineRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMFCY2LCYHsbcInlineRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmInlineFCY2LCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmInlineFCY2FCYNowTransaction")
    public void m2nmInlineFCY2FCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticFCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyM2NMFCY2FCYHsbcInlineNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMFCY2FCYHsbcInlineNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmInlineFCY2FCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineFCY2FCYLaterTransaction")
    public void m2nmInlineFCY2FCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticFCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyM2NMFCY2FCYHsbcInlineLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMFCY2FCYHsbcInlineLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmInlineFCY2FCYLaterTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineFCY2FCYRecurringNumberOfPaymentTransaction")
    public void m2nmInlineFCY2FCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewHSBCDomesticFCYPayeeDetails(profile, envProperties));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyM2NMFCY2FCYHsbcInlineRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMFCY2FCYHsbcInlineRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmInlineFCY2FCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmInlineNonHSBCFCY2LCYNowTransaction")
    public void m2nmInlineNonHSBCFCY2LCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewNonHSBCDomesticPayeeDetails());
            transaction.setAddress1(mmCapturePageModel.enterAddress());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyM2NMFCY2LCYNonHsbcInlineNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMFCY2LCYNonHsbcNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmInlineNonHSBCFCY2LCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmInlineNonHSBCFCY2LCYLaterTransaction")
    public void m2nmInlineNonHSBCFCY2LCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewNonHSBCDomesticPayeeDetails());
            transaction.setAddress1(mmCapturePageModel.enterAddress());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyM2NMFCY2LCYNonHsbcInlineLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMFCY2LCYNonHsbcInlineLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmInlineNonHSBCFCY2LCYLaterTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmInlineNonHSBCFCY2LCYRecurringNumberOfPaymentTransaction")
    public void m2nmInlineNonHSBCFCY2LCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewNonHSBCDomesticPayeeDetails());
            transaction.setAddress1(mmCapturePageModel.enterAddress());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyM2NMFCY2LCYNonHsbcInlineRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMFCY2LCYHsbcRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmInlineNonHSBCFCY2LCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2nmInlineNonHSBCLCY2LCYNowTransaction")
    public void m2nmInlineNonHSBCLCY2LCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewNonHSBCDomesticPayeeDetails());
            transaction.setAddress1(mmCapturePageModel.enterAddress());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyM2NMLCY2LCYNonHsbcInlineNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMLCY2LCYNonHsbcInlineNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2nmInlineNonHSBCLCY2LCYNowTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineNonHSBCLCY2LCYLaterTransaction")
    public void m2nmInlineNonHSBCLCY2LCYLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewNonHSBCDomesticPayeeDetails());
            transaction.setAddress1(mmCapturePageModel.enterAddress());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyM2NMLCY2LCYNonHsbcInlineLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMLCY2LCYNonHsbcInlineLaterTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();
            Reporter.log("m2nmInlineNonHSBCLCY2LCYLaterTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmInlineNonHSBCLCY2LCYRecurringNumberOfPaymentTransaction")
    public void m2nmInlineNonHSBCLCY2LCYRecurringNumberOfPaymentTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMNONHSBC_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.enterNewNonHSBCDomesticPayeeDetails());
            transaction.setAddress1(mmCapturePageModel.enterAddress());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeReferenceText());
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueWithTDS(profile, envProperties, transaction);
            mmVerifyPageModel.verifyM2NMLCY2LCYNonHsbcInlineRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2NMLCY2LCYHsbcRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2nmInlineNonHSBCLCY2LCYRecurringNumberOfPaymentTransaction test passed");
        } catch (Exception e) {
            M2NMDomesticAU.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterTest() {
        this.browserLib.closeAllBrowsers();
    }


}
