/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.accountservicing;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.UpdateMaturityInstructionModel;

/**
 * <p>
 * <b> This class will hold testing scripts for story 85  Update Maturity Instruction </b>
 * </p>
 * 
 * @version 1.0.0
 * @author Vaibhav Sharma
 * 
 */
public class UpdateMaturityInstruction {

    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    UpdateMaturityInstructionModel objUpdateMaturityInstructionModel;


    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(UpdateMaturityInstruction.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method method) {
        try {
            browserLib = new BrowserLib(browser);
            driver = browserLib.getDriver();
            envProperties = FileUtil.getConfigProperties(entity);
            String profile = XMLUtil.getProfileName(method, entity);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            objUpdateMaturityInstructionModel = (UpdateMaturityInstructionModel) ReflectionUtil.getEntityPOM(entity,
                "UpdateMaturityInstruction", driver);
            loginModel.login(profile, envProperties);
        } catch (Exception e) {
            UpdateMaturityInstruction.logger.error("Exception thrown at Login Contructor:", e);
        }
    }

    // This will complete the process of Update Maturity Instruction
    @Test(testName = "End to end flow for Update Matirity Instruction", groups = {"functionaltest"})
    public void updateMaturityInstructionEndToEnd() {
        try {
            objUpdateMaturityInstructionModel.updateMaturityInstructionEndToEndFlow(true);

        } catch (Exception e) {
            UpdateMaturityInstruction.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());

        }
    }

    @Test(testName = "Cancel flow from capture page", groups = {"functionaltest"})
    public void cancelUpdateMaturityFlowCapturePage() {
        try {
            objUpdateMaturityInstructionModel.updateMaturityInstructionEndToEndFlow(false);
            objUpdateMaturityInstructionModel.cancelFlowFromCapturePage();

        } catch (Exception e) {
            UpdateMaturityInstruction.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
        }
    }

    @Test(testName = "Cancel flow from review page", groups = {"functionaltest"})
    public void cancelUpdateMaturityFlowReviewPage() {
        try {
            objUpdateMaturityInstructionModel.updateMaturityInstructionEndToEndFlow(false);
            objUpdateMaturityInstructionModel.captureUpdateMaturityDetails();
            objUpdateMaturityInstructionModel.clicksContinueButton();
            objUpdateMaturityInstructionModel.cancelFlowFromReviewPage();


        } catch (Exception e) {
            UpdateMaturityInstruction.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());

        }
    }


    @Test(testName = "Back to My Account button functionality", groups = {"functionaltest"})
    public void verifyBackToMyAccountButtonFunctionality() {
        try {
            objUpdateMaturityInstructionModel.updateMaturityInstructionEndToEndFlow(false);
            objUpdateMaturityInstructionModel.captureUpdateMaturityDetails();
            objUpdateMaturityInstructionModel.clicksContinueButton();
            objUpdateMaturityInstructionModel.clicksConfirmButton();
            objUpdateMaturityInstructionModel.verifyBackToMYAccountFunctionality();


        } catch (Exception e) {
            UpdateMaturityInstruction.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());

        }
    }

    @Test(testName = "Print button functionality", groups = {"functionaltest"})
    public void verifyPrintButtonFunctionality() {
        try {
            objUpdateMaturityInstructionModel.updateMaturityInstructionEndToEndFlow(false);
            objUpdateMaturityInstructionModel.captureUpdateMaturityDetails();
            objUpdateMaturityInstructionModel.clicksContinueButton();
            objUpdateMaturityInstructionModel.clicksConfirmButton();
            objUpdateMaturityInstructionModel.verifyfunctionalityofPrintButtonConfirmation();

        } catch (Exception e) {
            UpdateMaturityInstruction.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());

        }
    }


    @Test(testName = "Edit Details button functionality", groups = {"functionaltest"})
    public void verifyEditDetailsButtonFunctionality() {
        try {
            objUpdateMaturityInstructionModel.updateMaturityInstructionEndToEndFlow(false);
            objUpdateMaturityInstructionModel.captureUpdateMaturityDetails();
            objUpdateMaturityInstructionModel.clicksContinueButton();
            objUpdateMaturityInstructionModel.verifyEditDetailsButtonFunctionality();

        } catch (Exception e) {
            UpdateMaturityInstruction.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());

        }
    }
}
