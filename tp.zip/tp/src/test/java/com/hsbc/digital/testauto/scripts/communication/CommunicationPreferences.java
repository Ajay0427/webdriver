/**
 * <p>
 * <b> This class will hold testing scripts for story 11 - Communication
 * Preferences </b>
 * </p>
 * 
 * @version 1.0.0
 * @author Bhargav Choudhury
 * 
 */

package com.hsbc.digital.testauto.scripts.communication;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.models.CommunicationPreferencess;
import com.hsbc.digital.testauto.pageobject.CommunicationPreferencesConfirmPageModel;
import com.hsbc.digital.testauto.pageobject.CommunicationPreferencesModel;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;

public class CommunicationPreferences {

    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    FlyerMenuNavigationModel flyerMenuNavigation;
    CommunicationPreferencesModel communicationPreferencesModel;
    CommunicationPreferencesConfirmPageModel communicationPreferencesConfirmPageModel;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(CommunicationPreferences.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, Method testMethod) throws IOException {
        try {
            this.browserLib = new BrowserLib(browser);
            this.driver = this.browserLib.getDriver();
            this.envProperties = FileUtil.getConfigProperties(entity);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            communicationPreferencesModel = (CommunicationPreferencesModel) ReflectionUtil.getEntityPOM(entity,
                "CommunicationPreferences", driver);
            communicationPreferencesConfirmPageModel = (CommunicationPreferencesConfirmPageModel) ReflectionUtil.getEntityPOM(
                entity, "CommunicationPreferencesConfirmPage", driver);
            flyerMenuNavigation = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", driver);
            String profile = XMLUtil.getProfileName(testMethod, entity);
            loginModel.login(profile, envProperties);
            loginModel.switchLanguage("English");
        } catch (Exception e) {
            logger.error("Exception thrown at Login Contructor:", e);
        }
    }

    @Test(groups = {"functionaltest"}, enabled = true)
    public void verify() {
        try {
            communicationPreferencesModel.navigateToCP();
            communicationPreferencesModel.verifyDetails();
            communicationPreferencesModel.verifyLevel();
            communicationPreferencesModel.defaultStatementPreference();
            communicationPreferencesModel.clicknCloseTnC();
            communicationPreferencesModel.clickCancelBtn();
            communicationPreferencesModel.getMyBankingPageTitle();
        } catch (Exception e) {
            logger.info(e);
        }
    }

    @Test(groups = {"functionaltest"}, enabled = true)
    public void changeStatementType() {
        try {
            communicationPreferencesModel.navigateToCP();
            communicationPreferencesModel.changeDefaultStatementType();
            communicationPreferencesModel.clickCheckBox();
            communicationPreferencesModel.verifySaveButtonActions();
        } catch (Exception e) {
            logger.info(e);
            Assert.fail("Error: " + e.getMessage());
        }
    }


    @Test(groups = {"functionaltest"}, enabled = true)
    public void cancelUpdatePreferences() {
        try {
            communicationPreferencesModel.navigateToCP();
            communicationPreferencesModel.clickUncheckedRadioBtn();
            communicationPreferencesModel.clickCheckBox();
            communicationPreferencesModel.clickCancelBtn();
            communicationPreferencesModel.clickPopUpCancelBtn();
            communicationPreferencesModel.getMyBankingPageTitle();
        } catch (Exception e) {
            logger.info(e);
            Assert.fail("Error: " + e.getMessage());
        }
    }


    @Test(groups = {"functionaltest"}, enabled = true)
    public void dontCancelUpdatePreferences() {
        try {
            communicationPreferencesModel.navigateToCP();
            communicationPreferencesModel.clickUncheckedRadioBtn();
            communicationPreferencesModel.clickCheckBox();
            communicationPreferencesModel.clickCancelBtn();
            communicationPreferencesModel.clickPopUpDontCancelBtn();
            communicationPreferencesModel.getCommPageTitle();
        } catch (Exception e) {
            logger.info(e);
            Assert.fail("Error: " + e.getMessage());
        }
    }

    /** Test cases specific to entity UK **/

    @Test(groups = {"functionaltest"})
    public void communicationPreferencesE2EUK() {
        try {
            flyerMenuNavigation.navigateToCP();
            CommunicationPreferencess communicationPreferences = communicationPreferencesModel.capturePageFlow();
            communicationPreferencesConfirmPageModel.confirmPageFlow(communicationPreferences);
        } catch (Exception e) {
            logger.info(e);
            Assert.fail("Error: " + e.getMessage());
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterMethod() {
        browserLib.closeAllBrowsers();
    }

    /**
     * 
     * <p>
     * <b> This method is used to take screen shot so every test script should
     * have it as it is used by Framework internally. </b>
     * </p>
     * 
     * @return driver
     */
    public WebDriver getDriver() {
        return driver;
    }

}