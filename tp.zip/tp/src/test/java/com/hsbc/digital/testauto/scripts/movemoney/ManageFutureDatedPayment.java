/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.movemoney;

import java.lang.reflect.Method;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.models.ManageFutureDatedDetails;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.ManageFutureDatedPaymentModel;

/**
 * <p>
 * <b> This Test script class has scripts for Story 43 - Manage Future Dated
 * Payments, it is for checking Transaction list with no Filter and Filter
 * functionality and also verifying the Edit, Delete and Print functionality
 * for each transaction </b>
 * </p>
 */
public class ManageFutureDatedPayment {

    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    ManageFutureDatedPaymentModel manageFutureDatedPaymentModel;
    FlyerMenuNavigationModel flyerMenuNavigationModel;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(ManageFutureDatedPayment.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method method) {
        try {
            this.browserLib = new BrowserLib(browser);
            this.driver = this.browserLib.getDriver();
            this.envProperties = FileUtil.getConfigProperties(entity);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            manageFutureDatedPaymentModel = (ManageFutureDatedPaymentModel) ReflectionUtil.getEntityPOM(entity,
                "ManageFutureDatedPayment", driver);
            flyerMenuNavigationModel = (FlyerMenuNavigationModel) ReflectionUtil
                .getEntityPOM(entity, "FlyerMenuNavigation", driver);
            String profile = XMLUtil.getProfileName(method, entity);
            loginModel.login(profile, this.envProperties);
            loginModel.switchLanguage("English");
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception thrown at Login Contructor:", e);
        }
    }

    /**
     * Test Case is for verifying the Transaction list displayed By Account
     * when no filter is applied and also Print functionality of the
     * Transaction List. DONES
     */
    @Test(groups = {"functionaltest"})
    public void verifyNoFilterByDateAndPrint() {
        try {
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.clickAccountTabForViewList();
            manageFutureDatedPaymentModel.verifyPrintForWholeList();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the Transaction list displayed by Date when
     * no filter is applied and check the details in the Show Details of a
     * transaction and Print functionality of a particular Transaction. DONES
     */
    @Test(groups = {"functionaltest"})
    public void verifyNoFilterByAccountAndShowDetailsPrint() {
        try {
            ManageFutureDatedDetails objmanageFDT;
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            manageFutureDatedPaymentModel.clickDateTabForViewList();
            objmanageFDT = manageFutureDatedPaymentModel.selectTransactionFromList();
            manageFutureDatedPaymentModel.verifyShowDetailsContent(objmanageFDT);
            manageFutureDatedPaymentModel.verifyPrintFromShowDetails();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    /**
     * Test Case is for verifying the Transaction list by Date when filter is
     * applied for Any selection from dropdown for From Date, To Date and Date
     * Range
     */
    @Test(groups = {"functionaltest"})
    public void verifyFilterByDateAllTypeAllFrequencyAndCheckDate() {
        try {
            ManageFutureDatedDetails manageFDTDate;
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            manageFDTDate = manageFutureDatedPaymentModel.getMaximumAndMinimumDateFromList();
            manageFutureDatedPaymentModel.clickFilterButton();
            manageFutureDatedPaymentModel.clickDateTabForViewList();
            manageFutureDatedPaymentModel.enterAccountAllTypeFrequencyFromDate(manageFDTDate);
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
            manageFutureDatedPaymentModel.enterAccountToDateAndClearFromDate(manageFDTDate);
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
            manageFutureDatedPaymentModel.enterAccountFromAndToDateAndClearToDate(manageFDTDate);
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the Transaction list by Date when filter is
     * applied for Any selection from dropdown for From Date, To Date and Date
     * Range
     */
    @Test(groups = {"functionaltest"})
    public void verifyFilterByDateAllTypeAllFrequencyAndCheckAmount() {
        try {
            ManageFutureDatedDetails manageFDTAmount;
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            manageFDTAmount = manageFutureDatedPaymentModel.findMaximumAndMinimumAmountFromList();
            manageFutureDatedPaymentModel.clickFilterButton();
            manageFutureDatedPaymentModel.clickDateTabForViewList();
            manageFutureDatedPaymentModel.enterAccountAllTypeFrequencyFromAmount(manageFDTAmount);
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
            manageFutureDatedPaymentModel.enterAccountToAmountAndClearFromAmount(manageFDTAmount);
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
            manageFutureDatedPaymentModel.enterAccountFromAndToAmountAndClearToAmount(manageFDTAmount);
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the Transaction list by Date when filter is
     * applied. It will cover all the possible flows or filters.
     */
    @Test(groups = {"functionaltest"})
    public void verifyFilterByDateTypeAllFrequencyOneTime() {
        try {
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            manageFutureDatedPaymentModel.clickFilterButton();
            manageFutureDatedPaymentModel.clickDateTabForViewList();
            manageFutureDatedPaymentModel.enterAccountTypeAllFrequencyOneTime();
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the Transaction list by Date when filter is
     * applied. It will cover all the possible flows or filters.
     */
    @Test(groups = {"functionaltest"})
    public void verifyFilterByDateTypeAllFrequencyRecurring() {
        try {
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            manageFutureDatedPaymentModel.clickFilterButton();
            manageFutureDatedPaymentModel.clickDateTabForViewList();
            manageFutureDatedPaymentModel.enterAccountTypeAllFrequencyRecurring();
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the Transaction list by Date when filter is
     * applied. It will cover all the possible flows or filters.
     */
    @Test(groups = {"functionaltest"})
    public void verifyFilterByDateDomesticFrequencyAll() {
        try {
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            manageFutureDatedPaymentModel.clickFilterButton();
            manageFutureDatedPaymentModel.clickDateTabForViewList();
            manageFutureDatedPaymentModel.enterAccountTypeDomesticFrequencyAll();
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the Transaction list by Date when filter is
     * applied. It will cover all the possible flows or filters.
     */
    @Test(groups = {"functionaltest"})
    public void verifyFilterByDateDomesticOneTime() {
        try {
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            manageFutureDatedPaymentModel.clickFilterButton();
            manageFutureDatedPaymentModel.clickDateTabForViewList();
            manageFutureDatedPaymentModel.enterAccountTypeDomesticFrequencyOneTime();
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the Transaction list by Date when filter is
     * applied. It will cover all the possible flows or filters.
     */
    @Test(groups = {"functionaltest"})
    public void verifyFilterByDateDomesticRecurring() {
        try {
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            manageFutureDatedPaymentModel.clickFilterButton();
            manageFutureDatedPaymentModel.clickDateTabForViewList();
            manageFutureDatedPaymentModel.enterAccountTypeDomesticFrequencyRecurring();
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the Transaction list by Date when filter is
     * applied. It will cover all the possible flows or filters.
     */
    @Test(groups = {"functionaltest"})
    public void verifyFilterByDateInternationalFrequencyAll() {
        try {
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            manageFutureDatedPaymentModel.clickFilterButton();
            manageFutureDatedPaymentModel.clickDateTabForViewList();
            manageFutureDatedPaymentModel.enterAccountTypeInternationalFrequencyAll();
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the Transaction list by Date when filter is
     * applied. It will cover all the possible flows or filters.
     */
    @Test(groups = {"functionaltest"})
    public void verifyFilterByDateInternationalOneTime() {
        try {
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            manageFutureDatedPaymentModel.clickFilterButton();
            manageFutureDatedPaymentModel.clickDateTabForViewList();
            manageFutureDatedPaymentModel.enterAccountTypeInternationalFrequencyOneTime();
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the Transaction list by Date when filter is
     * applied. It will cover all the possible flows or filters.
     */
    @Test(groups = {"functionaltest"})
    public void verifyFilterByDateInternationalRecurring() {
        try {
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            manageFutureDatedPaymentModel.clickFilterButton();
            manageFutureDatedPaymentModel.clickDateTabForViewList();
            manageFutureDatedPaymentModel.enterAccountTypeInternationalFrequencyRecurring();
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the Transaction list by Date when filter is
     * applied for Any selection from dropdown for From Date, To Date and Date
     * Range
     */
    @Test(groups = {"functionaltest"})
    public void verifyFilterByAccountAllTypeAllFrequencyAndCheckDate() {
        try {
            ManageFutureDatedDetails manageFDTDate;
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            manageFDTDate = manageFutureDatedPaymentModel.getMaximumAndMinimumDateFromList();
            manageFutureDatedPaymentModel.clickFilterButton();
            manageFutureDatedPaymentModel.clickAccountTabForViewList();
            manageFutureDatedPaymentModel.enterAccountAllTypeFrequencyFromDate(manageFDTDate);
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
            manageFutureDatedPaymentModel.enterAccountToDateAndClearFromDate(manageFDTDate);
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
            manageFutureDatedPaymentModel.enterAccountFromAndToDateAndClearToDate(manageFDTDate);
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the Transaction list by Date when filter is
     * applied for Any selection from dropdown for From Date, To Date and Date
     * Range
     */
    @Test(groups = {"functionaltest"})
    public void verifyFilterByAccountAllTypeAllFrequencyAndCheckAmount() {
        try {
            ManageFutureDatedDetails manageFDTAmount;
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            manageFDTAmount = manageFutureDatedPaymentModel.findMaximumAndMinimumAmountFromList();
            manageFutureDatedPaymentModel.clickFilterButton();
            manageFutureDatedPaymentModel.clickAccountTabForViewList();
            manageFutureDatedPaymentModel.enterAccountAllTypeFrequencyFromAmount(manageFDTAmount);
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
            manageFutureDatedPaymentModel.enterAccountToAmountAndClearFromAmount(manageFDTAmount);
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
            manageFutureDatedPaymentModel.enterAccountFromAndToAmountAndClearToAmount(manageFDTAmount);
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the Transaction list by Date when filter is
     * applied. It will cover all the possible flows or filters.
     */
    @Test(groups = {"functionaltest"})
    public void verifyFilterByAccountTypeAllFrequencyOneTime() {
        try {
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            manageFutureDatedPaymentModel.clickFilterButton();
            manageFutureDatedPaymentModel.clickAccountTabForViewList();
            manageFutureDatedPaymentModel.enterAccountTypeAllFrequencyOneTime();
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the Transaction list by Date when filter is
     * applied. It will cover all the possible flows or filters.
     */
    @Test(groups = {"functionaltest"})
    public void verifyFilterByAccountTypeAllFrequencyRecurring() {
        try {
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            manageFutureDatedPaymentModel.clickFilterButton();
            manageFutureDatedPaymentModel.clickAccountTabForViewList();
            manageFutureDatedPaymentModel.enterAccountTypeAllFrequencyRecurring();
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the Transaction list by Date when filter is
     * applied. It will cover all the possible flows or filters.
     */
    @Test(groups = {"functionaltest"})
    public void verifyFilterByAccountDomesticFrequencyAll() {
        try {
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            manageFutureDatedPaymentModel.clickFilterButton();
            manageFutureDatedPaymentModel.clickAccountTabForViewList();
            manageFutureDatedPaymentModel.enterAccountTypeDomesticFrequencyAll();
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the Transaction list by Date when filter is
     * applied. It will cover all the possible flows or filters.
     */
    @Test(groups = {"functionaltest"})
    public void verifyFilterByAccountDomesticOneTime() {
        try {
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            manageFutureDatedPaymentModel.clickFilterButton();
            manageFutureDatedPaymentModel.clickAccountTabForViewList();
            manageFutureDatedPaymentModel.enterAccountTypeDomesticFrequencyOneTime();
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the Transaction list by Date when filter is
     * applied. It will cover all the possible flows or filters.
     */
    @Test(groups = {"functionaltest"})
    public void verifyFilterByAccountDomesticRecurring() {
        try {
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            manageFutureDatedPaymentModel.clickFilterButton();
            manageFutureDatedPaymentModel.clickAccountTabForViewList();
            manageFutureDatedPaymentModel.enterAccountTypeDomesticFrequencyRecurring();
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the Transaction list by Date when filter is
     * applied. It will cover all the possible flows or filters.
     */
    @Test(groups = {"functionaltest"})
    public void verifyFilterByAccountInternationalFrequencyAll() {
        try {
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            manageFutureDatedPaymentModel.clickFilterButton();
            manageFutureDatedPaymentModel.clickAccountTabForViewList();
            manageFutureDatedPaymentModel.enterAccountTypeInternationalFrequencyAll();
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the Transaction list by Date when filter is
     * applied. It will cover all the possible flows or filters.
     */
    @Test(groups = {"functionaltest"})
    public void verifyFilterByAccountInternationalOneTime() {
        try {
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            manageFutureDatedPaymentModel.clickFilterButton();
            manageFutureDatedPaymentModel.clickAccountTabForViewList();
            manageFutureDatedPaymentModel.enterAccountTypeInternationalFrequencyOneTime();
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the Transaction list by Date when filter is
     * applied. It will cover all the possible flows or filters.
     */
    @Test(groups = {"functionaltest"})
    public void verifyFilterByAccountInternationalRecurring() {
        try {
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            manageFutureDatedPaymentModel.clickFilterButton();
            manageFutureDatedPaymentModel.clickAccountTabForViewList();
            manageFutureDatedPaymentModel.enterAccountTypeInternationalFrequencyRecurring();
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyFilterOutputList();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the message No Transaction List is available
     * for the filter.
     */
    @Test(groups = {"functionaltest"})
    public void verifyNoTransactionListMessageInFilter() {
        try {
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.clickFilterButton();
            manageFutureDatedPaymentModel.clickDateTabForViewList();
            manageFutureDatedPaymentModel.enterFromDateForNoTransaction();
            manageFutureDatedPaymentModel.clickShowResultsButton();
            manageFutureDatedPaymentModel.verifyNoTransactionMessage();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }

    }

    /**
     * Test Case is for verifying the cancel button on the filter option to set
     * filter fields to default.
     */
    @Test(groups = {"functionaltest"})
    public void verifyCancelInFilterToDefaultOption() {
        try {
            ManageFutureDatedDetails manageFDT;
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.clickFilterButton();
            manageFDT = manageFutureDatedPaymentModel.getDefaultValuesOfDropdowns();
            manageFutureDatedPaymentModel.enterRandomAccountTypeFrequency();
            manageFutureDatedPaymentModel.clickCancelInFilter();
            manageFutureDatedPaymentModel.verifyCancelFilterCondition(manageFDT);
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the edit button in the particular transaction
     * and confirm the edit of the transaction.
     */
    @Test(groups = {"functionaltest"})
    public void verifyEditTransactionAndConfirm() {
        try {
            ManageFutureDatedDetails objmanageFDT;
            ManageFutureDatedDetails objmanageFDTRandomAmount;
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            objmanageFDT = manageFutureDatedPaymentModel.selectTransactionFromList();
            manageFutureDatedPaymentModel.verifyShowDetailsContent(objmanageFDT);
            manageFutureDatedPaymentModel.clickEditButtonInTransaction();
            objmanageFDTRandomAmount = manageFutureDatedPaymentModel.changeValueInEditTransaction(objmanageFDT);
            manageFutureDatedPaymentModel.clickEditTransactionSaveDetails();
            manageFutureDatedPaymentModel.confirmEditTransaction();
            manageFutureDatedPaymentModel.verifyConfirmEditTransaction(objmanageFDTRandomAmount);
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the edit button in the particular transaction
     * and confirm the edit of the transaction.
     */
    @Test(groups = {"functionaltest"})
    public void verifyEditTransactionConfirmAndCheckCrossTick() {
        try {
            ManageFutureDatedDetails objmanageFDT, objmanageFDTRandomAmount;
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            objmanageFDT = manageFutureDatedPaymentModel.selectTransactionFromList();
            manageFutureDatedPaymentModel.verifyShowDetailsContent(objmanageFDT);
            manageFutureDatedPaymentModel.clickEditButtonInTransaction();
            objmanageFDTRandomAmount = manageFutureDatedPaymentModel.changeValueInEditTransaction(objmanageFDT);
            manageFutureDatedPaymentModel.clickEditTransactionSaveDetails();
            manageFutureDatedPaymentModel.confirmEditTransactionCheckCrossTick();
            manageFutureDatedPaymentModel.verifyConfirmEditTransaction(objmanageFDTRandomAmount);
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    /**
     * Test Case is for verifying the edit button in the particular transaction
     * and confirm the edit of the transaction.
     */

    @Test(groups = {"functionaltest"})
    public void verifyEditTransactionConfirmAndCancel() {
        try {
            ManageFutureDatedDetails objmanageFDT;
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            objmanageFDT = manageFutureDatedPaymentModel.selectTransactionFromList();
            manageFutureDatedPaymentModel.verifyShowDetailsContent(objmanageFDT);
            manageFutureDatedPaymentModel.clickEditButtonInTransaction();
            manageFutureDatedPaymentModel.changeValueInEditTransaction(objmanageFDT);
            manageFutureDatedPaymentModel.clickEditTransactionSaveDetails();
            manageFutureDatedPaymentModel.cancelConfirmEditTransaction();
            manageFutureDatedPaymentModel.verifyCancelConfirmEditTransaction();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the edit button in the particular transaction
     * and cancel the editing
     */
    @Test(groups = {"functionaltest"})
    public void verifyEditTransactionCancelAndConfirmCancel() {
        try {
            ManageFutureDatedDetails objmanageFDT;
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            objmanageFDT = manageFutureDatedPaymentModel.selectTransactionFromList();
            manageFutureDatedPaymentModel.verifyShowDetailsContent(objmanageFDT);
            manageFutureDatedPaymentModel.clickEditButtonInTransaction();
            manageFutureDatedPaymentModel.changeValueInEditTransaction(objmanageFDT);
            manageFutureDatedPaymentModel.clickCancelInEditTransaction();
            manageFutureDatedPaymentModel.clickYesCancelEditTransaction();
            manageFutureDatedPaymentModel.verifyYesCancelEditTransaction(objmanageFDT);
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the edit button in the particular transaction
     * and cancel the editing and reject and return to editing.
     */
    @Test(groups = {"functionaltest"})
    public void verifyEditTransactionCancelAndRejectCancel() {
        try {
            ManageFutureDatedDetails objmanageFDT;
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            objmanageFDT = manageFutureDatedPaymentModel.selectTransactionFromList();
            manageFutureDatedPaymentModel.verifyShowDetailsContent(objmanageFDT);
            manageFutureDatedPaymentModel.clickEditButtonInTransaction();
            manageFutureDatedPaymentModel.changeValueInEditTransaction(objmanageFDT);
            manageFutureDatedPaymentModel.clickCancelInEditTransaction();
            manageFutureDatedPaymentModel.checkCrossTickOnOverlay();
            manageFutureDatedPaymentModel.clickCancelInEditTransaction();
            manageFutureDatedPaymentModel.clickNoCancelEditTransaction();
            manageFutureDatedPaymentModel.verifyNoCancelEditTransaction();
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the edit button in the particular transaction
     * and confirm the delete.
     */
    @Test(groups = {"functionaltest"})
    public void editTransactionAndConfirmDelete() {
        try {
            ManageFutureDatedDetails objmanageFDT;
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            objmanageFDT = manageFutureDatedPaymentModel.selectTransactionFromList();
            manageFutureDatedPaymentModel.verifyShowDetailsContent(objmanageFDT);
            manageFutureDatedPaymentModel.clickEditButtonInTransaction();
            manageFutureDatedPaymentModel.changeValueInEditTransaction(objmanageFDT);
            manageFutureDatedPaymentModel.clickDeleteButtonInEditTransaction();
            manageFutureDatedPaymentModel.confirmDeleteTransaction();
            manageFutureDatedPaymentModel.transactionDisplayInList(false, objmanageFDT);
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the edit button in the particular transaction
     * and cancel the delete.
     */
    @Test(groups = {"functionaltest"})
    public void editTransactionAndCancelDelete() {
        try {
            ManageFutureDatedDetails objmanageFDT;
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            objmanageFDT = manageFutureDatedPaymentModel.selectTransactionFromList();
            manageFutureDatedPaymentModel.verifyShowDetailsContent(objmanageFDT);
            manageFutureDatedPaymentModel.clickEditButtonInTransaction();
            manageFutureDatedPaymentModel.changeValueInEditTransaction(objmanageFDT);
            manageFutureDatedPaymentModel.clickDeleteButtonInEditTransaction();
            manageFutureDatedPaymentModel.checkCrossTickOnOverlay();
            manageFutureDatedPaymentModel.clickDeleteButtonInEditTransaction();
            manageFutureDatedPaymentModel.cancelDeleteTransaction();
            manageFutureDatedPaymentModel.transactionDisplayInList(true, objmanageFDT);
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the delete button in the particular
     * transaction and confirm the delete.
     */
    @Test(groups = {"functionaltest"})
    public void verifyDeleteTransactionAndConfirm() {
        try {
            ManageFutureDatedDetails objmanageFDT;
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            objmanageFDT = manageFutureDatedPaymentModel.selectTransactionFromList();
            manageFutureDatedPaymentModel.verifyShowDetailsContent(objmanageFDT);
            manageFutureDatedPaymentModel.clickDeleteButtonOnTransaction();
            manageFutureDatedPaymentModel.confirmDeleteTransaction();
            manageFutureDatedPaymentModel.transactionDisplayInList(false, objmanageFDT);
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the delete button in the particular
     * transaction and cancel the delete.
     */
    @Test(groups = {"functionaltest"})
    public void verifyDeleteTransactionAndCancel() {
        try {
            ManageFutureDatedDetails objmanageFDT;
            flyerMenuNavigationModel.navigateToFutureDatedTransaction();
            manageFutureDatedPaymentModel.verifyOutputListIsDisplayed();
            objmanageFDT = manageFutureDatedPaymentModel.selectTransactionFromList();
            manageFutureDatedPaymentModel.verifyShowDetailsContent(objmanageFDT);
            manageFutureDatedPaymentModel.clickDeleteButtonOnTransaction();
            manageFutureDatedPaymentModel.checkCrossTickOnOverlay();
            manageFutureDatedPaymentModel.clickDeleteButtonOnTransaction();
            manageFutureDatedPaymentModel.cancelDeleteTransaction();
            manageFutureDatedPaymentModel.transactionDisplayInList(true, objmanageFDT);
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    /**
     * Test Case is for verifying the cancel button in the particular
     * transaction and to confirm the cancel of the transaction.
     */
    @Test(groups = {"functionaltest"})
    public void cancelTransaction() {
        try {
            ManageFutureDatedPayment.logger.info("Functionality for Cancel Transaction is NA");
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the suspend button in the particular
     * transaction and to confirm the transaction.
     */
    @Test(groups = {"functionaltest"})
    public void suspendTransaction() {
        try {
            ManageFutureDatedPayment.logger.info("Functionality for Suspend Transaction is NA");
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying the resume suspend button in the particular
     * transaction and to confirm the transaction.
     */
    @Test(groups = {"functionaltest"})
    public void resumeSuspendedTransaction() {
        try {
            ManageFutureDatedPayment.logger.info("Functionality for Resume Suspended Transaction is NA");
        } catch (Exception e) {
            ManageFutureDatedPayment.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterMethod() {
        this.browserLib.closeAllBrowsers();
    }

    /**
     * 
     * <p>
     * <b> This method is used to take screen shot so every test script should
     * have it as it is used by Framework internally. </b>
     * </p>
     * 
     * @return driver
     */
    public WebDriver getDriver() {
        return this.driver;
    }
}
