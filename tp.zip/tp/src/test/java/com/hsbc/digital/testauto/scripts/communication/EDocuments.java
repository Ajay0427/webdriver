/**
 *
 */
package com.hsbc.digital.testauto.scripts.communication;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.pageobject.EDocumentsModel;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;


/**
 * <p>
 * <b>This Test Script has scripts for Story 18 E Documents where user can view
 * edocs/taxslips</b>
 * 
 * @author Nikita Garg
 * @version 1.0.0
 *          </p>
 */
public class EDocuments {

    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    EDocumentsModel eDocumentsModel;
    FlyerMenuNavigationModel flyerMenuNavigation;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(EDocuments.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method testMethod) {
        try {
            browserLib = new BrowserLib(browser);
            driver = this.browserLib.getDriver();
            envProperties = FileUtil.getConfigProperties(entity);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            String profile = XMLUtil.getProfileName(testMethod, entity);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", this.driver);
            eDocumentsModel = (EDocumentsModel) ReflectionUtil.getEntityPOM(entity, "EDocumentsPage", this.driver);
            flyerMenuNavigation = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", driver);
            loginModel.login(profile, this.envProperties);
            loginModel.switchLanguage("English");
        } catch (Exception e) {
            EDocuments.logger.error("Exception thrown:", e);
        }
    }

    @Test(testName = "Open EDocuments", groups = {"functionaltest"})
    public void openeDocs() {
        try {
            flyerMenuNavigation.navigateToMyDocuments();
            eDocumentsModel.selectDaterangeFiveOptions();
            eDocumentsModel.selectDaterangeAllOptions();
            eDocumentsModel.selectAccountType();
            eDocumentsModel.selectDocumentType();
            eDocumentsModel.clickViewtn();
        } catch (Exception e) {
            EDocuments.logger.error("Exception at EDocuments openeDocs() : ", e);
            Assert.fail("Exception at openeDocs:", e);
        }
    }

    // Method to verify whether the download is enabled or not.
    @Test(testName = "Open EDocuments", groups = {"functionaltest"})
    public void downloadeDocs() {
        try {
            openeDocs();
            eDocumentsModel.viewDownloadPreview();
        } catch (Exception e) {
            EDocuments.logger.error("Exception at downloadeDocs() : ", e);
            Assert.fail("Exception at downloadeDocs : ", e);
        }
    }

    @Test(testName = "sorteDocs", groups = {"functionaltest"})
    public void sorteDocs() {
        try {
            flyerMenuNavigation.navigateToMyDocuments();
            eDocumentsModel.sortBY();
        } catch (Exception e) {
            EDocuments.logger.error("Exception at sorteDocs() : ", e);
            Assert.fail("Exception at sorteDocs : ", e);
        }
    }

    @AfterMethod(alwaysRun = false)
    public void afterMethod() {
        browserLib.closeAllBrowsers();
    }

    /**
     * @return driver
     */
    public WebDriver getDriver() {
        return driver;
    }
}
