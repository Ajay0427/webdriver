/**
 *
 */
package com.hsbc.digital.testauto.scripts.movemoney;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.models.TransactionFlow;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyConfirmPageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyVerifyPageModel;


/**
 * <p>
 * <b> This class is holding Test Case and functionality for M2MInternatinal
 * </b>
 * </p>
 * 
 * @author Shashikant
 * @version 1.0.0
 */
public class M2MInternational {
    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    FlyerMenuNavigationModel navigate;
    MoveMoneyCapturePageModel mmCapturePageModel;
    MoveMoneyVerifyPageModel mmVerifyPageModel;
    MoveMoneyConfirmPageModel mmConfirmPageModel;
    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(M2MInternational.class);


    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method testMethod) {
        browserLib = new BrowserLib(browser);
        driver = browserLib.getDriver();
        envProperties = FileUtil.getConfigProperties(entity);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        try {
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            navigate = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", driver);
            mmCapturePageModel = (MoveMoneyCapturePageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyCapturePage", driver);
            mmVerifyPageModel = (MoveMoneyVerifyPageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyVerifyPage", driver);
            mmConfirmPageModel = (MoveMoneyConfirmPageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyConfirmPage", driver);
            String profile = XMLUtil.getProfileName(testMethod, entity);
            loginModel.login(profile, envProperties);
            loginModel.switchLanguage("English");
        } catch (Exception e) {
            M2MInternational.logger.error("Exception thrown at Login Contructor:", e);
        }
    }


    @Test(groups = {"functionaltest", "regressiontest", "smoketest"}, enabled = true)
    @Parameters("browser")
    public void m2mLCYToLCYNow() {
        try {
            M2MInternational.logger.info("Method started");
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            M2MInternational.logger.info("Navigated to New transaction page");
            transaction.setFromAccount(mmCapturePageModel.selectInternationalFromLCYAccount(envProperties.get("countryName")));
            transaction.setToAccount(mmCapturePageModel.selectInternationalToLCYAccount(envProperties.get("countryName")));
            String amountEntered = mmCapturePageModel.enterTransferAmount(transaction);
            M2MInternational.logger.info("Amount entered");
            transaction.setAmount(amountEntered);
            mmCapturePageModel.selectReasonForTransaction(transaction);
            mmCapturePageModel.clickTermsAndConditionsCheckBox();
            mmCapturePageModel.clickContinueButton();
            M2MInternational.logger.info("Continue button clicked");
            mmVerifyPageModel.verifyLCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            M2MInternational.logger.info("Confirm button clicked");
            mmConfirmPageModel.verifyLCY2LCYNowTransactionDetailsOnConfirmPage(transaction);
        } catch (Exception e) {
            M2MInternational.logger.error("Exception thrown:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    // Created by US team
    @Test(groups = {"functionaltest", "regressiontest", "smoketest"}, enabled = true)
    @Parameters("browser")
    public void m2mLCYToFCYNow() {
        try {
            M2MInternational.logger.info("Method started");
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2MINTERNATIONAL_TRANSFER);
            navigate.navigateToNewTransactionPage();
            M2MInternational.logger.info("Navigated to New transaction page");
            transaction.setFromAccount(mmCapturePageModel.selectInternationalFromLCYAccount(envProperties.get("countryName")));
            transaction.setToAccount(mmCapturePageModel.selectInternationalToFCYAccount(envProperties.get("countryName")));
            String amountEntered = mmCapturePageModel.enterTransferAmount(transaction);
            M2MInternational.logger.info("Amount entered");
            transaction.setAmount(amountEntered);
            mmCapturePageModel.selectReasonForTransaction(transaction);
            mmCapturePageModel.clickTermsAndConditionsCheckBox();
            mmCapturePageModel.clickContinueButton();
            M2MInternational.logger.info("Continue button clicked");
            mmVerifyPageModel.verifyLCY2FCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            M2MInternational.logger.info("Confirm button clicked");
            mmConfirmPageModel.verifyLCY2FCYNowTransactionDetailsOnConfirmPage(transaction);
        } catch (Exception e) {
            M2MInternational.logger.error("exception thrown:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    // Created by US team
    @Test(groups = {"functionaltest", "regressiontest", "smoketest"}, enabled = true)
    @Parameters("browser")
    public void m2mLCYToFCYRecurring() {
        try {
            M2MInternational.logger.info("Method started");
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2MINTERNATIONAL_TRANSFER);
            navigate.navigateToNewTransactionPage();
            M2MInternational.logger.info("Navigated to New transaction page");
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.selectInternationalToFCYAccount(envProperties.get("currencyCode")));
            String amountEntered = mmCapturePageModel.enterTransferAmount(transaction);
            M2MInternational.logger.info("Amount entered");
            transaction.setAmount(amountEntered);
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            mmCapturePageModel.selectTransactionEnddate();
            mmCapturePageModel.verifyNumberOfPayements();
            mmCapturePageModel.selectLanguajeEnglish();
            mmCapturePageModel.clickContinueButton();
            M2MInternational.logger.info("Continue button clicked");
            mmVerifyPageModel.verifyLCY2LCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            M2MInternational.logger.info("Confirm button clicked");
            mmConfirmPageModel.verifyLCY2LCYRecurringTransactionDetailsOnConfirmPage(transaction);
        } catch (Exception e) {
            M2MInternational.logger.error("Excetpion thrown:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    // Created by US team
    @Test(groups = {"functionaltest", "regressiontest", "smoketest"}, enabled = true)
    @Parameters("browser")
    public void m2mLCYToFCYRecurringUntilFurtherNotice() {
        try {
            M2MInternational.logger.info("Method started");
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2MINTERNATIONAL_TRANSFER);
            navigate.navigateToNewTransactionPage();
            M2MInternational.logger.info("Navigated to New transaction page");
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.selectInternationalToFCYAccount(envProperties.get("currencyCode")));
            String amountEntered = mmCapturePageModel.enterTransferAmount(transaction);
            M2MInternational.logger.info("Amount entered");
            transaction.setAmount(amountEntered);
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            mmCapturePageModel.selectTransactionEnddateUntilFurtherNotice();
            mmCapturePageModel.selectLanguajeEnglish();
            mmCapturePageModel.clickContinueButton();
            M2MInternational.logger.info("Continue button clicked");
            mmVerifyPageModel.verifyLCY2LCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            M2MInternational.logger.info("Confirm button clicked");
            mmConfirmPageModel.verifyLCY2LCYRecurringTransactionDetailsOnConfirmPage(transaction);
        } catch (Exception e) {
            M2MInternational.logger.error("Excetpion thrown:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    // Created by US team
    @Test(groups = {"functionaltest", "regressiontest", "smoketest"}, enabled = true)
    @Parameters("browser")
    public void m2mLCYToLCYRecurring() {
        try {
            M2MInternational.logger.info("Method started");
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            M2MInternational.logger.info("Navigated to New transaction page");
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.selectInternationalToLCYAccount(envProperties.get("currencyCode")));
            String amountEntered = mmCapturePageModel.enterTransferAmount(transaction);
            M2MInternational.logger.info("Amount entered");
            transaction.setAmount(amountEntered);
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            String noOfPayements = mmCapturePageModel.verifyNumberOfPayements();
            transaction.setNumberOfPayment(noOfPayements);
            mmCapturePageModel.clickContinueButton();
            M2MInternational.logger.info("Continue button clicked");
            mmVerifyPageModel.verifyLCY2LCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            M2MInternational.logger.info("Confirm button clicked");
            mmConfirmPageModel.verifyLCY2LCYRecurringTransactionDetailsOnConfirmPage(transaction);
        } catch (Exception e) {
            M2MInternational.logger.error("Exception thrown:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    // Creating
    @Test(groups = {"functionaltest", "regressiontest", "smoketest"}, enabled = true)
    @Parameters("browser")
    public void m2mLCYToLCYRecurringUntilFurtherNotice() {
        try {
            M2MInternational.logger.info("Method started");
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            M2MInternational.logger.info("Navigated to New transaction page");
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.selectInternationalToLCYAccount(envProperties.get("currencyCode")));
            String amountEntered = mmCapturePageModel.enterTransferAmount(transaction);
            M2MInternational.logger.info("Amount entered");
            transaction.setAmount(amountEntered);
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            mmCapturePageModel.selectTransactionEnddateUntilFurtherNotice();
            mmCapturePageModel.selectLanguajeEnglish();
            mmCapturePageModel.clickContinueButton();
            M2MInternational.logger.info("Continue button clicked");
            mmVerifyPageModel.verifyLCY2LCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            M2MInternational.logger.info("Confirm button clicked");
            mmConfirmPageModel.verifyLCY2LCYRecurringTransactionDetailsOnConfirmPage(transaction);
        } catch (Exception e) {
            M2MInternational.logger.error("Exception thrown:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    // created by US team
    @Test(groups = {"functionaltest", "regressiontest", "smoketest"}, enabled = true)
    @Parameters("browser")
    public void m2mLCYToLCYNowCancelTransaction() {
        try {
            M2MInternational.logger.info("Method started");
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            M2MInternational.logger.info("Navigated to New transaction page");
            transaction.setFromAccount(mmCapturePageModel.selectInternationalFromLCYAccount(envProperties.get("countryName")));
            transaction.setToAccount(mmCapturePageModel.selectInternationalToLCYAccount(envProperties.get("countryName")));
            String amountEntered = mmCapturePageModel.enterTransferAmount(transaction);
            M2MInternational.logger.info("Amount entered");
            transaction.setAmount(amountEntered);
            mmCapturePageModel.selectReasonForTransaction(transaction);
            mmCapturePageModel.clickTermsAndConditionsCheckBox();
            mmCapturePageModel.clickCancelButton();
            mmCapturePageModel.clickCancelPopUpCancelButton();
            mmCapturePageModel.checkDashBoardContent();
        } catch (Exception e) {
            M2MInternational.logger.error("Exception thrown:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    // Created by US team
    @Test(groups = {"functionaltest", "regressiontest", "smoketest"}, enabled = true)
    @Parameters("browser")
    public void m2mLCYToFCYNowCancelTransaction() {
        try {
            M2MInternational.logger.info("Method started");
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2MINTERNATIONAL_TRANSFER);
            navigate.navigateToNewTransactionPage();
            M2MInternational.logger.info("Navigated to New transaction page");
            transaction.setFromAccount(mmCapturePageModel.selectInternationalFromLCYAccount(envProperties.get("countryName")));
            transaction.setToAccount(mmCapturePageModel.selectInternationalToFCYAccount(envProperties.get("countryName")));
            String amountEntered = mmCapturePageModel.enterTransferAmount(transaction);
            M2MInternational.logger.info("Amount entered");
            transaction.setAmount(amountEntered);
            mmCapturePageModel.selectReasonForTransaction(transaction);
            mmCapturePageModel.clickTermsAndConditionsCheckBox();
            mmCapturePageModel.clickContinueButton();
            M2MInternational.logger.info("Continue button clicked");
            mmVerifyPageModel.verifyLCY2FCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickCancelButton();
            mmVerifyPageModel.clickCancelPopUpCancelButton();
            mmVerifyPageModel.verifyPageTitle();
        } catch (Exception e) {
            M2MInternational.logger.error("exception thrown:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    // Created by US team
    @Test(groups = {"functionaltest", "regressiontest", "smoketest"}, enabled = true)
    @Parameters("browser")
    public void m2mLCYToLCYLaterEditTransaction() {
        try {
            M2MInternational.logger.info("Method started");
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            M2MInternational.logger.info("Navigated to New transaction page");
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.selectInternationalToLCYAccount(envProperties.get("currencyCode")));
            String amountEntered = mmCapturePageModel.enterTransferAmount(transaction);
            M2MInternational.logger.info("Amount entered");
            transaction.setAmount(amountEntered);
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyPageTitle();
            mmVerifyPageModel.verifyLCY2LCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickEditDetailsButton();
            mmCapturePageModel.verifyPageTitle();
            String amountEnteredEdited = mmCapturePageModel.enterTransferAmount(transaction);
            M2MInternational.logger.info("Amount entered");
            transaction.setAmount(amountEnteredEdited);
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYLaterTransactionDetailsOnVerifyPage(transaction);

        } catch (Exception e) {
            M2MInternational.logger.error("Exception thrown:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    // Created by cbh team
    @Test(groups = {"functionaltest", "regressiontest", "smoketest"}, enabled = true)
    @Parameters("browser")
    public void m2mFCYToFCYNow() {
        try {
            M2MInternational.logger.info("Method started");
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            M2MInternational.logger.info("Navigated to New transaction page");
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("countryName")));
            transaction.setToAccount(mmCapturePageModel.selectInternationalToFCYAccount(envProperties.get("countryName")));
            String amountEntered = mmCapturePageModel.enterTransferAmount(transaction);
            M2MInternational.logger.info("Amount entered");
            transaction.setAmount(amountEntered);
            String refrenceText = mmCapturePageModel.enterYourReferenceText(transaction);
            transaction.setYourReference(refrenceText);
            mmCapturePageModel.selectReasonForTransaction(transaction);
            mmCapturePageModel.clickTermsAndConditionsCheckBox();
            mmCapturePageModel.clickContinueButton();
            M2MInternational.logger.info("Continue button clicked");
            mmVerifyPageModel.verifyFCY2FCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            M2MInternational.logger.info("Confirm button clicked");
            mmConfirmPageModel.verifyFCY2FCYNowTransactionDetailsOnConfirmPage(transaction);
        } catch (Exception e) {
            M2MInternational.logger.error("exception thrown:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    // Created by cbh team
    @Test(groups = {"functionaltest", "regressiontest", "smoketest"})
    @Parameters("browser")
    public void m2mFCYToFCYLater() {
        try {
            M2MInternational.logger.info("Method started");
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            M2MInternational.logger.info("Navigated to New transaction page");
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("countryName")));
            transaction.setToAccount(mmCapturePageModel.selectInternationalToFCYAccount(envProperties.get("countryName")));
            String amountEntered = mmCapturePageModel.enterTransferAmount(transaction);
            M2MInternational.logger.info("Amount entered");
            transaction.setAmount(amountEntered);
            String refrenceText = mmCapturePageModel.enterYourReferenceText(transaction);
            transaction.setYourReference(refrenceText);
            mmCapturePageModel.selectReasonForTransaction(transaction);
            mmCapturePageModel.clickTermsAndConditionsCheckBox();

            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyFCY2FCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyFCY2FCYLaterTransactionDetailsOnConfirmPage(transaction);

        } catch (Exception e) {
            M2MDomestic.logger.error("exception thrown:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
        }
    }

    // Created by cbh team
    @Test(groups = {"functionaltest", "regressiontest", "smoketest"})
    @Parameters("browser")
    public void m2mFCYToFCYRecurringNumberOfPayment() {
        try {
            M2MInternational.logger.info("Method started");
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            M2MInternational.logger.info("Navigated to New transaction page");
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("countryName")));
            transaction.setToAccount(mmCapturePageModel.selectInternationalToFCYAccount(envProperties.get("countryName")));
            String amountEntered = mmCapturePageModel.enterTransferAmount(transaction);
            M2MInternational.logger.info("Amount entered");
            transaction.setAmount(amountEntered);
            String refrenceText = mmCapturePageModel.enterYourReferenceText(transaction);
            transaction.setYourReference(refrenceText);
            mmCapturePageModel.selectReasonForTransaction(transaction);
            mmCapturePageModel.clickTermsAndConditionsCheckBox();

            mmCapturePageModel.clickRecurringTab();
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2MFCY2FCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2MFCY2FCYRecurringTransactionDetailsOnConfirmPage(transaction);

        } catch (Exception e) {
            M2MDomestic.logger.error("Exception thrown:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
        }
    }
}
