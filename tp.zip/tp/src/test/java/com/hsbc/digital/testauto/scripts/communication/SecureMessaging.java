/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.communication;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.SecureMessageModel;

/**
 * <p>
 * <b> This Test Script has scripts for Story 15 Secure Messaging where user
 * will send/Receive/Read messages for communication with Bank. </b>
 * 
 * @author Shrikant Joshi
 * @version 1.0.0
 *          </p>
 */
public class SecureMessaging {

    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    SecureMessageModel secureMessageModel;
    FlyerMenuNavigationModel navigationMenu;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(SecureMessaging.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method testMethod) {
        try {
            this.browserLib = new BrowserLib(browser);
            this.driver = this.browserLib.getDriver();
            this.envProperties = FileUtil.getConfigProperties(entity);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            String profile = XMLUtil.getProfileName(testMethod, entity);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            secureMessageModel = (SecureMessageModel) ReflectionUtil.getEntityPOM(entity, "SecureMessagePage", driver);
            navigationMenu = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", driver);
            loginModel.login(profile, this.envProperties);
            loginModel.switchLanguage("English");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception thrown:", e);
        }
    }

    @Test(testName = "Send Secure Message End to End", groups = {"functionaltest"})
    public void doMessaging() {
        try {
            secureMessageModel.navigateToMessageCenter();
            String messageTitle = secureMessageModel.readMessage();
            secureMessageModel.replyToMessage(messageTitle);
            secureMessageModel.backToMessages();
            secureMessageModel.printMessage();
            secureMessageModel.deleteCurrentMessage(false);
            secureMessageModel.deleteCurrentMessage(true);
            secureMessageModel.isMessageExist(messageTitle);
            secureMessageModel.sendMessage();
            secureMessageModel.backToMessages();
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging Script:doMessaging()", e);
            Assert.fail("Exception at doMessaging:", e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void cancelReplyMessage() {
        try {
            secureMessageModel.navigateToMessageCenter();
            String messageTitle = secureMessageModel.readMessage();
            secureMessageModel.typeReplyMessage();
            secureMessageModel.cancelReplyMessage(false);
            secureMessageModel.verifyMessage(messageTitle, false);
            secureMessageModel.cancelReplyMessage(true);
            secureMessageModel.verifyMessage(messageTitle, true);
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging Script:cancelReplyMessage()", e);
            Assert.fail("Exception at cancelReplyMessage:", e);
        }
    }


    @Test(groups = {"functionaltest"}, enabled = true)
    public void cancelSendMessage() {
        try {
            secureMessageModel.navigateToMessageCenter();
            secureMessageModel.typeNewMessage();
            secureMessageModel.cancelSendMessage(false);
            secureMessageModel.checkSendMessageCancel(false);
            secureMessageModel.cancelSendMessage(true);
            secureMessageModel.checkSendMessageCancel(true);
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging Script:cancelSendMessage()", e);
            Assert.fail("Exception at cancelSendMessage:", e);
        }
    }

    @Test(testName = "Send Secure Message via header link End to End", groups = {"functionaltest"})
    public void sendMessageFromLink() {
        try {
            secureMessageModel.checkMessageNotification();
            secureMessageModel.navigateToMessageCenterSendMessage();
            secureMessageModel.sendMessageFromLink();
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging Script :sendMessageFromLink()", e);
            Assert.fail("Exception at doMessaging:", e);
        }
    }

    /*This TC covers 2 E2E flows from Transaction Summary-
    1. Cancel + Cancel Billing Dispute report from Capture Page
    2. Cancel + Don't cancel Billing Dispute report from Capture Page */
    @Test(groups = {"functionaltest"})
    public void cancelSubmitBillingDispute() {
        try {
            secureMessageModel.navigateToSubmitBillingDispute();
            secureMessageModel.enterBillingDisputeDetailsTxnSummary(false);
            secureMessageModel.cancelBillingDispute(false);
            secureMessageModel.verifyCancelSubmitBillingDispute(false);
            secureMessageModel.cancelBillingDispute(true);
            secureMessageModel.verifyCancelSubmitBillingDispute(true);
            SecureMessaging.logger.info("cancelSubmitBillingDispute execution completed");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging cancelSubmitBillingDispute()", e);
            Assert.fail("Exception at cancelSubmitBillingDispute:", e);
        }
    }

    /*This TC covers 2 E2E flows from Transaction Summary-
    1. Cancel + Cancel Transaction problem report from Capture Page
    2. Cancel + Don't cancel Transaction problem report from Capture Page */
    @Test(groups = {"functionaltest"})
    public void cancelReportTxnProblem() {
        try {
            secureMessageModel.navigateToReportTxnProblem();
            secureMessageModel.enterReportProblemDetailsTxnSummary(false);
            secureMessageModel.cancelProblem(false);
            secureMessageModel.verifyCancelReportTxnProblem(false);
            secureMessageModel.cancelProblem(true);
            secureMessageModel.verifyCancelReportTxnProblem(true);
            SecureMessaging.logger.info("cancelBillingDisputeReview execution completed");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging cancelReportTxnProblem()", e);
            Assert.fail("Exception at cancelReportTxnProblem:", e);
        }
    }

    /*This TC covers 3 E2E flows from Transaction Summary-
    1. Submit Billing Dispute report
    2. Edit Billing Dispute report
    3. Select 'Other' problem reason and Additional Comments field is mandatory*/
    @Test(groups = {"functionaltest"})
    public void submitBillingDispute() {
        try {
            secureMessageModel.navigateToSubmitBillingDispute();
            secureMessageModel.enterBillingDisputeDetailsTxnSummary(false);
            secureMessageModel.clickContinueButton();
            secureMessageModel.waitForReviewPageBillingDispute();
            secureMessageModel.validateSubmitBillingDispute();
            secureMessageModel.clickEditButton();
            secureMessageModel.enterBillingDisputeDetailsTxnSummary(true);
            secureMessageModel.clickContinueButton();
            secureMessageModel.waitForReviewPageBillingDispute();
            secureMessageModel.validateSubmitBillingDispute();
            secureMessageModel.isAdditionalCommentsDisplayed();
            secureMessageModel.clickSendButton();
            secureMessageModel.verifySuccessMsgDisplayed();
            secureMessageModel.validateSubmitBillingDispute();
            secureMessageModel.isAdditionalCommentsDisplayed();
            secureMessageModel.clickMyAccounts();
            logger.info("submitBillingDispute execution completed");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging submitBillingDispute()" + e);
            Assert.fail("Exception at submitBillingDispute:", e);
        }
    }

    /*This TC covers 3 E2E flows from Transaction summary-
    1. Submit Transaction Problem report
    2. Edit Transaction Problem report
    3. Select 'Other' problem reason and Additional Comments field is mandatory*/
    @Test(groups = {"functionaltest"})
    public void reportTransactionProblem() {
        try {
            secureMessageModel.navigateToReportTxnProblem();
            secureMessageModel.enterReportProblemDetailsTxnSummary(false);
            secureMessageModel.clickContinueButton();
            secureMessageModel.waitForReviewPageTxnProblem();
            secureMessageModel.validateReportTxnProblem();
            secureMessageModel.clickEditButton();
            secureMessageModel.enterReportProblemDetailsTxnSummary(true);
            secureMessageModel.clickContinueButton();
            secureMessageModel.waitForReviewPageTxnProblem();
            secureMessageModel.validateReportTxnProblem();
            secureMessageModel.isAdditionalCommentsDisplayed();
            secureMessageModel.clickSendButton();
            secureMessageModel.verifySuccessMsgDisplayed();
            secureMessageModel.validateReportTxnProblem();
            secureMessageModel.isAdditionalCommentsDisplayed();
            secureMessageModel.clickMyAccounts();
            logger.info("reportTransactionProblem execution completed");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging reportTransactionProblem()", e);
            Assert.fail("Exception at reportTransactionProblem:", e);
        }
    }


    /*This TC covers 2 E2E flows from Transaction Summary-
    1. Cancel + Cancel Billing Dispute report from Review Page
    2. Cancel + Don't cancel Billing Dispute report from Review Page */
    @Test(groups = {"functionaltest"})
    public void cancelBillingDisputeReview() {
        try {
            secureMessageModel.navigateToSubmitBillingDispute();
            secureMessageModel.enterBillingDisputeDetailsTxnSummary(false);
            secureMessageModel.clickContinueButton();
            secureMessageModel.waitForReviewPageBillingDispute();
            secureMessageModel.validateSubmitBillingDispute();
            secureMessageModel.cancelBillingDispute(false);
            secureMessageModel.verifyCancelSubmitBillingDispute(false);
            secureMessageModel.cancelBillingDispute(true);
            secureMessageModel.verifyCancelSubmitBillingDispute(true);
            SecureMessaging.logger.info("cancelBillingDisputeReview execution completed");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging cancelBillingDisputeReview()" + e);
            Assert.fail("Exception at cancelBillingDisputeReview:", e);
        }
    }

    /*This TC covers 2 E2E flows from Transaction summary-
    1. Cancel + Cancel Transaction problem report from Review Page
    2. Cancel + Don't cancel Transaction problem report from Review Page */
    @Test(groups = {"functionaltest"})
    public void cancelTxnProblemReview() {
        try {
            secureMessageModel.navigateToReportTxnProblem();
            secureMessageModel.enterReportProblemDetailsTxnSummary(false);
            secureMessageModel.clickContinueButton();
            secureMessageModel.waitForReviewPageTxnProblem();
            secureMessageModel.validateReportTxnProblem();
            secureMessageModel.cancelProblem(false);
            secureMessageModel.verifyCancelReportTxnProblem(false);
            secureMessageModel.cancelProblem(true);
            secureMessageModel.verifyCancelReportTxnProblem(true);
            SecureMessaging.logger.info("cancelTxnProblemReview execution completed");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging cancelTxnProblemReview()", e);
            Assert.fail("Exception at cancelTxnProblemReview:", e);
        }
    }

    /*This TC covers 2 E2E flows-
    1. Cancel + Cancel Billing Dispute report from Capture Page
    2. Cancel + Don't cancel Billing Dispute report from Capture Page */
    @Test(groups = {"functionaltest"})
    public void cancelBillingDisputeSmartSearch() {
        try {
            secureMessageModel.navigateToBillingDisputeSmartSearch();
            secureMessageModel.enterBillingDisputeDetailsSmartSearch(envProperties, false);
            secureMessageModel.cancelBillingDispute(false);
            secureMessageModel.verifyCancelSubmitBillingDispute(false);
            secureMessageModel.cancelBillingDispute(true);
            secureMessageModel.verifyCancelSubmitBillingDispute(true);
            SecureMessaging.logger.info("cancelBillingDisputeSmartSearch execution completed");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging cancelBillingDisputeSmartSearch()" + e);
            Assert.fail("Exception at cancelBillingDisputeSmartSearch:" + e);
        }
    }

    /*This TC covers 3 E2E flows using Smart Search-
    1. Submit Billing Dispute report
    2. Edit Billing Dispute report
    3. Select 'Other' problem reason and Additional Comments field is mandatory*/
    @Test(groups = {"functionaltest"})
    public void submitBillingDisputeSmartSearch() {
        try {
            secureMessageModel.navigateToBillingDisputeSmartSearch();
            secureMessageModel.enterBillingDisputeDetailsSmartSearch(envProperties, false);
            secureMessageModel.clickContinueButton();
            secureMessageModel.waitForReviewPageBillingDispute();
            secureMessageModel.validateBillingDisputeSmartSearch();
            secureMessageModel.clickEditButton();
            secureMessageModel.enterBillingDisputeDetailsSmartSearch(envProperties, true);
            secureMessageModel.clickContinueButton();
            secureMessageModel.waitForReviewPageBillingDispute();
            secureMessageModel.validateBillingDisputeSmartSearch();
            secureMessageModel.isAdditionalCommentsDisplayed();
            secureMessageModel.clickSendButton();
            secureMessageModel.verifySuccessMsgDisplayed();
            secureMessageModel.validateBillingDisputeSmartSearch();
            secureMessageModel.isAdditionalCommentsDisplayed();
            secureMessageModel.clickMyAccounts();
            logger.info("submitBillingDisputeSmartSearch execution completed");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging submitBillingDisputeSmartSearch()" + e);
            Assert.fail("Exception at submitBillingDisputeSmartSearch:", e);
        }
    }

    /*This TC covers 2 E2E flows using Smart Search-
    1. Cancel + Cancel Billing Dispute report from Review Page
    2. Cancel + Don't cancel Billing Dispute report from Review Page */
    @Test(groups = {"functionaltest"})
    public void cancelBillingDisputeSmartSearchReview() {
        try {
            secureMessageModel.navigateToBillingDisputeSmartSearch();
            secureMessageModel.enterBillingDisputeDetailsSmartSearch(envProperties, false);
            secureMessageModel.clickContinueButton();
            secureMessageModel.waitForReviewPageBillingDispute();
            secureMessageModel.validateBillingDisputeSmartSearch();
            secureMessageModel.cancelBillingDispute(false);
            secureMessageModel.verifyCancelSubmitBillingDispute(false);
            secureMessageModel.cancelBillingDispute(true);
            secureMessageModel.verifyCancelSubmitBillingDispute(true);
            SecureMessaging.logger.info("cancelBillingDisputeSmartSearchReview execution completed");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging cancelBillingDisputeSmartSearchReview()" + e);
            Assert.fail("Exception at cancelBillingDisputeSmartSearchReview:" + e);
        }
    }

    /*This TC covers 2 E2E flows using Smart Search-
    1. Cancel + Cancel Transaction problem report from Capture Page
    2. Cancel + Don't cancel Transaction problem report from Capture Page */
    @Test(groups = {"functionaltest"})
    public void cancelReportTxnProblemSmartSearch() {
        try {
            secureMessageModel.navigateToTxnProblemSmartSearch();
            secureMessageModel.enterReportProblemDetailsSmartSearch(envProperties, false);
            secureMessageModel.cancelProblem(false);
            secureMessageModel.verifyCancelReportTxnProblem(false);
            secureMessageModel.cancelProblem(true);
            secureMessageModel.verifyCancelReportTxnProblem(true);
            SecureMessaging.logger.info("cancelReportTxnProblemSmartSearch execution completed");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging cancelReportTxnProblemSmartSearch()", e);
            Assert.fail("Exception at cancelReportTxnProblemSmartSearch:", e);
        }
    }

    /*This TC covers 3 E2E flows using Smart Search-
    1. Submit Transaction Problem report
    2. Edit Transaction Problem report
    3. Select 'Other' problem reason and Additional Comments field is mandatory*/
    @Test(groups = {"functionaltest"})
    public void reportTransactionProblemSmartSearch() {
        try {
            secureMessageModel.navigateToTxnProblemSmartSearch();
            secureMessageModel.enterReportProblemDetailsSmartSearch(envProperties, false);
            secureMessageModel.clickContinueButton();
            secureMessageModel.waitForReviewPageTxnProblem();
            secureMessageModel.validateReportTxnProblemSmartSearch();
            secureMessageModel.clickEditButton();
            secureMessageModel.enterReportProblemDetailsSmartSearch(envProperties, true);
            secureMessageModel.clickContinueButton();
            secureMessageModel.waitForReviewPageTxnProblem();
            secureMessageModel.validateReportTxnProblemSmartSearch();
            secureMessageModel.isAdditionalCommentsDisplayed();
            secureMessageModel.clickSendButton();
            secureMessageModel.verifySuccessMsgDisplayed();
            secureMessageModel.validateReportTxnProblemSmartSearch();
            secureMessageModel.isAdditionalCommentsDisplayed();
            secureMessageModel.clickMyAccounts();
            logger.info("reportTransactionProblemSmartSearch execution completed");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging reportTransactionProblemSmartSearch()", e);
            Assert.fail("Exception at reportTransactionProblemSmartSearch:", e);
        }
    }

    /*This TC covers 2 E2E flows using Smart Search-
    1. Cancel + Cancel Transaction problem report from Review Page
    2. Cancel + Don't cancel Transaction problem report from Review Page */
    @Test(groups = {"functionaltest"})
    public void cancelTxnProblemSmartSearchReview() {
        try {
            secureMessageModel.navigateToTxnProblemSmartSearch();
            secureMessageModel.enterReportProblemDetailsSmartSearch(envProperties, false);
            secureMessageModel.clickContinueButton();
            secureMessageModel.waitForReviewPageTxnProblem();
            secureMessageModel.validateReportTxnProblemSmartSearch();
            secureMessageModel.cancelProblem(false);
            secureMessageModel.verifyCancelReportTxnProblem(false);
            secureMessageModel.cancelProblem(true);
            secureMessageModel.verifyCancelReportTxnProblem(true);
            SecureMessaging.logger.info("cancelTxnProblemSmartSearchReview execution completed");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging cancelTxnProblemSmartSearchReview()", e);
            Assert.fail("Exception at cancelTxnProblemSmartSearchReview:", e);
        }
    }

    /*This TC covers 2 E2E flows Req Check image-
    1. Cancel + Cancel Request check image from Capture Page
    2. Cancel + Don't cancel Request check image from Capture Page */
    @Test(groups = {"functionaltest"})
    public void cancelReqCheckImgCapture() {
        try {
            secureMessageModel.navigateToRequestCheckImage(envProperties);
            secureMessageModel.enterDetailsOnRequestCheckImage(envProperties, false);
            secureMessageModel.cancelCheckImgReq(false);
            secureMessageModel.verifyCancelCheckImage(false);
            secureMessageModel.cancelCheckImgReq(true);
            secureMessageModel.verifyCancelCheckImage(true);
            SecureMessaging.logger.info("cancelReqCheckImgCapture execution completed");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging cancelReqCheckImgCapture()", e);
            Assert.fail("Exception at cancelReqCheckImgCapture:", e);
        }
    }

    /*This TC covers 2 E2E flows Req Check image-
    1. Cancel + Cancel Request check image from Review Page
    2. Cancel + Don't cancel Request check image from Reivew Page */
    @Test(groups = {"functionaltest"})
    public void cancelReqCheckImgReview() {
        try {
            secureMessageModel.navigateToRequestCheckImage(envProperties);
            secureMessageModel.enterDetailsOnRequestCheckImage(envProperties, false);
            secureMessageModel.clickContinueButton();
            secureMessageModel.waitForReviewReqCheckImg();
            secureMessageModel.validateRequestCheckImg();
            secureMessageModel.cancelCheckImgReq(false);
            secureMessageModel.verifyCancelCheckImage(false);
            secureMessageModel.cancelCheckImgReq(true);
            secureMessageModel.verifyCancelCheckImage(true);
            SecureMessaging.logger.info("cancelReqCheckImgReview execution completed");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging cancelReqCheckImgReview()", e);
            Assert.fail("Exception at cancelReqCheckImgReview:", e);
        }
    }

    /*This TC covers 3 E2E flows Req Check image-
    1. Request check image
    2. Edit Request check image from review page
    3. request check image with 'Other' value */
    @Test(groups = {"functionaltest"})
    public void requestCheckImage() {
        try {
            secureMessageModel.navigateToRequestCheckImage(envProperties);
            secureMessageModel.enterDetailsOnRequestCheckImage(envProperties, false);
            secureMessageModel.clickContinueButton();
            secureMessageModel.waitForReviewReqCheckImg();
            secureMessageModel.validateRequestCheckImg();
            secureMessageModel.clickEditButton();
            secureMessageModel.enterDetailsOnRequestCheckImage(envProperties, true);
            secureMessageModel.clickContinueButton();
            secureMessageModel.waitForReviewReqCheckImg();
            secureMessageModel.validateRequestCheckImg();
            secureMessageModel.isDetails();
            secureMessageModel.clickSendButton();
            secureMessageModel.verifySuccessMsgDisplayed();
            secureMessageModel.validateRequestCheckImg();
            secureMessageModel.isDetails();
            secureMessageModel.clickMyAccounts();
            SecureMessaging.logger.info("requestCheckImage execution completed");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging requestCheckImage()", e);
            Assert.fail("Exception at requestCheckImage:", e);
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterMethod() {
        this.browserLib.closeAllBrowsers();
    }

    /**
     * 
     * <p>
     * <b> This method is used to take screen shot so every test script should
     * have it as it is used by Framework internally. </b>
     * </p>
     * 
     * @return driver
     */

    public WebDriver getDriver() {
        return this.driver;
    }


}
