/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.movemoney;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.models.TransactionFlow;
import com.hsbc.digital.testauto.pageobject.AddBeneficiaryModel;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LandingPageModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyConfirmPageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyVerifyPageModel;


public class IETransfer {
    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    String profile;
    LoginModel loginModel;
    FlyerMenuNavigationModel navigate;
    AddBeneficiaryModel addPayeeModel;
    LandingPageModel landingPageModel;
    MoveMoneyCapturePageModel mmCapturePageModel;
    MoveMoneyVerifyPageModel mmVerifyPageModel;
    MoveMoneyConfirmPageModel mmConfirmPageModel;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(IETransfer.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method testMethod) throws IOException {
        try {
            browserLib = new BrowserLib(browser);
            driver = browserLib.getDriver();
            envProperties = FileUtil.getConfigProperties(entity);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            navigate = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", driver);
            addPayeeModel = (AddBeneficiaryModel) ReflectionUtil.getEntityPOM(entity, "AddBeneficiary", driver);
            mmCapturePageModel = (MoveMoneyCapturePageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyCapturePage", driver);
            mmVerifyPageModel = (MoveMoneyVerifyPageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyVerifyPage", driver);
            mmConfirmPageModel = (MoveMoneyConfirmPageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyConfirmPage", driver);
            landingPageModel = (LandingPageModel) ReflectionUtil.getEntityPOM(entity, "LandingPage", driver);
            profile = XMLUtil.getProfileName(testMethod, entity);
            loginModel.login(profile, envProperties);
            loginModel.switchLanguage("English");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception thrown at Login Contructor:", e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "cancelLCY2LCYNowTransactionCapturePage")
    public void cancelLCY2LCYNowTransactionCapturePage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonIELCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processIsValidAccInFromDropDown(transaction.getToAccount(), envProperties.get("currencyCode"));
            mmCapturePageModel.enterTransferAmount(transaction);
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeMessageText(transaction));
            mmCapturePageModel.clickCancelButton();
            mmCapturePageModel.clickCancelPopUpCancelButton();
            landingPageModel.isLeftHandMenuForAccountsOnDashboardDisplayed();
            Reporter.log("cancelLCY2LCYNowTransactionCapturePage test passed.");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "cancelLCY2LCYNowTransactionVerifyPage")
    public void cancelLCY2LCYNowTransactionVerifyPage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonIELCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processIsValidAccInFromDropDown(transaction.getToAccount(), envProperties.get("currencyCode"));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeMessageText(transaction));
            transaction.setToAccount(mmCapturePageModel.updatePayeeInformation(transaction.getToAccount()));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYNowIETransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickCancelButton();
            mmVerifyPageModel.clickCancelPopUpCancelButton();
            mmCapturePageModel.verifyPageTitle();
            Reporter.log("cancelLCY2LCYNowTransactionVerifyPage test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "negateCancelLCY2LCYNowTransactionVerifyPage")
    public void negateCancelLCY2LCYNowTransactionVerifyPageIE() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonIELCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processIsValidAccInFromDropDown(transaction.getToAccount(), envProperties.get("currencyCode"));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeMessageText(transaction));
            transaction.setToAccount(mmCapturePageModel.updatePayeeInformation(transaction.getToAccount()));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYNowIETransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickCancelButton();
            mmVerifyPageModel.clickContinuePopupContinueButton();
            mmVerifyPageModel.verifyPageTitle();
            Reporter.log("negateCancelLCY2LCYNowTransactionVerifyPage test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2nmLCY2LCYNowTransaction")
    public void iETransferLCY2LCYNowTransactionBacktoMyAccounts() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonIELCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processIsValidAccInFromDropDown(transaction.getToAccount(), envProperties.get("currencyCode"));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeMessageText(transaction));
            transaction.setToAccount(mmCapturePageModel.updatePayeeInformation(transaction.getToAccount()));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYNowIETransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2LCYNowIETransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            mmVerifyPageModel.verifyMyAccountpage();

            Reporter.log("m2nmLCY2LCYNowTransaction test passed");

        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "iETransferLCY2LCYNow")
    public void iETransferLCY2LCYNow() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            IETransfer.logger.info(transaction.getToAccount());
            mmCapturePageModel.processIsValidAccInFromDropDown(transaction.getToAccount(), envProperties.get("currencyCode"));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeMessageText(transaction));
            mmCapturePageModel.clickContinueButton();
            Reporter.log("iETransferLCY2LCYNow test passed.");
        } catch (Exception e) {
            IETransfer.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }

    }

    @Test(groups = {"functionaltest", "regressiontest", "smoketest"}, enabled = true)
    @Parameters("browser")
    public void editLCY2LCYNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonIELCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processIsValidAccInFromDropDown(transaction.getToAccount(), envProperties.get("currencyCode"));
            mmCapturePageModel.enterTransferAmount(transaction);
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeMessageText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.clickEditDetailsButton();
            mmCapturePageModel.selectFromAccountByAccountDetail(transaction.getFromAccount());
            mmCapturePageModel.processIsValidAccInFromDropDown(transaction.getToAccount(), envProperties.get("currencyCode"));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            mmCapturePageModel.enterTransferAmount(transaction);
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeMessageText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyPageTitle();
            mmCapturePageModel.verfiyConfirmButton();
            mmCapturePageModel.verfiyCancelButton();
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickCancelOnPrintDialog();

            Reporter.log("editLCY2LCYNowTransaction test passed");
        } catch (Exception e) {
            IETransfer.logger.error(e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);

        }
    }

    @Test(groups = {"functionaltest", "regressiontest", "smoketest"}, enabled = true)
    @Parameters("browser")
    public void verifyIeTransferList() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonLCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToMyAccount();
            navigate.clickDashboardMMButton();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processIsValidAccInFromDropDown(transaction.getToAccount(), envProperties.get("currencyCode"));
            mmCapturePageModel.enterTransferAmount(transaction);
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeMessageText(transaction));
            mmCapturePageModel.enterPayeeMessageTextSpecialchar();
            mmCapturePageModel.VerfiyErrormsg();
            mmVerifyPageModel.verfiyInteractLogoCapturepage();
            mmVerifyPageModel.verfiyFeeBodyInputpage();
            mmVerifyPageModel.copytextInputpage();
            mmVerifyPageModel.verfiyCapctureBrandingTradeMark();
            mmCapturePageModel.clickContinueButton();
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeMessageText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyPageTitle();
            mmVerifyPageModel.verfiyFeeBodyVerifypage();
            mmVerifyPageModel.copytextVerifypage();
            mmVerifyPageModel.verfiypageBrandingTradeMark();
            mmVerifyPageModel.verfiyInteractLogoVerfiypage();
            mmVerifyPageModel.clickConfirmButton();
            mmVerifyPageModel.verfiyFeeBodyConfirmationpage();
            mmVerifyPageModel.copytextConfimationypage();
            mmVerifyPageModel.verfiyInteractLogoConfirmation();
            mmVerifyPageModel.clickMyAccountButton();
            mmVerifyPageModel.verifyMyAccountpage();
            Reporter.log("verifyIeTransferList test passed..");

        } catch (Exception e) {
            IETransfer.logger.error(e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);

        }
    }

    @Test(groups = {"functionaltest", "regressiontest", "smoketest"}, enabled = true)
    @Parameters("browser")
    public void iETransferLCY2LCYNowTransactionPrintConfirmation() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addPayeeModel.domesticHSBCPersonIELCYPayees(envProperties.get("currencyCode")));
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.processIsValidAccInFromDropDown(transaction.getToAccount(), envProperties.get("currencyCode"));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setPayeeReference(mmCapturePageModel.enterPayeeMessageText(transaction));
            transaction.setToAccount(mmCapturePageModel.updatePayeeInformation(transaction.getToAccount()));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYNowIETransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2LCYNowIETransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.clickPrintButton();
            mmConfirmPageModel.verifyPrintPageTitle();
            mmConfirmPageModel.clickPrintOnPrintDialog();
            Reporter.log("printConfirmation test passed");
        } catch (Exception e) {
            IETransfer.logger.error(e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is to validate Cancel & confirm Delete Payee Flow
     */
    @Test(groups = {"functionaltest", "regressiontest", "smoketest"}, enabled = true)
    @Parameters("browser")
    public void deletePayeeFlow() {
        try {
            navigate.navigateToMypayeesPage();
            addPayeeModel.cancelDeletePayee(addPayeeModel.selectPayee());
            addPayeeModel.deletePayee(addPayeeModel.selectPayee());

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
            ManageBeneficiary.logger.error("Exception:", e);
        }
    }

    /**
     * Test Case is to verify Payee details on clicking View button Also checks
     * the Close button functionality on selected Payee details pane
     * 
     */

    @Test(groups = {"functionaltest", "regressiontest", "smoketest"}, enabled = true)
    @Parameters("browser")
    public void viewPayeeDetails() {
        try {
            navigate.navigateToMypayeesPage();
            addPayeeModel.verifyPayeeDetails(addPayeeModel.selectPayee());
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
            ManageBeneficiary.logger.error("Exception:", e);
        }
    }


}
