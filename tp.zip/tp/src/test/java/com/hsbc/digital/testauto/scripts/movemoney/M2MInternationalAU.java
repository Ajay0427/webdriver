/**
 *
 */
package com.hsbc.digital.testauto.scripts.movemoney;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.models.TransactionFlow;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModelNew;
import com.hsbc.digital.testauto.pageobject.MoveMoneyConfirmPageModelNew;
import com.hsbc.digital.testauto.pageobject.MoveMoneyVerifyPageModelNew;


/**
 * <p>
 * <b> This class is holding Test Case and functionality for M2MInternatinal
 * </b>
 * </p>
 * 
 * @author Shashikant
 * @version 1.0.0
 */
public class M2MInternationalAU {
    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    FlyerMenuNavigationModel navigate;
    MoveMoneyCapturePageModelNew mmCapturePageModel;
    MoveMoneyVerifyPageModelNew mmVerifyPageModel;
    MoveMoneyConfirmPageModelNew mmConfirmPageModel;
    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(M2MInternationalAU.class);


    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method testMethod) {
        browserLib = new BrowserLib(browser);
        driver = browserLib.getDriver();
        envProperties = FileUtil.getConfigProperties(entity);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        try {
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            navigate = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", driver);
            mmCapturePageModel = (MoveMoneyCapturePageModelNew) ReflectionUtil.getEntityPOM(entity, "MoveMoneyCapturePageAU",
                driver);
            mmVerifyPageModel = (MoveMoneyVerifyPageModelNew) ReflectionUtil.getEntityPOM(entity, "MoveMoneyVerifyPageAU", driver);
            mmConfirmPageModel = (MoveMoneyConfirmPageModelNew) ReflectionUtil.getEntityPOM(entity, "MoveMoneyConfirmPageAU",
                driver);
            String profile = XMLUtil.getProfileName(testMethod, entity);
            loginModel.login(profile, envProperties);
            loginModel.switchLanguage("English");
        } catch (Exception e) {
            M2MInternationalAU.logger.error("Exception thrown at Login Contructor:", e);
        }
    }


    // Created by cbh team
    @Test(groups = {"functionaltest", "regressiontest", "smoketest"}, enabled = true)
    @Parameters("browser")
    public void m2mFCYToFCYNow() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            M2MInternationalAU.logger.info("Navigated to New transaction page");
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("countryName")));
            transaction.setToAccount(mmCapturePageModel.selectInternationalToFCYAccount(envProperties.get("countryName")));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.selectReasonForTransaction(transaction);
            mmCapturePageModel.clickTermsAndConditionsCheckBox();
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2MInternationalFCY2FCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2MInternationalFCY2FCYNowTransactionDetailsOnConfirmPage(transaction);
        } catch (Exception e) {
            M2MInternationalAU.logger.error("exception thrown:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    // Created by cbh team
    @Test(groups = {"functionaltest", "regressiontest", "smoketest"})
    @Parameters("browser")
    public void m2mFCYToFCYLater() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("countryName")));
            transaction.setToAccount(mmCapturePageModel.selectInternationalToFCYAccount(envProperties.get("countryName")));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.selectReasonForTransaction(transaction);
            mmCapturePageModel.clickTermsAndConditionsCheckBox();
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2MInternationalFCY2FCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2MInternationalFCY2FCYLaterTransactionDetailsOnConfirmPage(transaction);
        } catch (Exception e) {
            M2MDomestic.logger.error("exception thrown:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
        }
    }

    // Created by cbh team
    @Test(groups = {"functionaltest", "regressiontest", "smoketest"})
    @Parameters("browser")
    public void m2mFCYToFCYRecurringNumberOfPayment() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            M2MInternationalAU.logger.info("Navigated to New transaction page");
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("countryName")));
            transaction.setToAccount(mmCapturePageModel.selectInternationalToFCYAccount(envProperties.get("countryName")));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.selectReasonForTransaction(transaction);
            mmCapturePageModel.clickTermsAndConditionsCheckBox();
            mmCapturePageModel.clickRecurringTab();
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2MInternationalFCY2FCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2MFCY2FCYInternationalRecurringTransactionDetailsOnConfirmPage(transaction);

        } catch (Exception e) {
            M2MDomestic.logger.error("Exception thrown:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
        }
    }
}
