/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.accountopening;

import java.lang.reflect.Method;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.models.OpenAccountDetails;
import com.hsbc.digital.testauto.pageobject.FATCAModel;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LandingPageModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.OpenAccountConfirmPersonalDetailsModel;
import com.hsbc.digital.testauto.pageobject.OpenAccountConfirmationModel;
import com.hsbc.digital.testauto.pageobject.OpenAccountOptionsModel;
import com.hsbc.digital.testauto.pageobject.OpenAccountProductDetailsModel;
import com.hsbc.digital.testauto.pageobject.OpenAccountVerifyModel;
import com.hsbc.digital.testauto.pageobject.UpdatePersonelInformationModel;

/**
 * <p>
 * <b> This class will hold testing scripts for story 5n6 Apply open TD account
 * </b>
 * </p>
 * 
 * @version 1.0.0
 * @author SatyaPrakash S Vyas
 * 
 */
public class ApplyOpenAccount {

    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    Map<String, String> profileProperties;
    LoginModel loginModel;
    FlyerMenuNavigationModel navigationModel;
    OpenAccountProductDetailsModel productDetailsModel;
    OpenAccountConfirmPersonalDetailsModel confirmPersonalDetailsModel;
    OpenAccountOptionsModel optionsModel;
    FATCAModel fatcaModel;
    OpenAccountVerifyModel verifyModel;
    OpenAccountConfirmationModel confirmModel;
    LandingPageModel landingPageModel;
    UpdatePersonelInformationModel objUpdatePersonelInformation;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(ApplyOpenAccount.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method method) {
        try {
            browserLib = new BrowserLib(browser);
            driver = browserLib.getDriver();
            envProperties = FileUtil.getConfigProperties(entity);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            navigationModel = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", driver);
            productDetailsModel = (OpenAccountProductDetailsModel) ReflectionUtil.getEntityPOM(entity, "OpenAccountProductDetails",
                driver);
            confirmPersonalDetailsModel = (OpenAccountConfirmPersonalDetailsModel) ReflectionUtil.getEntityPOM(entity,
                "OpenAccountConfirmPersonalDetails", driver);
            optionsModel = (OpenAccountOptionsModel) ReflectionUtil.getEntityPOM(entity, "OpenAccountOptions", driver);
            fatcaModel = (FATCAModel) ReflectionUtil.getEntityPOM(entity, "FATCAPage", driver);
            verifyModel = (OpenAccountVerifyModel) ReflectionUtil.getEntityPOM(entity, "OpenAccountVerify", driver);
            confirmModel = (OpenAccountConfirmationModel) ReflectionUtil.getEntityPOM(entity, "OpenAccountConfirmation", driver);
            landingPageModel = (LandingPageModel) ReflectionUtil.getEntityPOM(entity, "LandingPage", driver);
            objUpdatePersonelInformation = (UpdatePersonelInformationModel) ReflectionUtil.getEntityPOM(entity,
                "UpdatePersonelInformation", driver);
            String profile = XMLUtil.getProfileName(method, entity);
            profileProperties = FileUtil.getTestDataProperties(envProperties.get("countryCode"), profile);
            loginModel.login(profile, envProperties);
            loginModel.switchLanguage("English");

        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
            logger.error("Exception thrown before method:", e);
        } catch (Exception e) {
            logger.error("Exception thrown at before method:", e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow")
    public void applyOpenTDAccount() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickFindOutMoreButton();
            productDetailsModel.clickApplyOnOpenTDPage();
            confirmPersonalDetailsModel.submitDetails();
            optionsModel.applyOpenTDAccountFillOptions(openAccount, profileProperties);
            fatcaModel.fillCitizenshipPage(false);
            openAccount.setIsTermInMonths(true);
            verifyModel.openTDProductVerifyPage(openAccount, envProperties);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow US Dollar TD")
    public void applyOpenUSTermDepositAccount() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickApplyNowOfUSDollarTD();
            confirmPersonalDetailsModel.submitDetails();
            openAccount.setTypeOfProduct(OpenAccountOptionsModel.US_TD);
            optionsModel.applyOpenTDAccountFillOptions(openAccount, profileProperties);
            fatcaModel.fillCitizenshipPage(false);
            openAccount.setIsTermInMonths(false);
            verifyModel.openUSTermDepositVerifyPage(openAccount, envProperties);
            confirmModel.openUSTermDepositConfirmationPage(openAccount);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow Non Redeemable Simple Interest GIC Account")
    public void applyOpenNonRedeemableSimpleInterestGICAccount() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickGICTab();
            productDetailsModel.clickOpenNonRedeemableSimpleInterestGIC();
            confirmPersonalDetailsModel.submitDetails();
            openAccount.setTypeOfProduct(OpenAccountOptionsModel.GIC_SIMPLE_INTEREST);
            optionsModel.openGICProductFillOptions(openAccount, profileProperties);
            openAccount.setIsTermInMonths(true);
            verifyModel.openAccountVerifyPage(openAccount, envProperties);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow Non Redeemable Compounded Interest GIC Account")
    public void applyOpenNonRedeemableCompoundedInterestGICAccount() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickGICTab();
            productDetailsModel.clickOpenNonRedeemableCompoundedInterestGIC();
            confirmPersonalDetailsModel.submitDetails();
            optionsModel.openGICProductFillOptions(openAccount, profileProperties);
            openAccount.setIsTermInMonths(true);
            verifyModel.openAccountVerifyPage(openAccount, envProperties);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow Redeemable GIC Account")
    public void applyOpenRedeemableGICAccount() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickGICTab();
            productDetailsModel.clickOpenRedeemableGIC();
            confirmPersonalDetailsModel.submitDetails();
            optionsModel.openGICProductFillOptions(openAccount, profileProperties);
            openAccount.setIsTermInMonths(true);
            verifyModel.openAccountVerifyPage(openAccount, envProperties);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow TFSA High Rate Saving")
    public void applyOpenTFSAHighRateSavingAccount() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToTFSA();
            productDetailsModel.clickApplyNowTFSASaving();
            confirmPersonalDetailsModel.submitDetails();
            optionsModel.applyOpenSavingsAccountFillOptions(openAccount, profileProperties, null);
            openAccount.setIsTermInMonths(false);
            verifyModel.openAccountVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, null);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow TFSA High Rate Saving")
    public void applyOpenTFSARedeemableGICAccount() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToTFSA();
            productDetailsModel.clickApplyNowTFSARedeemableGIC();
            confirmPersonalDetailsModel.submitDetails();
            optionsModel.openGICProductFillOptions(openAccount, profileProperties);
            openAccount.setIsTermInMonths(true);
            verifyModel.openAccountVerifyPage(openAccount, envProperties);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow TFSA High Rate Saving")
    public void applyOpenTFSAeTermAccount() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToTFSA();
            productDetailsModel.clickApplyNowTFSAeTerm();
            confirmPersonalDetailsModel.submitDetails();
            openAccount.setTypeOfProduct(OpenAccountOptionsModel.TFSA_TD);
            optionsModel.applyOpenTDAccountFillOptions(openAccount, profileProperties);
            openAccount.setIsTermInMonths(false);
            verifyModel.openAccountVerifyPage(openAccount, envProperties);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow High Rate Saving")
    public void applyOpenHighRateSaving() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToEverydayBanking();
            productDetailsModel.clickOpenHighRateSaving();
            confirmPersonalDetailsModel.submitDetails();
            optionsModel.applyOpenSavingsAccountFillOptions(openAccount, profileProperties, null);
            fatcaModel.fillCitizenshipPage(false);
            openAccount.setIsTermInMonths(false);
            verifyModel.openAccountVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow Foreign currency High Rate Saving")
    public void applyOpenForeignCurrencyHighRateSaving() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToEverydayBanking();
            productDetailsModel.clickForeignCurrencySavingTab();
            productDetailsModel.clickOpenForeignCurrencyHighRateSaving();
            confirmPersonalDetailsModel.submitDetails();
            optionsModel.applyOpenSavingsAccountFillOptions(openAccount, profileProperties,
                OpenAccountOptionsModel.FOREIGN_CURRENCY);
            fatcaModel.fillCitizenshipPage(false);
            openAccount.setIsTermInMonths(false);
            verifyModel.openAccountVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow Foreign currency High Rate Saving")
    public void applyOpenForeignCurrencyRegularSaving() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToEverydayBanking();
            productDetailsModel.clickForeignCurrencySavingTab();
            productDetailsModel.clickOpenForeignCurrencyRegularSaving();
            confirmPersonalDetailsModel.submitDetails();
            optionsModel.applyOpenSavingsAccountFillOptions(openAccount, profileProperties,
                OpenAccountOptionsModel.FOREIGN_CURRENCY);
            fatcaModel.fillCitizenshipPage(false);
            openAccount.setIsTermInMonths(false);
            verifyModel.openAccountVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void applyOpenAccountConfirmPersonalDetailsPageEdit() {
        try {
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickFindOutMoreButton();
            productDetailsModel.clickApplyOnOpenTDPage();
            confirmPersonalDetailsModel.clickEditDetailsButton(false);
            confirmPersonalDetailsModel.clickEditDetailsButton(true);
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void applyOpenAccountConfirmPersonalDetailsPageCancel() {
        try {
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickFindOutMoreButton();
            productDetailsModel.clickApplyOnOpenTDPage();
            confirmPersonalDetailsModel.clickCancelButton(false);
            confirmPersonalDetailsModel.clickCancelButton(true);

        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void applyOpenAccountOptionsPageCancel() {
        try {
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickFindOutMoreButton();
            productDetailsModel.clickApplyOnOpenTDPage();
            confirmPersonalDetailsModel.submitDetails();
            optionsModel.clickCancelButton(false);
            optionsModel.clickCancelButton(true);

        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void applyOpenAccountVerifyPageEdit() {
        try {
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickFindOutMoreButton();
            productDetailsModel.clickApplyOnOpenTDPage();
            confirmPersonalDetailsModel.submitDetails();
            optionsModel.fillOptions(profileProperties);
            optionsModel.clickContinueButton();
            verifyModel.clickEditDetailsButton();

        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void applyOpenAccountVerifyPageCancel() {
        try {
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickFindOutMoreButton();
            productDetailsModel.clickApplyOnOpenTDPage();
            confirmPersonalDetailsModel.submitDetails();
            optionsModel.fillOptions(profileProperties);
            optionsModel.clickContinueButton();
            verifyModel.clickCancelButton(false);
            verifyModel.clickCancelButton(true);
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /* Below methods are for Mexico entity */

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow for Pagare Moneda Nacional Product")
    public void openPagareMonedaNacionalProduct() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickApplyPagareMonedaNacional();
            openAccount.setProduct(OpenAccountOptionsModel.PAGARE_MONEDA_NACIONAL);
            openAccount.setIsNewInvestmentAcct(true);
            optionsModel.productsWithInputTermOptionsPage(openAccount, envProperties);
            verifyModel.openTDProductVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow for Inversion Express Product")
    public void openInversionExpressProduct() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickApplyInversionExpress();
            openAccount.setProduct(OpenAccountOptionsModel.INVERSION_EXPRESS);
            openAccount.setIsNewInvestmentAcct(true);
            optionsModel.productsWithInputTermOptionsPage(openAccount, envProperties);
            verifyModel.openTDProductVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow for CEDE Tasa Fija Product in LessThan50000Dollar tab")
    public void openCEDETasaFijaProductLessThan50000Dollar() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickLessThan50000DollarTab();
            productDetailsModel.clickApplyCEDETasaFija();
            openAccount.setProduct(OpenAccountOptionsModel.CEDE_TASA_FIJA);
            openAccount.setIsNewInvestmentAcct(true);
            optionsModel.cEDETasaProductsOptionsPage(openAccount, envProperties);
            verifyModel.openTDProductVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow for Pagare Moneda Nacional Product in LessThan50000Dollar tab")
    public void openPagareMonedaNacionalProductLessThan50000Dollar() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickLessThan50000DollarTab();
            productDetailsModel.clickApplyPagareMonedaNacional();
            openAccount.setProduct(OpenAccountOptionsModel.PAGARE_MONEDA_NACIONAL);
            openAccount.setIsNewInvestmentAcct(true);
            optionsModel.productsWithInputTermOptionsPage(openAccount, envProperties);
            verifyModel.openTDProductVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow for Inversion Express Product in LessThan50000Dollar tab")
    public void openInversionExpressProductLessThan50000Dollar() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickLessThan50000DollarTab();
            productDetailsModel.clickApplyInversionExpress();
            openAccount.setProduct(OpenAccountOptionsModel.INVERSION_EXPRESS);
            openAccount.setIsNewInvestmentAcct(true);
            optionsModel.productsWithInputTermOptionsPage(openAccount, envProperties);
            verifyModel.openTDProductVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow for CEDE Tasa Variable CETE Product in MoreThan50000Dollar tab")
    public void openCEDETasaVariableCETEProductMoreThan50000Dollar() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickMoreThan50000DollarTab();
            productDetailsModel.clickApplyCEDETasaVariableCETE();
            openAccount.setProduct(OpenAccountOptionsModel.CEDE_TASA_VARIABLE_CETE);
            openAccount.setIsNewInvestmentAcct(true);
            optionsModel.cEDETasaProductsOptionsPage(openAccount, envProperties);
            verifyModel.openTDProductVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow for CEDE Tasa Variable TIIE Product in MoreThan50000Dollar tab")
    public void openCEDETasaVariableTIIEProductMoreThan50000Dollar() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickMoreThan50000DollarTab();
            productDetailsModel.clickApplyCEDETasaVariableTIIE();
            openAccount.setProduct(OpenAccountOptionsModel.CEDE_TASA_VARIABLE_TIIE);
            openAccount.setIsNewInvestmentAcct(true);
            optionsModel.cEDETasaProductsOptionsPage(openAccount, envProperties);
            verifyModel.openTDProductVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow for CEDE Tasa Fija Product in MoreThan50000Dollar tab")
    public void openCEDETasaFijaProductMoreThan50000Dollar() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickMoreThan50000DollarTab();
            productDetailsModel.clickApplyCEDETasaFija();
            openAccount.setProduct(OpenAccountOptionsModel.CEDE_TASA_FIJA);
            openAccount.setIsNewInvestmentAcct(true);
            optionsModel.cEDETasaProductsOptionsPage(openAccount, envProperties);
            verifyModel.openTDProductVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow for Pagare Moneda Nacional Product in MoreThan50000Dollar tab")
    public void openPagareMonedaNacionalProductMoreThan50000Dollar() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickMoreThan50000DollarTab();
            productDetailsModel.clickApplyPagareMonedaNacional();
            openAccount.setProduct(OpenAccountOptionsModel.PAGARE_MONEDA_NACIONAL);
            openAccount.setIsNewInvestmentAcct(true);
            optionsModel.productsWithInputTermOptionsPage(openAccount, envProperties);
            verifyModel.openTDProductVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow for Inversion Express Product in MoreThan50000Dollar tab")
    public void openInversionExpressProductMoreThan50000Dollar() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickMoreThan50000DollarTab();
            productDetailsModel.clickApplyInversionExpress();
            openAccount.setProduct(OpenAccountOptionsModel.INVERSION_EXPRESS);
            openAccount.setIsNewInvestmentAcct(true);
            optionsModel.productsWithInputTermOptionsPage(openAccount, envProperties);
            verifyModel.openTDProductVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow for Pagare Moneda Nacional Product With Existing Investment Account")
    public void openPagareMonedaNacionalProductWithExistingInvestmentAccount() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickApplyPagareMonedaNacional();
            openAccount.setProduct(OpenAccountOptionsModel.PAGARE_MONEDA_NACIONAL);
            openAccount.setIsNewInvestmentAcct(false);
            optionsModel.productsWithInputTermOptionsPage(openAccount, envProperties);
            verifyModel.openTDProductVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow for Inversion Express Product With Existing Investment Account")
    public void openInversionExpressProductWithExistingInvestmentAccount() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickApplyInversionExpress();
            openAccount.setProduct(OpenAccountOptionsModel.INVERSION_EXPRESS);
            openAccount.setIsNewInvestmentAcct(false);
            optionsModel.productsWithInputTermOptionsPage(openAccount, envProperties);
            verifyModel.openTDProductVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow for CEDE Tasa Fija Product in LessThan50000Dollar tab With Existing Investment Account")
    public void openCEDETasaFijaProductLessThan50000DollarWithExistingInvestmentAccount() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickLessThan50000DollarTab();
            productDetailsModel.clickApplyCEDETasaFija();
            openAccount.setProduct(OpenAccountOptionsModel.CEDE_TASA_FIJA);
            openAccount.setIsNewInvestmentAcct(false);
            optionsModel.cEDETasaProductsOptionsPage(openAccount, envProperties);
            verifyModel.openTDProductVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow for Pagare Moneda Nacional Product in LessThan50000Dollar tab With Existing Investment Account")
    public void openPagareMonedaNacionalProductLessThan50000DollarWithExistingInvestmentAccount() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickLessThan50000DollarTab();
            productDetailsModel.clickApplyPagareMonedaNacional();
            openAccount.setProduct(OpenAccountOptionsModel.PAGARE_MONEDA_NACIONAL);
            openAccount.setIsNewInvestmentAcct(false);
            optionsModel.productsWithInputTermOptionsPage(openAccount, envProperties);
            verifyModel.openTDProductVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow for Inversion Express Product in LessThan50000Dollar tab With Existing Investment Account")
    public void openInversionExpressProductLessThan50000DollarWithExistingInvestmentAccount() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickLessThan50000DollarTab();
            productDetailsModel.clickApplyInversionExpress();
            openAccount.setProduct(OpenAccountOptionsModel.INVERSION_EXPRESS);
            openAccount.setIsNewInvestmentAcct(false);
            optionsModel.productsWithInputTermOptionsPage(openAccount, envProperties);
            verifyModel.openTDProductVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow for CEDE Tasa Variable CETE Product in MoreThan50000Dollar tab With Existing Investment Account")
    public void openCEDETasaVariableCETEProductMoreThan50000DollarWithExistingInvestmentAccount() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickMoreThan50000DollarTab();
            productDetailsModel.clickApplyCEDETasaVariableCETE();
            openAccount.setProduct(OpenAccountOptionsModel.CEDE_TASA_VARIABLE_CETE);
            openAccount.setIsNewInvestmentAcct(false);
            optionsModel.cEDETasaProductsOptionsPage(openAccount, envProperties);
            verifyModel.openTDProductVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow for CEDE Tasa Variable TIIE Product in MoreThan50000Dollar tab With Existing Investment Account")
    public void openCEDETasaVariableTIIEProductMoreThan50000DollarWithExistingInvestmentAccount() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickMoreThan50000DollarTab();
            productDetailsModel.clickApplyCEDETasaVariableTIIE();
            openAccount.setProduct(OpenAccountOptionsModel.CEDE_TASA_VARIABLE_TIIE);
            openAccount.setIsNewInvestmentAcct(false);
            optionsModel.cEDETasaProductsOptionsPage(openAccount, envProperties);
            verifyModel.openTDProductVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow for CEDE Tasa Fija Product in MoreThan50000Dollar tab With Existing Investment Account")
    public void openCEDETasaFijaProductMoreThan50000DollarWithExistingInvestmentAccount() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickMoreThan50000DollarTab();
            productDetailsModel.clickApplyCEDETasaFija();
            openAccount.setProduct(OpenAccountOptionsModel.CEDE_TASA_FIJA);
            openAccount.setIsNewInvestmentAcct(false);
            optionsModel.cEDETasaProductsOptionsPage(openAccount, envProperties);
            verifyModel.openTDProductVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow for Pagare Moneda Nacional Product in MoreThan50000Dollar tab With Existing Investment Account")
    public void openPagareMonedaNacionalProductMoreThan50000DollarWithExistingInvestmentAccount() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickMoreThan50000DollarTab();
            productDetailsModel.clickApplyPagareMonedaNacional();
            openAccount.setProduct(OpenAccountOptionsModel.PAGARE_MONEDA_NACIONAL);
            openAccount.setIsNewInvestmentAcct(false);
            optionsModel.productsWithInputTermOptionsPage(openAccount, envProperties);
            verifyModel.openTDProductVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-End flow for Inversion Express Product in MoreThan50000Dollar tab With Existing Investment Account")
    public void openInversionExpressProductMoreThan50000DollarWithExistingInvestmentAccount() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickMoreThan50000DollarTab();
            productDetailsModel.clickApplyInversionExpress();
            openAccount.setProduct(OpenAccountOptionsModel.INVERSION_EXPRESS);
            openAccount.setIsNewInvestmentAcct(false);
            optionsModel.productsWithInputTermOptionsPage(openAccount, envProperties);
            verifyModel.openTDProductVerifyPage(openAccount, null);
            confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
            landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /* TODO: To confirm whether to take this scenario or not 
     * @Test(groups = {"functionaltest"}, testName = "Verify unsuccessful Journey for accounts creation when total accounts limits exceed to max Limit")
     public void unsuccessfulJourneyForMaxLimitOnAccounts() {
         try {
             OpenAccountDetails openAccount = new OpenAccountDetails();
             int totalAccounts = landingPageModel.getAccountListSize();
             while (totalAccounts <= 89) {
                 navigationModel.navigateToApplyOpenNewTD();
                 productDetailsModel.clickApplyPagareMonedaNacional();
                 openAccount.setProduct(OpenAccountOptionsModel.PAGARE_MONEDA_NACIONAL);
                 openAccount.setIsNewInvestmentAcct(false);
                 optionsModel.productsWithInputTermOptionsPage(openAccount, envProperties);
                 verifyModel.openTDProductVerifyPage(openAccount, null);
                 confirmModel.applyOpenAccountConfirmationPage(openAccount, envProperties);
                 landingPageModel.validateNewAccount(openAccount.getNewAccountNumber());
                 if ((totalAccounts + 1) == landingPageModel.getAccountListSize()) {
                     totalAccounts++;
                 } else {
                     Assert.fail("Accounts not increased.");
                 }
             }
         } catch (Exception e) {
             logger.error("Exception: ", e);
             Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
         }
     }*/

    @Test(groups = {"functionaltest"})
    public void openAccountOptionsPageCancelMexico() {
        try {
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickApplyButtonForRandomProduct();
            optionsModel.clickCancelButton(false);
            optionsModel.clickCancelButton(true);
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void openAccountOptionsPageMaturityDateErrorMexico() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            productDetailsModel.clickApplyPagareMonedaNacional();
            openAccount.setProduct(OpenAccountOptionsModel.PAGARE_MONEDA_NACIONAL);
            optionsModel.validateMaturityErrorForHoliday(openAccount, envProperties, profileProperties);
            optionsModel.validateMaturityErrorForWeekend();
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void openAccountVerifyPageEditMexico() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            int productNumber = productDetailsModel.clickApplyButtonForRandomProduct();
            optionsModel.setProductToPOJO(openAccount, productNumber);
            optionsModel.productsWithInputTermOptionsPage(openAccount, envProperties);
            verifyModel.verifyTitle();
            verifyModel.clickEditDetailsButton();
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void openAccountVerifyPageCancelMexico() {
        try {
            OpenAccountDetails openAccount = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewTD();
            int productNumber = productDetailsModel.clickApplyButtonForRandomProduct();
            optionsModel.setProductToPOJO(openAccount, productNumber);
            optionsModel.productsWithInputTermOptionsPage(openAccount, envProperties);
            verifyModel.verifyTitle();
            verifyModel.clickCancelButton(false);
            verifyModel.clickCancelButton(true);
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Below Scenarios are applicable only for cbh entity
     */

    @Test(groups = {"functionaltest"})
    public void openSavingAccountForCBH() {
        try {
            OpenAccountDetails objOpenAccountDetails = new OpenAccountDetails();
            navigationModel.navigateToApplyOpenNewSaving();
            productDetailsModel.clickFindOutMoreButtonForSavingAccount();
            productDetailsModel.clickApplyOnOpenTDPage();
            confirmPersonalDetailsModel.confirmPersonalDetails();
            objOpenAccountDetails = optionsModel.captureDetailsForSavingOnOptionPage(profileProperties);
            verifyModel.verifyReviewPageForSaving(objOpenAccountDetails);
            objOpenAccountDetails = confirmModel.verifyConfirmationPage();
            landingPageModel.verifyCreatedAccontOnDashboard(objOpenAccountDetails);
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void openTermDepositAccountForCBH() {
        try {
            OpenAccountDetails objOpenAccountDetails = new OpenAccountDetails();
            navigationModel.navigateToApplyTermDepositAccount();
            productDetailsModel.clickFindOutMoreButton();
            productDetailsModel.clickApplyOnOpenTDPage();
            confirmPersonalDetailsModel.confirmPersonalDetails();
            objOpenAccountDetails = optionsModel.captureDetailsForTermDepositOnOptionPage(profileProperties);
            verifyModel.verifyReviewPageForTermDeposit(objOpenAccountDetails);
            objOpenAccountDetails = confirmModel.verifyConfirmationPageForTermDeposit();
            landingPageModel.verifyCreatedAccontOnDashboard(objOpenAccountDetails);
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void openCurrentAccountForCBH() {
        try {
            OpenAccountDetails objOpenAccountDetails = new OpenAccountDetails();
            navigationModel.navigateToApplyCurentAccount();
            productDetailsModel.clickFindOutMoreButtonForCurrentAccount();
            productDetailsModel.clickApplyOnOpenTDPage();
            confirmPersonalDetailsModel.confirmPersonalDetails();
            objOpenAccountDetails = optionsModel.captureDetailsForSavingOnOptionPage(profileProperties);
            verifyModel.verifyReviewPageForTermDeposit(objOpenAccountDetails);
            objOpenAccountDetails = confirmModel.verifyConfirmationPage();
            landingPageModel.verifyCreatedAccontOnDashboard(objOpenAccountDetails);
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void cancelFlowfromPersonalDetailsPage() {
        try {

            navigationModel.navigateToApplyOpenNewSaving();
            productDetailsModel.clickFindOutMoreButtonForSavingAccount();
            productDetailsModel.clickApplyOnOpenTDPage();
            confirmPersonalDetailsModel.clickCancelButton(true);

        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void cancelFlowfromPersonalOptionPage() {
        try {

            navigationModel.navigateToApplyOpenNewSaving();
            productDetailsModel.clickFindOutMoreButtonForSavingAccount();
            productDetailsModel.clickApplyOnOpenTDPage();
            confirmPersonalDetailsModel.confirmPersonalDetails();
            confirmPersonalDetailsModel.clickCancelButton(true);

        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void cancelFlowfromPersonalVerifyPage() {
        try {

            navigationModel.navigateToApplyOpenNewSaving();
            productDetailsModel.clickFindOutMoreButtonForSavingAccount();
            productDetailsModel.clickApplyOnOpenTDPage();
            confirmPersonalDetailsModel.confirmPersonalDetails();
            optionsModel.captureDetailsForSavingOnOptionPage(profileProperties);
            verifyModel.cancelFlowFromVerify();

        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void editDetailsButtonFunctionalityVerifyPage() {
        try {

            navigationModel.navigateToApplyOpenNewSaving();
            productDetailsModel.clickFindOutMoreButtonForSavingAccount();
            productDetailsModel.clickApplyOnOpenTDPage();
            confirmPersonalDetailsModel.confirmPersonalDetails();
            optionsModel.captureDetailsForSavingOnOptionPage(profileProperties);
            verifyModel.clickEditDetailsButton();

        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void printButtonFunctionality() {
        try {
            navigationModel.navigateToApplyOpenNewSaving();
            productDetailsModel.clickFindOutMoreButtonForSavingAccount();
            productDetailsModel.clickApplyOnOpenTDPage();
            confirmPersonalDetailsModel.confirmPersonalDetails();
            optionsModel.captureDetailsForSavingOnOptionPage(profileProperties);
            verifyModel.clicksConfirmButton();
            verifyModel.selectTermAndConditionVerifyPage();
            verifyModel.clicksConfirmButton();
            confirmModel.verifyPrintButtonFunctionality();
        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void editPersonalDetailButtonFunctionality() {
        try {
            navigationModel.navigateToApplyOpenNewSaving();
            productDetailsModel.clickFindOutMoreButtonForSavingAccount();
            productDetailsModel.clickApplyOnOpenTDPage();
            confirmPersonalDetailsModel.verifyeditDetailsFunctionality();
            objUpdatePersonelInformation.verifyEditDetailsFunctionality();

        } catch (Exception e) {
            logger.error("Exception: ", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterMethod() {
        browserLib.closeAllBrowsers();
    }

    /**
     * 
     * <p>
     * <b> This method is used to take screen shot so every test script should
     * have it as it is used by Framework internally. </b>
     * </p>
     * 
     * @return driver
     */
    public WebDriver getDriver() {
        return driver;
    }
}
